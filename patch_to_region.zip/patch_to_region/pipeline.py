"""
Patch-to-Region Pipeline

End-to-end pipeline that orchestrates:
1. ColPali model loading
2. Interpretability map generation (query token ↔ patch similarity)
3. MaxSim patch score aggregation
4. IoU-weighted propagation to OCR regions
5. Threshold-based region filtering

This is the main user-facing module.

Usage:
    from pipeline import PatchToRegionPipeline

    pipeline = PatchToRegionPipeline(model_id="ModernVBERT/colmodernvbert-merged")
    pipeline.load_model()

    result = pipeline.run(
        query="total revenue",
        image=page_image,
        ocr_regions=[
            {"content": "Total Revenue: $1.2M", "bbox": [512, 768, 1024, 896], "label": "table_cell"},
            {"content": "Net Income: $300K", "bbox": [512, 896, 1024, 1024], "label": "table_cell"},
        ],
        threshold=0.3,
    )

    for region in result.regions:
        print(f"[{region.relevance_score:.3f}] {region.text}")
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from PIL import Image

from colpali_interface import ColPaliModel
from patch_to_region import (
    BBox,
    OCRRegion,
    RegionFilterResult,
    TokenSimilarityMap,
    compute_patch_scores,
    filter_regions,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclass
class PipelineConfig:
    """Configuration for the patch-to-region pipeline."""

    # Model settings
    model_id: str = "ModernVBERT/colmodernvbert-merged"
    device: Optional[str] = None  # auto-detect if None
    torch_dtype: Optional[str] = None  # auto-select if None

    # Region filtering settings
    threshold: float = 0.3
    top_k: Optional[int] = None  # None = all above threshold
    aggregation: str = "iou_weighted"  # "iou_weighted" | "max" | "mean"


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------

class PatchToRegionPipeline:
    """End-to-end patch-to-region relevance propagation pipeline."""

    def __init__(self, config: Optional[PipelineConfig] = None):
        self.config = config or PipelineConfig()
        self._model: Optional[ColPaliModel] = None

    def load_model(self) -> None:
        """Load the ColPali model. Must be called before run()."""
        import torch

        dtype = None
        if self.config.torch_dtype:
            dtype = getattr(torch, self.config.torch_dtype)

        self._model = ColPaliModel(
            model_id=self.config.model_id,
            device=self.config.device,
            torch_dtype=dtype,
        )
        self._model.load()

    @property
    def model(self) -> ColPaliModel:
        if self._model is None:
            raise RuntimeError("Model not loaded. Call load_model() first.")
        return self._model

    def run(
        self,
        query: str,
        image: Image.Image,
        ocr_regions: List[Dict[str, Any]],
        threshold: Optional[float] = None,
        top_k: Optional[int] = None,
        aggregation: Optional[str] = None,
    ) -> RegionFilterResult:
        """Run the full patch-to-region propagation pipeline.

        Args:
            query: Search query text
            image: Document page image (PIL Image)
            ocr_regions: List of OCR region dicts with keys:
                - "content" or "text": text content
                - "bbox": [x1, y1, x2, y2] in pixel coordinates
                - "label" (optional): region type label
            threshold: Override config threshold
            top_k: Override config top_k
            aggregation: Override config aggregation method

        Returns:
            RegionFilterResult with scored and filtered regions
        """
        threshold = threshold if threshold is not None else self.config.threshold
        top_k = top_k if top_k is not None else self.config.top_k
        aggregation = aggregation or self.config.aggregation

        # Parse OCR regions
        regions = [OCRRegion.from_dict(r) for r in ocr_regions]

        # Step 1: Generate interpretability maps
        logger.info(f"Generating interpretability maps for query: '{query}'")
        interp = self.model.generate_interpretability_maps(query, image)

        logger.info(
            f"Got {len(interp.token_maps)} token maps, "
            f"patch grid: {interp.n_patches_x}x{interp.n_patches_y}"
        )

        # Step 2-5: Patch score aggregation + IoU propagation + filtering
        result = filter_regions(
            regions=regions,
            token_maps=interp.token_maps,
            n_patches_x=interp.n_patches_x,
            n_patches_y=interp.n_patches_y,
            image_width=interp.image_width,
            image_height=interp.image_height,
            threshold=threshold,
            top_k=top_k,
            aggregation=aggregation,
        )

        return result

    def run_from_raw_similarity(
        self,
        ocr_regions: List[Dict[str, Any]],
        token_maps: List[TokenSimilarityMap],
        n_patches_x: int,
        n_patches_y: int,
        image_width: int,
        image_height: int,
        threshold: Optional[float] = None,
        top_k: Optional[int] = None,
        aggregation: Optional[str] = None,
    ) -> RegionFilterResult:
        """Run propagation from pre-computed similarity maps (no model needed).

        Use this if you already have interpretability maps from an external
        ColPali service and just need the patch-to-region propagation.

        Args:
            ocr_regions: OCR region dicts (see run())
            token_maps: Pre-computed per-token similarity maps
            n_patches_x: Patch grid width
            n_patches_y: Patch grid height
            image_width: Image width in pixels
            image_height: Image height in pixels
            threshold: Override config threshold
            top_k: Override config top_k
            aggregation: Override config aggregation method

        Returns:
            RegionFilterResult with scored and filtered regions
        """
        threshold = threshold if threshold is not None else self.config.threshold
        top_k = top_k if top_k is not None else self.config.top_k
        aggregation = aggregation or self.config.aggregation

        regions = [OCRRegion.from_dict(r) for r in ocr_regions]

        return filter_regions(
            regions=regions,
            token_maps=token_maps,
            n_patches_x=n_patches_x,
            n_patches_y=n_patches_y,
            image_width=image_width,
            image_height=image_height,
            threshold=threshold,
            top_k=top_k,
            aggregation=aggregation,
        )


# ---------------------------------------------------------------------------
# Convenience function for one-shot usage
# ---------------------------------------------------------------------------

def propagate_relevance(
    query: str,
    image: Image.Image,
    ocr_regions: List[Dict[str, Any]],
    model_id: str = "ModernVBERT/colmodernvbert-merged",
    threshold: float = 0.3,
    top_k: Optional[int] = None,
    aggregation: str = "iou_weighted",
) -> RegionFilterResult:
    """One-shot convenience function for patch-to-region propagation.

    Loads the model, generates interpretability maps, and filters regions
    all in one call. For repeated usage, create a PatchToRegionPipeline
    instance and call load_model() once.

    Args:
        query: Search query text
        image: Document page image
        ocr_regions: OCR region dicts with "content"/"text", "bbox", optional "label"
        model_id: ColPali model ID
        threshold: Minimum relevance score
        top_k: Max regions to return
        aggregation: Aggregation method

    Returns:
        RegionFilterResult
    """
    pipeline = PatchToRegionPipeline(
        config=PipelineConfig(
            model_id=model_id,
            threshold=threshold,
            top_k=top_k,
            aggregation=aggregation,
        )
    )
    pipeline.load_model()
    return pipeline.run(query, image, ocr_regions)
