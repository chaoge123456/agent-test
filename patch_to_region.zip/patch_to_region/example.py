#!/usr/bin/env python3
"""
Example: Patch-to-Region Relevance Propagation

Demonstrates the end-to-end flow:
1. Load a ColPali model
2. Feed a query + page image
3. Generate interpretability maps (per-token patch similarity)
4. Propagate patch scores to OCR regions via IoU weighting
5. Filter and display relevant regions

Prerequisites:
    pip install -r requirements.txt

Usage:
    python example.py --image page.png --query "total revenue" --ocr-regions regions.json

    Where regions.json is a JSON file with format:
    [
        {"content": "Total Revenue: $1.2M", "bbox": [512, 768, 1024, 896], "label": "table_cell"},
        ...
    ]
"""

import argparse
import json
import sys
from pathlib import Path

from PIL import Image

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent))

from pipeline import PatchToRegionPipeline, PipelineConfig
from patch_to_region import compute_patch_scores, OCRRegion


def main():
    parser = argparse.ArgumentParser(
        description="Patch-to-Region Relevance Propagation Example"
    )
    parser.add_argument(
        "--image", required=True, help="Path to document page image"
    )
    parser.add_argument(
        "--query", required=True, help="Search query text"
    )
    parser.add_argument(
        "--ocr-regions",
        required=True,
        help="Path to JSON file with OCR regions",
    )
    parser.add_argument(
        "--model-id",
        default="ModernVBERT/colmodernvbert-merged",
        help="ColPali model ID",
    )
    parser.add_argument(
        "--threshold",
        type=float,
        default=0.3,
        help="Minimum relevance score (0.0-1.0)",
    )
    parser.add_argument(
        "--top-k",
        type=int,
        default=None,
        help="Max regions to return (default: all above threshold)",
    )
    parser.add_argument(
        "--aggregation",
        default="iou_weighted",
        choices=["iou_weighted", "max", "mean"],
        help="Aggregation method",
    )
    parser.add_argument(
        "--device",
        default=None,
        help="Device: cuda:0, mps, cpu (auto-detect if omitted)",
    )

    args = parser.parse_args()

    # Load image
    image = Image.open(args.image)
    print(f"Image size: {image.size[0]}x{image.size[1]}")

    # Load OCR regions
    with open(args.ocr_regions) as f:
        ocr_regions = json.load(f)
    print(f"OCR regions: {len(ocr_regions)}")

    # Initialize pipeline
    config = PipelineConfig(
        model_id=args.model_id,
        device=args.device,
        threshold=args.threshold,
        top_k=args.top_k,
        aggregation=args.aggregation,
    )
    pipeline = PatchToRegionPipeline(config)
    pipeline.load_model()

    # Run pipeline
    result = pipeline.run(
        query=args.query,
        image=image,
        ocr_regions=ocr_regions,
    )

    # Display results
    print(f"\n{'='*60}")
    print(f"Query: '{args.query}'")
    print(f"Patch grid: {result.patch_scores.shape[1]}x{result.patch_scores.shape[0]}")
    print(f"Input regions: {result.total_input_regions}")
    print(f"Filtered regions: {len(result.regions)} (threshold={result.threshold})")
    print(f"{'='*60}")

    if not result.regions:
        print("No regions above threshold.")
    else:
        for i, region in enumerate(result.regions, 1):
            print(
                f"\n  [{i}] Score: {region.relevance_score:.4f} | "
                f"Label: {region.label or 'N/A'}"
            )
            print(f"      BBox: ({region.bbox.x1:.0f}, {region.bbox.y1:.0f}, "
                  f"{region.bbox.x2:.0f}, {region.bbox.y2:.0f})")
            text_preview = region.text[:120] + ("..." if len(region.text) > 120 else "")
            print(f"      Text: {text_preview}")

    # Show patch score heatmap statistics
    scores = result.patch_scores
    print(f"\n--- Patch Score Statistics ---")
    print(f"  Min:  {scores.min():.4f}")
    print(f"  Max:  {scores.max():.4f}")
    print(f"  Mean: {scores.mean():.4f}")
    print(f"  Std:  {scores.std():.4f}")


if __name__ == "__main__":
    main()
