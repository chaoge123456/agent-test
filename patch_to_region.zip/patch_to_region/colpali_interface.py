"""
ColPali Model Interface

Thin wrapper around colpali_engine for:
- Loading ColPali/ColModernVBert models
- Generating query and image embeddings
- Generating interpretability maps (per-token similarity maps over patch grid)

Dependencies: torch, colpali_engine, Pillow
"""

from __future__ import annotations

import logging
from typing import Any, List, Optional, Tuple, Union, cast

import torch
from PIL import Image

from patch_to_region import (
    BBox,
    InterpretabilityResult,
    OCRRegion,
    TokenSimilarityMap,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Model loading
# ---------------------------------------------------------------------------

def resolve_model_classes(model_id: str) -> Tuple[Any, Any]:
    """Resolve the correct model and processor classes based on model ID.

    Supports:
    - ColModernVBert (e.g. "ModernVBERT/colmodernvbert-merged")
    - ColQwen3 (any model ID containing "qwen")

    Returns:
        (ModelClass, ProcessorClass) tuple
    """
    model_id_lower = model_id.lower()

    if "modernvbert" in model_id_lower:
        from colpali_engine.models import ColModernVBert, ColModernVBertProcessor

        return ColModernVBert, ColModernVBertProcessor
    else:
        from colpali_engine.models import ColQwen3, ColQwen3Processor

        return ColQwen3, ColQwen3Processor


class ColPaliModel:
    """Manages a ColPali model and processor for embedding & interpretability."""

    def __init__(
        self,
        model_id: str = "ModernVBERT/colmodernvbert-merged",
        device: Optional[str] = None,
        torch_dtype: Optional[torch.dtype] = None,
    ):
        """
        Args:
            model_id: HuggingFace model ID or local path
            device: "cuda:0", "mps", "cpu", or None (auto-detect)
            torch_dtype: Model precision, or None (auto-select based on device)
        """
        self.model_id = model_id
        self.device = device or (
            "cuda:0"
            if torch.cuda.is_available()
            else "mps" if torch.backends.mps.is_available() else "cpu"
        )
        self.torch_dtype = torch_dtype or (
            torch.bfloat16 if self.device != "cpu" else torch.float32
        )

        self.model: Any = None
        self.processor: Any = None
        self.image_token_id: int = 0

    def load(self) -> None:
        """Load the model and processor. Call once before any inference."""
        ModelClass, ProcessorClass = resolve_model_classes(self.model_id)

        logger.info(
            f"Loading model: {self.model_id} on {self.device} "
            f"(dtype={self.torch_dtype})"
        )

        self.model = ModelClass.from_pretrained(
            self.model_id,
            torch_dtype=self.torch_dtype,
            device_map=self.device,
            trust_remote_code=True,
        ).eval()

        # Processor may be returned as (processor, {}) or just processor
        loaded = ProcessorClass.from_pretrained(
            self.model_id, trust_remote_code=True
        )
        self.processor = loaded[0] if isinstance(loaded, tuple) else loaded

        # Resolve image token ID
        self.image_token_id = self._resolve_image_token_id()

        logger.info(f"Model loaded. Image token ID: {self.image_token_id}")

    def _resolve_image_token_id(self) -> int:
        """Best-effort resolution of the image token ID."""
        if hasattr(self.processor, "image_token_id"):
            return int(self.processor.image_token_id)

        image_token = getattr(self.processor, "image_token", None)
        if image_token is not None and hasattr(self.processor, "tokenizer"):
            token_id = self.processor.tokenizer.convert_tokens_to_ids(image_token)
            if token_id is not None:
                return int(token_id)

        raise AttributeError("Processor does not expose an image_token_id.")

    # ------------------------------------------------------------------
    # Embedding generation
    # ------------------------------------------------------------------

    def embed_queries(self, queries: List[str]) -> List[torch.Tensor]:
        """Generate multi-vector embeddings for text queries.

        Args:
            queries: List of query strings

        Returns:
            List of tensors, each of shape (seq_len, dim)
        """
        with torch.no_grad():
            batch = self.processor.process_queries(queries).to(self.device)
            embeddings = cast(torch.Tensor, self.model(**batch))
            return list(torch.unbind(embeddings.to("cpu")))

    def embed_images(self, images: List[Image.Image]) -> List[dict]:
        """Generate multi-vector embeddings for images with token boundaries.

        Args:
            images: List of PIL Images

        Returns:
            List of dicts, each containing:
            - embedding: list of list of float (seq_len, dim)
            - image_patch_start: int
            - image_patch_len: int
            - image_patch_indices: list of int
        """
        with torch.no_grad():
            batch = self.processor.process_images(images).to(self.device)
            embeddings = cast(torch.Tensor, self.model(**batch)).to("cpu")

            if "input_ids" not in batch:
                raise RuntimeError(
                    "Tokenizer output missing 'input_ids'; "
                    "cannot compute image token boundaries."
                )

            input_ids = batch["input_ids"].to("cpu")
            results = []

            for i in range(input_ids.shape[0]):
                ids = input_ids[i]
                mask = ids.eq(self.image_token_id)
                indices = torch.nonzero(mask, as_tuple=True)[0]
                indices_list = indices.view(-1).tolist() if indices.numel() > 0 else []

                start = int(indices_list[0]) if indices_list else -1
                length = len(indices_list)

                results.append(
                    {
                        "embedding": embeddings[i].tolist(),
                        "image_patch_start": start,
                        "image_patch_len": length,
                        "image_patch_indices": [int(idx) for idx in indices_list],
                    }
                )

            return results

    def get_n_patches(self, image_size: Tuple[int, int]) -> Tuple[int, int]:
        """Get number of patches for an image of given size.

        Args:
            image_size: (height, width) in pixels

        Returns:
            (n_patches_x, n_patches_y)
        """
        return self.processor.get_n_patches(image_size)

    # ------------------------------------------------------------------
    # Interpretability maps
    # ------------------------------------------------------------------

    def generate_interpretability_maps(
        self,
        query: str,
        image: Image.Image,
    ) -> InterpretabilityResult:
        """Generate per-query-token similarity maps over the image patch grid.

        This is the bridge between ColPali's late interaction mechanism
        and the patch-to-region propagation algorithm.

        Args:
            query: Query text
            image: Document page image

        Returns:
            InterpretabilityResult containing per-token similarity maps
        """
        with torch.no_grad():
            # Process query and image
            batch_query = self.processor.process_queries([query]).to(self.device)
            batch_images = self.processor.process_images([image]).to(self.device)

            # Generate embeddings
            query_embeddings = cast(
                torch.Tensor, self.model(**batch_query)
            )  # [1, seq, dim]
            image_embeddings = cast(
                torch.Tensor, self.model(**batch_images)
            )  # [1, seq, dim]

            # Get patch dimensions: (height, width) -> (n_patches_x, n_patches_y)
            n_patches = self.processor.get_n_patches(
                (image.size[1], image.size[0])
            )

            # Get local image mask (excludes global patch tokens for spatial correspondence)
            image_mask = self.processor.get_local_image_mask(
                cast(Any, batch_images)
            )

            # Generate similarity maps: [1, query_length, n_patches_y, n_patches_x]
            similarity_maps_batch = (
                self.processor.get_similarity_maps_from_embeddings(
                    image_embeddings=image_embeddings,
                    query_embeddings=query_embeddings,
                    n_patches=n_patches,
                    image_mask=image_mask,
                )
            )

            # Unbatch: [query_length, n_patches_y, n_patches_x]
            similarity_maps = similarity_maps_batch[0]

            # Extract and filter query tokens (remove special tokens)
            input_ids = batch_query.input_ids[0].tolist()
            query_tokens = self.processor.tokenizer.convert_ids_to_tokens(
                batch_query.input_ids[0]
            )
            special_token_ids = set(
                self.processor.tokenizer.all_special_ids or []
            )

            token_maps: List[TokenSimilarityMap] = []
            for idx, (token, token_id) in enumerate(zip(query_tokens, input_ids)):
                if token_id in special_token_ids:
                    continue

                token_sim_map = similarity_maps[idx].cpu().numpy()
                display_token = token.replace("\u0120", " ").replace("\u2581", " ")

                token_maps.append(
                    TokenSimilarityMap(
                        token=display_token,
                        token_index=idx,
                        similarity_map=token_sim_map,
                    )
                )

            return InterpretabilityResult(
                query=query,
                tokens=[tm.token for tm in token_maps],
                token_maps=token_maps,
                n_patches_x=int(n_patches[0]),
                n_patches_y=int(n_patches[1]),
                image_width=image.size[0],
                image_height=image.size[1],
            )
