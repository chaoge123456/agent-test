"""
Patch-to-Region Relevance Propagation — Standalone Implementation
=================================================================

This package implements the core algorithm from the paper:
"Spatially-Grounded Document Retrieval via Patch-to-Region Relevance Propagation"

It propagates ColPali patch-level similarity scores to OCR text regions
via IoU-weighted aggregation, enabling query-focused region filtering.

Quick Start
-----------

    from pipeline import PatchToRegionPipeline

    pipeline = PatchToRegionPipeline()
    pipeline.load_model()

    result = pipeline.run(
        query="total revenue",
        image=page_image,
        ocr_regions=[
            {"content": "Total Revenue: $1.2M", "bbox": [512, 768, 1024, 896]},
            {"content": "Net Income: $300K", "bbox": [512, 896, 1024, 1024]},
        ],
        threshold=0.3,
    )

    for region in result.regions:
        print(f"[{region.relevance_score:.3f}] {region.text}")

Algorithm Overview
------------------

1. ColPali generates per-query-token similarity maps over the patch grid
2. MaxSim aggregation: for each patch, take max similarity across all query tokens
3. IoU-weighted propagation: for each OCR region, compute weighted average of
   overlapping patch scores, weighted by IoU (Intersection over Union)
4. Filter: keep only regions with relevance_score >= threshold

The core propagation formula:

    rel(q, r) = sum_j IoU(B(r), patch_bbox(j)) * score_patch(j)
                / sum_j IoU(B(r), patch_bbox(j))

where score_patch(j) = max_i S[i,j]  (MaxSim across query tokens)

Module Structure
----------------

- patch_to_region.py  — Core algorithm (IoU, MaxSim, propagation, filtering)
                        Only depends on numpy. Can be used standalone if you
                        already have similarity maps.
- colpali_interface.py — ColPali model wrapper (load, embed, interpretability)
- pipeline.py         — End-to-end pipeline orchestrating all steps

Installation
------------

    pip install -r requirements.txt

Note: colpali_engine requires torch with CUDA for GPU inference.
For CPU-only, use a CPU-compatible model and set device="cpu".

References
----------

- Paper: https://arxiv.org/abs/2512.02660
- ColPali: "ColPali: Efficient Document Retrieval with Vision Language Models"
- ColBERT: "Efficient and Effective Passage Search via Contextualized Late Interaction"
"""
