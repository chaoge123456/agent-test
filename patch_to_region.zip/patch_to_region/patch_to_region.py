"""
Patch-to-Region Relevance Propagation

Implements the core algorithm from:
"Spatially-Grounded Document Retrieval via Patch-to-Region Relevance Propagation"

This module propagates ColPali patch-level similarity scores to OCR text regions
via IoU-weighted aggregation, enabling query-focused region filtering.

Dependencies: numpy only
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------

@dataclass
class BBox:
    """Axis-aligned bounding box in pixel coordinates (x1, y1, x2, y2)."""

    x1: float
    y1: float
    x2: float
    y2: float

    @property
    def width(self) -> float:
        return self.x2 - self.x1

    @property
    def height(self) -> float:
        return self.y2 - self.y1

    @property
    def area(self) -> float:
        return max(0.0, self.width) * max(0.0, self.height)

    def as_tuple(self) -> Tuple[float, float, float, float]:
        return (self.x1, self.y1, self.x2, self.y2)


@dataclass
class OCRRegion:
    """A single OCR-detected text region."""

    text: str
    bbox: BBox
    label: str = ""  # e.g. "table_cell", "paragraph", "figure"
    relevance_score: float = 0.0

    @classmethod
    def from_dict(cls, d: dict) -> OCRRegion:
        """Create from a dict with 'bbox' ([x1,y1,x2,y2]) and 'content'/'text' keys."""
        bbox_list = d.get("bbox", d.get("bounding_box", []))
        if len(bbox_list) < 4:
            raise ValueError(f"Invalid bbox in region dict: {d}")
        return cls(
            text=d.get("content", d.get("text", "")),
            bbox=BBox(*bbox_list[:4]),
            label=d.get("label", ""),
        )


@dataclass
class TokenSimilarityMap:
    """Per-query-token similarity map over the patch grid."""

    token: str
    token_index: int
    similarity_map: np.ndarray  # shape: (n_patches_y, n_patches_x)


@dataclass
class InterpretabilityResult:
    """Output of interpretability map generation."""

    query: str
    tokens: List[str]
    token_maps: List[TokenSimilarityMap]
    n_patches_x: int
    n_patches_y: int
    image_width: int
    image_height: int


@dataclass
class RegionFilterResult:
    """Result of patch-to-region propagation and filtering."""

    regions: List[OCRRegion]
    patch_scores: np.ndarray  # (n_patches_y, n_patches_x) - per-patch MaxSim scores
    total_input_regions: int = 0
    threshold: float = 0.0


# ---------------------------------------------------------------------------
# Core algorithm
# ---------------------------------------------------------------------------

def compute_iou(box1: BBox, box2: BBox) -> float:
    """Compute Intersection over Union between two bounding boxes.

    Args:
        box1: First bounding box
        box2: Second bounding box

    Returns:
        IoU value in [0, 1]
    """
    ix1 = max(box1.x1, box2.x1)
    iy1 = max(box1.y1, box2.y1)
    ix2 = min(box1.x2, box2.x2)
    iy2 = min(box1.y2, box2.y2)

    if ix2 <= ix1 or iy2 <= iy1:
        return 0.0

    intersection = (ix2 - ix1) * (iy2 - iy1)
    union = box1.area + box2.area - intersection

    if union <= 0:
        return 0.0

    return intersection / union


def compute_patch_scores(
    token_maps: List[TokenSimilarityMap],
) -> np.ndarray:
    """Aggregate per-token similarity maps into per-patch scores via MaxSim.

    For each patch position (py, px), take the maximum similarity across
    all query tokens:

        score_patch(py, px) = max_i S[i, py, px]

    This mirrors the ColPali MaxSim scoring mechanism in reverse:
    instead of "for each query token, find the best patch",
    we do "for each patch, find the best query token".

    Args:
        token_maps: List of TokenSimilarityMap, one per query token

    Returns:
        2D array of shape (n_patches_y, n_patches_x) with per-patch scores
    """
    if not token_maps:
        raise ValueError("No token maps provided")

    # Stack all token maps: (n_tokens, n_patches_y, n_patches_x)
    stacked = np.stack([tm.similarity_map for tm in token_maps], axis=0)

    # MaxSim across query tokens: (n_patches_y, n_patches_x)
    patch_scores = np.max(stacked, axis=0)

    return patch_scores


def compute_region_relevance(
    region_bbox: BBox,
    patch_scores: np.ndarray,
    n_patches_x: int,
    n_patches_y: int,
    image_width: int,
    image_height: int,
    aggregation: str = "iou_weighted",
) -> float:
    """Compute a single region's relevance score using IoU-weighted aggregation.

    Implements the paper's formula:

        rel(q, r) = sum_j IoU(B(r), patch_bbox(j)) * score_patch(j)
                    / sum_j IoU(B(r), patch_bbox(j))

    Args:
        region_bbox: The OCR region's bounding box in pixel coordinates
        patch_scores: Per-patch MaxSim scores, shape (n_patches_y, n_patches_x)
        n_patches_x: Number of patches in x dimension
        n_patches_y: Number of patches in y dimension
        image_width: Image width in pixels
        image_height: Image height in pixels
        aggregation: 'iou_weighted' (paper default), 'max', or 'mean'

    Returns:
        Relevance score for this region
    """
    patch_w = image_width / n_patches_x
    patch_h = image_height / n_patches_y

    # Find patch indices overlapping with this region
    px1 = max(0, int(region_bbox.x1 / patch_w))
    py1 = max(0, int(region_bbox.y1 / patch_h))
    px2 = min(n_patches_x, int(np.ceil(region_bbox.x2 / patch_w)))
    py2 = min(n_patches_y, int(np.ceil(region_bbox.y2 / patch_h)))

    if aggregation == "iou_weighted":
        weighted_sum = 0.0
        iou_sum = 0.0

        for py in range(py1, py2):
            for px in range(px1, px2):
                patch_bbox = BBox(
                    px * patch_w,
                    py * patch_h,
                    (px + 1) * patch_w,
                    (py + 1) * patch_h,
                )
                iou = compute_iou(region_bbox, patch_bbox)
                if iou > 0:
                    weighted_sum += iou * float(patch_scores[py, px])
                    iou_sum += iou

        return weighted_sum / iou_sum if iou_sum > 0 else 0.0

    elif aggregation == "max":
        region_values = patch_scores[py1:py2, px1:px2]
        return float(np.max(region_values)) if region_values.size > 0 else 0.0

    elif aggregation == "mean":
        region_values = patch_scores[py1:py2, px1:px2]
        return float(np.mean(region_values)) if region_values.size > 0 else 0.0

    else:
        raise ValueError(
            f"Unknown aggregation: {aggregation}. "
            f"Use 'iou_weighted', 'max', or 'mean'."
        )


def propagate_to_regions(
    regions: List[OCRRegion],
    patch_scores: np.ndarray,
    n_patches_x: int,
    n_patches_y: int,
    image_width: int,
    image_height: int,
    aggregation: str = "iou_weighted",
) -> List[Tuple[OCRRegion, float]]:
    """Propagate patch scores to all OCR regions and compute relevance.

    Args:
        regions: OCR regions with bounding boxes
        patch_scores: Per-patch MaxSim scores (n_patches_y, n_patches_x)
        n_patches_x: Patch grid width
        n_patches_y: Patch grid height
        image_width: Image width in pixels
        image_height: Image height in pixels
        aggregation: Aggregation method

    Returns:
        List of (region, relevance_score) sorted by score descending
    """
    scored: List[Tuple[OCRRegion, float]] = []

    for region in regions:
        score = compute_region_relevance(
            region_bbox=region.bbox,
            patch_scores=patch_scores,
            n_patches_x=n_patches_x,
            n_patches_y=n_patches_y,
            image_width=image_width,
            image_height=image_height,
            aggregation=aggregation,
        )
        scored.append((region, score))

    scored.sort(key=lambda x: x[1], reverse=True)
    return scored


def filter_regions(
    regions: List[OCRRegion],
    token_maps: List[TokenSimilarityMap],
    n_patches_x: int,
    n_patches_y: int,
    image_width: int,
    image_height: int,
    threshold: float = 0.3,
    top_k: Optional[int] = None,
    aggregation: str = "iou_weighted",
) -> RegionFilterResult:
    """End-to-end: compute patch scores → propagate to regions → filter.

    This is the main entry point for the patch-to-region relevance propagation.

    Args:
        regions: OCR regions with bounding boxes
        token_maps: Per-query-token similarity maps
        n_patches_x: Patch grid width
        n_patches_y: Patch grid height
        image_width: Image width in pixels
        image_height: Image height in pixels
        threshold: Minimum relevance score to keep a region (0.0 - 1.0)
        top_k: Max regions to return (None = all above threshold)
        aggregation: 'iou_weighted', 'max', or 'mean'

    Returns:
        RegionFilterResult with scored and filtered regions
    """
    if not regions or not token_maps:
        logger.warning("No regions or token maps provided")
        return RegionFilterResult(
            regions=[],
            patch_scores=np.array([]),
            total_input_regions=len(regions),
            threshold=threshold,
        )

    # Step 1: MaxSim aggregation across query tokens
    patch_scores = compute_patch_scores(token_maps)

    # Step 2: IoU-weighted propagation to regions
    scored_regions = propagate_to_regions(
        regions=regions,
        patch_scores=patch_scores,
        n_patches_x=n_patches_x,
        n_patches_y=n_patches_y,
        image_width=image_width,
        image_height=image_height,
        aggregation=aggregation,
    )

    # Step 3: Filter by threshold
    filtered = [(r, s) for r, s in scored_regions if s >= threshold]

    # Step 4: Apply top-k
    if top_k is not None and top_k > 0:
        filtered = filtered[:top_k]

    # Attach scores to regions
    result_regions = []
    for region, score in filtered:
        region.relevance_score = score
        result_regions.append(region)

    logger.info(
        f"Region filtering: {len(regions)} -> {len(result_regions)} "
        f"(threshold={threshold}, aggregation={aggregation})"
    )

    return RegionFilterResult(
        regions=result_regions,
        patch_scores=patch_scores,
        total_input_regions=len(regions),
        threshold=threshold,
    )
