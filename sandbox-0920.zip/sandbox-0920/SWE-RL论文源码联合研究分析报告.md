# SWE-RL：从开放软件演化中学习推理——论文与源码联合研究分析

> **论文**：*SWE-RL: Advancing LLM Reasoning via Reinforcement Learning on Open Software Evolution*（Wei et al., NeurIPS 2025，arXiv:2502.18449v2）  
> **分析对象**：`2025 SWE-RL.pdf`（26 页）与同目录官方仓库 `swe-rl/`  
> **阅读目标**：先建立“它为什么可行”的直觉，再看奖励、训练闭环、推理脚手架和可复现边界；实验结果仅作为支撑证据，而非重点。

---

## 0. 先给结论：这篇论文到底改变了什么？

SWE-RL 的核心转变是：**不再把真实软件工程中的 Pull Request（PR）仅当成监督微调的“答案对”，而是把它当成可以定义强化学习奖励的、规模极大的软件演化轨迹。** 给模型一个历史 issue 和变更前代码，让它自行推理并产生补丁；只要输出格式正确，就按其补丁与开发者合入补丁的相似度给连续奖励，再用 GRPO 优化策略。

这听起来像“用 diff 当奖励”，但有三层含义：

1. 它绕开了真实仓库中昂贵、脆弱且常常不可执行的测试反馈，把训练从“必须跑通完整环境”变成“可以离线比较文本化代码变更”。
2. 它让同一 issue 的多次生成在相对奖励下竞争。模型不是被教师答案逐 token 模仿，而是被鼓励找到**更接近有效修复轨迹**的推理与编辑方式。
3. 它把训练任务收窄为“带完整文件上下文的修复编辑”，但论文声称这种压力促使模型内化定位、核查和反思，进而在数学、代码推理等未训练任务上也提升。

应把它理解为一个很务实的命题：**当语义判定很贵时，能否用高覆盖率的人类演化痕迹构造足够稠密的代理奖励，先把推理能力推起来？** SWE-RL 的答案是“可以，但代理奖励和完整系统仍有明显边界”。

---

## 1. 研究背景：为什么“真实软件工程上的 RL”此前很难做？

### 1.1 问题不等于竞赛编程

在竞赛编程或函数级代码生成中，输入、输出和测试通常相对封闭，因此可以把“程序是否通过测试”作为接近真值的奖励：

$$R_{exec}(o)=\mathbb{1}[\mathrm{tests}(o)\ \mathrm{pass}]$$

真实 GitHub issue 则不同。一个修复可能跨文件、依赖特定提交快照、外部服务、数据集、构建工具和非确定性环境；有的仓库测试本身就不稳定，也有 issue 根本没有现成的可执行复现测试。若每次 RL rollout 都建立环境并跑测试，成本会迅速失控，且大量样本会因环境失败而没有有效学习信号。

这正是 SWE-RL 的出发点：它不试图把“补丁是否语义正确”直接做成训练期奖励，而是先问一个更可扩展的问题——**模型生成的变更是否越来越像真实开发者最终合入的变更？**

### 1.2 仅做 SFT 的不足

典型 SFT 把 `(问题、代码上下文) → (思维过程、修复补丁)` 当作条件语言建模。它可以教会格式、常见模板和表面模式，却有两个隐患：

- 高质量的长推理轨迹通常要靠更强教师模型合成，成本高，也会把教师偏好蒸馏进去；
- token 级模仿只告诉模型“参考答案长什么样”，不直接比较同一问题下多个候选方案谁更接近目标。

论文为公平比较，用相同 PR 种子构造了一个很强的 SFT 基线：由 Llama-3.3-70B-Instruct 合成定位和编辑样本，再混入 Llama 3 的代码与通用 SFT 数据，训练 2B tokens。这一点很重要：论文并不是拿一个弱 SFT 靶子来衬托 RL，而是在比较“合成示范模仿”与“从候选质量中学习”。

### 1.3 软件演化数据提供了什么新资源？

PR 是开发过程结束后留下的压缩证据：issue/讨论说明“为什么改”，merge base 给出“改之前是什么”，提交与最终 diff 给出“如何改、改成什么”。SWE-RL 将这些证据重组为三元组：

$$d=(\mathrm{issue},\mathrm{ctx},\mathrm{patch}_{gt})\in D_{seed}$$

其中 `ctx` 不只有被修改文件，还刻意加入相关但未修改的文件。这样做不是装饰：若上下文中只有 oracle 会改的文件，模型会学到“看到的每个文件都应该修改”的捷径；混入干扰文件迫使它同时学习**不该改什么**。

---

## 2. 方法总览：一条从 PR 到策略优化的闭环

```mermaid
flowchart LR
    A[GitHub events + git history] --> B[Curated PRs]
    B --> C[Seed: issue, context, oracle patch]
    C --> D[LLM generates thinking + search/replace]
    D --> E{Format valid?}
    E -->|No| F[reward = -1]
    E -->|Yes| G[Apply edits and normalize diff]
    G --> H[Sequence similarity to oracle]
    H --> I[Continuous reward in 0..1]
    F --> J[GRPO group update]
    I --> J
    J --> D
```

这张图里有一个容易忽略的取舍：**训练闭环只优化“修复生成”，端到端评测再用 Agentless Mini 补上文件定位、测试生成、测试选择和 rerank。** 因此须区分“论文训练的模型能力”和“最终 41.0% 系统成绩”——后者是模型、采样预算和脚手架共同的结果。

---

## 3. 创新一：把开放软件演化清洗成可训练的 RL 种子

### 3.1 数据流水线及其规模

论文附录 A 的数据链路十分关键：

| 阶段 | 操作 | 产物/规模 | 解决的问题 |
|---|---|---:|---|
| 采集 | 从 GH Archive 收集 2015-01-01 至 2024-08-31 的 GitHub events；克隆完整 Git 历史 | 处理 **4.6M** 仓库 | 恢复 PR 对应提交时刻而不是当前代码 |
| 聚合 | 对 merged PR 聚合 issue、讨论、评审、merge-base 文件、中间提交和最终 patch | **24M** PR 实例 | 让样本接近开发者当时看到的信息 |
| 去噪 | 删除机器人 PR、空/过大改动、lockfile/版本更新等低价值改动 | 约 **11M** 唯一 PR | 降低非修复性变更的噪声 |
| 选种子 | 要求链接 issue、bug-fix 描述和编程文件改动等启发式 | **273k** 高质量 seed | 形成 RL 训练分布 |

为了避免 SWE-bench 泄漏，论文声称在处理时排除了所有 SWE-bench 仓库。这里的防泄漏粒度是“仓库级”，保守但代价较大；它避免了同仓库相邻 PR 通过代码历史泄漏到评测集。

### 3.2 “相关但未修改文件”是一个小而重要的设计

作者先发现只给 changed files 会诱发错误归纳：模型把所有展示文件都编辑。于是使用 Llama-3.1-70B-Instruct，根据 PR 描述和已改文件预测相关的未改文件，并把其内容加入输入。

这使训练样本近似一个受控的判别任务：模型既要从文本和代码中找因果线索，又要在候选文件中拒绝干扰项。换句话说，SWE-RL 不是直接训练独立的 localization head，而是通过完整文件上下文，把**细粒度定位的负担折进 repair rollout**。

但这也应被诚实地视为一个边界：论文的“公开数据驱动”不等于流水线每个环节都不借助强模型——相关文件扩充阶段使用了 Llama-3.1-70B-Instruct。它不是私有教师蒸馏的主训练信号，却是数据构造中的模型辅助假设。

---

## 4. 创新二：用连续补丁相似度替代昂贵执行奖励

### 4.1 输出契约先于奖励

模型被要求输出两个明确区块：`<think>...</think>` 和 `<solution>...</solution>`；`solution` 内每个编辑都必须是带路径的 `SEARCH/REPLACE` 块。形式上：

$$o\xrightarrow{\mathrm{parse}}\mathrm{edits}\xrightarrow{\mathrm{apply}(ctx)}\mathrm{patch}_{pred}$$

格式不正确、没有有效搜索块、搜索内容无法在给定代码中匹配，都会直接得到：

$$R(o)=-1$$

这个负奖励并非琐碎的工程细节。真实的补丁代理首先必须产出**可被机器执行的编辑动作**；若不把格式纳入优化，模型可能有很好的自然语言解释，却不能进入后续补丁选择和测试环节。

### 4.2 正常样本如何打分？

对格式正确的输出，系统先把 search/replace 应用于原始上下文，再分别把“模型修改后内容”和“oracle 修改后内容”归一化为 unified diff。对所有预测或 oracle 涉及到的文件并集逐文件比较：

$$s_f=\mathrm{SequenceMatcher}(\Delta^{pred}_f,\Delta^{gt}_f)\in[0,1]$$

最终奖励是逐文件相似度的平均：

$$R(o)=\frac{1}{|F_{pred}\cup F_{gt}|}\sum_{f\in F_{pred}\cup F_{gt}}s_f$$

它给出了一个**稠密的 shaping signal**：即便模型没有完全复刻 oracle，只要文件、局部上下文或修改方向逐渐对齐，就能获得比 0 更有区分度的反馈。相比精确匹配奖励

$$R_{exact}(o)=\mathbb{1}[\Delta_{pred}=\Delta_{gt}]$$

这对高度多样的真实补丁尤为重要。论文消融中，连续奖励的 oracle-file repair 为 34.8，而离散奖励为 29.0；离散奖励的平均回报长期接近 0，直观说明大多数 rollout 从未“恰好写出同一个 diff”。

### 4.3 它奖励的不是语义正确性

一定要区分以下两个命题：

- **可证实**：该奖励让输出在文本化变更轨迹上越来越接近历史开发者补丁；
- **不可直接推出**：高奖励补丁必然能修复 bug，或所有能修复 bug 的不同补丁都会高奖励。

作者在 Limitations 中明确承认这一点。两个功能等价的实现，只要 diff 形状不同，也可能拿低分；反之，和 oracle 共享大量上下文行但不真正修复的补丁可能拿到相对高分。SWE-RL 的成功依赖于一个经验假设：在海量、高质量 PR 上，**编辑相似度与修复能力具有足够强的统计相关性**。最终的 SWE-bench 测试和 rerank 只是在训练后检验这一代理目标是否有用，并不使奖励本身变成语义验证器。

---

## 5. 创新三：以 GRPO 让“更好的候选推理”相互竞争

给定一个由 issue 与 context 组成的 prompt：

$$q=\mathrm{form\_prompt}(\mathrm{issue},\mathrm{ctx})$$

旧策略一次采样一个大小为 $G$ 的候选组 $\{o_i\}_{i=1}^{G}$，并以组内标准化回报定义优势：

$$A_i=\frac{r_i-\mathrm{mean}(r_1,\ldots,r_G)}{\mathrm{std}(r_1,\ldots,r_G)}$$

再使用 GRPO 的 clipped objective 更新策略：

$$
J(\theta)=\mathbb{E}\left[\frac1G\sum_{i=1}^{G}\left(
\min\left(\rho_iA_i,\operatorname{clip}(\rho_i,1-\epsilon,1+\epsilon)A_i\right)
-\beta D_{KL}(\pi_\theta\parallel\pi_{ref})\right)\right],
\quad
\rho_i=\frac{\pi_\theta(o_i\mid q)}{\pi_{\theta_{old}}(o_i\mid q)}.
$$

人话解释如下：对于**同一个 issue**，比同组其他输出更接近 oracle 的回答被强化，较差回答被压低；`clip` 阻止单次更新跨得太远，KL 项阻止模型为了迎合代理奖励而偏离初始指令模型过猛。它不需要像传统 actor-critic 那样另训一个 value model，这是 GRPO 特别适合大语言模型在线采样训练的一点。

论文将模型出现的自我反思、多方案探索、分解问题等文本行为称为 "aha moments"。应谨慎理解：这不是被显式标注为“反思”的监督目标，而是当长推理有机会带来更高 patch similarity 时，策略学习到愿意在输出中投入更多推理 token 的**可观察行为结果**；这并不单独证明模型拥有某种可分离的、普适的推理模块。

---

## 6. 训练流程：如何把方法落到一次实际训练中？

### 6.1 论文报告的训练配置

基础模型为 Llama-3.3-70B-Instruct。训练采用 16k context window，进行 1,600 个 step；每个全局 batch 有 512 个样本，即 32 个问题、每题 16 个 rollout（$G=16$），每个 global step 进行一次 Adam 更新。论文报告使用 512 张 NVIDIA H100，单次训练约 32 个墙钟小时。

把这一过程写成伪代码，会更容易把握关键顺序：

```text
for step in 1..1600:
    seeds = sample 32 PR triples from D_seed
    prompts = format(issue, full relevant-file context)
    for each prompt:
        generate 16 (thinking, search/replace) rollouts
        parse and apply edits
        reward = -1 if malformed else diff_similarity(pred, oracle)
        normalize rewards inside this 16-sample group
    update Llama policy once using GRPO + KL regularization
```

训练中真正被优化的是“根据给定相关文件进行 repair”。文件级定位、复现测试生成和运行测试没有进入这条 RL 反向传播路径。因此如果未来要扩展该工作，最自然的方向不是盲目堆更多 PR，而是把交互式测试反馈、语义等价信号和多阶段决策也纳入训练。

### 6.2 为什么“给完整文件”比只给局部片段更有研究意义？

搜索/替换动作要求原始代码片段精确匹配，缩进也必须正确。模型若没定位到准确区域，即便在概念上知道修法也无法取得高 reward。完整文件因此同时提供了三种学习压力：

1. 从 issue 映射到可能的文件/函数；
2. 在真实代码约束中验证假设，并选择唯一、可匹配的 search block；
3. 生成既小又可应用的 edit，而非笼统解释。

这解释了为何论文把 repair-only 任务视作能力核心：其奖励虽然只看 diff，却将“诊断—定位—编辑格式化”绑成了一个端到端可度量动作。

---

## 7. 从论文到源码：哪些地方真正落地了？

下面的表格基于当前目录中的官方仓库快照（HEAD `5aa10d6`，2025-03-16），不是对作者内部训练基础设施的推测。

| 论文组件 | 当前源码对应 | 联合解读 |
|---|---|---|
| 训练 prompt 与输出格式 | `src/swerl/core/prompts.py:3-55` | `AGENTLESS_REPAIR` 要求 issue、文件内容和 `SEARCH/REPLACE`；`THINKING_SYSTEM` 定义 `<think>/<solution>` 契约，和论文附录 D 对齐。 |
| 格式校验及 -1 惩罚 | `core/reward.py:23-57, 231-270` | `extract_thought_solution` 强制四个标签各出现一次并要求 thought 非空；没有有效 search 块或 search 无法匹配均捕获为 `FormatError`，返回 `-1.0`。 |
| 从编辑得到模型 patch | `core/reward.py:95-152` | 先把 search/replace 应用于原始代码，再用 `difflib.unified_diff` 生成归一化 diff，避免直接比较自由文本回答。 |
| 连续相似度奖励 | `core/reward.py:162-228` | 对预测和 oracle 的文件键并集逐项运行 `difflib.SequenceMatcher(..., autojunk=False).ratio()` 并求平均，正是论文的 compare 实例。 |
| 统一 diff 的通用接口 | `core/reward.py:273-342` | `calculate_reward_unidiff` 支持将两组 unified diff 解析为文件级变更后再复用同一相似度逻辑；说明奖励设计不与一种编辑格式强绑定。 |
| 文件级定位 | `agentless_mini/localize.py:56-118` | 对仓库结构与 issue 多次采样；样本数大于 1 时随机选择 2–5 个文件、结构缩进与顺序，提升候选多样性。 |
| 修复候选生成 | `agentless_mini/repair.py:30-54, 69-96, 150-252` | 将定位到的**完整文件内容**拼到上下文，受默认 60k input-token 上限控制；解析 solution、应用编辑并保存轨迹。 |
| 基于测试的候选筛选 | `agentless_mini/rerank.py:211-329` | 在有执行结果时，先保留回归失败最少者，再把通过同一复现测试集合的 patch 聚类，核心分数为 $|T|^2\times|P|$，最后多数投票。 |

### 7.1 奖励实现的一个细读要点

源码并没有直接拿 LLM 原始文本和 oracle 文本算相似度。它先把模型的编辑**施加到给定旧文件**，再对“真实发生的变更”生成 diff。这个转换消除了推理文本长短、代码块注释等表面噪声，使奖励主要比较 edit effect。

此外，`compute_change_similarities` 用预测/真实文件路径的并集计分：多改一个 oracle 没有的文件会多出一个相似度为 0 的项，漏改真实文件也会受罚。这比只比较重叠文件更难被“只答一小段正确改动”钻空子。

但仍应注意实现层面的语义：`apply_code_change` 使用字符串替换，而不是语言 AST 或实际仓库 `git apply`；它能保证 search block 能找到，却不保证修改后的项目能构建或满足行为。换言之，**训练奖励的可扩展性正来自它放弃了完整语义验证**。

### 7.2 Agentless Mini 如何把模型能力转为系统能力？

论文图 7 与源码都采用“可分解、可并行、可扩样本”的 pipeline：

```text
issue + repository structure
        ↓  multiple file-location samples
full contents of each candidate file set
        ↓  multiple repair samples
applied patches
        ↓  regression / reproduction test evidence
consensus reranking + majority vote
        ↓
one submitted patch
```

这里的设计哲学是把昂贵执行留到较少的候选 patch 上，而把大量便宜的模型采样用于扩大搜索。也因此，报告 41.0% 时不能忽略其推理时预算：主评测对每题生成 **500 个 repair patch**，再以最多 **30 个 reproduction tests** 做执行和 rerank；这不是单次贪心解码的模型分数。

---

## 8. 实验方法：它实际验证了哪些问题？

用户若只关心方法是否站得住，实验应按“验证链条”而非 leaderboard 排名来读。

| 要回答的问题 | 设计 | 最小必要证据 | 应得出的结论 |
|---|---|---|---|
| RL 是否提升核心 repair？ | 在 SWE-bench Verified 提供 oracle 定位文件，只测单次贪心修复 | RL 34.8，SFT 29.6；基础 Llama 多数投票仅 16.6 | 提升并非全由外部定位/重排造成，repair 模型本身确实变强。 |
| 能否形成端到端系统能力？ | Agentless Mini 的定位、500 repair 样本、测试 rerank 后提交 pass@1 | RL 41.0%，SFT 36.2% | 模型提升能传递到完整 pipeline；但结果包含大规模 test-time search。 |
| 更多采样为什么有效？ | 分别扫描 repair 数和复现测试数 | repair 从 20 到 160 时 33.6→40.0，之后趋于饱和；tests 到 20 后基本饱和 | 采样和验证会显著影响成绩，应把它们作为方法资源而非隐藏常数。 |
| 连续奖励是否必要？ | 连续 diff similarity 对比精确 0/1 diff match | repair 34.8 vs 29.0 | 在多解、长补丁的真实工程分布中，稠密代理奖励比稀疏精确奖励更可学习。 |
| 是否只记住 bug repair？ | 零样本贪心评测五类 OOD benchmark | RL 在 HumanEval+、CRUXEval、MATH、MMLU 等总体优于基座/SFT | 有跨任务迁移迹象，但不是形式化的“通用推理”证明。 |

论文还报告 RL 模型在 MATH、CRUXEval 等需多步推理任务提升，而 SFT 平均退化。最有价值的解释不是“RL 天生万能”，而是：SFT 强行拟合一个合成数据分布时可能造成能力偏移；组内相对奖励加 KL 约束似乎更能保持基座模型的广泛能力。该因果解释仍需要更多种子、模型族和训练预算的重复实验来巩固。

---

## 9. 公开仓库的复现边界：能复现什么，不能复现什么？

这是阅读源码后最需要避免误解的部分。

### 9.1 当前可用、可审计的部分

- prompt 模板与搜索/替换输出契约；
- 基于 `SequenceMatcher` 的三套奖励 API（search/replace、unified diff、通用新文件内容接口）；
- Agentless Mini 的文件定位、修复候选生成、patch 归一化和 rerank 代码；
- 少量真实定位资源文件，例如 `resources/sweb_verified_gt_loc.jsonl`；
- `tests/test_reward.py` 中的奖励单元测试案例。

### 9.2 当前未随仓库完整释放的部分

论文 checklist 已说明原始训练数据与训练 pipeline 因隐私/专有考虑当时未公开。README 也明确说当前主要提供 prompt 与 reward。更重要的是，README 将“复现测试生成、回归测试选择、测试执行”标成 **WIP**，而 `rerank.py:3` 注记“mostly not refactored”。

因此，这个仓库最准确的定位是：**论文方法的奖励和推理脚手架参考实现**，不是“一键重训 Llama3-SWE-RL-70B 并复现 41.0%”的完整 artifact。README 还主动警告重构后的代码可能与内部实现存在不一致。研究者使用它时，应把公开 reward 的正确性、公开推理 pipeline 的可运行性、论文中大规模训练/评测数值的可复现性分开核查。

本次环境中，内置 Python 缺少 `pytest` 和 `unidiff`，因此未能直接运行仓库测试；这反映的是分析环境未安装仓库声明的开发依赖，而不是测试失败或源码功能异常。仓库建议的安装方式为 `pip install -e ".[dev]"` 后执行 `pytest`。

---

## 10. 局限与批判性判断

### 作者明确承认的局限

1. **奖励不是语义等价。** 文本 diff 相似不能充分鼓励不同但正确的补丁，也可能压制创新修法。
2. **定位上下文不完整。** Agentless Mini 把定位简化为由仓库结构映射到文件路径，缺少更丰富的代码、调用图和运行时语境。
3. **外部 pipeline 结构割裂。** 阶段被拆在外部脚手架里，模型没有通过多轮环境交互学习整个问题的全局决策。

### 基于论文与代码对照的补充判断

1. **目标错配会随补丁多样性放大。** 对小修复，编辑相似度往往是好代理；对重构、性能优化、依赖升级或多种可行设计，它可能把“最像历史作者”误作“最好”。未来可把静态分析、编译、测试、语义 embedding 或 learned verifier 与 diff reward 混合，形成分层奖励。
2. **41.0% 是系统-预算结果，不是纯模型标签。** 500 repair 样本、30 个复现测试与 rerank 是实质资源。论文已经用 oracle-file repair 实验拆出了模型贡献，但部署比较时仍须同时报告单样本、相同 token 预算和相同执行预算下的曲线。
3. **数据质量是方法的隐形核心。** 273k seed 的选择依赖多层启发式和 LLM 辅助的相关文件预测。若迁移到小众语言、私有仓库或缺 issue 关联的提交，奖励—质量相关性可能显著下降。
4. **推理文本不是可靠的因果证据。** `<think>` 的增长和“aha moment”展示具有解释性价值，但不能仅由文本现象推断内部机制。应配合行为消融，例如限制思维 token、打乱 context、控制相同 patch 长度等。
5. **开源复现目前不闭环。** 公开仓库可检验奖励计算，却无法从原始数据一路构建 seed、训练 GRPO、执行完整测试和复现论文所有数字。这不否定方法贡献，但会限制独立验证和后续基线比较的精确性。

---

## 11. 对后续研究与工程实践的启发

### 11.1 如果你要沿这条线做研究

建议将问题拆成四个可独立发表/验证的方向：

1. **更接近语义的稠密奖励**：比较 AST/调用图变化，使用编译、轻量静态检查和选择性测试，把低成本代理与高精度验证结合。
2. **从单阶段 repair 到多阶段 RL**：把“选择文件—阅读—编辑—写复现测试—根据执行结果再修”表示为轨迹，而不是固定 pipeline 的多个独立调用。
3. **预算公平的 scaling law**：报告训练 compute、rollout 数、候选数、测试数与通过率的共同曲线，区分 policy 质量和 test-time search 增益。
4. **数据质量与泛化审计**：按语言、仓库大小、变更类型、issue 信息密度和补丁多解性分桶，测量 diff similarity 与真实测试通过率的相关性在哪些区域失效。

### 11.2 如果你要把它用于内部代码修复

最值得直接复用的是“编辑格式 + 可应用性检查 + 多候选 + 后验验证”这一骨架，而不是机械地把 `SequenceMatcher` 当真值：

- 有历史 PR 但测试昂贵时，可先用类似 diff reward 预训练或过滤候选；
- 有可靠 CI 时，应让编译/测试结果成为最终选择器，最好也逐步进入训练奖励；
- 要记录训练时上下文构造方式和测试时工具权限，否则模型提升可能只是数据或脚手架变化；
- 私有代码场景要特别处理凭据、许可证、敏感修复和历史提交中的安全信息，不能把“开放 PR 的可用性”直接类推到企业数据。

---

## 12. 一条高效的学习路线

如果目标是快速深入该领域，建议按以下顺序读，而不是从头反复读 26 页论文：

1. **先读论文 Fig. 1、§2.1 与式 (1)**：弄清一个 rollout 为什么会得 `-1` 或 `[0,1]` 的分数。
2. **读附录 A 的 Fig. 6**：确认“软件演化数据”不是简单抓 diff，而是带时间快照、关联 issue 和过滤的 PR 重建过程。
3. **读 `swe-rl/src/swerl/core/reward.py`**：从 `calculate_search_replace_reward` 逆向追到 `compute_change_similarities`，把数学奖励变成可执行语义。
4. **读论文 §3.1 与附录 B Fig. 7**：把 RL 训练任务和 Agentless Mini 的端到端评测任务严格分开。
5. **最后读 §3.3、§3.6 和 Limitations**：先看 repair-only、连续/离散奖励消融，再看 41.0% 的系统分数，最不容易被单一 leaderboard 数字误导。

一句话收束：**SWE-RL 的价值不只在于把 SWE-bench 分数推高，而在于展示了一个可扩展范式——把开放软件的“人类最终改动”转化为稠密策略学习信号；它也提醒我们，代理奖励可以打开训练规模，但不能替代语义验证与交互式软件工程。**

---

## 附：本报告的证据范围

- 论文事实、公式、数据规模、训练配置、评测设计和作者自述局限，均来自本地 `2025 SWE-RL.pdf`；已检查正文、附录 A-D 和论文 checklist。
- 源码映射来自本地 `swe-rl/` 官方仓库快照；关键文件为 `README.md`、`src/swerl/core/prompts.py`、`src/swerl/core/reward.py`、`src/swerl/agentless_mini/{localize,repair,rerank}.py`。
- 未访问互联网或替换用户提供的版本；报告中“补充判断”均明确标为分析推断，而非作者原始实验结论。
