# 面向 Agent Reinforcement Learning 的 Agent Sandbox 快速 Checkpoint/Restore 技术研究提纲

## 1. 报告目标与核心研究问题

本报告面向 **Agent Reinforcement Learning（AgentRL）中的 Agent Sandbox
快速 Checkpoint/Restore（C/R）** 场景，目标是从 AgentRL
的运行机制出发，理解为什么环境状态管理会成为 AgentRL
基础设施中的关键问题，并进一步梳理 Agent Sandbox 快速 C/R
的技术发展脉络、主要技术路线和未来研究方向。

建议整篇报告围绕以下问题链条展开：

> **AgentRL 为什么需要大量环境交互 → 环境为什么具有状态 → 为什么需要
> Agent Sandbox → 为什么传统 Sandbox 生命周期管理无法满足 AgentRL →
> 为什么 C/R 会进入 AgentRL 的关键路径 → Fast C/R 需要解决哪些问题 →
> 当前有哪些技术路线？**

核心研究问题可以概括为：

> **如何让大量 Agent Rollout 低成本地从相同或中间 Environment State
> 出发，实现快速恢复、分叉、探索、复用和回收？**

------------------------------------------------------------------------

# Part I：Agent Reinforcement Learning

## 2. AgentRL 研究背景与发展脉络

### 2.1 从 LLM RL 到 Agent RL

建议按照以下技术演进路线进行介绍：

``` text
Traditional LLM RL
Prompt → LLM → Response → Reward

        ↓

Reasoning RL
Prompt → Reasoning Trajectory → Answer → Reward

        ↓

Agent RL
Task
 ↓
Agent
 ↓
Action → Environment
 ↑          ↓
Observation ← State Change
 ↓
Action → Environment
 ↓
...
 ↓
Reward
```

重点解释 AgentRL 与传统 LLM RL 的区别。

传统 LLM RL 的主要优化对象是：

``` text
Prompt → Response
```

而 AgentRL 的训练过程变为：

``` text
State_t
   ↓
Agent
   ↓
Action_t
   ↓
Environment
   ↓
State_{t+1}
   ↓
Observation_{t+1}
```

因此 AgentRL 的核心变化之一是：

> **Policy 开始与 Stateful Environment 持续交互。**

系统状态也不再只有 LLM Context，而是：

``` text
Agent State
+
Environment State
```

这一变化是后续引出 Agent Sandbox 与 Environment State Management
的基础。

### 2.2 AgentRL 的研究背景

建议重点研究：

-   为什么传统 RLHF / Reasoning RL 无法覆盖复杂 Agent 任务；
-   Tool Use、Coding Agent、Web Agent、Computer Use Agent 等场景如何推动
    AgentRL；
-   AgentRL 为什么需要真实或高保真的交互环境；
-   Long-horizon task 对 RL training infrastructure 带来的影响；
-   Agent rollout 数量增长后，环境侧开销如何逐渐成为系统瓶颈。

### 2.3 AgentRL 的发展脉络

重点梳理：

-   LLM RLHF；
-   Reasoning RL；
-   Tool-use RL；
-   Multi-turn RL；
-   Agentic RL；
-   Environment-based RL；
-   Long-horizon Agent RL。

同时选取代表性框架和论文分析其系统架构。

------------------------------------------------------------------------

## 3. AgentRL 系统架构

建议从系统视角，而不是单纯从 RL 算法视角理解 AgentRL。

典型架构：

``` text
                 ┌──────────────┐
                 │   Trainer    │
                 └──────┬───────┘
                        │
               Policy / Parameters
                        │
                 ┌──────▼───────┐
                 │ Rollout Engine│
                 └──────┬───────┘
                        │
              Massive Parallel Episodes
                        │
        ┌───────────────┼───────────────┐
        ▼               ▼               ▼
     Agent 1          Agent 2         Agent N
        │               │               │
        ▼               ▼               ▼
    Sandbox 1       Sandbox 2       Sandbox N
        │               │               │
        ▼               ▼               ▼
   Environment      Environment     Environment
        │
        ▼
 Trajectory / Reward
        │
        ▼
 Policy Optimization
```

### 3.1 核心组件

重点介绍：

-   Trainer
-   Actor / Policy Model
-   Rollout Engine
-   Rollout Worker
-   Environment Manager
-   Agent Sandbox
-   Tool Runtime
-   Reward / Verifier
-   Replay / Trajectory Storage
-   Reference Model
-   Scheduler

需要说明不同组件之间的数据流和控制流。

------------------------------------------------------------------------

## 4. AgentRL 完整训练流程

建议围绕"一次 rollout 到底发生了什么"展开。

``` text
Task
 │
 ▼
Initialize Environment
 │
 ▼
Agent Observation
 │
 ▼
LLM Inference
 │
 ▼
Tool Call
 │
 ▼
Sandbox Execution
 │
 ▼
Environment State Mutation
 │
 ▼
New Observation
 │
 ├──────────────┐
 │              │
 ▼              │
LLM Inference   │
 │              │
 ▼              │
Tool Call       │
 │              │
 └──────────────┘
 │
 ▼
Terminal State
 │
 ▼
Verifier / Reward
 │
 ▼
Trajectory
 │
 ▼
PPO / GRPO / Other RL Algorithm
 │
 ▼
Policy Update
```

重点解释：

> **Agent rollout 已经不再只是 Token Generation，而是 LLM Inference +
> Tool Execution + Environment State Transition。**

### 4.1 AgentRL 关键技术

建议研究：

-   PPO / GRPO 等 RL 算法；
-   Multi-turn rollout；
-   Long-horizon trajectory；
-   Tool calling；
-   Reward / Verifier；
-   Parallel rollout；
-   Async rollout；
-   Rollout scheduling；
-   Environment management；
-   Branching / Tree Search；
-   Best-of-N；
-   Experience replay / trajectory reuse。

------------------------------------------------------------------------

# Part II：从 AgentRL 引出 Agent Sandbox

## 5. AgentRL 的系统挑战

这一部分作为 AgentRL 与 Sandbox C/R 之间的桥梁。

核心问题：

> **AgentRL Scaling 到底贵在哪里？**

可以将成本分为两部分：

``` text
AgentRL Scaling
│
├── Model Side
│   ├── LLM Inference
│   ├── Training
│   └── Communication
│
└── Environment Side
    ├── Sandbox Creation
    ├── Environment Initialization
    ├── Environment Reset
    ├── State Duplication
    ├── Fork
    ├── Rollback
    ├── Tool Execution
    └── Cleanup
```

重点研究：

-   Environment initialization；
-   Sandbox creation；
-   Repository / dependency initialization；
-   Tool execution；
-   Environment reset；
-   Parallel rollout；
-   Tree search / branch rollout；
-   Failure recovery；
-   Rollout state duplication；
-   GPU 与 Sandbox execution pipeline 的资源错配。

------------------------------------------------------------------------

## 6. Agent Sandbox

### 6.1 什么是 Agent Sandbox

首先回答：

> **为什么 Agent 不能直接运行在 Host Environment 中？**

Agent Sandbox 的主要能力包括：

``` text
Isolation
Security
Reproducibility
Resource Control
State Management
Parallel Execution
```

### 6.2 Agent Sandbox 与传统 Container / VM 的区别

传统 Sandbox 生命周期通常为：

``` text
Create
 ↓
Run
 ↓
Destroy
```

而 AgentRL 中的 Sandbox 生命周期可能逐渐演变为：

``` text
Create
 ↓
Initialize
 ↓
Run
 ↓
Checkpoint
 ↓
Fork ───→ Rollout A
 │
 ├──────→ Rollout B
 │
 └──────→ Rollout C
 ↓
Restore
 ↓
Run
 ↓
Checkpoint
 ↓
...
```

因此 Agent Sandbox 不再只是：

> **Isolated Execution Environment**

而逐渐成为：

> **Stateful Agent Execution Environment**

------------------------------------------------------------------------

# Part III：Environment State Management

## 7. 什么是 Environment State

需要首先明确：

> **所谓 Restore，究竟 Restore 了什么？**

建议将 Agent Environment State 分层：

``` text
Environment State
│
├── Filesystem State
│   ├── Source Code
│   ├── Generated Files
│   └── Dependencies
│
├── Process State
│   ├── Processes
│   ├── Threads
│   ├── Registers
│   └── Memory
│
├── Runtime State
│   ├── Sockets
│   ├── Pipes
│   ├── File Descriptors
│   └── IPC
│
├── Logical Agent State
│   ├── Conversation
│   ├── Trajectory
│   ├── Tool History
│   └── Agent Memory
│
├── LLM State
│   ├── Context
│   └── KV Cache
│
└── External World State
    ├── Database
    ├── Remote Service
    ├── Browser / Web State
    └── External APIs
```

需要特别区分：

``` text
Git Restore
    ≠
Filesystem Restore
    ≠
Filesystem + Process Restore
    ≠
Complete Environment Restore
```

并讨论不同 State Layer 对：

-   Restore Fidelity
-   Restore Latency
-   Storage Cost
-   Isolation
-   Consistency

的影响。

------------------------------------------------------------------------

## 8. Environment State Management 核心能力

Fast C/R 不应该被孤立研究，而应该放入更大的 **Environment State
Management** 框架中。

``` text
Environment State Management
          │
          ├── Checkpoint
          ├── Restore
          ├── Rollback
          ├── Fork
          ├── Clone
          ├── State Reuse
          ├── State Scheduling
          └── State Garbage Collection
```

### 8.1 Checkpoint

研究：

-   Full checkpoint；
-   Incremental checkpoint；
-   Selective checkpoint；
-   Async checkpoint；
-   Semantic checkpoint。

### 8.2 Restore / Rollback

研究：

-   Full restore；
-   Partial restore；
-   In-place rollback；
-   Cross-node restore；
-   Lazy restore。

### 8.3 Fork

重点研究：

> 如何从同一个 Environment State 快速创建多个独立 rollout？

### 8.4 State Reuse

研究：

-   Initial state reuse；
-   Intermediate state reuse；
-   Prefix trajectory reuse；
-   Shared base state；
-   Cross-rollout state reuse。

### 8.5 State Garbage Collection

研究：

-   State lifetime；
-   Reference counting；
-   State dependency；
-   State eviction；
-   Storage reclamation。

### 8.6 State Scheduling

研究：

-   State locality；
-   Sandbox placement；
-   Cross-node migration；
-   Hot state caching；
-   State-aware rollout scheduling。

------------------------------------------------------------------------

# Part IV：为什么 AgentRL 需要 Fast C/R

## 9. Fast C/R 的典型 AgentRL 场景

建议通过 Coding Agent 场景进行直观说明。

假设 Agent 已执行：

``` text
Clone Repo
↓
Install Dependencies
↓
Build Project
↓
Read Code
↓
Locate Bug
↓
State S
```

此时希望探索三种修改：

``` text
                State S
                   │
           Checkpoint(S)
                   │
       ┌───────────┼───────────┐
       ▼           ▼           ▼
     Fork A      Fork B      Fork C
       │           │           │
   Patch A      Patch B      Patch C
       │           │           │
    Test A       Test B       Test C
       │           │           │
     R=0.2        R=1.0        R=0
```

### 9.1 没有 Fast C/R

每个 rollout 都可能需要：

``` text
Create Sandbox
→ Clone Repo
→ Install Dependencies
→ Build
→ Replay Agent History
→ Reach State S
→ Execute New Action
```

### 9.2 使用 Fast C/R

``` text
Prepare State S Once
        ↓
    Checkpoint
        ↓
   ┌────┼────┐
   ▼    ▼    ▼
 Fork Fork Fork
   ↓    ↓    ↓
   A    B    C
```

因此 Fast C/R 可以支撑：

-   Environment Reset
-   Parallel Rollout
-   Branching Rollout
-   Tree Search
-   Best-of-N
-   Speculative Agent Execution
-   Fault Recovery
-   State Reuse

核心价值是：

> **避免重复执行相同的环境初始化和 trajectory prefix，从而降低 rollout
> 成本并提高 AgentRL 吞吐量。**

------------------------------------------------------------------------

# Part V：Fast C/R 技术发展脉络

## 10. 第一阶段：传统 VM / OS Checkpoint-Restore

重点研究：

-   VM Snapshot
-   Container Snapshot
-   CRIU
-   Filesystem Snapshot

基本思想：

> **Capture Everything**

优势：

-   Fidelity 高；
-   通用性强。

问题：

-   State Size 大；
-   Checkpoint Latency 高；
-   Restore Latency 高；
-   Storage / Network Cost 高。

------------------------------------------------------------------------

## 11. 第二阶段：Copy-on-Write 与 Incremental State

主要技术：

-   OverlayFS
-   Copy-on-Write
-   Incremental Checkpoint
-   Dirty Page Tracking
-   Memory Snapshot
-   Filesystem Delta

基本思想：

> **不要复制整个 State，只保存相对于 Base State 的变化。**

状态结构可以表示为：

``` text
Traditional Full Snapshot

S0 → Full State
S1 → Full State
S2 → Full State

            ↓

Incremental State

S0 → Base
      │
      Δ1
      │
      Δ2
      │
      Δ3
```

------------------------------------------------------------------------

## 12. 第三阶段：Agent-aware / Semantic C/R

这一阶段是值得重点关注的研究方向。

核心问题逐渐从：

> **How can we checkpoint faster?**

发展为：

> **What should we checkpoint?**

以及：

> **Do we actually need a checkpoint at this Agent step?**

### 12.1 Delta / Change-based C/R

研究：

-   Agent 相邻状态之间的差异；
-   Filesystem Delta；
-   Process Delta；
-   State Deduplication；
-   Shared Base State。

代表方向：

-   DeltaBox 等。

### 12.2 Selective / Semantic C/R

研究：

-   哪些 Agent action 会真正修改 recovery-relevant state；
-   是否所有 Agent turn 都需要 checkpoint；
-   如何根据 action / syscall / state mutation 动态决定 checkpoint
    粒度。

代表方向：

-   Crab 等。

### 12.3 Async / Overlapped C/R

研究：

``` text
LLM Thinking / Inference
          │
          ├─────────────┐
          │             │
          ▼             ▼
     LLM Compute    Checkpoint
```

利用 Agent 的 LLM inference 时间隐藏 checkpoint 开销。

------------------------------------------------------------------------

# Part VI：当前 Fast C/R 的主要技术路线

## 13. 技术路线分类

建议系统比较以下技术路线：

### 13.1 Full Snapshot

完整保存：

-   Filesystem；
-   Memory；
-   Process；
-   Runtime state。

### 13.2 Filesystem-only Reset

只处理文件系统变化。

适合：

-   Coding Agent；
-   文件修改为主要环境变化的场景。

### 13.3 Process + Filesystem C/R

同时恢复：

-   Filesystem；
-   Process memory；
-   Runtime state。

### 13.4 Copy-on-Write Fork

利用共享 Base State：

``` text
              Base State
                  │
       ┌──────────┼──────────┐
       │          │          │
      ΔA         ΔB         ΔC
       │          │          │
   Rollout A  Rollout B  Rollout C
```

### 13.5 Incremental / Delta C/R

只保存：

``` text
State(t+1) - State(t)
```

### 13.6 Semantic / Selective C/R

根据 Agent Action 判断：

``` text
Agent Action
     ↓
State Mutation Analysis
     ↓
Need Checkpoint?
   /       \
 No        Yes
 |          |
Skip    Select State
```

### 13.7 State Cache / State Reuse

将常用 state 作为 cache：

``` text
Task
 ↓
Find Reusable State
 ↓
State Cache
 ↓
Restore
 ↓
Continue Rollout
```

------------------------------------------------------------------------

# Part VII：代表性系统与研究工作

## 14. 建议重点调研对象

### 14.1 基础系统技术

-   CRIU
-   Firecracker
-   Docker / Container Checkpoint-Restore
-   VM Snapshot
-   OverlayFS
-   Copy-on-Write Filesystem

### 14.2 Agent Sandbox / Agent Infrastructure

重点寻找：

-   Agent Sandbox Framework
-   RL Environment Infrastructure
-   Coding Agent Sandbox
-   Stateful Sandbox
-   Sandbox Pool
-   Environment Manager

### 14.3 Agent-native C/R

重点研究：

-   DeltaBox
-   Crab
-   其他 Agent-specific Checkpoint / Restore / Fork 工作

对于每个代表工作建议统一分析：

1.  Target Scenario
2.  State Model
3.  Checkpoint Granularity
4.  Restore Mechanism
5.  Fork Mechanism
6.  Storage Architecture
7.  Optimization Technique
8.  Checkpoint Latency
9.  Restore Latency
10. State Size
11. Fidelity
12. AgentRL Integration
13. Limitations

------------------------------------------------------------------------

# Part VIII：AgentRL + Fast C/R 系统架构

## 15. 建议重点构建的目标架构

``` text
                       AgentRL Trainer
                             │
                             ▼
                      Rollout Scheduler
                             │
              ┌──────────────┼──────────────┐
              │              │              │
              ▼              ▼              ▼
          Rollout A      Rollout B      Rollout C
              │              │              │
              └──────────────┼──────────────┘
                             │
                       Sandbox Manager
                             │
                     ┌───────┴────────┐
                     │                │
                     ▼                ▼
                Sandbox Pool      State Manager
                                      │
                     ┌────────────────┼───────────────┐
                     │                │               │
                     ▼                ▼               ▼
                Checkpoint         Restore           Fork
                     │                │               │
                     └────────────────┼───────────────┘
                                      │
                                  State Store
                                      │
                       ┌──────────────┼──────────────┐
                       ▼              ▼              ▼
                     Base           Delta          Cache
```

建议分析的核心模块：

-   Trainer
-   Rollout Scheduler
-   Environment Manager
-   Sandbox Pool
-   State Manager
-   Checkpoint Manager
-   Restore Engine
-   Fork Engine
-   State Store
-   State Cache
-   State Scheduler
-   Garbage Collector

------------------------------------------------------------------------

# Part IX：核心挑战

## 16. Fast C/R 面临的问题

### 16.1 C/R Latency

目标：

``` text
Checkpoint / Restore Cost
        <<
Agent Rollout Cost
```

### 16.2 State Size

需要解决：

-   Memory duplication；
-   Filesystem duplication；
-   Repeated dependency state；
-   Repeated runtime state。

### 16.3 Fidelity

需要明确：

> 恢复后的 Environment 是否与原状态等价？

### 16.4 Consistency

涉及：

-   Filesystem consistency；
-   Process consistency；
-   Runtime consistency；
-   External state consistency。

### 16.5 Isolation

Fork 后不同 rollout 必须互不影响。

### 16.6 Cross-node Restore

大规模 AgentRL 中：

``` text
Checkpoint @ Node A
        ↓
Restore @ Node B
```

涉及：

-   State transfer；
-   Network overhead；
-   Data locality。

### 16.7 External State

例如：

-   Database；
-   Browser；
-   Remote APIs；
-   External services。

这些状态可能无法简单通过 VM / Container snapshot 捕获。

### 16.8 GPU / Accelerator State

如果 Sandbox 内包含：

-   GPU process；
-   CUDA state；
-   NPU runtime；

Checkpoint / Restore 会更加复杂。

### 16.9 Large-scale State Scheduling

大规模 AgentRL 可能产生：

``` text
Thousands / Millions of States
```

因此需要解决：

-   Placement；
-   Caching；
-   Eviction；
-   Deduplication；
-   GC；
-   Scheduling。

------------------------------------------------------------------------

# Part X：未来研究方向

## 17. 值得关注的方向

### 17.1 Agent-aware State Abstraction

根据 Agent 行为理解：

> 哪些状态真正影响未来 trajectory？

### 17.2 Semantic Checkpoint

从：

``` text
System-level State
```

发展到：

``` text
Agent-relevant State
```

### 17.3 Hierarchical State

构建：

``` text
Environment State
│
├── Base State
├── Task State
├── Trajectory State
├── Step State
└── Temporary State
```

### 17.4 Incremental State

利用 Agent 相邻状态高度相似的特点，只记录变化。

### 17.5 State Deduplication

大量 rollout 共享：

-   OS image；
-   Dependencies；
-   Repository；
-   Environment prefix。

因此可以进行跨 Sandbox deduplication。

### 17.6 State Locality-aware Scheduling

让 rollout 尽可能被调度到已经缓存目标 State 的节点。

### 17.7 State Reuse

研究：

``` text
Trajectory Prefix
      ↓
Reusable State
      ↓
Different Rollouts
```

### 17.8 Distributed Fork

支持：

``` text
             State S
                │
       ┌────────┼────────┐
       ▼        ▼        ▼
    Node A   Node B   Node C
```

### 17.9 Environment State DAG

Agent 的状态天然可能形成：

``` text
                  S0
                   │
                  S1
               /      \
             S2        S3
           /   \        \
         S4    S5        S6
```

因此可以将 Environment State 管理抽象为一个 **State DAG / Versioned
Environment**。

### 17.10 RL-aware Sandbox Runtime

最终可能形成专门面向 AgentRL 的 Sandbox Runtime：

``` text
Traditional Sandbox Runtime
        +
Agent State Awareness
        +
Fast Checkpoint / Restore
        +
Fork
        +
State Reuse
        +
State Scheduling
        +
State GC
        =
RL-aware Agent Sandbox Runtime
```

------------------------------------------------------------------------

# 18. 建议的整体研究框架

最终建议用以下逻辑总结全文：

``` text
                     AgentRL
                        │
                Massive Rollouts
                        │
               Stateful Environment
                        │
                  Agent Sandbox
                        │
          Environment State Management
                        │
       ┌────────────────┼────────────────┐
       │                │                │
  Checkpoint         Restore            Fork
       │                │                │
       └────────────────┼────────────────┘
                        │
                    State Reuse
                        │
               State Scheduling / GC
                        │
                    Fast C/R
```

核心认知不是：

> **如何把 Sandbox Checkpoint 从几百毫秒优化到几十毫秒？**

而应该提升到：

> **AgentRL 正在把 Agent Sandbox
> 从"无状态的隔离执行容器"，变成"支持高频状态探索、分叉和复用的可版本化执行环境"。**

因此可以将更大的研究问题定义为：

# AgentRL Environment State Management

Fast Checkpoint / Restore 是其中最核心的系统 Primitive 之一。

------------------------------------------------------------------------

# 19. 建议 Agent 深度调研时重点回答的问题

1.  AgentRL 相比传统 LLM RL，为什么更加依赖 Stateful Environment？
2.  一次完整的 AgentRL rollout 中，Sandbox 位于什么位置？
3.  AgentRL 的 Environment Side 主要有哪些性能开销？
4.  Environment Reset 是否已经成为大规模 rollout 的瓶颈？
5.  AgentRL 哪些场景真正需要 Checkpoint / Restore？
6.  Branching / Tree Search / Best-of-N 如何受益于 C/R？
7.  Agent Environment State 应该如何分层？
8.  不同 State Layer 的恢复成本和 Fidelity 有什么区别？
9.  Full Snapshot、CoW、Incremental C/R、Selective C/R
    的核心差异是什么？
10. DeltaBox、Crab 等新工作分别解决了什么问题？
11. Agent-specific C/R 与传统 VM / Container C/R 的本质区别是什么？
12. Fast C/R 是否应该进一步演化为 State Reuse？
13. 大规模 AgentRL 是否需要 State-aware Scheduling？
14. 是否可以构建 Environment State DAG？
15. 最终是否需要一个专门面向 AgentRL 的 Stateful Sandbox Runtime？

------------------------------------------------------------------------

# 20. 推荐报告主线

整篇报告建议始终保持以下问题驱动链条：

> **AgentRL 为什么需要大量环境交互？**

↓

> **为什么这些交互会产生复杂的 Environment State？**

↓

> **为什么需要 Agent Sandbox 管理这些环境？**

↓

> **为什么传统 Create → Run → Destroy 生命周期无法满足大规模 AgentRL？**

↓

> **为什么需要 Checkpoint / Restore / Fork？**

↓

> **为什么 C/R 必须足够快？**

↓

> **如何通过 CoW、Incremental、Delta、Selective、Async 等技术实现 Fast
> C/R？**

↓

> **Fast C/R 如何进一步发展为 State Reuse、State Scheduling 和
> Environment State Management？**

最终将研究视角从单纯的 **Fast Checkpoint / Restore** 提升到：

> **面向 AgentRL 的高效 Environment State Management 与 Stateful Sandbox
> Runtime。**
