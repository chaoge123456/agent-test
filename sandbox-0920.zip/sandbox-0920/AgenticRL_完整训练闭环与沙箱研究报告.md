# AgenticRL 完整训练闭环与沙箱系统研究报告

> **范围与结论。** 本报告以本地 `Agentic-RL-Most-Detailed-Intro` 的教程与 `agentic-tau-rl` 参考实现为算法视角，以本地 OpenRLHF 为训练编排视角、AgentENV 为环境运行时视角，并用公开项目资料核验生态现状。它不做代码导读，而是回答：怎样把“模型 RL”“有状态工具环境”“可恢复的大规模沙箱”合成一个能真正训练的系统。
>
> **最重要的结论：** 公开生态里，尚难找到一个可验证的、成熟开源的单体项目同时把大规模 RL 训练、通用 Agent 工作流、隔离沙箱调度，以及面向分叉的快速 checkpoint/restore（C/R）全部做深。现实中的完整系统通常是**训练框架 + Agent/环境适配层 + 沙箱运行时 + 状态与评测服务**的组合；“一体化”首先是接口和调度的一体化，而不一定是一个仓库。

---

## 0. 先建立共同语言：AgenticRL 到底在训练什么

普通 LLM RL 的一条样本近似为“prompt → 一段模型输出 → reward”。AgenticRL 的一条样本则是一段闭环交互：

```text
任务/用户 + 初始环境状态
        ↓
Policy 生成动作（文字、工具调用、代码、浏览器操作）
        ↓
环境执行动作并改变状态 → 观测/工具结果
        ↓
Policy 再决策 …… 直到结束、失败或截断
        ↓
Verifier / Reward → 轨迹价值 → Advantage → 策略更新
```

因此，训练对象不只是“回答文本”，而是条件策略 \(\pi_\theta(a_t\mid h_t)\)：它在历史 \(h_t\)（对话、工具结果、文件、页面、数据库状态的文本化观测）下选择下一步动作 \(a_t\)。环境的状态转移为 \(s_{t+1}=f(s_t,a_t)\)。

这里有三个容易混淆、但必须分开的对象：

| 对象 | 谁拥有 | 例子 | 是否通常参与反向传播 |
|---|---|---|---|
| **Agent 轨迹** | rollout 系统 | prompt、动作 token、工具结果、终态 | 仅模型产生的动作 token 参与 loss |
| **环境状态** | 沙箱/环境平台 | 文件系统、进程、数据库、浏览器会话 | 否；但决定下一步观测与最终 reward |
| **训练状态** | Trainer | 权重、优化器、参考策略、数据队列 | 不直接是任务环境的一部分 |

本地 `agentic-tau-rl` 对这个边界的处理很有代表性：一轮包含“assistant 动作 + 随后的环境反馈”，拍平成 token 序列时只有前者的 loss mask 为 1，环境/用户/工具反馈为 0。这不是实现细节，而是 AgenticRL 的因果边界：**模型应学习自己做过的选择，不应被当作生成工具回显文本来训练。**

---

## 1. 问题一：有没有同时具备 OpenRLHF、环境管理平台和 AgentENV 能力的完整框架？

### 1.1 结论：有“接近完整的组合”，没有公开可验证的万能单体

应避免把“支持 Agentic RL”与“已具备大规模 stateful sandbox C/R”画等号。下表按公开可核验能力做定位，而非给项目排名。

| 项目/组合 | 强项 | 公开可见的缺口 | 与问题的关系 |
|---|---|---|---|
| **OpenRLHF** | Ray + vLLM 的高吞吐 rollout、PPO/GRPO/REINFORCE++ 等优化、可插拔 Agent executor、同步/异步流水线 | 不负责生产级沙箱生命周期、跨节点状态调度、快照 C/R | 是“训练与 rollout 编排层” |
| **AgentENV** | Firecracker microVM、分层文件/内存快照、pause/resume、fork、对象存储持久化、暖池与集群调度接口 | 不拥有策略优化、reward 学习、轨迹 advantage 与模型权重同步 | 是“状态化环境运行时” |
| **AReaL** | 异步分布式 RL、Agent workflow/在线代理、把常见 Agent SDK 的调用采集为 token 级训练数据 | 文档明确要求接入方为 Agent runtime 提供权限约束和隔离执行环境；不是 AgentENV 式快照沙箱平台 | 当前公开项目中最接近“训练 + 通用 Agent 接入”的一端 |
| **TRL + OpenEnv** | Gym 风格的 `reset/step/state` 环境契约；可部署隔离环境，并能接入 TRL 的 GRPO | OpenEnv 是环境接口/部署生态，非完整的多节点 RL 集群与高性能 C/R 状态管理器 | 很好的“环境标准层”，不是单体全栈替代品 |
| **AgentGym / benchmark suites** | 多环境、统一轨迹格式、并发探索和评测 | 重点在任务集合与评测，不是大模型分布式 trainer + snapshot runtime | 适合作为环境资产层 |
| **内部生产平台** | 头部团队很可能将上述能力内聚部署 | 细节、接口与性能数字通常不可审计，不能据此断言开源可复现 | 可能存在，但不应当作选型依据 |

因此，若“完整”指**一套可以训练真实代码/浏览器/业务 Agent 的生产闭环**，推荐的参考拼图是：

```text
训练控制面：OpenRLHF / AReaL / veRL / 其他 RL trainer
        +
Agent 适配与轨迹协议：Agent executor / OpenAI-compatible proxy / OpenEnv API
        +
环境数据面：AgentENV（或其他隔离执行平台）
        +
任务、verifier、reward、课程与数据治理服务
```

其中 AReaL 的设计尤其值得注意：它用 OpenAI/Anthropic 兼容接口代理 Agent 对模型的调用，从而捕获 token 级概率，而不要求重写既有 Agent 编排逻辑。这补上了“训练系统与复杂 Agent 框架之间的桥”。但它并不替你解决外部工具的安全隔离、可回滚文件状态和跨节点 snapshot locality；这些仍须交给 AgentENV 一类运行时。

### 1.2 为什么没有一个框架包打天下

这是职责冲突，而非单纯工程尚未完善。

- Trainer 追求 GPU 利用率、数值正确性、权重版本一致性和吞吐。
- Sandbox 追求安全隔离、内核/网络/进程的忠实恢复、低尾延迟与资源回收。
- Environment/Verifier 追求任务语义正确、可重复、难以被 reward hacking。
- Agent framework 追求工具编排、记忆、用户体验与线上兼容。

将四者完全绑定，会使每种环境都被迫依赖某种 VM、每个 Agent 都被迫改成某种训练 API，反而削弱环境多样性。合理目标是规定稳定契约：`task → reset/fork → action → observation → terminal → score`，以及 `trajectory → token spans/logprobs → reward/metadata → learner`。

### 1.3 对本地三个项目的准确定位

```text
OpenRLHF：如何把采到的可训练 token 轨迹高效地变成梯度？
AgentENV：如何让有状态、隔离的执行环境大量、快速且可重复地出现？
agentic-tau-rl：一条多轮轨迹为什么值得（或不值得）学习，信用如何分配？
```

三者并非替代关系，而是一条链的三个纵切面。将 AgentENV 称作“AgenticRL 框架”会遗漏训练；将 OpenRLHF 称作“沙箱系统”会遗漏状态与隔离；将 `agentic-tau-rl` 称作“生产集群”则会误读其作为算法/验证参考实现的定位。

---

## 2. 问题二：完整 AgenticRL 训练框架有哪些组件，如何交互，一个 epoch 怎样运行？

### 2.1 参考架构：三条数据面与一个治理闭环

```mermaid
flowchart LR
    TS[任务池 / 课程生成器] --> RS[Rollout Scheduler]
    RS --> SM[Sandbox Pool & State Manager]
    SM --> AE[Agent Executor]
    AE <--> IN[Inference / Rollout Engines]
    AE <--> ENV[Tools / Sandbox / External Simulators]
    ENV --> TV[Trajectory & Event Store]
    IN --> TV
    TV --> VG[Validator / Verifier / Reward]
    VG --> SQ[Quality Gate & Group Selector]
    SQ --> EX[Experience Buffer]
    EX --> LR[Trainer: Advantage / PPO / GRPO]
    LR --> CK[Checkpoint & Model Registry]
    CK --> IN
    TV --> OB[Observability / Audit]
    VG --> OB
    SM --> OB
```

| 组件 | 核心职责 | 输入 → 输出 | 典型错误 |
|---|---|---|---|
| **Task / curriculum manager** | 选题、难度、种子、目标状态与数据划分 | 任务规范 → episode 请求 | train/eval 泄漏、只生成易题导致 reward 方差消失 |
| **Rollout scheduler** | 将任务、模型版本、并发预算分配给 rollout worker | episode 请求 → worker/sandbox 租约 | 未考虑 snapshot 所在节点，造成远端恢复风暴 |
| **Inference engine** | 高效生成模型动作及其 token/logprob | 历史 → action token、logprob、版本号 | 用错权重版本、无法定位动作 token 范围 |
| **Agent executor** | 将 token 解码成工具动作，管理多轮上下文和终止 | action → env 调用；observation → 新上下文 | 将工具输出误当 policy 输出，或隐藏中间调用而无法训练 |
| **Sandbox / environment runtime** | 隔离执行、状态管理、工具/浏览器/代码运行 | reset/fork/exec → observation、状态句柄 | reset 不干净、状态串扰、恢复不忠实 |
| **Verifier / reward service** | 对终态、约束、轨迹和成本计分 | 轨迹 + 终态 → reward breakdown | LLM judge 噪声直接放大到每个 token |
| **Selector / buffer** | 质量门控、按 prompt 成组、保留元数据 | 候选轨迹 → 可训练经验 | 只收成功样本而把 RL 变成有偏 SFT |
| **Learner** | 估计 advantage、优化 actor/critic/ref-KL | 经验 → 新权重与统计 | group 构造错误、异步过陈旧、mask 错位 |
| **State & artifact store** | 持久化 snapshot、轨迹、权重、可审计证据 | 状态/事件 → 可恢复资产 | 只存最终 reward，无法复现或诊断 |

把它们压缩成一句话：**模型负责提出动作，环境负责把动作变成事实，verifier 负责判断事实，Trainer 只从可归因的模型动作中学习。**

### 2.2 两条关键契约

第一条是环境契约。它应至少返回以下信息，而不只是一个文本：

```text
reset(task, seed, base_state) -> {observation, sandbox_id, state_id}
step(action) -> {observation, done, tool_events, state_id, optional_reward}
fork(state_id) -> {child_state_ids}
restore(snapshot_id) -> {sandbox_id, state_id}
```

第二条是训练轨迹契约。它应保留：任务与环境版本、模型权重版本、每段动作 token 的起止位置和旧 logprob、每次观测、状态句柄、终止原因、reward 各分量、以及有效性标志。缺少其中任意一项，后续就难以判断是“模型错了”“环境坏了”还是“样本不可用于 on-policy 更新”。

本地 OpenRLHF 的 Agent executor 正是在第二条契约上工作：多轮执行器把 agent action ranges、环境反馈和累计 reward 一起交回训练系统，因而 optimizer 能仅针对动作区间计算 policy loss。`agentic-tau-rl` 的 `Turn / Trajectory / Sample` 则用更小的参考实现说明了相同原则。

### 2.3 一个同步 epoch 的标准流程

这里的 epoch 指“用固定或近似固定策略采一批经验，再完成一轮更新”的语义周期；在流式异步系统中，它可能没有严格的全局边界。

1. **冻结 rollout 版本。** Trainer 发布 \(\theta_k\)，rollout worker 记录 `policy_version=k`。任务管理器抽取 \(B\) 个任务，每题计划 \(N\) 条候选轨迹。
2. **分配基态。** Scheduler 为每个任务选择模板/快照；如果是独立样本，恢复同一 clean base；如果是从某一步分支，先恢复共同父状态再 fork (N) 个子环境。
3. **交错执行。** Policy 生成一段动作 token，executor 解析为工具调用，sandbox 执行后返回 observation；直到 `done`、超时、违反安全策略或达到 token/step 上限。每一步记录事件和动作 token span。
4. **封存并验证。** 对每条轨迹检查协议完整性、环境版本、工具错误、状态泄漏、超时和可重放性；再由确定性 verifier 读取终态、单元测试、数据库断言或结构化目标。
5. **计算 reward。** 先算 outcome/safety/cost 等分量，后做有约束的聚合；将返回的 breakdown 与轨迹绑定，而不是只保存一个浮点数。
6. **组内构造学习信号。** 同一个任务的 \(N\) 条样本形成 group；筛掉无效样本后，若仍满足算法要求，计算组相对 reward 与 advantage。对于 GRPO，常见形式是 \(A_i=(R_i-\mu_G)/(\sigma_G+\epsilon)\)。
7. **优化。** 根据动作 token 的旧/新 logprob、mask、advantage、KL 约束和可选 critic，执行若干 minibatch 更新，得到 \(\theta_{k+1}\)。环境 observation 永远是上下文，不是 loss target。
8. **发布与回收。** 训练端保存模型/优化器 checkpoint，向 inference engine 广播新权重；Scheduler 销毁临时沙箱、保留有价值的状态/轨迹/失败样本，按 TTL 和引用计数回收其余资源。
9. **评测与课程闭环。** 固定 holdout 在独立 clean state 上评测；按失败类型、方差、成本和安全信号更新下轮任务分布，而不是仅看训练 reward。

### 2.4 异步 epoch 改变了什么

为提升 GPU 与环境利用率，OpenRLHF 等系统可以将生成、训练和权重广播重叠。其收益是把“GPU 等环境”减少为队列化流水线；代价是样本的行为策略可能落后于当前 \(\theta\)。因此异步系统应同时记录 policy version、限制队列长度/陈旧度，并在必要时做 importance correction、丢弃过陈旧样本或采用更稳健的 on-policy 近似。

异步不是免费吞吐：它把同步等待转换为**可控的 off-policy 风险**。特别是在长轨迹、C/R 或外部工具使生成很慢时，队列越深，策略版本差距越大。

---

## 3. 问题三：沙箱在 AgenticRL 中做什么，性能要求是什么，是否需要快速 C/R 与大规模并发？

### 3.1 沙箱不是“执行一条 shell 命令”的容器

在代码、浏览器、终端、数据分析、业务工具和多用户模拟任务中，环境往往有可变状态：工作区文件、进程、依赖缓存、浏览器 cookie、数据库、服务端口和网络策略。沙箱承担五类职责：

1. **隔离与安全。** 不同 rollout 不应共享进程、凭据、写目录或网络权限；不可信 agent 不应越过资源、网络和系统边界。
2. **语义执行。** 将工具调用真正作用于有状态世界，使“写错文件/改错记录/启动失败”能够影响后续 observation 和 reward。
3. **可重复初始化。** 同一任务、模板、随机种子应从同一基态开始，避免前一条轨迹污染后一条。
4. **可恢复与可分叉。** pause/resume、checkpoint/restore、rollback、fork 使长任务可暂停、失败可重试、共同前缀可复用、分支搜索可并行。
5. **资源治理与可观测。** 配额、TTL、清理、审计、日志、版本和故障恢复是训练可持续运行的前提。

### 3.2 AgenticRL 对沙箱的性能 SLO

没有一个放之四海而皆准的毫秒阈值，合理 SLO 应由整条 trajectory 的时间预算决定。不过可将要求分为四层：

| 层 | 关键指标 | 为什么重要 |
|---|---|---|
| **启动/重置** | p50/p95 reset、冷启动率、模板命中率 | 每条 episode 都可能支付；尾延迟决定集群空转 |
| **运行** | 工具执行时延、I/O 吞吐、网络隔离开销、资源密度 | 多轮轨迹会累加；运行慢会压低 GPU 采样供给 |
| **状态操作** | pause/resume、snapshot/restore/fork p95，增量大小 | 决定重试、Best-of-N、树搜索是否可用 |
| **规模与可靠性** | 并发沙箱数、成功率、泄漏率、回收时间、状态可用性 | 一个偶发脏状态就可能污染整批训练信号 |

性能的优先级通常是：**先保证隔离/忠实/可观测，再降低尾延迟，最后追求平均吞吐。** 一个 10 ms 但偶尔把父环境写坏的 fork，远差于一个 100 ms 且语义可靠的 fork。

### 3.3 快速 C/R 与大量并发是刚需吗？分场景判断

是，但并非所有 AgenticRL 任务都同等依赖。

| 场景 | 是否强依赖 C/R | 原因 |
|---|---|---|
| 数学/静态文本工具调用 | 通常弱 | 环境接近无状态，重新构造成本低 |
| 短代码题、一次性容器任务 | 中等 | reset 很多，但每次可用 clean image 重建 |
| 浏览器/代码仓库/多服务任务 | 强 | 初始化依赖、文件与进程状态重，轨迹多轮且昂贵 |
| 同题 (N) 次采样（GRPO/Best-of-N） | 强 | (N) 个候选应共享同一 clean base，而不能顺序污染 |
| tree search、错误恢复、反事实评估 | 极强 | 从共同前缀 fork 比从头重跑节省大量时间，也保证比较公平 |
| 长程在线 Agent 训练 | 强 | pause/restore 释放空闲资源，避免将长期会话永久占住 CPU/RAM |

AgentENV 的设计体现了后几类需求：以 Firecracker microVM 隔离，以分层块存储维护文件系统，以内存快照、写时复制和暖池缩短 resume/fork 路径，并将 snapshot 持久化到共享存储。它将“状态”视作一等对象，而不是训练框架的一段临时日志。

### 3.4 大规模并发为什么不只是“多起几个容器”

并发 rollout 会同时争夺至少三种资源：GPU 上的 prefill/decode 槽位、CPU/内存/磁盘/网络上的沙箱槽位、以及快照/镜像存储带宽。若只扩沙箱数，模型推理成为瓶颈；若只扩 GPU，模型又会等环境。有效系统需要背压和协同调度：

```text
可完成 rollout 速率 ≈ min(推理服务能力, 沙箱执行能力, 状态恢复能力, verifier 能力)
```

更细一点，Scheduler 应优先把需要某 snapshot 的任务放到其本地缓存或同一节点，选择暖的模板/网络槽位，限制同一远端镜像或数据库的突发访问，并按任务的预计长度而不是简单轮询分配资源。这是“state locality-aware scheduling”的价值所在。

---

## 4. 问题四：沙箱生成轨迹阶段的时延如何分解？C/R 会不会成为瓶颈？

### 4.1 一条轨迹的端到端时延模型

对第 (j) 条有 (K_j) 个 agent 决策轮的轨迹，可用下式做容量规划：

$$
T_{\mathrm{traj},j}=T_{\mathrm{alloc}}+T_{\mathrm{base}}+
\sum_{t=1}^{K_j}\left(T_{\mathrm{prefill},t}+T_{\mathrm{decode},t}+T_{\mathrm{parse},t}+T_{\mathrm{env},t}\right)
+T_{\mathrm{verify}}+T_{\mathrm{persist}}.
$$

其中：

- \(T_{\mathrm{alloc}}\)：调度、租约、排队；
- \(T_{\mathrm{base}}\)：冷启动、reset、restore 或 fork；
- \(T_{\mathrm{prefill}}+T_{\mathrm{decode}}\)：LLM 读上下文和生成动作；
- \(T_{\mathrm{parse}}\)：解析/校验 action、代理转发；
- \(T_{\mathrm{env}}\)：工具、代码、浏览器、数据库、网络服务实际执行；
- \(T_{\mathrm{verify}}\)：终态断言、单元测试、judge 或规则评估；
- \(T_{\mathrm{persist}}\)：轨迹、状态和审计事件落盘。

这个式子说明一个反直觉事实：**沙箱并不自动是主要瓶颈。** 对于 32k token 的长推理，decode/prefill 可能远超过一次 restore；对于一个只生成数十 token、但每次冷起 VM/拉镜像/装依赖的任务，环境基态操作反而支配总时延。

### 4.2 判断 C/R 是否为瓶颈的三个比率

不要只报 “restore 50 ms”，而应同时看：

$$
\rho_{\mathrm{CR}}=
\frac{T_{\mathrm{base}}+T_{\mathrm{checkpoint}}}{T_{\mathrm{traj}}},\qquad
\rho_{\mathrm{cold}}=\frac{\#\,\text{cold start}}{\#\,\text{all start}},\qquad
\rho_{\mathrm{tail}}=\frac{p95(T_{\mathrm{traj}})}{p50(T_{\mathrm{traj}})}.
$$

- 当 \(\rho_{\mathrm{CR}}\) 很高时，优先做 snapshot/warm pool/CoW/state locality；增加 GPU 没有用。
- 当 \(\rho_{\mathrm{cold}}\) 很高时，问题常是缓存和调度，而不是 C/R 算法本身。
- 当 \(\rho_{\mathrm{tail}}\) 很高时，少数拉镜像、恢复远端状态、工具超时会拖住整个同步 batch；异步流水线或 straggler 策略更重要。

### 4.3 C/R 成为主瓶颈的典型模式

1. **每条短轨迹都全量重建环境。** 例如创建 VM、下载镜像、安装依赖后只执行一次工具调用。此时 \(T_{\mathrm{base}}\gg \sum T_{\mathrm{decode}}\)。
2. **同一共同前缀被反复执行。** Best-of-N 或树搜索从头跑 (N) 次，浪费了前缀状态；应在决策点 snapshot/fork。
3. **快照过大或脏页过多。** 将全部内存/磁盘全量复制到远端，使 checkpoint 被带宽主导；应采用增量层、脏页跟踪、异步上传和层去重。
4. **状态不在本地。** 任务被调度到没有目标 snapshot 的节点，导致 restore 变成远端读取；缓存命中率比单次 restore 微优化更关键。
5. **同步批次被少数异常环境阻塞。** p50 很快而 p99 很慢，仍会使 GPU 在 barrier 前空转。

相反，若一次环境恢复仅占几百轮模型 decode 的很小比例，优化 C/R 对吞吐的边际收益有限；此时应优先优化推理 batching、前缀缓存、工具并行和 verifier。

### 4.4 设计上的正确顺序

```text
测量端到端 trace
→ 分开统计 cold start / restore / tool / inference / verifier
→ 先降低冷启动与尾延迟
→ 用 checkpoint 复用“昂贵共同前缀”
→ 以任务组和状态 locality 调度
→ 最后才扩大无差别并发
```

这也解释了为什么 AgentENV 同时需要分层快照、页缓存共享、持久存储、暖 Firecracker/网络/块设备池：只加一个 `snapshot()` API 不能解决状态传输、缓存命中和资源释放问题。

### 4.5 截至 2026 年 9 月：沙箱系统的主要瓶颈在哪里

近期系统工作给出的共同结论是：**基本的“启动隔离环境”正在变快，真正难点已转移到“以正确的语义管理、复用、分发和恢复完整状态”。** 因而不应只用冷启动时间判断一个 AgenticRL 沙箱系统。

| 瓶颈 | 为什么它仍是主要问题 | 最新研究/工程证据 | 对 AgenticRL 的直接影响 |
|---|---|---|---|
| **完整状态的 C/R 成本** | 文件系统之外还有进程地址空间、运行时上下文、已启动服务与内存脏页；全量复制会随状态膨胀 | DeltaBox 指出传统机制在每次 C/R 复制完整文件与进程状态，常达数百毫秒至秒级；其增量设计报告 checkpoint 14 ms、rollback 5 ms | 限制树搜索深度、失败重试频率、同前缀的 N 路 rollout |
| **Agent 语义与 OS 状态的错位** | Agent 框架只知道“调用了什么工具”，OS 只看到文件/进程变化；二者都无法单独判断何时必须 checkpoint | Crab 报告称超过 75% 的 agent turn 没有恢复相关状态，说明逐 turn 全快照浪费；但只存对话历史又会遗漏 OS 副作用 | checkpoint 太勤会耗尽 I/O，太少又不能可靠 rollback；这是正确性与效率的矛盾 |
| **跨节点状态分发与 locality** | 快照可能含数百 MB 至 GB 的内存/磁盘层；状态不在执行节点时，快 restore 会退化为远端读取/上传 | AgentENV 的公开 issue 表明现有策略可采用 round-robin 而不感知节点缓存；其 P2P snapshot 议题也明确将中心存储上传与网络带宽视作关键路径问题 | 沙箱数量增加后，存储/网络而非 VM 启动拖慢吞吐；同一 batch 的尾延迟变长 |
| **高并发下的资源密度与尾延迟** | 长短不一的 agent task 共同竞争 CPU、内存、page cache、磁盘、网络和工具服务；平均值掩盖 straggler | AgentENV 以内存 ballooning、共享页缓存和 warm pool 解决资源密度，恰好说明这些仍是系统关键路径 | 同步 batch 等待少数慢环境，GPU 推理槽位空转；盲目扩并发常降低有效吞吐 |
| **环境恢复与 LLM 上下文的一致性** | 恢复了文件或容器，不代表模型历史、工具事件 ledger 与环境前缀仍一致 | Belayer 将“联合恢复容器文件系统/运行时状态，并与 LLM context 协调以保持 prefix consistency”作为核心问题 | 错配会产生不可重放轨迹和错误 reward，污染 on-policy 数据，而不仅是一次执行失败 |
| **外部副作用不可回滚** | 支付、邮件、远程数据库、第三方 API、人类用户状态不在 VM 快照里 | 这属于所有 VM/container C/R 的边界，而非某个快照实现可自动解决的问题 | 需要 shadow state、事务、幂等键、补偿操作或事件重放；否则 branching 既不安全也不公平 |
| **隔离强度、可观测性与性能的张力** | 为不可信模型提供网络限制、凭据隔离、审计和多租户清理会增加执行与运维复杂度 | AgentENV 选择 microVM 与独立网络/文件系统；Crab 选择 eBPF 观察 OS effect，均说明安全/可观测不是外围功能 | 只追求低时延可能破坏训练可信性；安全策略和审计必须进入 capacity planning |

优先级随任务形态改变：短轨迹、频繁分支时，增量 C/R 与语义选择最关键；长轨迹、重工具执行时，推理/工具时延通常更大，但 C/R 的 p95 仍决定 batch 尾部；多节点、大状态集群中，snapshot 分发、缓存命中与 locality 调度最关键；涉及真实外部系统时，事务一致性与副作用治理则不是 C/R 可以单独解决的问题。

这里有一个重要的研究转向：从“每一步都做完整 checkpoint”转向**增量 + 语义选择 + 异步重叠**。DeltaBox 的思路是只保存连续 checkpoint 的变化；Crab 则根据 OS 可见副作用决定是否需要 checkpoint，并把必要的 C/R 与模型等待时间重叠；AgentENV 使用分层文件/内存状态、共享页缓存和暖池。三条路线解决的是同一个问题的不同层面，且必须同时满足：

1. **Fidelity：** 恢复后文件、进程、服务、动作日志与模型上下文代表同一个历史前缀；
2. **Latency：** checkpoint/restore/fork 不应主导短分支任务的关键路径；
3. **Locality：** 任务尽量移动到状态所在处，而不是让状态反复穿过网络；
4. **Isolation：** fork 的子环境能独立写入，且不会泄漏凭据、网络或父状态；
5. **Economics：** 被长期保留的状态须有生命周期、引用计数、配额和 GC，否则快照本身变成存储债务。

因此，在当前系统中“快速 C/R”依然是关键，但更精确的说法是：**C/R 的瓶颈已从单次 API 延迟，升级为状态语义、数据路径、调度与一致性的联合瓶颈。** 只把单机 checkpoint 从 100 ms 优化到 10 ms，而没有解决跨节点 cache miss、外部副作用或 LLM-prefix 对齐，无法得到可靠的规模化 AgenticRL。

---

## 5. 问题五：沙箱生成的执行轨迹怎样选择？reward 怎样计算？

### 5.1 先区分四个动作：验证、评分、筛选、信用分配

它们不能合并成“根据 reward 选好轨迹”。

| 阶段 | 要回答的问题 | 典型输出 |
|---|---|---|
| **验证（validation）** | 这条轨迹是否真实、完整、可比较、没有环境异常？ | valid/invalid + 原因 |
| **评分（scoring）** | 行为的结果、约束和代价如何？ | reward breakdown |
| **筛选（selection）** | 哪些经验值得进入某种训练目标？ | group、权重、丢弃原因 |
| **信用分配（credit assignment）** | 一条轨迹的 reward 应怎样影响哪个动作/哪个时刻？ | trajectory/turn/token advantage |

本地材料反复强调第四点：终态 (R\in\{0,1\}) 直接广播给长轨迹的所有动作会错分 credit；但将噪声 judge 分数粗暴地逐 turn 注入，也可能比稀疏奖励更不稳定。因此，reward 稀疏、轨迹选择和 credit assignment 是三个相连但独立的设计问题。

### 5.2 评分：以“可验证结果”为主，以过程信号为辅

一个通用的 reward 分解可写为：

$$
R(\tau)=R_{\mathrm{outcome}}(\tau)
-\lambda_c C_{\mathrm{cost}}(\tau)
-\lambda_l C_{\mathrm{length}}(\tau)
-\lambda_s C_{\mathrm{safety}}(\tau)
+\lambda_p R_{\mathrm{process}}(\tau).
$$

但这不是建议“把所有分项线性相加”。实践中更稳妥的顺序是：

1. **硬门（不可补偿）。** 安全越权、环境逃逸、非法工具参数、不可恢复的数据破坏、任务终态错误应直接判无效或把 outcome 置零。
2. **确定性 outcome。** 优先用单元测试、数据库终态、文件 diff、schema、浏览器 DOM/任务断言等可复现 verifier。本地 tau² 示例以指定 reward basis 的分量乘积作为终态 gate：一个关键 DB/环境/沟通断言失败即可失败。
3. **软目标。** 在结果正确的前提下，再考虑 token/时间/工具成本、重复调用、用户打扰、偏好质量和鲁棒性。
4. **过程信号。** 对没有廉价确定性中间检查的任务，可用规则、PRM 或 LLM judge；但必须离线校准其与最终成功的相关性、跨长度偏差和被攻击可能性。不要让“看起来合理”压过“最终确实做对”。

一个实用的层级形式是：

$$
R(\tau)=\mathbb{1}[\mathrm{safe}(\tau)]\cdot\mathbb{1}[\mathrm{valid}(\tau)]
\cdot\bigl(R_{\mathrm{goal}}+R_{\mathrm{quality}}-C_{\mathrm{effort}}\bigr).
$$

这样能避免 Agent 通过刷过程分、冗余工具调用或“貌似努力”的文字获得高 reward。对于会修改现实外部资源的系统，建议先使用模拟器或事务性 shadow state；外部状态不可由本地 snapshot 回滚，不能假设 C/R 会替你撤销支付、邮件或线上数据库写入。

### 5.3 验证与质量门：先去掉不可学样本

进入 optimizer 前应至少标记并通常剔除：

- 超时、解析失败、模型服务中断、沙箱崩溃且无法判定终态；
- 工具事件/动作 token/logprob 不完整，无法重放或计算 ratio；
- reset 失败、跨 episode 状态污染、使用了错误模板/任务版本；
- 含机密、越权访问或违反安全策略的轨迹；
- 训练/验证集混杂，或 verifier 本身异常。

这一步是**数据完整性**而非“挑好看结果”。若把系统异常当成失败 reward，模型可能学会规避工具；若把异常当成成功或悄悄丢掉，又会扭曲任务难度统计。因此要记录 discard reason 和比例，并触发运行时告警。

### 5.4 同一任务的多条候选：不同算法的正确选法不同

对于同一 prompt/初始状态生成 (N) 条候选，先确保它们使用等价的 base state、同一任务版本、可比的预算。然后：

| 目标 | 推荐处理 | 不该做什么 |
|---|---|---|
| **GRPO / group-relative RL** | 尽量保留同组所有有效候选，以组内均值/方差形成相对 advantage | 只留最高分再假装仍是原始 group；这会破坏 baseline 语义 |
| **PPO / actor-critic** | 保留满足 on-policy/版本窗口的有效轨迹，按 advantage 与 mask 更新 | 混入无旧 logprob 的历史“好轨迹”当作 PPO 样本 |
| **Rejection sampling / SFT 蒸馏** | 明确转为“条件化优质行为数据”，保留选择概率/来源，独立于 on-policy RL 报告 | 把只含成功的 Best-of-N 当作无偏 RL rollout |
| **Best-of-N 推理评测** | 只用于展示“有搜索预算时的上界”或服务时选择 | 与 pass@1、单样本 RL 训练效果混为一谈 |
| **课程/失败挖掘** | 选择可诊断、可验证的失败类型，生成新任务后经独立 verifier 审核 | 让教师模型的自然语言猜测直接成为 ground truth |

特别要警惕 group saturation：若同一任务的候选全成功或全失败，GRPO 的组内方差接近零，学习信号会消失。处理手段包括调整任务难度/采样温度/候选数，增加可靠的过程或反事实信号，或在明确说明偏差的前提下做动态过滤；不是简单地把所有零方差样本都称为“无价值”。

### 5.5 credit assignment：reward 到梯度不是一跳完成

最朴素的做法是把一个 trajectory advantage 广播到全部 policy token。它稳定、简单，但会把后期偶然成功的功劳归给早期无关动作。更细的方式包括：

- **Reward-to-Go（R2G）。** 用 \(G_t=r_t+\gamma G_{t+1}\) 将后续回报向前传播，适合有合理 step reward 或明确时间折扣的交互任务。
- **Counterfactual / information gain。** 比较保留或遮蔽某轮反馈后策略分布的变化，为“哪一轮 observation 真改变了决策”提供补充信号。
- **Turn-level/process reward。** 仅在 verifier/judge 足够可靠、且经过相关性检验时使用；更稳妥的变体会把多轮过程评分压缩为 trajectory-level 标量，防止局部 judge 噪声经 group normalization 放大。
- **行为正则化。** 对重复提问、过早放弃、无效工具循环、过长输出等进行明确惩罚；它应补充而不是替代 outcome。

无论采用哪一种，最终 loss 仍应只覆盖 policy 生成 token。环境观测是造成决策变化的条件，不是模型要模仿的标签。

---

## 6. 将 OpenRLHF、AgentENV 与本地 AgenticRL 参考实现接成一个实践闭环

下面是一个建议的、可逐步落地的组合架构。它不是声称三个仓库已经提供现成插件，而是依据各自公开边界给出的集成分工。

```text
1. OpenRLHF / AReaL
   - 维护 actor、ref/critic（视算法）、vLLM/SGLang rollout、优势估计与权重发布。

2. 自定义 Agent Executor
   - 为每条 episode 保存 {task_id, base_snapshot_id, sandbox_id, policy_version}。
   - reset 时向 AgentENV 请求从模板或 snapshot 恢复环境；step 时调用沙箱内工具。
   - 将 assistant action span、环境 observation、工具事件、结束状态组成训练轨迹。

3. AgentENV
   - 给每个 episode 提供隔离 microVM；为 N 个候选从同一父状态 fork。
   - pause/restore 管理长期或空闲会话；快照和环境镜像进入状态存储。

4. Verifier / Reward 服务
   - 读取受控的最终状态或事件 ledger；输出可审计 reward breakdown。
   - 不信任 agent 自报“我已完成”。

5. Trajectory store + observability
   - 连接 policy version、环境/快照版本、事件、reward、训练 batch 与指标。
```

### 6.1 推荐最小实施顺序

1. 先选一个**确定性、可重置、可验证**的小环境（文件/数据库/单元测试），做 pass@1 与完整事件记录。
2. 再接入多样本 rollout，验证同一基态下的组内比较与 action-token mask。
3. 引入 AgentENV 的模板恢复与 TTL；先解决 reset 污染、崩溃处理和审计。
4. 只在测得共同前缀重复、重置占比高或需要分支搜索时加入 snapshot/fork；不要过早把所有状态都 checkpoint。
5. 最后开启异步训练，并用 policy staleness、有效样本率、p95 trajectory latency、GPU 空转率与 reward 分布共同验收。

### 6.2 必须共同观测的指标

| 类别 | 最小指标 |
|---|---|
| 训练 | reward 均值/方差、有效 group 比例、KL、policy version lag、token 吞吐 |
| 轨迹 | 成功率、完成率、平均轮数、重复工具率、截断率、无效样本率 |
| 沙箱 | create/restore/fork p50/p95/p99、冷启动率、快照增量大小、缓存命中率、状态泄漏率 |
| 资源 | GPU 利用率、CPU/内存密度、对象存储流量、队列深度、straggler 比例 |
| 可信性 | verifier disagreement、可重放率、训练/评测隔离、外部副作用事件数 |

如果模型 reward 上升但可重放率下降、环境错误率上升或评测基态不干净，不能将其解释为模型能力提升。

---

## 7. 最容易犯的五个认知错误

1. **“有 `reset/step` 就等于有沙箱。”** `reset/step` 是环境 API；安全隔离、进程/文件状态、快照层、C/R 延迟、故障恢复是运行时问题。
2. **“快照越快，训练一定越快。”** 只有 C/R 在端到端关键路径占比高，或者它消除了共同前缀重复时才成立；必须看 \(\rho_{\mathrm{CR}}\) 与尾延迟。
3. **“只训练成功轨迹更高效。”** 这常把 RL 变成有选择偏差的蒸馏，丢掉负例、比较基线与错误恢复能力。若要这样做，应明确称为 rejection sampling/SFT 或混合目标。
4. **“过程 reward 越细越好。”** 高噪声的逐步 judge 会造成更严重的错误信用分配与 reward hacking；过程分必须被结果 verifier 约束并经相关性验证。
5. **“Agent state 可以被沙箱快照完全恢复。”** 沙箱通常只能恢复受它控制的本地状态。外部 API、远程数据库、消息发送、支付和人类用户状态需要幂等键、事务/补偿、shadow mode 或事件重放，不能依赖 VM restore。

---

## 8. 学习路线与最终总结

建议按以下顺序理解这个领域：

```text
先：一条多轮轨迹如何被正确表示（action vs observation、mask）
再：reward、选择与 credit assignment 为什么必须分层
再：PPO/GRPO 如何消费“同任务的多条可比较轨迹”
再：有状态环境为何要求 reset、isolation、verifier
最后：Fast C/R、fork、warm pool、state locality 如何把算法需求变成系统吞吐
```

完整 AgenticRL 的竞争力不在于某一个 PPO 公式，也不在于某个 microVM 的启动数字，而在于闭环是否完整：**从干净、可控的初始状态出发，让模型产生真实后果；用可信 verifier 给后果定价；仅将可归因的模型动作交给训练器；再以高效、隔离、可恢复的状态系统把这一闭环扩到足够大的规模。**

---

## 参考材料与证据边界

### 本地材料

- [Agentic-RL-Most-Detailed-Intro 总览](</D:\工作空间\sandbox-CR\AgentRL\Agentic-RL-Most-Detailed-Intro\README.md>)：教程目录与参考实现定位。
- [agentic-tau-rl README](</D:\工作空间\sandbox-CR\AgentRL\Agentic-RL-Most-Detailed-Intro\agentic-tau-rl代码实战\README.md>)：多轮 rollout、reward、credit、算法与迁移边界。
- [轨迹与 token-mask 契约](</D:\工作空间\sandbox-CR\AgentRL\Agentic-RL-Most-Detailed-Intro\agentic-tau-rl代码实战\agentic_rl\utils\types.py>)：本报告“动作 token vs 观测 token”分析的本地依据。
- [tau² reward 聚合](</D:\工作空间\sandbox-CR\AgentRL\Agentic-RL-Most-Detailed-Intro\agentic-tau-rl代码实战\agentic_rl\env\reward.py>)：终态 verifier/乘法门控示例。
- [真机迁移说明](</D:\工作空间\sandbox-CR\AgentRL\Agentic-RL-Most-Detailed-Intro\agentic-tau-rl代码实战\docs\MIGRATION.md>)：算法与环境/模型后端解耦的参考。
- [OpenRLHF 中文文档](</D:\工作空间\sandbox-CR\AgentRL\OpenRLHF\README_zh.md>)、[异步 AgenticRL 示例](</D:\工作空间\sandbox-CR\AgentRL\OpenRLHF\examples\scripts\train_reinforce_baseline_ray_agent_async.sh>)：训练与异步 rollout 编排依据。
- [AgentENV 架构](</D:\工作空间\sandbox-CR\AgentRL\AgentENv\docs\src\internals\architecture.md>)、[AgentENV README](</D:\工作空间\sandbox-CR\AgentRL\AgentENv\README.md>)：快照、分叉、暖池与隔离环境运行时依据。

### 公开资料（查阅于 2026-09-19）

- [AReaL Agentic RL guide](https://github.com/areal-project/AReaL/blob/main/docs/en/tutorial/agentic_rl.md)：Agent framework 与 token-level RL bridge。
- [AReaL agent workflow reference](https://github.com/areal-project/AReaL/blob/main/docs/en/reference/agent_workflow.md)：代理、workflow 与调度边界。
- [OpenEnv](https://github.com/huggingface/OpenEnv)：环境接口、隔离执行环境与 provider 生态；项目仍标注为实验性。
- [TRL 的 OpenEnv 集成说明](https://github.com/huggingface/trl/blob/main/docs/source/openenv.md)：stateful environment 与 Trainer 的连接边界。
- [AgentGym](https://github.com/Hsch22/AgentGym)：统一任务环境、实时反馈与并发探索的环境/评测侧参考。
- [DeltaBox](https://arxiv.org/abs/2605.22781)：增量文件与进程状态 C/R；文中的性能数字为论文作者在其评测边界内的报告。
- [Crab](https://arxiv.org/abs/2604.28138)：以 agent turn 的 OS 语义选择 checkpoint，并与模型等待时间重叠的预印本工作。
- [Belayer](https://arxiv.org/abs/2608.14635)：面向 AgenticRL 故障恢复及 LLM-context/environment prefix consistency 的预印本工作。
- [AgentENV locality-aware scheduling issue](https://github.com/kvcache-ai/AgentENV/issues/15)、[P2P snapshot distribution issue](https://github.com/kvcache-ai/AgentENV/issues/12)：公开工程路线中关于缓存 locality 和快照分发尚待解决的证据。
- [Kimi K3 / AgentENV 官方发布说明](https://www.kimi.com/news/kimi-k3-open-source)：AgentENV 面向大规模并行 Agent 工作流、快照、恢复与分叉的官方定位。

> 本报告将公开 README/文档的能力表述视为项目的设计声明，而不是对任意硬件、任意工作负载的独立性能复测；所有具体吞吐与延迟都应在目标任务、镜像、状态大小和集群拓扑下重新测量。
