# AgentRL 与 Agent Sandbox 快速 Checkpoint/Restore（C/R）技术研究分析报告

> **定位**：面向希望快速建立全局认识、并进一步开展系统设计或技术选型的读者。本文讨论的不是“如何给容器做一次快照”这个孤立问题，而是：在 AgentRL 中，怎样把沙箱变成可恢复、可分叉、可复用、可调度的**版本化执行环境**。
>
> **范围与时点**：本文以目录中的《面向 Agent Reinforcement Learning 的 Agent Sandbox 快速 Checkpoint/Restore 技术研究提纲》为大纲扩展，并核对公开论文和项目文档；资料截至 2026-09-18。DeltaBox、Crab 均为 2026 年公开的预印本，其绝对性能数字应以目标硬件、工作负载和实现版本复测为准。

---

## 摘要：先给出结论

Agent Reinforcement Learning（AgentRL）将优化对象从“提示词到单次回答”扩展为“策略在真实、可变环境中多轮行动的轨迹”。随之而来的关键变化是：每次 rollout 不仅消耗模型推理，还要创建、初始化、执行、重置并回收一个包含文件、进程和运行时资源的环境。长轨迹、并行采样、Best-of-N 和树搜索会反复抵达相同的中间环境状态；若每个分支都从头创建沙箱、克隆仓库、安装依赖并回放前缀，环境侧成本会迅速吞没并行收益。

快速 Checkpoint/Restore（C/R）正是把这一重复成本转换为一次准备、多次复用的系统原语：从状态 (S) 创建检查点后，可恢复到 (S)、从 (S) 分叉多个独立候选，或在故障后回滚。但它并非天然正确：Git 回退、文件系统回退、进程恢复、网络连接恢复和外部服务一致性，恢复的对象和保证完全不同。

因此，本报告的核心判断是：

> **Fast C/R 是 AgentRL Environment State Management 的数据平面；真正的控制平面还必须包含状态分层、语义选择、复用、局部性调度、生命周期管理和垃圾回收。**

工程上不应从“做全量快照”直接跳到“追求毫秒级快照”。更稳妥的路径是：先界定任务所需的恢复语义；优先采用可验证的文件系统 reset/CoW 基线；再按收益逐层引入进程 C/R、增量状态、异步化和跨节点状态缓存。

---

## 1. 问题链条：为什么 AgentRL 会把 C/R 推入关键路径？

理解本领域最简洁的路径是以下七个问题：

```text
大量 rollout
    ↓
多轮工具调用改变真实环境
    ↓
环境成为有状态执行体，而非纯函数
    ↓
隔离、复现与资源控制要求使用 Sandbox
    ↓
创建/初始化/回放前缀在大量分支中被重复执行
    ↓
需要 checkpoint、restore、fork 与 reuse
    ↓
它们必须足够快、足够正确、且可在规模化集群中调度
```

传统语言模型 RL 的典型样式可近似看作：

$$
\text{prompt} \rightarrow \text{model response} \rightarrow \text{reward}
$$

而 AgentRL 的一次交互是状态转移：

$$
(o_t, h_t, e_t) \xrightarrow{\pi_\theta} a_t
\xrightarrow{\mathcal{E}} (o_{t+1}, h_{t+1}, e_{t+1})
$$

其中 \(h_t\) 是 agent 的逻辑状态（对话、工具历史、记忆等），\(e_t\) 是环境状态（代码、文件、进程、端口、数据库会话等）。策略学习的轨迹由模型输出和环境转移共同决定。**只保存聊天历史，不等价于保存可继续执行的 rollout。**

这也解释了“为什么 RL 算法本身不够”：PPO、GRPO 等决定怎样使用轨迹更新策略；Sandbox C/R 决定怎样以可接受成本产出那些轨迹。二者是训练系统的上下游，而不是替代关系。

---

## 2. AgentRL 系统图：Sandbox 在哪里，瓶颈又在哪里？

```text
 ┌───────────┐   policy/version   ┌────────────────┐
 │  Trainer  │ ─────────────────► │ Rollout Engine │
 └─────▲─────┘                    └───────┬────────┘
       │ trajectories / rewards            │ tasks, actions
       │                                    ▼
 ┌─────┴────────┐                 ┌────────────────┐
 │ Verifier &   │ ◄── observations │ Sandbox Manager│
 │ Trajectory   │                 └───┬─────────┬───┘
 │ Store        │                     │         │
 └──────────────┘                 sandbox    State Manager
                                  pool       (C/R/fork/cache/GC)
                                     │         │
                                     ▼         ▼
                                  Environment State Store
```

一次 rollout 的关键路径为：任务装载 → 取得初始沙箱 → 观察 → LLM 推理 → 工具调用 → 环境突变 → 新观察，循环至终止 → 验证器给分 → 写入轨迹 → 训练器更新。它的端到端时间可粗略写为：

$$
T_{\mathrm{rollout}} = \sum_{t=1}^{H}\left(T_{\mathrm{LLM},t}+T_{\mathrm{tool},t}+T_{\mathrm{env},t}\right)+T_{\mathrm{init}}+T_{\mathrm{reset}}+T_{\mathrm{verify}}
$$

其中 \(H\) 为轨迹中的交互步数。在短任务中，LLM 推理往往主导；在代码仓库初始化重、依赖复杂、并行分支多或模型推理变快时，\(T_{\mathrm{init}}\)、\(T_{\mathrm{reset}}\) 与 \(T_{\mathrm{env}}\) 会暴露为瓶颈。重要的是，**环境侧瓶颈不是固定比例**；必须以“任务类型 × 模型时延 × 分支因子 × 沙箱密度”进行测量，而不能仅凭单机 C/R 延迟下结论。

### 2.1 Sandbox 的职责不止安全

Agent Sandbox 通常承担五类职责：

1. **隔离与安全**：限制 agent 命令、文件、网络和凭据的影响范围。
2. **可复现性**：固定镜像、依赖、代码基线和资源配额，使 reward 可比较。
3. **资源治理**：CPU、内存、磁盘、网络、并发及清理配额。
4. **并行执行**：给大量 rollout 提供相互独立的工作空间。
5. **状态管理**：reset、checkpoint、restore、fork、缓存和回收。

传统容器的生命周期是 `Create → Run → Destroy`。AgentRL 更接近：`Create → Initialize → Run → Checkpoint → Fork/Restore → Run → … → GC`。后者天然是版本控制问题，而不是单次执行问题。

---

## 3. 先定义“状态”：Restore 到底恢复什么？

错误的技术选型通常源自一个含混的“状态”。推荐使用下表的分层模型，并在每个任务族上明确恢复边界。

| 状态层 | 示例 | 只恢复这一层的典型做法 | 能否保证继续执行等价？ |
|---|---|---|---|
| 逻辑 Agent 状态 | conversation、计划、tool history、memory | 数据库/编排器 checkpoint | 通常不能；OS 副作用丢失 |
| 文件系统状态 | 源码、生成文件、依赖、工作目录 | Git reset、OverlayFS/ZFS/Btrfs snapshot | 对无常驻进程的 coding 任务往往足够 |
| 进程状态 | 进程树、内存、寄存器、线程 | CRIU、容器 C/R、VM snapshot | 仍取决于 FD、内核对象和外部连接 |
| 运行时/内核对象 | socket、pipe、FD、IPC、namespace、cgroup | 进程/VM 级 C/R | 只能在受支持对象与兼容主机上逼近 |
| LLM 服务状态 | context、KV cache、请求流 | 推理服务专用持久化 | 与 Sandbox C/R 是相关但独立的问题 |
| 外部世界状态 | DB、浏览器账户、远程 API、网页 | 补偿事务、mock、可版本化服务 | 一般不能由沙箱快照自动恢复 |

由此得到四个常被混淆的命题：

```text
Git restore               ≠ filesystem restore
filesystem restore         ≠ filesystem + process restore
process restore            ≠ external-world consistency
sandbox restore            ≠ agent logical-state consistency
```

### 3.1 合理的正确性合同

对 AgentRL 而言，最有用的并非要求“恢复宇宙中的所有状态”，而是写明恢复合同。例如：

> 对任意已发布检查点 (c)，在相同任务输入、镜像版本、随机种子与受控外部依赖下，`restore(c)` 后环境对后续允许动作的可见文件、进程接口和验证结果，应与从原状态继续执行在约定容差内一致。

这个合同需额外声明：是否恢复网络连接；是否允许时钟变化；外部 DB 是否为只读/事务隔离；密钥、随机源和任务身份如何重置；以及恢复失败的退化路径是什么。没有合同，所谓“Fidelity 高”没有可测试含义。

---

## 4. C/R、Fork 与 Reuse：它们解决的不是同一个问题

| 原语 | 输入/结果 | 最直接价值 | 关键约束 |
|---|---|---|---|
| Checkpoint | 运行状态 → 版本化工件 | 保存可回退点、抗故障 | 原子发布、开销、存储 |
| Restore / Rollback | 工件 → 可运行状态 | 回到已知正确状态 | 等价性、兼容性、外部副作用 |
| Fork / Clone | 一个基态 → 多个可写分支 | 并行探索、Best-of-N、树搜索 | 分支隔离、CoW 放大 |
| Reuse | 已有状态 → 新任务/新 rollout | 消除重复初始化/前缀 | key 是否正确、污染检测 |
| Migration | 节点 A 状态 → 节点 B | 弹性、容错、负载均衡 | 传输、硬件/内核兼容性 |
| GC / Compaction | 状态 DAG → 可控存储 | 避免状态爆炸 | 引用计数、可达性、重建代价 |

以 Coding Agent 为例，若 agent 已经完成“克隆仓库、装依赖、构建、定位缺陷”，得到状态 (S)，再探索三种补丁，理想执行是：

```text
prepare S once ── checkpoint(S) ──┬─ fork A → patch/test A → reward A
                                  ├─ fork B → patch/test B → reward B
                                  └─ fork C → patch/test C → reward C
```

没有 C/R 时，每条分支需要重做前缀。令前缀成本为 \(P\)、分支后缀成本为 \(Q\)、分支数为 \(b\)，则从头运行约为 \(b(P+Q)\)，而“准备一次再分叉”约为 \(P+C+b(R+Q)\)，其中 \(C\) 为 checkpoint 成本、\(R\) 为每个分支的 restore/fork 成本。只要：

$$
(b-1)P > C+bR
$$

状态复用就具备纯时间意义上的收益；若考虑存储、资源争用、失败重试与模型并行空转，还需纳入总拥有成本。

---

## 5. 技术路线：从通用快照到 Agent-aware C/R

### 5.1 路线总览

| 路线 | 捕获范围 | 优点 | 主要代价/风险 | 适用起点 |
|---|---|---|---|---|
| 重建式 reset | 镜像 + 脚本 + Git | 最简单、可审计 | 初始化重复、慢 | 环境准备轻、追求稳健 |
| 文件系统 reset / snapshot | 工作树与依赖层 | 快、易分支 | 活跃进程和 IPC 未恢复 | 大多数 coding rollout |
| 容器/CRIU C/R | 文件 + Linux 进程态 | 可恢复常驻进程 | 内核/FD/安全策略限制 | 受控 Linux 单机 |
| microVM snapshot | 客体内存 + VMM 状态 + 外部磁盘管理 | 隔离强、恢复范围广 | 内存工件大、跨机兼容性 | 高隔离、可控硬件池 |
| CoW fork | 共享基态 + 私有 delta | 高效扇出 | 写放大、层深与 GC | Best-of-N、树搜索 |
| 增量/dirty tracking | 相对基态的页/文件变更 | 降低连续 checkpoint 成本 | 追踪开销、链式恢复 | 高频连续状态 |
| 语义/选择性 C/R | 仅恢复相关状态/仅在必要时保存 | 消除无效 checkpoint | 误判会损害正确性 | agent 行为稀疏且可观测 |
| 异步/惰性恢复 | 后台持久化、按需装页 | 隐藏关键路径延迟 | 背压、尾延迟、故障窗口 | LLM wait 明显的 workload |

### 5.2 全量快照：正确性的基线，不是最终答案

VM snapshot、容器 C/R 和 CRIU 的共同思路是“尽可能捕获完整运行状态”。Docker 的 checkpoint/restore 基于 CRIU，文档仍标记为实验性，并以单机场景为主；这提醒我们，不要把通用容器 C/R 误当成现成的分布式 AgentRL 方案。[Docker checkpoint 文档](https://docs.docker.com/reference/cli/docker/checkpoint/)

全量快照的价值在于建立最可信的恢复基线与测试 oracle。其问题是工件体积、暂停/序列化、写盘和网络传输会随内存与设备状态增长；在每一 agent turn 都做一次时，更会与同宿主沙箱争抢 I/O。

### 5.3 CoW 与增量：把共享前缀变成共享基态

OverlayFS、ZFS/Btrfs snapshot、thin-provisioning 或虚拟内存 CoW 的抽象都相似：只读 base 由多个分支共享，写入落到每个分支的私有 upper/delta。它使 fork 从“复制一份完整状态”变成“创建轻量引用并按写入付费”。

但 CoW 并不自动解决所有问题：

- 热点文件反复写会造成写放大；
- 深层 delta 链增加读取和恢复路径复杂度，应有 compaction 策略；
- 分支共享基态时，身份、随机性、端口、网络地址和凭据必须去重；
- 删除 base 前必须确认所有后代均不可达。

Firecracker 的快照实现提供了一个清晰的机制样例：它可以保存客体内存与 VMM 状态；恢复时可将内存文件以 `MAP_PRIVATE` 映射，并用 CoW 承接后续写入，从而把部分加载成本推迟到按页访问时。不过其磁盘文件需由集成方管理，跨主机存在内核、CPU、设备与网络连接限制，diff snapshot 也有明确限制。[Firecracker Snapshotting](https://github.com/firecracker-microvm/firecracker/blob/main/docs/snapshotting/snapshot-support.md)

### 5.4 Agent-aware / Semantic C/R：回答“该不该存、存什么”

这是与传统 C/R 最本质的区别。传统系统通常在固定时间间隔或固定事件上存储；AgentRL 可利用“turn 边界、工具类型、系统调用、副作用范围、预计分叉价值”等语义决定：

1. 该 turn 是否产生未来可见的恢复相关状态；
2. 若产生，文件系统、进程态和逻辑状态各自是否需要更新；
3. 该检查点是否可能成为分叉热点，值得预热/持久化；
4. 是否能在下一次 LLM 推理等待期间后台完成。

这并不是允许“不安全地少保存”，而是要在**可验证的语义规则**下消除冗余。最保守的做法是在不能证明安全时回退到完整 checkpoint。

---

## 6. 两项 Agent-native 工作：DeltaBox 与 Crab 的互补性

### 6.1 DeltaBox：以 delta 数据路径压低 C/R 时延

[DeltaBox](https://arxiv.org/abs/2605.22781) 聚焦“高频状态探索下，怎样让完整沙箱的 checkpoint/rollback 接近毫秒级”。论文报告在其 SWE-bench 与 RL 微基准中，checkpoint 约 14 ms、rollback 约 5 ms；设计关键词包括 OverlayFS、CRIU、CoW 与 delta 化状态。其重要思想是区分同步短路径与可在 LLM 推理窗口中隐藏的后台工作：恢复走高效 delta 路径，较重的进程状态持久化尽量异步化。

应如何理解它：

- **解决的主矛盾**：完整沙箱状态的复制与恢复延迟限制了 fan-out / tree search。
- **核心杠杆**：共享基态、记录差异、让慢操作与 LLM 等待重叠。
- **不能直接外推的部分**：14/5 ms 是特定实验设置的结果，不是任意镜像、内存规模、写入模式、存储介质或跨节点网络下的 SLA。
- **对系统设计的启示**：若分叉后主要改文件、进程态变化相对可控，应把“文件 delta 快路径”和“进程快照慢路径”拆开管理，而不是每次都同步复制全部对象。

### 6.2 Crab：以语义控制平面减少不必要 C/R

[Crab](https://arxiv.org/abs/2604.28138) 的出发点不同：agent 框架能看到工具调用但不了解 OS 副作用，OS 能看到状态变化却不了解 turn 的恢复语义，形成 agent–OS semantic gap。它用 eBPF 观察 OS 可见影响，在 turn 边界分类 checkpoint 粒度，并由协调器将 C/R 与 LLM 等待重叠，在宿主层协调密集沙箱的 checkpoint 流量。

论文在 shell 密集和代码修复工作负载中报告：超过 75% 的 turn 没有恢复相关状态；相对全量逐 turn checkpoint，可减少最高 87% 的 checkpoint 流量，并使恢复正确性达到其定义下的 100%。这些数字的价值首先是**证明工作负载存在稀疏性**，不是把阈值 75%/87% 当成通用常数。

### 6.3 放在一起看

| 维度 | DeltaBox | Crab | 应得出的设计结论 |
|---|---|---|---|
| 主要问题 | 每次 C/R 太慢 | 太多 C/R 根本不必做 | 同时优化“每次成本”和“发生次数” |
| 主导机制 | delta、CoW、异步数据路径 | 语义感知、eBPF 观察、调度 | 数据平面与控制平面分离 |
| 最适合的情境 | 高频 restore/fork | turn 状态突变稀疏、宿主密集部署 | 树搜索与规模化 rollout 可二者叠加 |
| 首要风险 | delta 链、兼容性与一致性 | 分类漏判造成恢复缺口 | 均需可回退的完整基线与故障注入测试 |

一句话概括：**DeltaBox 关注“把需要的快照做快”，Crab 关注“不要做不需要的快照”。** 它们不是互斥路线。

---

## 7. 面向 AgentRL 的目标架构

```text
                         ┌──────────────────┐
                         │   AgentRL Trainer │
                         └────────┬─────────┘
                                  │ task / policy
                         ┌────────▼─────────┐
                         │ Rollout Scheduler │
                         │  (branch budget)  │
                         └───┬───────────┬───┘
                             │           │ state locality hint
                  ┌──────────▼───┐   ┌───▼─────────────────────────┐
                  │ Sandbox Pool │   │ State Manager (control plane)│
                  │  isolation   │   │ semantic policy / catalog /  │
                  └──────┬───────┘   │ ref-count / GC / placement   │
                         │           └───┬───────────────┬──────────┘
                         │               │               │
                  ┌──────▼───────────────▼───────────────▼───────┐
                  │ C/R data plane: FS snapshot | process C/R |  │
                  │ CoW fork | lazy restore | integrity manifest │
                  └───────────────────────┬──────────────────────┘
                                          │
                  ┌───────────────────────▼──────────────────────┐
                  │ State Store: immutable base | delta DAG |     │
                  │ local hot cache | durable remote tier          │
                  └───────────────────────────────────────────────┘
```

### 7.1 必备模块及职责

- **Rollout Scheduler**：除 GPU/CPU 资源外，接收状态位置、恢复时延、分支价值等输入；将优先级高的分支放在已有热状态的节点。
- **Sandbox Pool**：维护隔离边界、镜像版本和资源配额。池化不应绕过 reset 验证，否则污染会让 reward 静默失真。
- **State Manager（控制平面）**：为检查点生成 manifest；维护父子依赖、引用计数、可达性、兼容性与生命周期；决定 checkpoint 粒度。
- **C/R Engine（数据平面）**：执行文件、内存、进程或 microVM 级的导出/导入；提供原子发布和失败回滚。
- **State Store / Cache**：保存 immutable base 与 delta；区分本地热缓存、持久存储和跨节点传输；验证内容哈希与访问控制。
- **Integrity Verifier**：restore 后至少验证任务工作树、进程策略、关键服务健康度和状态版本；失败即隔离该 sandbox 并退化为重新创建。

### 7.2 将状态建模为 DAG，而不是快照列表

状态天然形成版本 DAG：

```text
Base B ── S1 ── S2 ──┬── S3a ── S4a
                     ├── S3b
                     └── S3c ── S4c
```

每个节点包含 `parent_id`、镜像/内核/运行时兼容性、逻辑状态版本、FS delta、进程 delta、外部依赖合同、完整性哈希、引用计数和访问标签。DAG 带来三项直接收益：共享公共前缀、按分支回收不可达节点、按“恢复价值/访问热度”进行缓存与压缩。但它也要求严肃处理删 base、链过深和 manifest 原子性。

---

## 8. 性能、成本与正确性：如何评价方案而非只看毫秒数？

建议建立下列指标面板：

| 维度 | 必测指标 | 解释 |
|---|---|---|
| 时间 | checkpoint/restore/fork p50/p95/p99；端到端 rollout wall time | p99 直接影响同步采样尾部 |
| 吞吐 | episodes/s、有效 branch nodes/s、GPU 等待占比 | 快照快不等于训练吞吐高 |
| 存储 | 每 checkpoint bytes、dedup ratio、delta-chain depth、GC 回收率 | 检查状态爆炸是否被隐藏 |
| 正确性 | restore 等价测试通过率、污染率、故障恢复成功率 | 应按状态层与任务族统计 |
| 隔离 | 分支间写入泄漏、身份/网络冲突、权限越界 | fork 的硬约束 |
| 调度 | local-cache hit rate、跨节点迁移字节数、重建回退率 | 判断 state-aware scheduling 是否真有价值 |
| 经济性 | 每有效 trajectory 成本、每 reward 成本、单位增益成本 | 最终应服务于训练效果 |

一个更完整的优化目标可写成：

$$
\min \; \mathbb{E}\!\left[T_{\mathrm{rollout}}\right]
     + \lambda_s C_{\mathrm{storage}}
     + \lambda_n C_{\mathrm{network}}
     + \lambda_f\Pr\!\left(\text{incorrect restore}\right)
$$

其中错误恢复的惩罚权重 \(\lambda_f\) 通常远大于其他项：错误状态会污染后续轨迹和 reward，形成难以察觉的训练数据质量问题。因此，**高吞吐但无法证明 reset 正确的系统不是合格的 AgentRL 基础设施。**

---

## 9. 最大的难题与常见误区

### 9.1 外部世界不能靠沙箱“拍进去”

数据库、远程 API、网页登录态、对象存储和第三方服务往往不在本地 snapshot 的一致性边界内。可选策略是：

- 将训练环境设计成可重置的本地/模拟服务；
- 对数据库使用每 rollout schema、事务或可克隆实例；
- 对外部调用做录制回放、幂等键和补偿；
- 在 manifest 中显式声明不可恢复依赖，而不是假装其已恢复。

### 9.2 进程恢复不等于连接恢复

Firecracker 文档明确说明，在另一个进程中恢复后网络/vsock 的连接不保证存活；Docker/CRIU 也有终端和内核能力限制。对于 agent-with-a-sandbox 架构，应把命令请求做成可记录、可重试、可去重的协议；对于 agent-in-a-sandbox 架构，还要处理 agent 内存进度与已恢复文件系统之间的错位。

### 9.3 语义 checkpoint 的漏判比多存一次更危险

选择性 C/R 必须坚持“无法证明无关，就视为相关”的保守规则，并用故障注入验证：在每个候选恢复点崩溃、恢复、重放后续动作，比对文件哈希、服务探针、tool response 和最终 verifier reward。不能只测“正常运行更快”。

### 9.4 不要混淆训练数据 replay 与环境状态 replay

经验回放复用的是 `(observation, action, reward)` 等训练数据；环境 C/R 复用的是能够产生未来交互的执行状态。两者可以协同，但一个无法替代另一个。

### 9.5 不要过早跨节点

跨节点 restore 会引入传输、硬件兼容、机密数据分发与缓存一致性难题。若任务具有高 state locality，先在同一节点用本地热缓存和 CoW 实现大部分收益，通常比直接做“全局状态池”更稳健。

---

## 10. 推荐的工程落地路线

### 阶段 0：先做状态审计，而非先选引擎

为目标 workload 列出：文件写入、常驻进程、端口、IPC、浏览器、数据库、外部 API、LLM KV cache；对每项标注“必须恢复 / 可重建 / 不允许存在”。再定义恢复合同、基线测试和污染隔离规则。

### 阶段 1：可验证的 filesystem reset + Sandbox Pool

适用于多数代码修改型 AgentRL。用不可变镜像与任务基线，配合 Git/worktree 或 CoW filesystem reset；清理进程和临时目录；随后验证工作树哈希、关键路径和基线测试。公开的 Agent Sandbox RL 示例也强调：reset 后若发现 drift，应隔离 sandbox 并重新取得新实例，而不是把污染传给下一条 rollout。[Agent Sandbox RL 示例](https://agent-sandbox.sigs.k8s.io/docs/use-cases/examples/agent-sandbox-rl/)

**完成标准**：先证明 reset 正确率和污染率，而不是先追逐延迟。

### 阶段 2：引入共享 base 与 CoW fork

将 OS image、依赖层、仓库预构建层与 task base 作为可共享、不可变的 base；分支只持有写层。实现状态 manifest、引用计数、配额与层深阈值。此阶段通常已能显著改善 Best-of-N 和从同一 bug 定位点开始的多补丁探索。

### 阶段 3：按需加入 process C/R 与异步化

仅当常驻服务启动、依赖预热或长运行进程确实占据关键路径时，才加入 CRIU/VM snapshot。将 checkpoint 传输与 LLM inference 交叠，但要建立背压：后台积压超过存储带宽时，不能无限产生“尚未持久化”的检查点。

### 阶段 4：语义选择、热点缓存与 state-aware scheduling

记录每类 tool action 的真实状态突变和 checkpoint 命中率；仅在可验证的规则下跳过 checkpoint。再把状态 ID、所在节点、预计恢复成本传给调度器，先追求节点内 cache hit，再考虑跨节点复制。最终形成状态 DAG、分层存储和 GC。

### 技术选型速查

| 场景 | 首选 | 不宜一开始就选 |
|---|---|---|
| 纯代码编辑，进程可重启 | Git/文件系统 reset + CoW | 全进程 checkpoint |
| 大量共享依赖与同一前缀分支 | 预热 base + CoW fork | 每分支复制整个工作区 |
| 服务启动很慢且进程态关键 | 受控 CRIU 或 microVM snapshot | 仅 Git restore |
| 高隔离、安全边界很重 | microVM + 磁盘/内存分层快照 | 假设容器 C/R 自动等价 |
| 外部 DB / API 强耦合 | 可重置 mock、事务隔离、录制回放 | 单靠 sandbox snapshot |
| 跨节点弹性为主 | 内容寻址状态库 + 热点副本 + 兼容性矩阵 | 无差别同步全部状态 |

---

## 11. 值得继续研究的开放问题

1. **Agent-relevant state abstraction**：什么状态真正影响未来 trajectory？能否在不破坏正确性的前提下，压缩为比 OS 全状态更小的表示？
2. **Semantic checkpoint policy**：如何把工具语义、系统调用和未来分叉价值合成为一个有置信度、可回退的决策？
3. **状态 DAG 的最优保留**：在有限存储下，保留哪个中间节点的期望收益最高？它类似带重建成本的缓存/分页问题，但访问分布还受训练策略影响。
4. **状态局部性感知调度**：GPU、CPU、网络与状态缓存的目标常冲突；如何在吞吐、尾延迟和状态迁移成本间联合优化？
5. **跨层一致性**：如何原子地协调 agent 逻辑状态、filesystem、process、LLM context 与外部事务？
6. **可证明的恢复语义**：能否用状态等价测试、差分执行或形式化合同，替代“恢复后看起来能跑”的经验判断？
7. **安全与多租户**：checkpoint 是高度敏感的状态包，如何实现加密、访问控制、密钥轮换、来源追踪与安全删除，同时仍支持 dedup？

这些问题共同指向一个更完整的研究对象：**RL-aware Stateful Sandbox Runtime**。其关键不是增加一个快照 API，而是让运行时理解状态、控制状态版本、把状态移动到最合适的位置，并用严格合同保证恢复后的训练数据可信。

---

## 12. 最终认识框架

```text
AgentRL
  └─ 大规模、多轮 rollout
       └─ Stateful Environment
            └─ Agent Sandbox
                 └─ Environment State Management
                      ├─ checkpoint / restore / rollback
                      ├─ fork / clone / reuse
                      ├─ cache / locality-aware scheduling
                      └─ lifecycle / integrity / GC
                           └─ Fast C/R（关键 primitive）
```

如果只记住三点：

1. **C/R 的对象是环境状态，不是聊天记录；恢复边界必须显式定义。**
2. **Fast C/R 的价值主要来自消除共享前缀的重复执行，尤其服务于分支探索、故障恢复与状态复用。**
3. **最终竞争力来自系统化状态管理：选择何时存、何处存、谁可复用、如何验证和何时回收，而不只是把一次 restore 从 100 ms 降到 10 ms。**

---

## 参考资料

1. Yunpeng Dong et al. (2026). [DeltaBox: Scaling Stateful AI Agents with Millisecond-Level Sandbox Checkpoint/Rollback](https://arxiv.org/abs/2605.22781)。
2. Tianyuan Wu et al. (2026). [Crab: A Semantics-Aware Checkpoint/Restore Runtime for Agent Sandboxes](https://arxiv.org/abs/2604.28138)。
3. Firecracker 项目。[Snapshotting documentation](https://github.com/firecracker-microvm/firecracker/blob/main/docs/snapshotting/snapshot-support.md)。
4. Docker。[docker checkpoint](https://docs.docker.com/reference/cli/docker/checkpoint/)。
5. Kubernetes SIGs Agent Sandbox。[Agent Sandbox RL 示例](https://agent-sandbox.sigs.k8s.io/docs/use-cases/examples/agent-sandbox-rl/)。

> 注：本文将 DeltaBox 和 Crab 作为“机制代表”而非成熟标准。文中的论文性能数字均为作者在各自实验设置下的报告值，不构成跨系统的直接性能比较。
