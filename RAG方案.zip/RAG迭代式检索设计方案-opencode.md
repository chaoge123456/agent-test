# 基于知识感知的渐进式迭代检索 — 方案设计文档

> **版本**: v1.0  
> **日期**: 2026-07-06  

---

## 目录

1. [产品 25B 版本现状](#1-产品-25b-版本现状)
   - 1.1 单轮检索为主
   - 1.2 融合 DeepSearch 方案
2. [工业界/学术界方案](#2-工业界学术界方案)
   - 2.1 学术界迭代式 RAG 最新进展
   - 2.2 工业界迭代式 RAG 产品分析
3. [基于知识感知的渐进式迭代检索](#3-基于知识感知的渐进式迭代检索)
   - 3.1 核心概念与架构
   - 3.2 方案 A：效率优先 — 轻量级渐进式迭代检索（L-PIR）
   - 3.3 方案 B：质量优先 — 深度知识感知迭代检索（D-PIR）
   - 3.4 方案对比与场景适配

---

## 1. 产品 25B 版本现状

### 1.1 单轮检索为主

当前 25B 版本的核心 RAG 流程以**单轮检索**为主，其典型流程为：

```
用户 Query → Query 改写/Multi-Query 生成 → 向量检索 + 关键词检索 → Rerank → LLM 生成回答
```

**单轮检索的局限性**：

| 问题维度 | 具体表现 |
|---------|---------|
| **复杂多跳推理** | 涉及跨文档、多实体关联的查询（如"A 公司的 CEO 和 B 公司的 CEO 之间有什么关系？"），单轮检索无法完成多步推理，容易检索到表面相关内容但丢失深层关联 |
| **信息分散** | 当答案需要从多个文档、多个页面中拼接信息时，单轮检索返回的 Top-K 片段难以覆盖所有必要证据点 |
| **检索粒度固定** | 无法根据查询复杂度动态调整检索粒度——简单查询可能返回过多冗余信息，复杂查询则可能遗漏关键细节 |
| **缺乏反馈闭环** | 检索结果质量无法被评估和纠正，存在"一次性检索 → 不充分结果 → 直接生成低质量回答"的风险 |
| **检索盲区** | 初始 Query 表达不精确时，缺乏根据中间结果调整检索策略的能力，陷入局部最优 |

**核心困境**：单轮检索本质上将"检索什么"和"检索到什么程度"的决策压缩为一次性操作，无法像人类那样"先粗查定位、再细查验证、发现遗漏后补充检索"。

---

### 1.2 融合 DeepSearch 方案

25B 版本中融合了 DeepSearch 能力以应对复杂场景。DeepSearch 与迭代式 RAG 存在本质差异：

#### DeepSearch 方案特点

DeepSearch（以 OpenAI Deep Research、Google Deep Research、Perplexity Deep Research 为典型代表）的核心特征：

- **长时间运行**：单次任务耗时 2-30 分钟，执行数十到数百次搜索
- **开放域检索**：面向互联网全网检索，而非封闭知识库
- **Multi-Agent 协作**：Plan → Search → Read → Reflect → Iterate → Synthesize 的多步循环
- **结构化报告生成**：以生成长篇研究报告为目标，而非即时问答
- **高成本**：单次会话 API 成本可达 $5-$30

#### DeepSearch vs 迭代式 RAG 的关键差异

| 维度 | DeepSearch | 迭代式 RAG |
|------|-----------|-----------|
| **时延要求** | 分钟到小时级 | 毫秒到秒级 |
| **检索范围** | 开放互联网（Web-scale） | 封闭私有知识库 |
| **交互模式** | 异步报告生成 | 实时对话式问答 |
| **检索深度** | Web 爬取 + 工具使用（代码执行、浏览器操作） | 知识库内多轮精细化检索 |
| **成本模型** | 按 session 计费（数美元） | 按 query 计费（毫分级） |
| **核心目标** | 深度研究、综合分析、报告撰写 | 精准知识检索、快速问答 |
| **典型产品** | OpenAI Deep Research (o3), Gemini Deep Research, Perplexity Deep Research | 腾讯知文、阿里百炼 RAG、NVIDIA RAG Blueprint |
| **适用场景** | 学术研究、市场分析、竞品调研 | 企业知识问答、客服、合规审查 |

**关键认识**：DeepSearch 解决的是"广度"问题（从海量开放信息中筛选综合），而迭代式 RAG 解决的是"精度"问题（在已知知识库内逐级深入、精准定位）。两者面向不同需求场景，互为补充而非替代。

---

## 2. 工业界/学术界方案

### 2.1 学术界迭代式 RAG 最新进展

#### 2.1.1 Self-RAG（ICLR 2024 Oral, Top 1%）

- **论文**: [Self-RAG: Learning to Retrieve, Generate, and Critique through Self-Reflection](https://arxiv.org/abs/2310.11511)
- **作者**: Akari Asai, Zeqiu Wu, Yizhong Wang, Avirup Sil, Hannaneh Hajishirzi (University of Washington / IBM)
- **核心机制**:
  - 训练 LLM 生成特殊的 **Reflection Token**（Retrieve/IsRel/IsSup/IsUse），在推理时自主决策是否需要检索、检索结果是否相关、生成内容是否有据、整体效用如何
  - 采用**按需检索**（on-demand retrieval），简单问题跳过检索，复杂问题多次检索
  - 使用 Segment-level Beam Search 选择效用最大化的生成路径
- **关键贡献**: 首次将检索决策、相关性评估、生成质量评估统一到 LLM 的 token 生成过程中

#### 2.1.2 Corrective RAG（CRAG, 2024）

- **论文**: [Corrective Retrieval Augmented Generation](https://arxiv.org/abs/2401.15884)
- **核心机制**:
  - 引入 **Retrieval Evaluator**，将检索文档分类为 Correct / Ambiguous / Incorrect
  - 对低质量检索结果执行 decompose-then-recompose 策略
  - 本地检索失败时自动触发 Web 搜索作为补救
- **关键贡献**: 提供检索后评估与纠正闭环，是迭代式检索的关键使能技术

#### 2.1.3 Adaptive RAG（2024）

- **论文**: [Adaptive-RAG: Learning to Adapt Retrieval-Augmented Large Language Models through Question Complexity](https://arxiv.org/abs/2403.14403)
- **核心机制**:
  - 训练分类器预测查询复杂度
  - 根据复杂度动态路由到 **No Retrieval / Single-shot RAG / Iterative RAG** 三种策略
- **关键贡献**: 首次提出按查询复杂度自适应选择检索策略，避免"一刀切"的冗余检索

#### 2.1.4 ITER-RETGEN（2023, 111+ Citations）

- **论文**: [Enhancing Retrieval-Augmented Large Language Models with Iterative Retrieval-Generation Synergy](https://arxiv.org/abs/2305.15294)
- **核心机制**:
  - "检索增强生成 → 生成增强检索"双向协同
  - 每轮使用前一轮的生成内容作为下一轮检索的 Query 补充，从而捕获模型"仍不知道什么"
- **关键贡献**: 首次系统性地证明了迭代式检索-生成协同的有效性

#### 2.1.5 FLARE（2023）

- **论文**: [Active Retrieval Augmented Generation](https://arxiv.org/abs/2305.06983)
- **核心机制**:
  - 在生成过程中**主动预测**未来的信息需求
  - 当 LLM 对即将生成的 token 信心不足时，触发检索
- **关键贡献**: 将检索决策前置到生成规划阶段，"前瞻式"检索

#### 2.1.6 FAIR-RAG（2025）

- **论文**: [FAIR-RAG: Faithful Adaptive Iterative Refinement for Retrieval-Augmented Generation](https://arxiv.org/abs/2510.22344)
- **核心机制**:
  - **Structured Evidence Assessment (SEA)** 模块：Checklist 驱动的证据充分性分析
  - 显式识别信息缺口后针对性补全
  - 结合多 Agent 范式：Planner → Retriever → Assessor → Generator
- **关键贡献**: 克服了 FLARE 和 CRAG 仅依赖启发式触发/事后调整的局限，提供原则性的迭代证据精炼框架

#### 2.1.7 FunnelRAG（NAACL 2025）

- **论文**: [FunnelRAG: A Coarse-to-Fine Progressive Retrieval Paradigm for RAG](https://arxiv.org/abs/2410.10293)
- **核心机制**:
  - **粗到细三级检索**：Clustered Document (4K tokens) → Document (1K) → Passage (100)
  - 混合能力检索器协同：BM25（粗粒度）→ Dense Retriever（中粒度）→ Cross-Encoder（细粒度）
  - 语料库压缩 30x，时间成本降低 40%，检索精度持平
- **关键贡献**: 与本文提出的渐进式检索理念高度一致，验证了粗到细策略的实用价值

#### 2.1.8 Hierarchical RAG with Rethink（HiRAG, 2024）

- **论文**: [Hierarchical Retrieval-Augmented Generation Model with Rethink for Multi-hop Question Answering](https://arxiv.org/abs/2408.11875)
- **核心机制**:
  - 文档级（Sparse Retrieval）→ 片段级（Dense Retrieval）的多级检索
  - **Rethink 机制**：答案核验不通过时，回溯选择其他候选片段重新作答
- **关键贡献**: 引入"回溯-再检索"闭环，实现检索路径的自我纠错

#### 2.1.9 RAS（Retrieval-And-Structuring, 2025）

- **论文**: [RAS: Retrieval-And-Structuring for Knowledge-Intensive LLM Generation](https://arxiv.org/abs/2502.10996)
- **核心机制**:
  - 迭代检索与增量知识图谱构建交织进行
  - Planning 模块识别知识缺口 → 检索 → 提取三元组 → 更新查询特定 KG
- **关键贡献**: 将结构化知识构建与迭代检索深度融合

#### 2.1.10 其他重要工作

| 论文 | 链接 | 核心特点 |
|------|------|---------|
| SeaKR (2024) | [arxiv.org/abs/2406.19215](https://arxiv.org/abs/2406.19215) | 基于 LLM 内部状态的自感知不确定性激活检索，自感知重排序 |
| GRIP (2025) | [arxiv.org/abs/2604.11407](https://arxiv.org/abs/2604.11407) | "检索即生成"，通过控制 Token 在单一自回归轨迹中管理检索全流程 |
| SCMRAG (2025) | [doi.org/10.65109/wjjv5555](https://doi.org/10.65109/wjjv5555) | 自纠正多跳 RAG，动态知识图谱 + 自主识别信息缺口 |
| Mix-of-Granularity (2025) | [arxiv.org/abs/2406.00456](https://arxiv.org/abs/2406.00456) | 路由器预测最优分块粒度，自适应多粒度检索 |
| SproutRAG (2025) | [arxiv.org/abs/2606.18381](https://arxiv.org/abs/2606.18381) | 注意力引导的层级树结构，渐进式 Embedding，多粒度 Beam Search |
| MacRAG (2025) | [arxiv.org/abs/2505.06569](https://arxiv.org/abs/2505.06569) | 多尺度自适应上下文，粗到细压缩-分割-扩展 |
| LPKG (2024) | [arxiv.org/abs/2406.14282](https://arxiv.org/abs/2406.14282) | 从知识图谱学习查询规划，增强迭代检索中的规划能力 |
| DynaRAG (2025) | OpenReview | 知识感知的动态检索，混合 Query-Knowledge 相似度空间 + 多粒度语义变体检索 |

**学术趋势总结**：

```
迭代式 RAG 演进路径：
  固定轮次检索 → 按需触发检索 → 自适应策略选择 → 知识感知规划检索 → 端到端自主检索

核心方向：
  1. 检索决策内化（Self-RAG → GRIP）
  2. 质量闭环建立（CRAG → FAIR-RAG）
  3. 粒度精细化（FunnelRAG → Mix-of-Granularity → SproutRAG）
  4. 知识结构化（GraphRAG → RAS → PRoH）
  5. 规划自主化（Adaptive-RAG → LPKG → Agentic RAG）
```

---

### 2.2 工业界迭代式 RAG 产品分析

#### 2.2.1 腾讯 — 腾讯云 ADP / 混元 / WeKnora

**腾讯云智能体开发平台（ADP）知识库检索 Agent**

- **来源**: [腾讯云 ADP 文档](https://www.tencentcloud.com/zh/document/product/1254/78742)
- **核心能力**: 基于 **Agentic RAG** 的自主检索 Agent
  - 自主规划并拆解检索任务，支持多轮调用检索工具和计算工具
  - 内置多种工具：知识库检索、Text2SQL、SQLExecutor、计算工具等
  - 明确区分：传统 RAG（单次检索+生成）vs Agentic RAG（多次检索+自主规划）
- **适用场景**: 多文档综合回复、文档筛选后回复、复杂表格数据查询
- **知识图谱 GraphRAG**: 支持自动从文档提取实体、关系、属性构建知识图谱，进行多跳推理问答

**WeKnora（开源）**

- **来源**: [GitHub - Tencent/WeKnora](https://github.com/Tencent/WeKnora)
- **核心能力**:
  - ReAct Agent 模式：自主编排检索、MCP 工具、Web 搜索
  - 混合检索策略：BM25 + Dense Retrieval + GraphRAG
  - 跨知识库检索 + 多次迭代
  - Wiki 模式：自我维护的互联 Markdown 知识库 + 交互式知识图谱
  - 20+ LLM 提供商集成，完整的多租户 RBAC

#### 2.2.2 阿里巴巴 — 百炼平台 / 通义实验室 VRAG

**百炼（Bailian）知识库 RAG**

- **来源**: [阿里云百炼文档](https://www.alibabacloud.com/help/zh/model-studio/rag-knowledge-base)
- **核心能力**:
  - 多轮对话改写（Query Rewriting）：轻量级专用模型结合对话历史，将当前问题改写为完整独立查询
  - 多路召回 + Rerank：向量检索 + BM25 关键词检索 + 官方排序模型（GTE-ReRank）
  - 知识库权重配置：多知识库场景下按重要性权重分配
  - API 化 RAG 服务：通过 SDK 快速接入外部 AI 应用
- **妙搜（AI 妙搜）**: Multi-Agent 架构的多模态搜索产品，支持多源异构数据库，自主决策筛选资料

**VRAG（Vision-based RAG）— 阿里通义实验室**

- **来源**: [GitHub - Alibaba-NLP/VRAG](https://github.com/Alibaba-NLP/VRAG)
- **核心能力**:
  - **粗到细的渐进式信息收集**：VRAG 使 VLM 能够从粗粒度到细粒度逐步收集视觉信息
  - VRAG-RL：基于强化学习的多轮多模态训练框架
  - VimRAG：多模态记忆图（Multimodal Memory Graph）+ 图引导策略优化（GGPO）
  - ViDoRAG：多 Agent Actor-Critic 范式的动态迭代推理
- **关键亮点**: 与本文提出的"由粗到细渐进式检索"理念高度契合，验证了该范式在视觉文档理解场景的有效性

#### 2.2.3 字节跳动 — 火山引擎 / 豆包

- **来源**: 火山引擎 RAG 服务、豆包大模型 API
- **核心能力**:
  - 字节跳动主要通过火山引擎提供企业级 RAG 能力，集成豆包（Doubao）大模型
  - WeKnora 已集成豆包（Volcengine）作为 LLM 提供商和对象存储后端
  - 知识库检索 + 多轮对话能力
- **特征**: 侧重于将 RAG 能力与字节系 IM 生态（飞书、企业微信等）深度融合

#### 2.2.4 微软 — GraphRAG

- **来源**: [Microsoft Research - GraphRAG](https://www.microsoft.com/en-us/research/project/graphrag/) | [GitHub](https://github.com/microsoft/graphrag)
- **核心能力**:
  - **Global Search**: 利用层级社区结构的 Map-Reduce 全局搜索，回答需要全局理解的问题
  - **Local Search**: 基于实体关系图的局部搜索
  - **Dynamic Community Selection**: 从知识图谱根节点开始，用 LLM 评分社区相关度，只遍历相关路径，降低 Token 成本
  - **LazyGraphRAG**: NLP 名词短语提取（替代 LLM）+ 迭代加深搜索，大幅降低索引成本
- **检索流程**: `Query → 实体抽取 → 候选匹配（Text Units / Reports / Entities / Relationships）→ Ranking → 最终答案`
- **关键洞察**: GraphRAG 验证了"预先构建结构化知识（知识图谱）→ 按需检索"的模式，为知识感知检索提供了参考范式

#### 2.2.5 NVIDIA — RAG Blueprint

- **来源**: [GitHub - NVIDIA-AI-Blueprints/rag](https://github.com/NVIDIA-AI-Blueprints/rag)
- **核心能力**:
  - 模块化 RAG 流水线：GPU 加速的 Ingestion → Embedding → Retrieval → Reranking → Generation
  - NeMo Retriever 系列模型：多模态文档解析（文本/表格/图表/图像）
  - 多层 Guardrailing：内容安全、主题控制
  - 多轮对话与上下文感知查询处理
  - 支持 Elasticsearch / Milvus（GPU 加速）作为向量数据库
- **特征**: 侧重于企业级高性能、可扩展架构，而非检索策略的创新

#### 2.2.6 Google — Vertex AI RAG / Deep Research

- **Gemini Deep Research**:
  - 创建多步研究计划，浏览数百个站点
  - 1M Token 上下文窗口 + RAG，单个任务可达 900K 输入 Token
  - 深度和广度并重，强调与 Google 生态（Docs、Gmail）的集成
- **Vertex AI Agent Builder**: 提供企业级 RAG 构建能力，集成搜索和对话 Agent

#### 2.2.7 行业趋势总结

| 趋势 | 代表产品 |
|------|---------|
| **Agentic RAG 成为主流** | 腾讯 ADP Agent、WeKnora ReAct Agent、阿里 VRAG-RL |
| **知识图谱增强 RAG** | 微软 GraphRAG、腾讯 GraphRAG、WeKnora Neo4j |
| **粗到细渐进式检索** | 阿里 VRAG、FunnelRAG（学术界）、HiRAG |
| **多工具编排** | WeKnora MCP、腾讯 ADP 内置工具集 |
| **检索质量闭环** | 腾讯文档强调"单次检索的失效场景"、阿里百炼的多轮改写+Rerank |
| **开源生态爆发** | WeKnora、GraphRAG、VRAG、LangChain/LlamaIndex |

---

## 3. 基于知识感知的渐进式迭代检索

### 3.1 核心概念与架构

#### 核心思想

基于知识感知的渐进式迭代检索，依托**知识库层级架构**、**多维度元数据**与**多粒度检索工具**，融合**静态知识**与**动态知识**，动态编排检索流程，有效提升迭代检索效率。

#### 知识体系定义

| 知识类型 | 内容 | 示例 |
|---------|------|------|
| **静态知识** | 检索工具特性（召回率、精度、成本、时延） | BM25 适合关键词匹配，Dense 适合语义匹配 |
| | 历史检索经验（成功/失败模式、有效 Query 模式） | "财务报表类查询→先检索目录页再定位具体表格" |
| | 底层知识库基础属性（文档结构树、元数据Schema、质量评分） | PDF 有 TOC 结构，Excel 有 Sheet 层级 |
| **动态知识** | 当前检索生成的实时上下文 | 上一轮检索到的文档列表、实体关系 |
| | 检索充分性评估结果 | "当前已有证据覆盖问题的 60%，缺少对 Y 的确认" |
| | 中间推理结果 | 子问题回答、实体链接结果 |

#### 检索粒度逻辑

```
粗粒度                        细粒度
  文档级  ──→  页面级  ──→  元素/片段级
  (Document)   (Page)       (Element/Chunk)
     │              │               │
  定位相关文档   定位文档中     定位答案所需的
  集合          相关页面       精确文本/表格/图表
```

#### 辅助检索工具

- **文档树导航**：利用文档目录结构（TOC）快速跳转到相关章节
- **跨文档关联**：通过共享实体、引用关系发现跨文档的知识联系
- **跨页面关联**：同一文档内不同页面的前后文关联
- **元数据过滤**：基于时间、作者、文档类型、标签等元数据缩小检索范围

---

### 3.2 方案 A：效率优先 — 轻量级渐进式迭代检索（L-PIR）

#### 设计哲学

**"用最小的检索成本获取足够好的答案"**。方案 A 面向高并发、低时延场景，通过规则驱动的渐进式检索 + 轻量级充分性评估，在不显著增加算力消耗的前提下实现迭代检索。

#### 架构设计

```
┌─────────────────────────────────────────────────────────────┐
│                      用户 Query                              │
└──────────────────────────┬──────────────────────────────────┘
                           │
                    ┌──────▼───────┐
                    │  Query 分析   │ ← 规则引擎 + 轻量分类器
                    │  & 改写拆分   │   (判断复杂度: Simple/Medium/Complex)
                    └──────┬───────┘
                           │
              ┌────────────┼────────────┐
              ▼            ▼            ▼
         Simple       Medium        Complex
         (直接检索)   (2级渐进)     (3级渐进)
              │            │            │
              │    ┌───────▼───────┐    │
              │    │ 一级：文档级   │    │
              │    │ (BM25/Meta)   │    │
              │    └───────┬───────┘    │
              │            │            │
              │    ┌───────▼───────┐    │
              │    │ 二级：页面级   │◄───┘
              │    │ (Dense + RRF) │    │
              │    └───────┬───────┘    │
              │            │            │
              │            │    ┌───────▼───────┐
              │            │    │ 三级：元素级   │
              │            │    │ (Cross-Enc)    │
              │            └───►└───────┬───────┘
              │                         │
              └─────────┬───────────────┘
                        │
                 ┌──────▼───────┐
                 │  去重 + 筛选  │
                 └──────┬───────┘
                        │
                 ┌──────▼───────┐
                 │ 充分性评估    │ ← 轻量级规则 + LLM 二分类
                 │ (Sufficiency) │   (充分 / 不充分)
                 └──┬───────┬───┘
                    │       │
              充分  │       │  不充分 (最多 2 轮迭代)
                    │       │
                    ▼       ▼
              ┌────────┐ ┌──────────────┐
              │ 生成   │ │ 缺口识别      │
              │ 回答   │ │ → 补充检索    │
              └────────┘ │ (使用关联工具) │
                         └──────┬───────┘
                                │
                         ┌──────▼───────┐
                         │ 结果合并     │
                         │ → 最终回答   │
                         └──────────────┘
```

#### 关键模块

**1. 查询分析器（Query Analyzer）**

- 基于规则 + 轻量级分类模型（~100M 参数）
- 输出：查询复杂度（Simple / Medium / Complex）+ 子查询列表
- 规则示例：
  - 包含比较词（"vs"、"对比"、"区别"）→ Medium+
  - 包含多实体名 → Complex
  - 包含时间范围 + 聚合词（"总和"、"平均值"）→ Complex

**2. 多级渐进检索管道**

| 级别 | 检索单元 | 检索方式 | 召回量 | 典型耗时 |
|------|---------|---------|--------|---------|
| 一级（文档级） | 整篇文档 | BM25 + 元数据过滤 | Top 20 | ~50ms |
| 二级（页面级） | 单页/段落 | Dense Retriever + RRF | Top 10 | ~100ms |
| 三级（元素级） | 句子/表格/图表 | Cross-Encoder Rerank | Top 5 | ~150ms |

**3. 去重与筛选**

- 基于 SimHash 的去重
- 基于元数据的时间/来源/权威度加权
- 相邻片段合并（减少碎片化）

**4. 轻量级充分性评估**

- 规则层：证据片段覆盖率（是否覆盖所有子问题）、检索分数阈值
- LLM 层（仅在规则层不确定时触发）：二分类判断（充分 / 不充分）
- 触发 LLM 评估的条件：规则置信度 < 0.7

**5. 缺口识别与补充检索**

- 识别未覆盖的子问题
- 调用关联工具（文档树导航 / 跨文档关联）进行定向补充
- 最多 2 轮迭代（硬性限制，防止时延膨胀）

#### 静态知识利用

| 静态知识 | 利用方式 |
|---------|---------|
| 检索工具特性 | Query Analyzer 根据查询类型路由到合适检索器（如关键词查询优先 BM25） |
| 历史检索经验 | 缓存高频 Query 的最佳检索路径，构建 Query Pattern → Retrieval Strategy 映射表 |
| 知识库属性 | 根据文档类型（PDF/Excel/Markdown）选择不同解析和检索策略 |

#### 算力与效率特征

| 指标 | 估算值 |
|------|-------|
| 检索轮次 | 1-3 轮（平均 1.5 轮） |
| 单轮耗时 | 50-300ms（取决于粒度级别） |
| LLM 调用次数 | 2-4 次（分析 + 评估 + 生成 + 可选缺口识别） |
| 总时延（P95） | < 2s（Simple）/ < 5s（Medium）/ < 10s（Complex） |
| 额外算力（vs 单轮） | +20-50% |
| 适用并发量 | 高（适合在线实时服务） |

---

### 3.3 方案 B：质量优先 — 深度知识感知迭代检索（D-PIR）

#### 设计哲学

**"宁可多花时间，也要确保检索充分"**。方案 B 面向高质量要求场景，通过 LLM 驱动的深度规划、动态知识图谱构建、多维度充分性评估，实现精准的迭代检索。适合对答案质量要求极高的场景。

#### 架构设计

```
┌─────────────────────────────────────────────────────────────┐
│                      用户 Query                              │
└──────────────────────────┬──────────────────────────────────┘
                           │
                    ┌──────▼───────┐
                    │  知识感知     │ ← 查询静态知识库：
                    │  查询规划器   │   工具特性、历史经验、知识库结构
                    └──────┬───────┘
                           │
                    ┌──────▼───────┐
                    │  深度 Query   │ ← LLM 驱动的多维度改写
                    │  改写与拆分   │   生成查询 DAG（子查询依赖图）
                    └──────┬───────┘
                           │
         ┌─────────────────┼─────────────────┐
         ▼                 ▼                 ▼
   ┌──────────┐     ┌──────────┐     ┌──────────┐
   │ 主路径    │     │ 辅助路径  │     │ 探索路径  │
   │(文档级)   │     │(元数据)   │     │(关联工具) │
   └────┬─────┘     └────┬─────┘     └────┬─────┘
        │                │                │
        └────────────────┼────────────────┘
                         │
                    ┌────▼─────┐
                    │ 多路检索  │
                    │ 结果融合  │
                    └────┬─────┘
                         │
         ┌───────────────┼───────────────┐
         ▼               ▼               ▼
   ┌──────────┐   ┌──────────┐   ┌──────────┐
   │ 页面级    │   │ 跨文档   │   │ 知识图谱  │
   │ 精排检索  │   │ 关联扩展  │   │ 路径检索  │
   └────┬─────┘   └────┬─────┘   └────┬─────┘
        │              │              │
        └──────────────┼──────────────┘
                       │
                  ┌────▼─────┐
                  │ 元素/片段 │
                  │ 精确定位  │
                  └────┬─────┘
                       │
                  ┌────▼─────┐
                  │ 去重 +    │
                  │ 融合排序  │
                  └────┬─────┘
                       │
                  ┌────▼─────┐
                  │ 深度充分  │ ← 多维度评估矩阵
                  │ 性评估    │   (覆盖度 + 一致性 + 可信度)
                  └──┬───┬───┘
                     │   │
               充分   │   │  不充分
                     │   │
                     ▼   ▼
               ┌────────┐ ┌──────────────────────┐
               │ 结构化  │ │ 动态知识图谱更新      │
               │ 答案生成│ │ + 缺口分析            │
               └────────┘ │ + 策略调整 (知识感知)  │
                          │ → 下一轮检索 (最多5轮) │
                          └──────────┬───────────┘
                                     │
                          ┌──────────▼───────────┐
                          │ 迭代收敛或达上限      │
                          │ → 最优结果输出        │
                          └──────────────────────┘
```

#### 关键模块

**1. 知识感知查询规划器（Knowledge-Aware Planner）**

- 在检索开始前，根据 **静态知识库** 制定初始检索策略：
  - 检索工具选择：根据历史经验为不同子查询类型匹配最优工具
  - 检索路径规划：基于知识库文档结构树规划检索顺序
  - 预算分配：为每条检索路径分配算力/时延预算

**2. 查询 DAG 生成**

- LLM 将复杂查询拆分为子查询依赖图（DAG）
- 示例：查询"A 公司 2024 年 Q3 营收与 B 公司同期对比"
  ```
  [Q1: A公司2024Q3营收] ──┐
                          ├──→ [Q3: 数值对比与原因分析]
  [Q2: B公司2024Q3营收] ──┘
  ```
- 依赖关系决定检索顺序（Q1、Q2 可并行检索）

**3. 多路并行检索**

| 检索路径 | 方式 | 目标 |
|---------|------|------|
| **主路径** | 文档级 BM25 → 页面级 Dense → 元素级 Cross-Encoder | 逐级精确定位答案 |
| **元数据路径** | 时间/类型/标签过滤 + 向量检索 | 利用结构化元数据快速缩小范围 |
| **关联路径** | 文档树导航 + 跨文档实体链接 | 发现主路径可能遗漏的关联信息 |
| **图谱路径** | 知识图谱实体扩展 + 多跳路径检索 | 利用结构化知识发现隐含关系 |

**4. 动态知识图谱构建与更新**

- **增量构建**：每轮检索后，从新检索到的内容中提取实体和关系，更新查询特定的知识图谱
- **缺口分析**：对比知识图谱覆盖范围与查询需求，识别未覆盖的实体和关系
- **策略调整**：根据上一轮检索结果和缺口分析，调整下一轮的检索策略（如更换检索工具、调整检索粒度）

**5. 深度充分性评估矩阵**

| 评估维度 | 评分方式 | 阈值 |
|---------|---------|------|
| **信息覆盖度** | 子问题覆盖率、关键实体覆盖率 | ≥ 90% |
| **证据一致性** | 跨文档证据冲突检测 | 冲突率 < 10% |
| **来源可信度** | 基于元数据的权威度加权评分 | ≥ 0.7 |
| **语义完备度** | LLM 判断当前证据是否足以给出确定性回答 | 置信度 ≥ 0.8 |

只有当所有维度均达到阈值，或已达到最大迭代轮次（5 轮），才终止迭代。

**6. 知识感知的策略调整**

在每轮迭代后，系统根据以下信息动态调整检索策略：

| 信号 | 调整动作 |
|------|---------|
| 文档级检索返回过多无关文档 | 增加元数据过滤条件，提升检索粒度到页面级 |
| 某子查询反复检索失败 | 更换检索器类型（如从 Dense 切换到 Hybrid），或调整 Query 改写策略 |
| 发现新的关键实体 | 添加到查询 DAG 中，触发新的子查询 |
| 跨文档发现矛盾信息 | 标记为高优先级，触发针对性核查检索 |
| 历史经验匹配 | 直接应用历史成功模式 |

#### 静态 + 动态知识融合利用

```
静态知识层（预构建）              动态知识层（运行时构建）
┌──────────────────┐           ┌──────────────────┐
│ 知识库文档结构树  │           │ 查询特定知识图谱  │
│ 文档元数据索引    │◄─────────►│ 中间检索结果缓存  │
│ 检索工具性能画像  │  融合     │ 充分性评估历史    │
│ 历史成功Query模式 │           │ 缺口分析记录      │
│ 知识图谱(预构建)  │           │ 策略调整日志      │
└──────────────────┘           └──────────────────┘
          │                            │
          └──────────┬─────────────────┘
                     ▼
           ┌──────────────────┐
           │ 检索规划与决策引擎 │
           └──────────────────┘
```

#### 算力与效率特征

| 指标 | 估算值 |
|------|-------|
| 检索轮次 | 1-5 轮（平均 3 轮） |
| 单轮耗时 | 100-500ms |
| LLM 调用次数 | 5-15 次（规划 + 评估 + 缺口分析 + 图谱更新 + 生成） |
| 总时延（P95） | < 5s（Simple）/ < 15s（Medium）/ < 45s（Complex） |
| 额外算力（vs 单轮） | +80-200% |
| 适用并发量 | 低-中（适合高价值场景/异步服务） |

---

### 3.4 方案对比与场景适配

#### 核心差异对比

| 维度 | 方案 A（L-PIR，效率优先） | 方案 B（D-PIR，质量优先） |
|------|--------------------------|--------------------------|
| **检索策略** | 规则驱动 + 轻量分类 | LLM 驱动 + 深度规划 |
| **查询规划** | 复杂度三分类 + 简单拆分 | 查询 DAG + 多路径并行规划 |
| **迭代深度** | 最多 2 轮 | 最多 5 轮 |
| **充分性评估** | 规则层 + LLM 二分类（降级触发） | 四维度评估矩阵 + 知识图谱缺口分析 |
| **知识利用** | 静态知识为主（缓存、规则） | 静态+动态深度融合（增量图谱） |
| **关联工具** | 按需调用（文档树导航） | 深度集成（多路并行 + 图谱扩展） |
| **策略调整** | 预设 fallback 策略 | 基于动态知识的多信号自适应调整 |
| **算力消耗** | +20-50% vs 单轮 | +80-200% vs 单轮 |
| **时延（P95）** | Simple <2s, Medium <5s, Complex <10s | Simple <5s, Medium <15s, Complex <45s |
| **LLM 调用次数** | 2-4 次/query | 5-15 次/query |
| **并发能力** | 高 | 中-低 |

#### 场景适配建议

| 场景 | 推荐方案 | 理由 |
|------|---------|------|
| **实时客服问答** | 方案 A | 低时延要求，高并发，多数问题为单文档查找 |
| **企业知识库搜索** | 方案 A | 用户期望秒级响应，信息分布相对集中 |
| **合规审查/法律检索** | 方案 B | 不容遗漏，允许较长等待，需要跨文档交叉验证 |
| **金融研报分析** | 方案 B | 多文档数据对比、计算、交叉验证，容错率低 |
| **医疗文献检索** | 方案 B | 精确度要求极高，遗漏代价大 |
| **多渠道混合场景** | 方案 A + 复杂度路由 | Simple→A-Simple, Medium→A-Medium, Complex→B |
| **内部知识管理（异步）** | 方案 B | 可接受分钟级延迟，追求检索完整性 |

#### 演进路径建议

```
Phase 1: 方案 A 落地
  └── 建立渐进式检索基础框架
  └── 积累历史检索经验（静态知识）
  └── 验证渐进式策略的收益

Phase 2: 方案 B 核心模块引入
  └── 引入深度充分性评估矩阵
  └── 引入动态知识图谱（增量构建）
  └── 在 A 的基础上增加 B 的核心评估能力

Phase 3: 全场景融合
  └── 智能路由：Query 复杂度分析 → 自动选择 A 或 B
  └── 预算感知调度：根据时延预算动态调整迭代深度
  └── 持续学习：从 A/B 方案的反馈中优化静态知识库
```

---

## 附录：参考文献

### 学术论文

1. Asai A, Wu Z, Wang Y, et al. "Self-RAG: Learning to Retrieve, Generate, and Critique through Self-Reflection." ICLR 2024. https://arxiv.org/abs/2310.11511
2. Yan S, et al. "Corrective Retrieval Augmented Generation." 2024. https://arxiv.org/abs/2401.15884
3. Jeong S, et al. "Adaptive-RAG: Learning to Adapt Retrieval-Augmented Large Language Models through Question Complexity." 2024. https://arxiv.org/abs/2403.14403
4. Shao Z, et al. "Enhancing Retrieval-Augmented Large Language Models with Iterative Retrieval-Generation Synergy." 2023. https://arxiv.org/abs/2305.15294
5. Jiang Z, et al. "Active Retrieval Augmented Generation (FLARE)." 2023. https://arxiv.org/abs/2305.06983
6. "FAIR-RAG: Faithful Adaptive Iterative Refinement for Retrieval-Augmented Generation." 2025. https://arxiv.org/abs/2510.22344
7. "FunnelRAG: A Coarse-to-Fine Progressive Retrieval Paradigm for RAG." NAACL 2025. https://arxiv.org/abs/2410.10293
8. Zhang X, et al. "Hierarchical Retrieval-Augmented Generation Model with Rethink for Multi-hop Question Answering (HiRAG)." 2024. https://arxiv.org/abs/2408.11875
9. "RAS: Retrieval-And-Structuring for Knowledge-Intensive LLM Generation." 2025. https://arxiv.org/abs/2502.10996
10. "SeaKR: Self-aware Knowledge Retrieval for Adaptive Retrieval Augmented Generation." 2024. https://arxiv.org/abs/2406.19215
11. "GRIP: Generation-guided Retrieval with Information Planning." 2025. https://arxiv.org/abs/2604.11407
12. "MacRAG: Multi-scale Adaptive Context RAG." 2025. https://arxiv.org/abs/2505.06569
13. "Mix-of-Granularity: Optimize the Chunking Granularity for RAG." COLING 2025. https://arxiv.org/abs/2406.00456
14. "SproutRAG: Attention-Guided Tree Search with Progressive Embeddings." 2025. https://arxiv.org/abs/2606.18381
15. "LPKG: Learning to Plan for Retrieval-Augmented LLMs from Knowledge Graphs." 2024. https://arxiv.org/abs/2406.14282
16. Singh A, et al. "Agentic Retrieval-Augmented Generation: A Survey on Agentic RAG." 2025. https://arxiv.org/abs/2501.09136
17. Gupta S, et al. "A Comprehensive Survey of RAG: Evolution, Current Landscape and Future Directions." 2024. https://arxiv.org/abs/2410.12837
18. Gao Y, et al. "Retrieval-Augmented Generation for Large Language Models: A Survey." 2023. https://arxiv.org/abs/2312.10997
19. Zhang W, et al. "From Web Search towards Agentic Deep Research." 2025. https://arxiv.org/abs/2506.18959
20. Huang Y, et al. "Deep Research Agents: A Systematic Examination And Roadmap." 2025. https://arxiv.org/abs/2506.18096

### 工业产品

21. 腾讯云 ADP 知识库检索 Agent —— https://www.tencentcloud.com/zh/document/product/1254/78742
22. 腾讯 WeKnora 开源知识框架 —— https://github.com/Tencent/WeKnora
23. 阿里云百炼知识库 RAG —— https://www.alibabacloud.com/help/zh/model-studio/rag-knowledge-base
24. 阿里通义实验室 VRAG —— https://github.com/Alibaba-NLP/VRAG
25. 微软 GraphRAG —— https://github.com/microsoft/graphrag
26. NVIDIA RAG Blueprint —— https://github.com/NVIDIA-AI-Blueprints/rag
27. Deep Research 系统架构分析 —— https://zylos.ai/research/2026-04-21-deep-research-agent-architectures
28. OpenAI vs Perplexity vs Google Deep Research —— https://www.punku.ai/blog/comprehensive-analysis-deep-research-implementations
