# 经验驱动的RAG自适应进化技术调研报告

> 编制日期：2026年7月  
> 调研范围：产品现状 / 工业界方案 / 学术界研究 / 技术方案设计

---

## 目录

1. [产品25B版本现状分析](#1-产品25b版本现状分析)
2. [学术界自适应与自进化RAG研究进展](#2-学术界自适应与自进化rag研究进展)
3. [工业界自适应与自进化RAG产品分析](#3-工业界自适应与自进化rag产品分析)
4. [经验驱动的持续自适应进化技术方案](#4-经验驱动的持续自适应进化技术方案)
5. [总结与建议](#5-总结与建议)

---

## 1. 产品25B版本现状分析

### 1.1 当前能力定位

当前25B版本产品采用**传统的静态RAG（Retrieval-Augmented Generation）管线**，其核心流程为：

```
用户Query → 向量检索（Embedding匹配） → Top-K片段召回 → LLM生成回答
```

这是一种**一次检索+一次生成**的单次（single-pass）RAG模式。

### 1.2 当前版本局限性分析

基于用户提供的现状描述"当前产品不具备经验沉淀的能力"，结合对传统RAG管线局限性的分析，25B版本存在以下核心短板：

| 维度 | 现状描述 | 具体影响 |
|------|---------|---------|
| **知识沉淀** | 每次检索独立执行，历史检索行为无留存 | 同一query反复检索浪费算力；高价值的检索路径无法复用 |
| **关联挖掘** | 检索结果间无关联关系建模 | 无法发现不同query对应相似检索需求时的跨查询知识关联 |
| **路径优化** | 检索工具组合固定，无自适应调整机制 | 面对复杂query时工具选择不灵活，检索效率低下 |
| **经验复用** | 检索经验完全依赖模型参数记忆，无持久化经验库 | 同类问题反复"从零开始"检索，无法利用历史成功经验 |
| **反馈闭环** | 用户反馈与检索质量无关联通路 | 检索失败的信息无法驱动系统自我改进 |

### 1.3 与业界差距

当前主流工业界RAG产品已普遍具备以下能力，而这些能力在25B版本中缺失：

- **自适应检索路由**（Adaptive RAG）：根据query复杂度动态选择检索策略（无检索/单次检索/多轮检索）
- **知识图谱增强**（GraphRAG）：实体关系建模实现多跳推理
- **Agentic RAG**：自主规划检索步骤、调用工具组合
- **检索经验记忆**：历史检索轨迹的持久化与复用
- **反馈驱动优化**：基于用户反馈的检索策略动态调整

---

## 2. 学术界自适应与自进化RAG研究进展

### 2.1 自适应RAG（Adaptive RAG）

#### 2.1.1 Self-RAG：通过自反思实现检索、生成与评判

- **论文**：Self-RAG: Learning to Retrieve, Generate and Critique through Self-Reflection（ICLR 2024, Asai et al.）
- **链接**：https://selfrag.github.io/ | https://proceedings.iclr.cc/paper_files/paper/2024/file/25f7be9694d7b32d5cc670927b8091e1-Paper-Conference.pdf
- **核心思想**：训练LLM在生成过程中自主决定何时检索、评判检索内容的相关性和支持度、以及输出的完整性。通过引入特殊"反思token"（Retrieve、ISREL、ISSUP、ISUSE），模型可以根据任务需求自适应调整检索行为。
- **关键价值**：不再无差别检索，而是按需检索+自我评判，实现了可控的检索引擎。在事实性要求高的任务中频繁检索，在开放式创作任务中减少检索。

#### 2.1.2 Adaptive-RAG：基于问题复杂度动态选择检索策略

- **论文**：Adaptive-RAG: Learning to Adapt Retrieval-Augmented Large Language Models through Question Complexity（NAACL 2024, Jeong et al.）
- **链接**：https://aclanthology.org/2024.naacl-long.389/
- **核心思想**：训练一个轻量级分类器（T5-large）预测query复杂度，将query分为三类：
  - 简单问题 → 无需检索，直接回答
  - 中等复杂度 → 单次检索+生成
  - 高复杂度 → 多轮迭代检索（IRCoT）
- **关键价值**：首次系统性地将query复杂度分层与检索策略匹配，避免了"一刀切"的检索方式。

#### 2.1.3 CRAG（Corrective RAG）：检索结果自校正

- **论文**：Corrective Retrieval Augmented Generation（2024, Yan et al.）
- **链接**：https://www.kore.ai/blog/corrective-rag-crag
- **核心思想**：引入检索评估器判断检索质量，当检索结果不理想时自动触发知识精炼、网络搜索等校正动作。
- **关键价值**：闭环的检索质量保障机制，从"信任检索结果"变为"验证后使用"。

#### 2.1.4 SeaKR：基于模型内部不确定度的自适应检索

- **论文**：SeaKR: Self-aware Knowledge Retrieval for Adaptive Retrieval Augmented Generation（ACL 2025）
- **链接**：https://aclanthology.org/2025.acl-long.1312/
- **核心思想**：从LLM内部状态中提取"自我感知不确定性"（self-aware uncertainty），当模型对回答不确定时自动触发检索。同时利用不确定性进行检索结果重排序。
- **关键价值**：利用模型内在的不确定性信号驱动检索决策，无需额外训练分类器。

#### 2.1.5 SPARKLE：基于强化学习的即插即用检索策略

- **论文**：SPARKLE: A Structured and Plug-and-play Agentic Retrieval Policy for Adaptive RAG（ACL 2026）
- **链接**：https://aclanthology.org/2026.acl-long.1793.pdf
- **核心思想**：引入轻量级proxy模型+知识图谱推理做逐步检索决策（何时检索、检索什么、如何整合），使用PPO强化学习训练。采用二叉树结构化的rollout策略增强RL训练时的探索。
- **关键价值**：即插即用设计，proxy模型独立于检索器和LLM，可跨模型泛化。在域内提升9.17%，域外提升2.85%。

#### 2.1.6 完整对比：35种自适应检索方法研究

- **论文**：Adaptive Retrieval without Self-Knowledge? Bringing Uncertainty Back Home（ACL 2025）
- **链接**：https://aclanthology.org/2025.acl-long.319.pdf
- **核心发现**：对35种自适应检索方法（8种最新方法+27种不确定性估计方法）的全面对比发现——简单的不确定性估计方法往往在效率和自我认知上优于复杂的pipeline方案，同时保持相当的QA性能。

### 2.2 自进化与经验驱动RAG

#### 2.2.1 GAM-RAG：增益自适应记忆的进化检索

- **论文**：GAM-RAG: Gain-Adaptive Memory for Evolving Retrieval in RAG（arXiv 2025）
- **链接**：https://arxiv.org/abs/2603.01783v1
- **核心思想**：**训练自由（training-free）的检索经验积累框架**。构建轻量级关系自由的分层索引，每次检索后通过sentence-level反馈更新节点记忆，使用卡尔曼启发的增益自适应规则（Kalman-inspired gain rule）平衡记忆的稳定性与可塑性。
- **关键指标**：平均性能提升3.95%（最强baseline对比），5轮记忆后提升8.19%，推理成本降低61%。
- **与本方案高度相关**：该工作在无训练前提下实现了检索经验的持续积累和自适应更新，是经验驱动RAG的重要参考。

#### 2.2.2 SegMem-RAG：多语料库自适应记忆路由

- **论文**：SegMem-RAG: Adaptive Memory for Retrieval-Augmented Generation in Open-Ended Knowledge Environments（AAAI 2026）
- **链接**：https://ojs.aaai.org/index.php/AAAI/article/view/40320
- **核心思想**：面向多源无标注语料库的RAG框架，增量更新结构化记忆，利用自反思指导不同语料库间的检索路由。
- **关键价值**：解决了真实场景中知识来源异构、无标注的问题，通过经验学习最优检索路由。

#### 2.2.3 REMINDRAG / ReMindRAG：基于KG记忆的路径优化

- **论文**：ReMindRAG: Low-Cost LLM-Guided Knowledge Graph Traversal for Efficient RAG（NeurIPS 2025）
- **链接**：https://proceedings.neurips.cc/paper_files/paper/2025/file/4d880ba08f6b115bb8d685159bb167eb-Paper-Conference.pdf
- **核心思想**：在知识图谱的边上嵌入检索经验权重，成功的路径加强（沿query embedding方向更新），失败的路径削弱（沿反方向更新）。通过记忆回放（Memory Replay）在相似query到来时快速扩展初始子图，减少LLM调用。
- **关键指标**：多轮记忆后性能提升5%-10%；在"同类query"和"微妙不同query"两种设定下均展现出鲁棒的自我校正能力。

#### 2.2.4 ExpRAG & ERL：经验检索增强生成

- **论文**：Retrieval-Augmented LLM Agents: Learning to Learn from Experience（arXiv 2025）
- **链接**：https://arxiv.org/html/2603.18272v1
- **核心思想**：系统性地研究了如何训练LLM Agent利用检索到的历史经验（ExpRAG）。分析了经验存储策略、检索query构建、轨迹筛选等关键设计选择，并提出将经验检索整合到微调过程中的pipeline。
- **配套工作**：Experiential Reflective Learning (ERL) 构建经验启发式库，通过LLM对历史经验进行反思提取可复用的启发式规则。

#### 2.2.5 ExpWeaver & ExpGraph：隐空间经验检索

- **论文（ExpWeaver）**：ExpWeaver: LLM Agents Learn from Experience via Latent RAG（arXiv 2025）
- **链接**：https://arxiv.org/html/2606.01041
- **核心思想**：在LLM隐空间内进行经验检索，每一步解码时从经验库中检索相似经验的dense embedding，通过交叉注意力和门控残差机制整合。
- **论文（ExpGraph）**：ExpGraph: Model-Agnostic Experience Learning with Graph-Structured Memory（arXiv 2025）
- **链接**：https://arxiv.org/html/2605.30712
- **核心思想**：将经验组织为图结构，节点为技能（成功经验的提炼）和教训（失败经验的提炼），边表示语义或策略关联。通过轻量级检索副驾驶（copilot）学习任务自适应的检索控制，使用PPO优化。

#### 2.2.6 HERA：多Agent RAG的经验驱动进化编排

- **论文**：Experience as a Compass: Multi-agent RAG with Evolving Orchestration and Agent Prompts（arXiv 2026）
- **链接**：https://arxiv.org/html/2604.00901v1
- **核心思想**：三层层次化框架。顶层编排器基于经验库生成query特定的执行计划，底层专业化Agent基于角色感知提示优化（Role-Aware Prompt Evolution）进行针对性改进，经验库从成功与失败轨迹中提取反思洞察。
- **关键指标**：6个知识密集型benchmark上平均提升38.69%。

#### 2.2.7 MetaKGRAG：元认知知识图谱RAG

- **论文**：Towards Self-cognitive Exploration: Metacognitive Knowledge Graph Retrieval Augmented Generation（arXiv 2025）
- **链接**：https://arxiv.org/html/2508.09460
- **核心思想**：引入"感知-评估-调整"（Perceive-Evaluate-Adjust）闭环，让系统自我评估探索质量，识别覆盖度或相关性的不足，并从精确定位点执行轨迹关联的修正。
- **关键价值**：路径感知的闭环优化，解决了传统KG-RAG的"认知盲区"问题。

#### 2.2.8 RAG-on-a-Diet 与 RouteRAG：RL驱动的检索效率优化

- **RAG-on-a-Diet**（ACL 2026）：使用轻量级RL agent在每一步做独立的检索决策（模型选择+停止策略），实现60%的成本节省
- **RouteRAG**（ACL 2026 Findings）：在文本检索、图谱检索、混合检索三种模式间基于GRPO强化学习动态选择，同时优化准确率和检索效率

### 2.3 关键学术趋势总结

| 趋势方向 | 代表性工作 | 技术方法 | 成熟度 |
|---------|-----------|---------|-------|
| 按需检索（检索门控） | Self-RAG, SeaKR, Adaptive-RAG | 反思token / 不确定度 / 复杂度分类器 | ⭐⭐⭐⭐⭐ |
| 检索质量自校正 | CRAG, Self-Corrective RAG | 检索评估→重写query→二次检索 | ⭐⭐⭐⭐ |
| 检索经验积累 | GAM-RAG, REMINDRAG, ExpWeaver | 记忆更新/记忆回放/隐空间检索 | ⭐⭐⭐ |
| 经验驱动编排 | HERA, ExpGraph, APEX-EM | 图结构经验+RL策略优化 | ⭐⭐ |
| 多轮自适应检索 | SIM-RAG, RAG-on-a-Diet | Critic模块+自我练习+RL | ⭐⭐⭐ |
| 元认知闭环优化 | MetaKGRAG, ERL | 感知-评估-调整+反思提取 | ⭐⭐ |

---

## 3. 工业界自适应与自进化RAG产品分析

### 3.1 微软（Microsoft）

#### 3.1.1 GraphRAG

- **开源地址**：https://github.com/microsoft/GraphRAG （34K+ Stars）
- **技术博客**：https://www.microsoft.com/en-us/research/blog/graphrag-unlocking-llm-discovery-on-narrative-private-data/
- **技术架构**：
  - **索引阶段**：LLM自动从文档中提取实体和关系，构建知识图谱 → 社区检测（Leiden算法）→ 层级社区摘要生成
  - **查询阶段**：四种检索模式
    - **Global Search**：利用社区摘要回答全局性问题（如"数据集的主要主题是什么？"）
    - **Local Search**：实体邻居展开+关联概念检索
    - **DRIFT Search**：融合社区信息的实体搜索
    - **Basic Search**：标准向量检索
  - **动态社区选择**（v2.0+）：用LLM评估社区报告相关性，逐层遍历知识图谱选择最有价值的社区，降低token消耗
  - **Prompt Tuning**：自动适配领域特征的prompt优化机制
- **核心特点**：通过知识图谱实现跨文档关系推理，解决了传统RAG无法回答全局性/总结性问题的核心痛点
- **与经验驱动方案的关联**：GraphRAG的社区摘要可视为一种"预计算的经验知识"，但其经验是静态的，不随使用反馈动态进化

#### 3.1.2 Azure HorizonDB Graph-Augmented RAG

- **文档**：https://learn.microsoft.com/en-us/azure/horizondb/ai/graph-rag
- **特点**：将向量搜索+语义重排序+Cypher图遍历+结果融合全部在数据库内完成，无需跨系统数据搬运

### 3.2 英伟达（NVIDIA）

#### 3.2.1 NeMo Retriever — Agentic Retrieval Pipeline

- **技术博客**：https://huggingface.co/blog/nvidia/nemo-retriever-agentic-retrieval
- **开源地址**：https://github.com/NVIDIA/NeMo-Retriever
- **技术架构**：
  - **ReACT架构**：Agent迭代搜索→评估→优化方法
  - **工具集**：`think`（规划）、`retrieve(query, top_k)`（检索）、`final_results`（输出）
  - **自适应行为**：
    - 动态生成更优检索query
    - 持续改写query直到找到有用信息
    - 将复杂多部分query拆解为多个简单子query
  - **安全网**：Agent达到最大步数时回退到RRF（倒数排序融合）
- **性能**：ViDoRe v3 pipeline leaderboard **第1名**，BRIGHT benchmark **第2名**
- **核心特点**：Agentic pipeline的泛化能力——同一架构在不同benchmark上无需调整即可达到SOTA
- **成本优化方向**：正在研究将Agent推理模式蒸馏到小模型中

#### 3.2.2 NeMo Retriever 其他核心能力

- **多模态提取**：PDF中的文本、表格、图表、信息图15x加速提取
- **Embedding & Reranking微服务**：动态embedding尺寸（存储降35x）、长上下文支持（8192 tokens）、hard-negative mining训练
- **数据飞轮**：基于合成数据的embedding模型定制+在线评估反馈闭环

### 3.3 谷歌（Google）

#### 3.3.1 Vertex AI RAG Engine

- **官方文档**：https://cloud.google.com/vertex-ai/generative-ai/docs/rag-engine/rag-overview
- **技术博客**：https://cloud.google.com/blog/products/ai-machine-learning/introducing-vertex-ai-rag-engine
- **核心能力**：
  - **Cross Corpus Retrieval（跨语料库检索）**：Agentic Retrieval后端，自动从多个RAG语料库中路由和检索
    - 编排器/路由器：接收query并协调检索流程
    - 规划Agent：分析query，基于语料库描述确定相关语料
    - 推理Agent：评估检索上下文是否充分（SCA，Sufficient Context Awareness），不充分时生成反馈触发二次检索
  - **动态检索（Dynamic Retrieval）**：为Google Search grounding提供动态阈值，评估query是否需要联网搜索，自动控制延迟/质量/成本
  - **Task-Type Embeddings**：基于LLM蒸馏的dual-encoder embedding模型，不同任务类型（QA、文档检索、事实验证）使用不同embedding策略
  - **RAG Managed DB**：支持KNN精确检索和ANN近似检索两种策略，可配置树深度和叶子节点数

#### 3.3.2 DataGemma

- **链接**：https://deepmind.google/models/gemma/datagemma/
- **核心能力**：将LLM输出与Google Data Commons的真实统计数据grounding，使用RIG（Retrieval-Interleaved Generation）和RAG两种方法

### 3.4 腾讯（Tencent）

#### 3.4.1 腾讯云智能体开发平台（TCADP）

- **产品文档**：https://cloud.tencent.com/document/product/1759/123554
- **技术博客**：https://adp.tencentcloud.com/zh/blog/enterprise-rag-guide
- **核心能力**：
  - **知识库检索Agent（Agentic RAG）**：自主规划并拆解知识库检索任务，支持多次调用检索工具和计算工具组合
    - 内置工具：KnowledgeRetrievalAnswer（全库检索+回答）、BoundedKnowledgeQA（指定范围检索）、Text2SQL+SQLExecutor（结构化数据查询）
  - **混合检索**：向量检索+关键词检索，支持Excel检索增强
  - **结果重排序**：重排序模型对召回片段二次排序
  - **多模型配置**：向量模型、问答对生成模型、Schema生成模型、文档解析模型分别可配置
  - **标签/分类管理**：文档支持标签和到期时间管理

#### 3.4.2 KnowLion：动态超图知识检索

- **技术文章**：https://developer.cloud.tencent.com/article/2638651
- **核心能力**：
  - **五重检索内核**：Vector语义 + BM25关键词 + Graph动态推理 + 上下文关联 + 实体多跳推理
  - **全属性实时演化**：实体频次、实时语义聚合等属性通过动态聚合函数自动更新，新文档入库即可检索
  - **智能自维护**：段落主题重叠率≥80%时触发VectorSimCrudAgent，LLM自动合并相似知识、更新冲突关系，维护成本降低80%
  - **三级超图架构**：Doc→Para→Entity一体化存储，跨文档多对多轻量级聚合边
- **核心特点**：**这是目前公开资料中最接近"知识自生长、自优化"理念的工业级产品**。通过动态图数据库实现知识实时聚合，具备"越用越聪明"的特性。

### 3.5 阿里云（Alibaba Cloud）

#### 3.5.1 百炼大模型服务平台 RAG

- **官方文档**：https://help.aliyun.com/zh/model-studio/rag-knowledge-base
- **核心能力**：
  - 知识库创建+文档管理+向量化入库的全托管服务
  - 支持多种Embedding模型（text-embedding-v3/v4）
  - 检索策略：向量+全文混合检索（权重7:3），RRF或加权融合
  - 结果重排序（Rerank）
  - **查询改写（Query Rewrite）**：利用conv-rewrite-qwen-1.8b基于会话上下文自动改写query

#### 3.5.2 PAI-RAG

- **官方文档**：https://help.aliyun.com/zh/pai/rag-dialogue-system/
- **核心能力**：
  - 支持FAISS（本地）/ Hologres / ElasticSearch / Milvus / RDS PostgreSQL 等多种向量数据库
  - 查询改写+结果重排
  - 混合检索（Hybrid）：向量+BM25关键字
  - 多模态RAG支持（Qwen-VL系列）

#### 3.5.3 Tablestore 知识存储（RAG）服务

- **文档**：https://www.alibabacloud.com/help/zh/tablestore/knowledge-storage-architecture
- **特点**：Serverless全托管架构，Subspace多租户隔离，自动向量索引+全文索引

### 3.6 字节跳动（ByteDance）

#### 3.6.1 ContextSearch（上下文搜索）

- **技术文章**：https://developer.volcengine.com/articles/7599494396346400774
- **核心能力**：
  - **端到端搜索链路**：数据导入 → Embedding → Rerank → 搜索打分 → 意图分析 → VLM
  - **融合豆包大模型生态**，预集成开源模型
  - RAG链路效果提升超15%，特定垂类高达80%
  - 支持知识库、以图搜图、视频搜索等场景化搜索
- **底层基础设施**：
  - **云搜索服务**：完全兼容OpenSearch/ElasticSearch，自研DiskANN+RaBitQ算法
  - **Milvus原生向量数据库**：向量搜索全面融入VeDB、MongoDB、MySQL、Redis
  - 查询性能提升115%、内存消耗降90%、成本降75%

#### 3.6.2 Mem0 Agentkit

- 提供记忆管理能力，通过Token消耗节省特性降低企业成本

### 3.7 Anthropic（Anthropic）

#### 3.7.1 Contextual Retrieval（上下文检索）

- **技术博客**：https://www.anthropic.com/engineering/contextual-retrieval
- **核心技术**：
  - **Contextual Embeddings**：在chunk embedding前，使用LLM为每个chunk生成上下文解释并前置拼接，解决chunk语义隔离问题
  - **Contextual BM25**：同样策略应用于BM25索引
  - 综合效果：检索失败率降低49%（Contextual Embeddings + Contextual BM25），加Reranking后降低67%
  - 成本：约$1.02/百万文档token

### 3.8 开源框架生态

#### 3.8.1 LangChain / LangGraph

- **Adaptive RAG Tutorial**：https://langchain-opentutorial.gitbook.io/langchain-opentutorial
- **模式**：Query分析 → 路由（Web Search / Self-Corrective RAG） → 文档评估 → 答案生成 → 幻觉检测
- **核心价值**：将Adaptive RAG的实现模式标准化为LangGraph状态机

#### 3.8.2 LlamaIndex

- **开源地址**：https://github.com/run-llama/llama_index
- **核心能力**：多策略检索（HyDE、Fusion Retrieval、Adaptive RAG）、Reranking、查询变换、结构化输出

### 3.9 工业界能力对比矩阵

| 能力维度 | 微软 GraphRAG | NVIDIA NeMo | Google Vertex | 腾讯 KnowLion | 阿里 百炼 | 字节 ContextSearch |
|---------|:---:|:---:|:---:|:---:|:---:|:---:|
| 知识图谱增强 | ✅ | ⚠️ | ✅ | ✅ | ❌ | ❌ |
| Agentic检索 | ❌ | ✅ | ✅ | ✅ | ❌ | ⚠️ |
| 自适应路由 | ⚠️ | ✅ | ✅ | ✅ | ❌ | ⚠️ |
| 查询改写 | ❌ | ✅ | ⚠️ | ✅ | ✅ | ✅ |
| 结果重排序 | ❌ | ✅ | ✅ | ✅ | ✅ | ✅ |
| 混合检索 | ⚠️ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **经验/记忆积累** | ❌ | ❌ | ❌ | ✅ | ❌ | ❌ |
| **自进化能力** | ❌ | ❌ | ❌ | ✅ | ❌ | ❌ |
| 多模态检索 | ❌ | ✅ | ❌ | ❌ | ✅ | ✅ |

> 注：✅=具备，⚠️=部分具备，❌=暂未公开
> 
> **关键发现**：在"经验/记忆积累"和"自进化能力"两个维度上，仅腾讯KnowLion有一定探索，且使用了动态图数据库实现知识实时聚合。**这验证了本方案的前瞻性和差异化价值**。

---

## 4. 经验驱动的持续自适应进化技术方案

### 4.1 方案概述与设计理念

基于前述调研，当前工业界产品普遍使用**静态检索管线**或**Agentic自适应路由**，但在"检索经验沉淀→关联挖掘→路径优化→持续进化"的闭环方面几乎空白（仅KnowLion有部分探索）。学术界GAM-RAG、REMINDRAG、ExpWeaver等工作已在经验驱动检索方面取得初步成果，但多为单模块优化，缺乏系统性的工程方案。

本方案依托历史检索上下文数据，实现知识沉淀、关联挖掘与路径优化的三大核心能力闭环，让检索系统具备**自主迭代、自适应优化**的进化能力。以下提出两个差异化技术方案，适应不同场景需求。

### 4.2 三大核心模块（两个方案的共性基础）

无论采用方案A还是方案B，系统均包含以下三大核心模块：

#### 模块一：领域知识抽取与存储

**核心流程**：

```
用户查询 → 检索执行 → 高置信度结果筛选 → LLM知识抽取 → 结构化存储 → 双路匹配复用
```

**能力细化**：

1. **高置信度结果筛选**：基于多维信号过滤
   - 用户正反馈（采纳/点赞/复制等行为信号）
   - 入库标签匹配度（预定义的领域标签体系）
   - 检索结果的一致性得分（多次检索结果的稳定性）
   - LLM自评置信度（类似SeaKR的自我感知不确定性）

2. **核心领域知识抽取**：依托大模型从高置信度检索结果中抽取
   - 关键实体（人物、组织、产品、技术术语等）
   - 核心概念定义与解释
   - 实体间关系（因果关系、层级关系、时序关系等）
   - 操作流程与最佳实践
   - 常见误区与边界条件

3. **标准化字段结构化存储**：
   - 实体ID / 实体类型 / 实体名称 / 别名列表
   - 属性字段（key-value对）
   - 关系列表（source→relation→target）
   - 来源文档引用（chunk_id, document_id）
   - 置信度得分 / 最后更新时间 / 使用频次
   - 关联query embedding（用于相似query匹配）

4. **双路匹配复用**：
   - **实体精确匹配**：基于实体名称/别名/ID的结构化查询
   - **Embedding向量匹配**：将query embedding与已存储知识关联的query embedding计算余弦相似度，召回历史成功匹配的知识

#### 模块二：检索关联关系挖掘

**核心流程**：

```
Query执行 → 多组检索结果 → 片段主题聚类 → 关联关系发现 → 关系图存储 → 相似Query自动推送
```

**能力细化**：

1. **多组高置信度结果捕捉**：同一query对应的多次检索执行（可能由不同工具/策略组合产生）中，筛选出用户最终采纳的结果链。

2. **片段间潜在关联挖掘**：
   - **主题聚类**：对检索结果片段进行语义聚类，发现同一query下多个独立片段间的隐含主题关联
   - **概念桥接**：识别不同片段中出现的共指实体（co-reference），建立跨文档概念关联
   - **时序关联**：基于文档时间戳发现知识演化的时序关系

3. **Query-Result对应关系留存**：
   - 记录结构：`{query_embedding, query_text, result_chunks[], tool_chain[], confidence_score, timestamp, user_feedback}`
   - 支持按query embedding相似度 + query关键词匹配的双路查询

4. **相似检索自动推送**：
   - 新query到来时，计算其与历史query的embedding相似度
   - 超过阈值（如cosine_sim > 0.85）时，自动将历史匹配的高质量结果作为补充上下文推送给LLM
   - 支持人工审核开关：可选择"自动推送"或"提示推送"

#### 模块三：检索路径自适应优化

**核心流程**：

```
历史检索数据统计 → 工具组合效果评估 → 场景-策略映射构建 → 新Query策略推荐 → 在线效果反馈 → 策略动态更新
```

**能力细化**：

1. **历史检索数据统计**：
   - 按query类型（事实型/分析型/对比型/操作型等）统计各工具组合的：
     - 召回率 / 精确率（基于用户反馈）
     - 平均检索耗时
     - Token消耗
     - 用户满意度得分

2. **工具组合适配场景挖掘**：
   - 发现"query特征 → 最优工具组合"的规律
   - Query特征维度：复杂度、领域、实体密度、时效性要求、多跳推理需求
   - 工具组合示例：
     - `向量检索 → Rerank`（适合简单事实查询）
     - `关键词检索 + 向量检索 → RRF融合 → Rerank`（适合中等复杂度）
     - `Query分解 → 多路并行检索 → 结果聚合 → Rerank`（适合复杂多跳查询）
     - `向量检索 → KG遍历 → 上下文扩展 → 结果整合`（适合关系推理查询）

3. **动态策略推荐**：
   - 新query到来时，先做query特征分析
   - 匹配历史最优策略（基于相似query的经验）
   - 若为新类型query，回退到默认策略并标记为"探索模式"

4. **在线效果反馈闭环**：
   - 每次检索执行后收集：检索结果质量、用户反馈、资源消耗
   - 定期（或事件触发）更新场景-策略映射表

### 4.3 方案A：轻量级渐进式方案（低成本、快速落地）

#### 4.3.1 设计哲学

"**先积累，再优化**"——以最小成本启动经验沉淀能力，随着经验数据积累逐步释放优化价值。适合算力预算有限、需要快速验证ROI的场景。

#### 4.3.2 技术架构

```
┌─────────────────────────────────────────────────────────┐
│                    Query入口层                           │
│  ┌─────────────┐  ┌──────────────┐  ┌───────────────┐  │
│  │ Query分类器  │  │ 相似Query匹配 │  │ 历史策略查询   │  │
│  │ (轻量级)     │  │ (Embedding)  │  │ (规则匹配)    │  │
│  └──────┬──────┘  └──────┬───────┘  └───────┬───────┘  │
└─────────┼─────────────────┼───────────────────┼──────────┘
          │                 │                   │
          ▼                 ▼                   ▼
┌─────────────────────────────────────────────────────────┐
│                    经验存储层（离线维护）                    │
│  ┌───────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │ 知识条目库     │  │ Query-Result  │  │ 策略统计表    │  │
│  │ (结构化存储)   │  │ 关联表        │  │ (统计聚合)   │  │
│  │               │  │               │  │              │  │
│  │ 实体 + 属性   │  │ query_emb →   │  │ query_type → │  │
│  │ + 关系 + 来源 │  │ result_chunks │  │ best_tools   │  │
│  │ + 关联query   │  │ + confidence  │  │ + avg_score  │  │
│  └───────────────┘  └──────────────┘  └──────────────┘  │
└─────────────────────────────────────────────────────────┘
          │                 │                   │
          ▼                 ▼                   ▼
┌─────────────────────────────────────────────────────────┐
│                    离线经验提炼层（定时任务）                 │
│  ┌──────────────────────────────────────────────────┐   │
│  │ 1. 知识抽取Job（日频）：筛选高置信度结果→LLM抽取    │   │
│  │ 2. 关联挖掘Job（日频）：聚类+关系发现+图谱更新      │   │
│  │ 3. 策略统计Job（周频）：聚合统计→规则生成/更新      │   │
│  └──────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────┘
```

#### 4.3.3 关键设计决策

| 设计维度 | 方案A选择 | 理由 |
|---------|----------|------|
| **知识抽取时机** | 离线批量（日频） | 避免在线推理延迟，用批量+缓存降低LLM调用成本 |
| **Query关联匹配** | Embedding向量相似度 | 简单高效，无需训练，部署成本低 |
| **策略优化方式** | 统计规则（非ML） | 基于历史统计的启发式规则，可解释、可调试 |
| **经验更新机制** | 定时全量更新 | 一致性高，实现简单 |
| **存储方案** | 关系型DB + 向量DB | 结构化数据用PostgreSQL，向量用Milvus/FAISS |
| **LLM调用策略** | 仅离线Job调用 | 最大化控制成本，在线仅做检索匹配 |

#### 4.3.4 优势与劣势

**优势**：
- ✅ **算力消耗低**：LLM调用仅在离线批量Job中执行，在线服务无额外LLM开销
- ✅ **部署复杂度低**：组件少、依赖少，可在现有RAG架构上增量叠加
- ✅ **可解释性强**：策略规则基于统计，可审计、可调试
- ✅ **风险可控**：经验提炼与在线服务解耦，离线Job异常不影响在线服务质量
- ✅ **快速落地**：2-4周可完成MVP验证

**劣势**：
- ❌ **实时性差**：新产生的检索经验需要等待下一个定时Job才能被系统利用
- ❌ **策略优化粒度粗**：基于统计规则，无法捕捉精细的query特征与最优策略间的复杂非线性关系
- ❌ **知识关联浅层**：关联挖掘限于共现统计，缺乏深度语义推理
- ❌ **冷启动问题**：初期需要积累足够历史数据才能发挥作用

#### 4.3.5 适用场景

- 算力预算有限的团队
- 知识更新频率不高（天级别可接受）的业务
- 需要快速验证经验沉淀ROI的POC阶段
- 对可解释性有较高要求的合规场景

### 4.4 方案B：深度自进化方案（高质量、持续进化）

#### 4.4.1 设计哲学

"**在线积累，实时进化**"——构建完整的在线经验-反馈-优化闭环，利用ML模型和强化学习实现检索策略的持续自适应进化。适合对检索质量有极致追求、算力预算充足的场景。

#### 4.4.2 技术架构

```
┌──────────────────────────────────────────────────────────────────┐
│                        在线服务层                                  │
│                                                                  │
│  ┌──────────┐   ┌──────────────┐   ┌─────────────────────────┐  │
│  │ Query    │   │ 经验检索Agent │   │ 策略Agent (RL Policy)   │  │
│  │ 理解模块  │──▶│              │──▶│                         │  │
│  │          │   │ • 相似Query   │   │ • 工具组合选择          │  │
│  │ • 意图分类│   │   匹配        │   │ • 检索深度决策          │  │
│  │ • 实体抽取│   │ • 知识库匹配  │   │ • 是否多轮检索          │  │
│  │ • 复杂度  │   │ • 关联图遍历  │   │ • Rerank是否启用        │  │
│  │   评估    │   │ • 历史策略    │   │ • 结果融合策略          │  │
│  └──────────┘   │   推荐        │   │                         │  │
│                 └──────┬───────┘   └───────────┬─────────────┘  │
│                        │                       │                 │
│                        ▼                       ▼                 │
│              ┌─────────────────────────────────────┐            │
│              │         检索执行引擎                  │            │
│              │  工具集: Vector / BM25 / KG / Web    │            │
│              └─────────────────┬───────────────────┘            │
│                                ▼                                 │
│              ┌─────────────────────────────────────┐            │
│              │       在线反馈采集                    │            │
│              │  用户行为 / 检索质量 / 资源消耗        │            │
│              └─────────────────┬───────────────────┘            │
└────────────────────────────────┼────────────────────────────────┘
                                 │
                                 ▼
┌──────────────────────────────────────────────────────────────────┐
│                       经验进化层（在线+近线）                       │
│                                                                  │
│  ┌───────────────────┐  ┌──────────────────┐  ┌───────────────┐ │
│  │   经验图谱          │  │  策略优化引擎     │  │  知识蒸馏模块  │ │
│  │                   │  │                  │  │               │ │
│  │ • 节点: Query/    │  │ • RL Training    │  │ • 高频经验→   │ │
│  │   Result/Entity/  │  │   (PPO/GRPO)     │  │   规则压缩    │ │
│  │   Strategy        │  │ • 奖励函数:       │  │ • 图嵌入更新  │ │
│  │ • 边: SIMILAR_TO/ │  │   答案质量 +      │  │ • 冷热分层    │ │
│  │   LEADS_TO/       │  │   检索效率 -      │  │               │ │
│  │   BELONGS_TO/     │  │   资源消耗        │  │               │ │
│  │   CONFLICTS_WITH  │  │ • 在线增量更新    │  │               │ │
│  │                   │  │                  │  │               │ │
│  │ • 节点属性:       │  │ • Experience     │  │               │ │
│  │   置信度/频次/     │  │   Replay Buffer  │  │               │ │
│  │   新鲜度/不确定度  │  │                  │  │               │ │
│  └────────┬──────────┘  └────────┬─────────┘  └───────┬───────┘ │
│           │                      │                      │         │
│           ▼                      ▼                      ▼         │
│  ┌─────────────────────────────────────────────────────────────┐ │
│  │                    知识库层（持久化存储）                       │ │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────────┐ │ │
│  │  │ 向量索引  │  │ 图数据库  │  │ 关系型DB  │  │ Embedding    │ │ │
│  │  │ (Milvus) │  │ (Neo4j/  │  │(PostgreSQL│  │ 模型注册表   │ │ │
│  │  │          │  │  Nebula)  │  │ +pgvector)│  │              │ │ │
│  │  └──────────┘  └──────────┘  └──────────┘  └──────────────┘ │ │
│  └─────────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────────┘
```

#### 4.4.3 关键设计决策

| 设计维度 | 方案B选择 | 理由 |
|---------|----------|------|
| **知识抽取时机** | 在线实时（流式） | 新知识即时可用，配合在线反馈闭环 |
| **经验表示** | 异构图（经验图谱） | 支持多类型节点（Query/Result/Entity/Strategy）和多类型边，表达能力远超关系表 |
| **Query关联匹配** | 图遍历 + Embedding双路 | 图结构支持多跳关联发现（如A→B→C的间接关联），Embedding保证语义匹配精度 |
| **策略优化方式** | 强化学习（PPO/GRPO） | 支持在线增量学习，捕捉query特征与最优策略间的非线性关系，持续自适应进化 |
| **记忆更新机制** | 卡尔曼启发增益自适应（参考GAM-RAG） | 平衡稳定性（不遗忘有用经验）与可塑性（快速吸收新经验），避免噪声积累 |
| **存储方案** | 向量DB + 图DB + 关系DB | 多模态经验数据需要多引擎协同 |
| **奖励函数设计** | 多层次复合奖励 | 答案质量分(F1/用户采纳) + 检索效率奖励(-耗时) + 资源效率奖励(-token) |

#### 4.4.4 核心在线流程

**步骤1：Query理解与经验检索**

```
输入: 用户Query
输出: 增强Query上下文 + 推荐策略

1. Query意图分类（事实型/分析型/操作型/对比型）
2. 实体识别与链接
3. 经验图谱检索：
   a. Embedding相似度匹配 → 召回历史相似Query节点
   b. 从匹配Query节点出发，图遍历发现关联Result/Entity/Strategy节点
   c. 根据节点置信度、新鲜度、频次进行排序过滤
4. 知识库匹配：
   a. 结构化知识条目精确匹配（实体查询）
   b. 语义向量匹配（query embedding → 知识条目关联query embedding）
5. 组装增强上下文：
   - 匹配的历史知识条目
   - 关联的历史高质量Result片段
   - 推荐的检索策略
```

**步骤2：策略Agent决策**

```
输入: Query特征 + 经验图谱推荐 + 当前系统状态
输出: 检索执行计划

策略Agent（RL Policy网络）输出：
- 工具选择: {Vector_Search, BM25, KG_Traversal, Web_Search, SQL_Query}
- 工具组合方式: {顺序执行, 并行执行, 条件分支}
- 检索参数: top_k, 相似度阈值, 是否启用Rerank
- 是否多轮: {Single_Pass, Multi_Hop, Iterative_Refine}
- 停止条件: 置信度阈值 / 最大轮次

决策输入特征:
- Query复杂度得分、实体密度、领域标签
- 历史相似Query的最优策略统计
- 各候选工具的平均耗时和效果（近期窗口）
- 当前系统负载状态
```

**步骤3：检索执行与反馈采集**

```
1. 按策略Agent输出的计划执行检索
2. 记录全链路数据：
   - 检索耗时、token消耗
   - 各工具返回结果数量和相关性
   - 最终LLM回答的置信度
   - 用户行为反馈（采纳/忽略/修改/否定）
3. 实时计算奖励信号
```

**步骤4：经验图谱在线更新**

```
基于本次检索结果更新经验图谱：

1. 新Query节点创建（或已有节点属性更新）
2. Query→Result边创建/更新（关联强度 += 置信度反馈）
3. Result片段聚类，发现新关联关系边
4. 高置信度结果触发知识抽取流程
5. 实体节点属性更新（频次、新鲜度）
6. 卡尔曼增益更新记忆权重：
   - 新信号、高置信度 → 大步更新（快速学习）
   - 稳定信号、低新颖度 → 小步更新（防止遗忘）
   - 噪声信号 → 阻尼更新（防止污染）
```

**步骤5：策略Agent在线微调**

```
1. 将本次检索轨迹（state, action, reward）写入Experience Replay Buffer
2. 当Buffer达到阈值或定时触发时：
   - 采样batch轨迹
   - 使用PPO/GRPO更新Policy网络
   - 奖励 = 答案质量分 × w1 + (1 / 检索耗时) × w2 + (1 / token消耗) × w3
3. 更新后的Policy网络替换旧版本（滚动更新，支持A/B对比）
```

#### 4.4.5 知识蒸馏与分层优化

为控制长期运行的存储和计算膨胀，引入知识蒸馏机制：

| 层级 | 内容 | 存储方式 | 更新频率 | 用途 |
|------|------|---------|---------|------|
| **热层** | 近7天高频经验 | 内存缓存 + 图DB热节点 | 实时 | 在线快速匹配 |
| **温层** | 7-30天经验 | 图DB + 向量DB | 日级增量 | 策略统计与RL训练 |
| **冷层** | 30天以上经验 | 压缩规则 + 聚合统计 | 周级蒸馏 | 规则提取与长期知识 |

蒸馏策略：
- 高频且稳定的经验 → 提取为确定性规则（减少图DB存储）
- 低频经验 → 聚合为统计摘要（保留统计信号，丢弃原始轨迹）
- 冲突经验 → 保留原始数据用于人工审核

#### 4.4.6 优势与劣势

**优势**：
- ✅ **检索质量持续提升**：RL策略随时间自动优化，越用越准
- ✅ **实时性极强**：新经验在线即时可用，无需等待离线Job
- ✅ **深度关联发现**：图结构支持多跳关系推理，发现间接隐含关联
- ✅ **策略精细度高**：RL可捕捉query特征与最优策略间的复杂非线性关系
- ✅ **抗噪声能力强**：卡尔曼增益更新机制过滤噪声反馈
- ✅ **自适应冷热分层**：蒸馏机制控制存储成本

**劣势**：
- ❌ **算力消耗高**：在线LLM调用（知识抽取）+ RL训练GPU资源 + 图数据库维护
- ❌ **系统工程复杂度高**：多组件协同（向量DB + 图DB + RL Training + 流处理），运维门槛高
- ❌ **可解释性弱**：RL策略为黑盒模型，决策路径难以审计
- ❌ **冷启动期长**：初期经验数据不足时RL策略不稳定，需要"预热"阶段
- ❌ **落地周期长**：预计3-6个月完成完整系统搭建和调优

#### 4.4.7 适用场景

- 对检索质量有极致追求的旗舰产品
- 知识密集、查询高频的核心业务场景
- 算力预算充足、有专业ML工程团队
- 需要持续进化的长期运营产品
- 用户反馈信号丰富的场景（有充足的训练数据）

### 4.5 方案对比总结

| 对比维度 | 方案A（轻量级渐进式） | 方案B（深度自进化） |
|---------|---------------------|-------------------|
| **算力消耗** | 低（仅离线LLM调用） | 高（在线LLM + RL训练GPU） |
| **存储成本** | 低（关系DB + 向量DB） | 中高（向量DB + 图DB + 关系DB） |
| **实时性** | 天级延迟 | 秒级实时 |
| **策略优化方式** | 统计规则 | 强化学习（PPO/GRPO） |
| **关联深度** | 浅层（共现+相似度） | 深层（多跳图推理） |
| **部署复杂度** | 低 | 高 |
| **冷启动速度** | 快（1-2周数据积累） | 慢（需RL预热阶段） |
| **可解释性** | 高 | 低 |
| **检索质量上限** | 中等 | 高 |
| **持续进化能力** | 弱（依赖定时规则更新） | 强（在线持续学习） |
| **落地周期** | 2-4周 | 3-6个月 |
| **适用团队规模** | 2-3人 | 5-8人（含ML工程师） |

### 4.6 推荐的渐进式演进路径

建议分三阶段推进，最大化投入产出比：

```
阶段一（MVP）：方案A核心模块
  ├── 离线知识抽取Job（日频）
  ├── Query-Result关联表（Embedding匹配）
  ├── 基础策略统计表（周频规则更新）
  └── 目标：验证"经验可沉淀、可复用"的核心假设
        ↓ 验证成功后
阶段二（增强）：方案A + 方案B部分能力
  ├── 引入图数据库存储关联关系
  ├── 在线实时知识匹配（复用离线抽取结果）
  ├── 卡尔曼增益记忆更新（替代简单覆盖）
  └── 目标：提升实时性和关联深度
        ↓ 数据积累充分后
阶段三（全面）：方案B完整能力
  ├── 策略Agent RL在线优化
  ├── 在线知识抽取（流式处理）
  ├── 知识蒸馏与冷热分层
  └── 目标：实现持续自进化闭环
```

---

## 5. 总结与建议

### 5.1 核心发现

1. **差异化机会明确**：当前工业界产品在"经验沉淀与自进化"方面普遍缺失（仅腾讯KnowLion有部分探索），这正是本方案可以建立竞争壁垒的方向。

2. **学术界已提供方法论基础**：GAM-RAG的记忆更新机制、REMINDRAG的记忆回放、ExpGraph的经验图结构、SPARKLE的RL策略优化等，均为方案设计提供了可参考的技术路径。

3. **三大模块设计合理**：领域知识抽取、关联关系挖掘、检索路径优化三者形成完整的"认知→关联→行动"闭环，与学术界趋势一致。

4. **双方案策略可行**：轻量级方案快速验证价值，深度方案追求极致效果，可根据实际场景灵活选择或渐进演进。

### 5.2 关键风险与缓解

| 风险 | 影响 | 缓解措施 |
|------|------|---------|
| 经验噪声积累 | 错误反馈导致策略退化 | 卡尔曼增益更新 + 置信度门控 + 人工抽检 |
| 计算成本失控 | ROI不达预期 | 方案A先行验证 + 知识蒸馏 + 冷热分层 |
| 冷启动效果差 | 初期无经验可复用 | 基于规则的人工初始策略 + 模拟数据预热 |
| 经验遗忘 | 新经验覆盖旧有用经验 | 增益自适应更新 + 重要性采样保留 |

### 5.3 下一步行动建议

1. **短期（1-2周）**：启动方案A的MVP开发，聚焦"知识抽取+Embedding匹配复用"最小闭环
2. **中期（1-2月）**：完成方案A全模块上线，积累1个月以上的经验数据，量化ROI
3. **长期（3-6月）**：基于方案A的数据积累和效果验证，决策是否升级到方案B

---

## 参考文献与链接汇总

### 学术论文
| 序号 | 论文 | 会议/年份 | 链接 |
|------|------|----------|------|
| 1 | Self-RAG: Learning to Retrieve, Generate and Critique | ICLR 2024 | https://selfrag.github.io/ |
| 2 | Adaptive-RAG: Learning to Adapt RAG through Question Complexity | NAACL 2024 | https://aclanthology.org/2024.naacl-long.389/ |
| 3 | SeaKR: Self-aware Knowledge Retrieval for Adaptive RAG | ACL 2025 | https://aclanthology.org/2025.acl-long.1312/ |
| 4 | GAM-RAG: Gain-Adaptive Memory for Evolving Retrieval | arXiv 2025 | https://arxiv.org/abs/2603.01783v1 |
| 5 | SegMem-RAG: Adaptive Memory for RAG | AAAI 2026 | https://ojs.aaai.org/index.php/AAAI/article/view/40320 |
| 6 | REMINDRAG: Low-Cost LLM-Guided KG Traversal | NeurIPS 2025 | https://proceedings.neurips.cc (Paper ID: 4d880ba0) |
| 7 | SPARKLE: Structured Plug-and-play Agentic Retrieval Policy | ACL 2026 | https://aclanthology.org/2026.acl-long.1793.pdf |
| 8 | HERA: Experience as a Compass - Multi-agent RAG | arXiv 2026 | https://arxiv.org/html/2604.00901v1 |
| 9 | ExpWeaver: LLM Agents Learn from Experience via Latent RAG | arXiv 2025 | https://arxiv.org/html/2606.01041 |
| 10 | ExpGraph: Model-Agnostic Experience Learning | arXiv 2025 | https://arxiv.org/html/2605.30712 |
| 11 | MetaKGRAG: Metacognitive KG Retrieval Augmented Generation | arXiv 2025 | https://arxiv.org/html/2508.09460 |
| 12 | Reflective RAG: Self-Evaluation Driven Strategy Optimization | ACL 2026 | https://aclanthology.org/2026.findings-acl.648/ |
| 13 | Adaptive Retrieval without Self-Knowledge? (35 methods survey) | ACL 2025 | https://aclanthology.org/2025.acl-long.319.pdf |
| 14 | APEX-EM: Non-Parametric Online Learning via Experience Replay | arXiv 2025 | https://arxiv.org/html/2603.29093v2 |
| 15 | RouteRAG: Efficient RAG from Text and Graph via RL | ACL 2026 Findings | https://aclanthology.org/2026.findings-acl.1502.pdf |

### 工业产品
| 序号 | 产品/项目 | 公司 | 链接 |
|------|----------|------|------|
| 1 | GraphRAG | Microsoft | https://github.com/microsoft/GraphRAG |
| 2 | NeMo Retriever | NVIDIA | https://github.com/NVIDIA/NeMo-Retriever |
| 3 | Vertex AI RAG Engine | Google | https://cloud.google.com/vertex-ai/generative-ai/docs/rag-engine/rag-overview |
| 4 | KnowLion（动态超图RAG） | 腾讯 | https://developer.cloud.tencent.com/article/2638651 |
| 5 | TCADP（智能体开发平台） | 腾讯 | https://cloud.tencent.com/document/product/1759 |
| 6 | 百炼 RAG知识库 | 阿里云 | https://help.aliyun.com/zh/model-studio/rag-knowledge-base |
| 7 | PAI-RAG | 阿里云 | https://help.aliyun.com/zh/pai/rag-dialogue-system/ |
| 8 | ContextSearch | 字节跳动 | https://developer.volcengine.com/articles/7599494396346400774 |
| 9 | Contextual Retrieval | Anthropic | https://www.anthropic.com/engineering/contextual-retrieval |
| 10 | LlamaIndex | LlamaIndex | https://github.com/run-llama/llama_index |
