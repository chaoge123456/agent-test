# CodeGraph 初始化与 Explore 关键流程分析报告

> 研究对象：CodeGraph 1.5.0 当前仓库源码  
> 报告定位：面向同事和管理者的技术研究结论，同时作为后续优化 CodeGraph 的问题地图  
> 研究范围：项目初始化、全量索引、数据库模型，以及 <code>codegraph explore</code> 的召回、图扩展、排序、源码拼装与结果语义

## 摘要

CodeGraph 不是一个“把源码文本放进全文索引”的搜索工具。它先把代码转换成一张持久化的符号关系图，再以这张图为基础完成检索和上下文组装。

初始化阶段解决的是“图从哪里来”：

1. 扫描项目中应当参与分析的源码文件；
2. 通过 Tree-sitter、原生 kernel 和框架提取器，把文件转换为符号节点、文件内确定关系和待解析引用；
3. 以文件为单位写入 SQLite；
4. 在全项目符号已经可见后解析跨文件引用，把“调用了某个名字”绑定为“从节点 A 指向节点 B 的边”；
5. 再补充回调、接口实现、框架路由等仅靠单文件语法树难以得到的关系。

Explore 阶段解决的是“如何把图变成可直接阅读的答案”：

1. 从自然语言、符号名和显式文件路径中召回一组入口节点；
2. 沿调用、引用、继承等关系扩展相关子图；
3. 把节点相关性聚合到文件，结合命名命中、图连通度、测试或生成文件惩罚进行排序；
4. 从命名符号之间提炼调用主干和动态分发边界；
5. 重新读取当前磁盘源码，在字符预算内返回整文件、完整方法簇、聚焦视图或签名骨架；
6. 同时返回影响面、关系、未展示文件指针和会话去重信息。

因此，理解 CodeGraph 的关键不在于记住大量启发式规则，而在于抓住下面这条主线：

~~~text
源码文件
  → 符号节点 + 局部边 + 待解析引用
  → 全局引用解析 + 动态关系补全
  → SQLite 代码图
  → 查询入口节点
  → 相关子图
  → 相关文件与调用主干
  → 当前磁盘源码上下文
~~~

这条主线也直接决定后续优化方向：初始化优化应关注“建图速度、图的完整性和可增量维护性”，Explore 优化应关注“召回率、排序正确性、调用链完整度和单位上下文预算的信息密度”。

## 研究边界与重要结论

本报告中的“初始化”包含两个层次：

- 容器初始化：创建项目专属的 <code>.codegraph</code> 目录和 SQLite 数据库；
- 语义初始化：执行第一次全量索引，生成可供 Explore 使用的代码图。

CLI 中的 <code>codegraph init</code> 会默认完成这两个层次。虽然库接口 <code>CodeGraph.init(projectRoot, { index: false })</code> 可以只创建数据库，但 CLI 随后总会调用 <code>indexAll()</code>。因此，对最终用户而言，“初始化完成”应理解为数据库已经建好且首次索引已经结束，而不是仅仅出现了 <code>codegraph.db</code>。

还需要先明确三个容易产生误解的事实：

- 数据库不保存完整源码正文，只保存文件指纹、符号位置、符号属性和关系；Explore 的正文来自查询时重新读取磁盘。
- CodeGraph 当前没有向量数据库或 embedding 召回。源码中所称的 hybrid 或 semantic context，本质上是精确名称、FTS5、名称片段、前缀、CamelCase 子串、词干和图遍历的组合。
- Explore 的最终交付单位是文件或文件内完整代码区间，而不是裸节点列表。节点是检索和推理单元，文件源码才是交付给编码智能体的主要上下文。

---

# 第一章：CodeGraph 初始化流程

## 1.1 初始化要解决的核心问题

一个可用的代码图至少需要回答四类问题：

1. 项目中有哪些源文件和符号？
2. 符号定义位于哪个文件、哪几行？
3. 符号之间存在什么关系，例如包含、调用、继承、实现和引用？
4. 当源码变化或初始化中断时，怎样判断索引是否完整、是否需要重建？

CodeGraph 的初始化围绕这四个问题组织。它并不是先把所有源码拼在一起再统一分析，而是采用“单文件提取、确定性落库、全局解析、后处理补图”的分阶段架构。

~~~mermaid
flowchart LR
    A[CLI init] --> B[安全检查与目录创建]
    B --> C[创建 SQLite 与表结构]
    C --> D[扫描可索引文件]
    D --> E[并行解析每个文件]
    E --> F[节点/局部边/待解析引用]
    F --> G[按文件顺序写入数据库]
    G --> H[全局引用解析]
    H --> I[回调与框架关系补全]
    I --> J[重建索引/FTS并维护 WAL]
    J --> K[记录完整性与版本元数据]
~~~

这套分段设计的核心原因是：解析单个文件时只看得到该文件的语法和局部上下文，无法可靠知道一个名称最终指向项目中的哪个定义。CodeGraph 因而把“抽取引用”和“绑定目标”分开，让所有定义先落库，再做全局解析。

## 1.2 命令入口与初始化容器

CLI 入口位于 <code>src/bin/codegraph.ts</code>。关键行为如下：

1. 解析目标目录，默认使用当前工作目录；
2. 拒绝在文件系统根目录、用户主目录或主目录的父目录初始化，除非显式传入 <code>--force</code>；
3. 检查目标是否已经存在有效的 <code>.codegraph/codegraph.db</code>；
4. 调用 <code>CodeGraph.init(projectPath, { index: false })</code> 创建容器；
5. 无条件执行首次 <code>indexAll()</code>；
6. 输出索引统计，必要时提示被 <code>.gitignore</code> 排除的嵌套仓库；
7. 尝试配置后续自动同步能力。

<code>CodeGraph.init()</code> 的容器创建过程很短，但很重要：

- 初始化语法 grammar；
- 把项目路径规范化为绝对路径；
- 创建 <code>.codegraph</code> 目录；
- 在目录中写入一个“默认忽略全部、仅保留自身”的 <code>.gitignore</code>，避免数据库、WAL、锁和守护进程文件进入 Git；
- 创建 <code>codegraph.db</code>；
- 应用连接级 SQLite 参数和当前 schema；
- 组装查询、抽取、解析、图遍历和上下文构建等上层组件。

<code>CODEGRAPH_DIR</code> 可以把默认目录名改成另一个单段目录名，用于 Windows 与 WSL 等共享工作树但不能安全共享 SQLite 锁的场景。这个配置改变存放位置，不改变数据库模型。

## 1.3 SQLite 初始化与连接策略

数据库连接创建后会统一应用以下关键 PRAGMA：

| 配置 | 值 | 主要目的 |
|---|---:|---|
| <code>busy_timeout</code> | 5000 ms | 写锁竞争时短暂等待，避免立即报 database is locked |
| <code>foreign_keys</code> | ON | 让节点删除自动级联到边和待解析引用 |
| <code>journal_mode</code> | WAL | 允许读写并发，降低查询被索引写入阻塞的概率 |
| <code>synchronous</code> | NORMAL | 在 WAL 模式下平衡持久性和性能 |
| <code>cache_size</code> | -64000 | 约 64 MB 页缓存 |
| <code>temp_store</code> | MEMORY | 临时表放在内存 |
| <code>mmap_size</code> | 256 MB | 使用内存映射提高大库读取效率 |
| <code>journal_size_limit</code> | 默认 64 MB | 防止异常终止遗留的 WAL 长期膨胀 |

新数据库直接执行当前 <code>schema.sql</code>，并记录当前 schema 版本 9。打开旧数据库时，则根据 <code>schema_versions</code> 逐版本执行迁移。数据库打开还承担自愈职责：如果上次进程在批量加载期间退出，导致 FTS 触发器或次级索引尚未恢复，打开过程会重建它们。

这意味着 schema、索引和 FTS 不是单纯的静态建表脚本，而是初始化可靠性协议的一部分。

## 1.4 全量索引前的并发与写入模式

<code>CodeGraph.indexAll()</code> 在真正扫描文件前先建立两层互斥：

- 进程内 <code>Mutex</code>：避免同一个实例并发索引；
- 文件锁 <code>codegraph.lock</code>：避免 CLI、MCP、Git hook 等不同进程同时写库。

随后将 <code>project_metadata.index_state</code> 标为 <code>indexing</code>。如果进程在中途被终止，这个状态会保留下来，使 <code>codegraph status</code> 能够区分“正常完成的索引”和“看似有数据、实际被截断的索引”。

首次空库初始化还会启用几项只影响性能、不改变最终图语义的批量写优化：

- 临时使用内存 journal 和 <code>synchronous=OFF</code>，因为首次索引失败后数据库可以整体重建；
- 暂时删除 FTS 同步触发器，节点全部写完后一次性重建 FTS；
- 暂时删除解析阶段不需要维护的次级索引，批量写完后按表扫描重建；
- 在可用时使用独立 store worker，让解析主线程不承担所有 SQLite 写入开销；
- 对 WAL 自动 checkpoint 进行延迟和限流，避免大批量写入反复回写热点页。

这些机制值得在后续性能优化时单独评估，但从理解业务流程的角度，只需记住：CodeGraph 在首次索引期间把数据库视为“可丢弃的构建产物”，完成后再恢复正常持久化和查询状态。

## 1.5 文件扫描：确定哪些内容属于代码图

扫描阶段不是简单递归遍历目录。

在 Git 仓库中，CodeGraph 优先使用 <code>git ls-files</code> 获取已跟踪和可见的未跟踪文件，从而继承各层 <code>.gitignore</code> 语义；在非 Git 项目中，才回退到文件系统递归遍历并自行加载各层 <code>.gitignore</code>。

在此基础上还有三组过滤或补充规则：

- 内置忽略：依赖、构建产物、缓存、虚拟环境、覆盖率目录、Android 资源目录等默认不进入图；
- <code>codegraph.json.exclude</code>：即使文件已被 Git 跟踪，也强制排除；
- <code>codegraph.json.include</code> 和 <code>includeIgnored</code>：把明确指定的第一方源码或嵌套 Git 仓库重新纳入；
- 扩展名覆盖：把项目特有扩展名映射到已有语言 grammar。

扫描最终只返回 CodeGraph 支持的源码类型。单文件上限为 1 MB，超过上限的文件会留下带错误信息的文件记录，但不会进入高成本语法解析。

这一阶段直接决定初始化的理论召回上限：文件没有进入扫描结果，后续再强的解析和 Explore 排序都无法找回它。因此，优化扫描策略时应优先监控“应索引文件漏检率”，而不仅是扫描耗时。

## 1.6 单文件解析：生成三类中间结果

每个文件的解析结果统一为：

~~~text
ExtractionResult
├── nodes                  符号节点
├── edges                  文件内已经能确定的边
├── unresolvedReferences   需要全局绑定的引用
└── errors                 可恢复或不可恢复的抽取问题
~~~

解析入口会按语言和文件类型选择不同实现：

- 部分语言进入原生 Rust kernel；
- 其他常规语言使用 WASM Tree-sitter；
- Svelte、Vue、Astro、Liquid、Razor、MyBatis XML、CFML、DFM 等使用专用提取器；
- YAML、properties 等文件级语言先只记录文件，适用的框架提取器再补节点；
- 已识别的框架会追加路由、中间件、配置键等框架语义节点和引用。

### 1.6.1 节点

常规源码文件首先生成一个 file 节点，之后函数、类、方法等节点按语法树遍历产生。

普通节点 ID 的实际生成方式是：

~~~text
kind + ":" + SHA256(filePath + ":" + kind + ":" + name + ":" + startLine) 的前 32 个十六进制字符
~~~

file 节点使用特殊形式：

~~~text
file:<项目相对路径>
~~~

普通节点 ID 包含起始行，因此在符号上方插入几行注释也会改变 ID。这解释了增量同步为何需要在重建目标文件时按 <code>filePath + kind + name</code> 重新挂接来自其他文件的入边，而不能直接复用旧 target ID。

### 1.6.2 可立即确定的边

解析单文件时能够确定的关系直接生成边。最典型的是：

- file contains class/function；
- class contains method/field；
- 同文件内已经能够确认目标的调用或引用；
- 语法上明确的局部关系。

所有顶层声明通过 file 节点形成包含层次，这既提供文件到符号的导航，也使图遍历能够从符号回到代码容器。

### 1.6.3 待解析引用

跨文件调用、导入目标、继承目标、类型引用等在单文件阶段通常只有名称和上下文，没有全局目标 ID，因此先写成 <code>UnresolvedReference</code>。

它记录：

- 引用发生在哪个源节点；
- 引用了什么名称；
- 期望形成哪种关系；
- 调用点的行列；
- 所在文件和语言；
- 可选候选限定名。

这是初始化流程中最关键的“延迟绑定”设计。它把语法抽取器与复杂的跨语言、跨框架名称解析解耦，也使失败引用能在后续增量同步时重试。

## 1.7 并行解析与确定性写入

文件读取按小批次并行，解析在 worker pool 中并发进行。默认 worker 数量会结合可用 CPU 核数确定，并设置超时和周期性回收：

- 单个解析超时可以触发 worker 重启；
- 每处理一定数量文件后回收 worker，释放无法缩小的 WASM 线性内存；
- 内存错误或超时文件会在全新 worker 上重试；
- 仍然失败时，可尝试去掉纯注释行后再次解析，同时保留“结果可能不完整”的警告。

并行解析完成顺序是不稳定的，但数据库提交顺序必须稳定。CodeGraph 给扫描结果分配顺序号，把已完成结果暂存在有界缓冲区中，只按原文件顺序提交。

这个细节不是单纯为了测试可重复。解析器在多个同名候选之间可能使用数据库插入顺序作为最终消歧依据，如果按 worker 完成顺序写库，同一份源码在不同机器或不同运行中可能形成不同的边。确定性提交保证相同输入尽量得到相同代码图。

## 1.8 以文件为单位落库

常规文件的节点、局部边、待解析引用和文件记录会在一个事务中写入。文件记录最后落地，使异常中断后的部分写入更容易被识别和重建。

写入前还会做三类完整性过滤：

1. 缺少 ID、kind、name、filePath 或 language 的节点不写入；
2. 局部边的 source 和 target 必须都属于本次有效节点；
3. 待解析引用的 fromNodeId 必须是本次有效节点。

大文件会按 2000 条记录分块写入并在块间让出事件循环，以防单个超大生成文件长时间阻塞守护进程心跳。

完整源码不会写入数据库。文件表只保存 SHA-256、大小、修改时间、抽取错误等信息，节点表保存源码范围。这个选择减小数据库体积，也让 Explore 能返回工作区当前内容；代价是当磁盘内容已变而同步尚未完成时，索引行号可能过期。

## 1.9 全局引用解析：从名字变成图边

所有文件完成基础落库后，resolver 重新检测框架并执行跨文件后处理，再批量读取 <code>unresolved_refs</code>。

每条引用的解析目标是：

~~~text
(fromNodeId, referenceName, referenceKind, file/language/context)
    → 目标 Node
    → Edge(source=fromNodeId, target=targetNode.id, kind=...)
~~~

解析会综合：

- 精确名称和限定名；
- 当前文件的 import、namespace、package；
- 语言特定的模块和类型规则；
- 接收者类型与返回类型；
- 框架约定；
- 已经生成的 extends 和 implements 边；
- 多个候选之间的上下文相关度。

处理结果分为两类：

- 解析成功：生成 edge，并精确删除对应 <code>unresolved_refs.id</code>；
- 解析失败：把状态从 <code>pending</code> 改为 <code>failed</code>，同时记录名称尾段 <code>name_tail</code>。

失败引用不会继续占据“待处理”队列，但也不会被丢弃。后续 sync 如果新增或改变了同名符号，可以通过 <code>name_tail</code> 找回并重试。这使增量索引能够逐步收敛到全量重建结果。

主解析之后还有两个依赖已生成继承关系的补充阶段：

- 解析链式调用中定义在父类型或协议扩展上的方法；
- 解析 <code>this.member</code> 指向继承成员的延迟引用。

## 1.10 动态关系与框架后处理

纯静态语法无法完整表达以下常见结构：

- 回调函数先注册、后由框架或容器调用；
- observer、event bus、closure collection；
- 接口或抽象方法在运行时分发到具体实现；
- 路由注册、依赖注入、框架模块前缀；
- 函数指针、反射或注册表驱动调用。

CodeGraph 在基本调用和类型边已经形成后执行 callback synthesis 和框架后处理，补充 provenance 为 heuristic 的关系。它们对 Explore 的 Flow 和动态边界非常重要，因为这些关系正是普通文本检索难以还原的“胶水”。

合成阶段是 best effort：失败不会让整个索引失败。这有利于可用性，但也意味着“索引成功”不等于“动态关系全部完整”。后续质量评估应单独统计静态边、解析边和 heuristic 边的覆盖率与准确率。

## 1.11 初始化收尾与完整性判定

索引完成后会：

- 恢复或重建解析阶段暂时删除的次级索引；
- 从 nodes 一次性重建 <code>nodes_fts</code> 并恢复触发器；
- 执行数据库维护、更新查询规划统计、折叠 WAL；
- 重新统计最终节点和边数量，因为解析及合成阶段可能贡献大量新边；
- 记录 CodeGraph 包版本和 extraction version；
- 对比扫描发现文件数与 indexed、skipped、errored 三者之和。

<code>index_state</code> 的最终值可能是：

| 状态 | 含义 |
|---|---|
| <code>complete</code> | 扫描发现的文件均有明确归宿，索引流程正常结束 |
| <code>partial</code> | 发现文件数大于已处理总数，存在静默丢失风险 |
| <code>failed</code> | 索引流程整体失败 |
| <code>indexing</code> | 正在构建，或上次构建中途退出后遗留 |

“文件有解析警告”与“索引整体不完整”是两个不同维度。前者记录在 files.errors，后者记录在 project_metadata。

## 1.12 数据库表结构与功能

当前 schema 版本为 9。数据库包含 7 张普通表和 1 张 FTS5 虚拟表。

### 1.12.1 <code>schema_versions</code>：schema 演进记录

| 字段 | 类型与约束 | 作用 |
|---|---|---|
| <code>version</code> | INTEGER PRIMARY KEY | 已应用版本号 |
| <code>applied_at</code> | INTEGER NOT NULL | 应用时间，毫秒时间戳 |
| <code>description</code> | TEXT | 版本说明 |

它只管理数据库结构版本，不代表索引内容由哪个抽取引擎生成；后者存放在 <code>project_metadata</code>。

### 1.12.2 <code>nodes</code>：代码图的实体层

每行表示一个文件、类型、函数、方法、变量、路由或组件等代码实体。

| 字段 | 类型与约束 | 作用 |
|---|---|---|
| <code>id</code> | TEXT PRIMARY KEY | 节点稳定标识；普通节点与路径、kind、name、起始行相关 |
| <code>kind</code> | TEXT NOT NULL | 节点类型 |
| <code>name</code> | TEXT NOT NULL | 简单名称，如 <code>getUser</code> |
| <code>qualified_name</code> | TEXT NOT NULL | 限定名，用于消歧和跨文件解析 |
| <code>file_path</code> | TEXT NOT NULL | 项目根目录相对路径 |
| <code>language</code> | TEXT NOT NULL | 语言 |
| <code>start_line</code> | INTEGER NOT NULL | 起始行，1 基 |
| <code>end_line</code> | INTEGER NOT NULL | 结束行，1 基 |
| <code>start_column</code> | INTEGER NOT NULL | 起始列，0 基 |
| <code>end_column</code> | INTEGER NOT NULL | 结束列，0 基 |
| <code>docstring</code> | TEXT | 文档字符串 |
| <code>signature</code> | TEXT | 方法或符号签名 |
| <code>visibility</code> | TEXT | public、private、protected、internal 等 |
| <code>is_exported</code> | INTEGER，默认 0 | 布尔值，是否导出 |
| <code>is_async</code> | INTEGER，默认 0 | 布尔值，是否异步 |
| <code>is_static</code> | INTEGER，默认 0 | 布尔值，是否静态 |
| <code>is_abstract</code> | INTEGER，默认 0 | 布尔值，是否抽象 |
| <code>decorators</code> | TEXT | JSON 数组，装饰器、注解或附加修饰信息 |
| <code>type_parameters</code> | TEXT | JSON 数组，泛型参数 |
| <code>return_type</code> | TEXT | 规范化返回类型，辅助链式接收者类型推断 |
| <code>updated_at</code> | INTEGER NOT NULL | 节点更新时间 |

当前节点 kind 包括：

~~~text
file, module, class, struct, interface, trait, protocol,
function, method, property, field, variable, constant,
enum, enum_member, type_alias, namespace, parameter,
import, export, route, component, union
~~~

作用可以概括为三类：

- 定位：告诉 Explore 相关实现在哪个文件和行区间；
- 检索：名称、限定名、docstring、signature 进入精确索引或 FTS；
- 图端点：edges 的 source 和 target 都指向 nodes.id。

### 1.12.3 <code>edges</code>：代码图的关系层

| 字段 | 类型与约束 | 作用 |
|---|---|---|
| <code>id</code> | INTEGER PRIMARY KEY AUTOINCREMENT | 边的数据库行 ID |
| <code>source</code> | TEXT NOT NULL，FK | 起点节点，删除节点时级联删除 |
| <code>target</code> | TEXT NOT NULL，FK | 终点节点，删除节点时级联删除 |
| <code>kind</code> | TEXT NOT NULL | 关系类型 |
| <code>metadata</code> | TEXT | JSON 对象，保存 refName、合成器类型、注册点等 |
| <code>line</code> | INTEGER | 关系发生行，例如调用点 |
| <code>col</code> | INTEGER | 关系发生列 |
| <code>provenance</code> | TEXT | tree-sitter、scip、heuristic 或空 |

当前边 kind 包括：

| kind | 语义 |
|---|---|
| <code>contains</code> | 文件或容器包含子符号 |
| <code>calls</code> | 函数或方法调用另一可调用符号 |
| <code>imports</code> | 文件或符号导入另一目标 |
| <code>exports</code> | 文件导出符号 |
| <code>extends</code> | 类型继承父类型 |
| <code>implements</code> | 类型实现接口、trait 或 protocol |
| <code>references</code> | 通用引用或函数值引用 |
| <code>type_of</code> | 变量或参数具有某类型 |
| <code>returns</code> | 函数返回某类型 |
| <code>instantiates</code> | 创建某类型实例 |
| <code>overrides</code> | 方法覆盖父方法 |
| <code>decorates</code> | 装饰器或注解作用于符号 |

边身份由 <code>source + target + kind + line + col</code> 唯一确定，空行列会折叠为 -1 参与唯一索引。这保证 <code>INSERT OR IGNORE</code> 真正能够消除重复边。

### 1.12.4 <code>files</code>：文件状态与增量同步依据

| 字段 | 类型与约束 | 作用 |
|---|---|---|
| <code>path</code> | TEXT PRIMARY KEY | 项目相对路径 |
| <code>content_hash</code> | TEXT NOT NULL | 文件内容 SHA-256，用于跳过未变化文件和检测磁盘漂移 |
| <code>language</code> | TEXT NOT NULL | 检测到的语言 |
| <code>size</code> | INTEGER NOT NULL | 文件字节数 |
| <code>modified_at</code> | INTEGER NOT NULL | 文件系统修改时间 |
| <code>indexed_at</code> | INTEGER NOT NULL | 最近索引时间 |
| <code>node_count</code> | INTEGER，默认 0 | 抽取节点数量 |
| <code>errors</code> | TEXT | JSON 数组，解析错误和警告 |
| <code>generated</code> | INTEGER NOT NULL，默认 0 | 是否由文件名约定或文件头标记判定为生成代码 |

这张表不是源码表，而是“索引账本”：

- sync 用 hash 判断文件是否变化；
- Explore 用 hash 检测索引范围是否仍可安全映射到当前源码；
- generated 作为排序降权信号，而不是硬过滤；
- 零节点加 errors 的记录可作为超大、读取失败或解析失败文件的标记。

<code>files.path</code> 与 <code>nodes.file_path</code> 是逻辑一对多关系，但 schema 没有外键。文件重建时由应用层先删除该文件节点，edges 和 unresolved_refs 再通过 nodes 外键级联清理。

### 1.12.5 <code>unresolved_refs</code>：跨文件引用的延迟绑定队列

| 字段 | 类型与约束 | 作用 |
|---|---|---|
| <code>id</code> | INTEGER PRIMARY KEY AUTOINCREMENT | 精确标识一次引用发生位置 |
| <code>from_node_id</code> | TEXT NOT NULL，FK | 引用所在源节点，删除节点时级联删除 |
| <code>reference_name</code> | TEXT NOT NULL | 待解析名称，可带限定符 |
| <code>reference_kind</code> | TEXT NOT NULL | 期望生成的边类型，或内部 <code>function_ref</code> |
| <code>line</code> | INTEGER NOT NULL | 引用发生行 |
| <code>col</code> | INTEGER NOT NULL | 引用发生列 |
| <code>candidates</code> | TEXT | JSON 数组，可能的限定名候选 |
| <code>file_path</code> | TEXT NOT NULL，默认空串 | 冗余文件路径，避免解析时额外关联 |
| <code>language</code> | TEXT NOT NULL，默认 unknown | 冗余语言，供语言特定解析规则使用 |
| <code>status</code> | TEXT NOT NULL，默认 pending | pending 或 failed |
| <code>name_tail</code> | TEXT NOT NULL，默认空串 | 名称最后一段，支持后续新增同名符号时重试 |

表中一行代表一次具体引用，而不是一个唯一名称。相同调用方在不同代码行多次调用同名函数，会有多行记录。解析完成后必须按 row ID 精确删除或标记失败，否则批次边界可能误删尚未处理的同名兄弟引用。

### 1.12.6 <code>nodes_fts</code>：FTS5 检索派生表

这是一个 external-content FTS5 虚拟表，声明字段为：

| 字段 | 来源 | 作用 |
|---|---|---|
| <code>id</code> | nodes.id | 与实体表关联 |
| <code>name</code> | nodes.name | 主要名称检索字段 |
| <code>qualified_name</code> | nodes.qualified_name | 限定名检索 |
| <code>docstring</code> | nodes.docstring | 文档语义词检索 |
| <code>signature</code> | nodes.signature | 签名词检索 |

<code>content='nodes'</code> 且 <code>content_rowid='rowid'</code> 表示正文仍以 nodes 为准。平时由 <code>nodes_ai</code>、<code>nodes_ad</code>、<code>nodes_au</code> 三个触发器保持同步；全量索引时暂时删除触发器，最后通过 FTS 的 rebuild 命令一次性重建。

FTS 查询使用 BM25，并显著提高 name 和 qualified_name 的权重。FTS 适合前缀和词项检索，但默认 tokenizer 不会把 <code>OrderStateMachine</code> 拆成 order、state、machine，这正是下一张表存在的原因。

### 1.12.7 <code>name_segment_vocab</code>：自然语言词到符号名的桥

| 字段 | 类型与约束 | 作用 |
|---|---|---|
| <code>segment</code> | TEXT NOT NULL | 小写名称片段，如 order、state、machine |
| <code>name</code> | TEXT NOT NULL | 原始符号名，如 OrderStateMachine |

主键是 <code>(segment, name)</code>，表使用 <code>WITHOUT ROWID</code>。

写 nodes 时，除 file 和 import 外的符号名会被拆成片段并写入此表。例如：

~~~text
OrderStateMachine
  → (order, OrderStateMachine)
  → (state, OrderStateMachine)
  → (machine, OrderStateMachine)
~~~

Explore 因而可以让“订单状态机”一类包含 Latin 技术词的自然语言查询，通过 state 和 machine 找到 <code>OrderStateMachine</code>，再把它作为较低权重的精确名称种子。

删除节点时故意不逐行删除词表数据，以减少写放大。词表命中只是候选，返回前必须再次到 nodes 验证；全量索引开始时会清空并重建词表。

### 1.12.8 <code>project_metadata</code>：项目索引状态

| 字段 | 类型与约束 | 作用 |
|---|---|---|
| <code>key</code> | TEXT PRIMARY KEY | 元数据键 |
| <code>value</code> | TEXT NOT NULL | 元数据值 |
| <code>updated_at</code> | INTEGER NOT NULL | 更新时间 |

主要键包括：

| key | 作用 |
|---|---|
| <code>index_state</code> | indexing、complete、partial、failed |
| <code>index_files_discovered</code> | 扫描发现文件数 |
| <code>index_files_accounted</code> | indexed、skipped、errored 合计 |
| <code>indexed_with_version</code> | 构建索引的 CodeGraph 包版本 |
| <code>indexed_with_extraction_version</code> | 抽取逻辑版本 |

### 1.12.9 关键索引与触发器

数据库次级索引可以按读路径理解：

| 对象 | 关键索引 | 服务的主要路径 |
|---|---|---|
| nodes | kind、name、qualified_name、file_path、language、file_path+start_line、lower(name) | 精确符号查找、文件内节点、大小写无关查找、源码区间排序 |
| edges | kind、source+kind、target+kind、provenance、唯一 identity | callers、callees、类型关系、按来源筛选、去重 |
| files | language、modified_at、generated 部分索引 | 状态统计、同步、生成文件筛选 |
| unresolved_refs | from_node、name、file_path、from+name、status、failed name_tail 部分索引 | 批量解析、按变更文件解析、失败引用重试 |

需要特别注意，<code>idx_edges_source_kind</code> 和 <code>idx_edges_target_kind</code> 的左前缀已经覆盖只按 source 或 target 查询，所以旧的窄索引被迁移删除，以降低边写入成本。

## 1.13 数据关系总览

~~~mermaid
erDiagram
    FILES ||--o{ NODES : "逻辑关联 file_path"
    NODES ||--o{ EDGES : "source FK"
    NODES ||--o{ EDGES : "target FK"
    NODES ||--o{ UNRESOLVED_REFS : "from_node_id FK"
    NODES ||--|| NODES_FTS : "rowid external content"
    NODES }o--o{ NAME_SEGMENT_VOCAB : "name 派生，无 FK"
    PROJECT_METADATA {
      text key PK
      text value
      integer updated_at
    }
    SCHEMA_VERSIONS {
      integer version PK
      integer applied_at
      text description
    }
~~~

从生命周期看：

~~~text
files 负责“这个文件是否需要重建”
nodes 负责“代码里有什么”
edges 负责“它们如何连接”
unresolved_refs 负责“暂时还不知道连到哪里”
nodes_fts 负责“按词找候选节点”
name_segment_vocab 负责“自然语言词如何触达 CamelCase 符号”
project_metadata 负责“整个索引是否可信、由哪个版本构建”
~~~

## 1.14 示例：一次跨文件调用如何进入数据库

假设项目有：

~~~typescript
// src/controller.ts
export function getUser(id: string) {
  return findUser(id);
}

// src/service.ts
export function findUser(id: string) {
  // ...
}
~~~

单文件解析 <code>controller.ts</code> 时大致产生：

- file 节点 <code>file:src/controller.ts</code>；
- function 节点 <code>getUser</code>；
- contains 边：file → getUser；
- unresolved ref：from=getUser，name=findUser，kind=calls，line=3。

解析 <code>service.ts</code> 时产生：

- file 节点 <code>file:src/service.ts</code>；
- function 节点 <code>findUser</code>；
- contains 边：file → findUser。

全局解析阶段看到项目中已有 <code>findUser</code> 定义，结合 import 或模块上下文选择 <code>src/service.ts</code> 中的节点，随后：

1. 写入 calls 边：getUser → findUser，line=3；
2. 删除该 unresolved_refs 行；
3. callers(findUser) 和 callees(getUser) 从此可以直接通过 edges 查询；
4. Explore 可以沿这条边把 controller 和 service 聚合到同一相关子图。

如果当前无法解析 <code>findUser</code>，引用会变为 failed 并保留。未来另一个文件新增该符号时，sync 可以重新尝试。

## 1.15 初始化阶段的优化观察

### 1.15.1 性能热点

- 文件扫描：大型 monorepo、嵌套仓库和复杂 ignore 规则会放大 I/O；
- grammar 加载与 WASM 内存：多语言项目会增加 worker 启动和常驻内存；
- SQLite 写放大：nodes、edges、unresolved_refs 及其索引维护是主要成本；
- 全局解析：复杂语言和大量同名符号会增加候选匹配成本；
- FTS、次级索引和 WAL 收尾：大库中可能成为显著的尾部延迟。

现有实现已经通过 worker pool、确定性有界缓冲、store worker、批量插入、临时删除索引、WAL valve 和 keyset 分页进行了大量优化。后续优化应以阶段耗时、峰值内存、WAL 峰值和每千节点写入成本为依据，避免只优化某个局部函数。

### 1.15.2 质量热点

- 扫描漏文件会形成不可恢复的召回缺口；
- 单文件抽取漏符号会同时影响精确检索、图边和源码区间；
- 名称解析错绑比未解析更危险，因为它会给 Explore 提供一条看似可信的错误路径；
- heuristic 边可以补动态语义，但需要独立衡量 precision；
- 普通节点 ID 含起始行，轻微行位移会导致 ID 改变并增加增量维护复杂度；
- files 与 nodes 没有外键，文件级一致性依赖应用层删除和写入协议。

建议建立以下初始化质量指标：

| 指标 | 说明 |
|---|---|
| 文件覆盖率 | 应索引文件中实际进入 files 的比例 |
| 符号抽取率 | 与语言服务或人工基准相比的定义覆盖 |
| pending/failed 引用率 | 每千节点未解析引用数量及主要类别 |
| 边准确率 | calls、extends、implements、heuristic 分类型抽样 |
| 全量/增量收敛一致性 | 同一工作树执行 full index 与若干次 sync 后图是否一致 |
| 确定性 | 同一提交重复索引的 nodes/edges 差异 |
| 完整性状态可靠性 | partial、failed 是否能捕获真实中断和静默丢文件 |

---

# 第二章：CodeGraph Explore 流程

## 2.1 Explore 的目标与输入输出边界

Explore 的目标不是返回“最相似的十个符号”，而是在一次调用中交付足够回答代码问题的上下文：

- 找到问题涉及的核心定义；
- 说明这些定义之间如何连接；
- 展示修改前需要关注的调用方和测试影响面；
- 返回当前工作区中的真实源码；
- 在预算不足时明确告诉调用者还有哪些文件没有展示。

CLI 的 <code>codegraph explore</code> 与 MCP 的 <code>codegraph_explore</code> 最终进入同一个 <code>ToolHandler.handleExplore()</code>，因此核心行为一致。

输入主要包括：

| 参数 | 作用 |
|---|---|
| <code>query</code> | 自然语言、符号名、路径或它们的组合 |
| <code>projectPath</code> | 指定已初始化项目 |
| <code>maxFiles</code> | 最多展示文件数，限制在 1 到 20 |

默认输出预算随已索引文件数调整：小项目约 13K 或 18K 字符，大项目上限约 24K 字符；最终 hard ceiling 不超过 25K 左右，以避免工具结果被宿主外置为文件。

## 2.2 总体流程

~~~mermaid
flowchart LR
    A[查询] --> B[规范化与路径 pin]
    B --> C[多通道节点召回]
    C --> D[入口节点 roots]
    D --> E[类型层级 + 双向 BFS]
    E --> F[相关子图]
    F --> G[命名符号补强与胶水节点]
    G --> H[按文件聚合]
    H --> I[文件打分 + RWR]
    I --> J[Flow / 动态边界]
    J --> K[按相关度分配字符预算]
    K --> L[读取当前磁盘源码]
    L --> M[整文件/聚焦/骨架/代码簇]
    M --> N[最终结果 + 未展示指针]
~~~

可以把 Explore 理解为三次收敛：

1. 查询 → 少量入口节点；
2. 相关子图 → 少量高价值文件；
3. 候选文件 → 预算允许的完整源码区间。

每次收敛使用不同信号。入口召回主要依赖名称和文本，文件排序主要依赖结构和查询显式意图，源码组装主要依赖完整方法边界与预算。

## 2.3 查询预处理与路径 pin

查询首先进行语言形式规范化，例如把 Erlang 的 <code>module:function/arity</code> 转成统一可解析形式。

随后识别查询中的路径。成功匹配的路径会：

- 从用于文本召回的查询中移除，避免目录名和文件名碎片污染 FTS；
- 进入 pinnedFiles；
- 在候选准入、排序和预算分配中获得最高优先级；
- 在结果摘要中明确说明是否成功展示。

路径匹配先尝试项目相对精确匹配，再尝试按路径段对齐的后缀匹配。无法唯一匹配的路径片段会保留在结果说明中，而不是静默忽略。

这一步体现了一个重要优先级原则：

~~~text
用户显式指定文件 > 用户显式指定符号 > 图结构相关 > 文本相关
~~~

Explore 还会读取当前会话已经发送过的文件区间和内容 fingerprint。后续相同查询若再次覆盖未变化区间，可以返回“本会话之前已发送”的反向指针，把预算让给新内容。

## 2.4 第一阶段：多通道召回入口节点

<code>CodeGraph.findRelevantContext()</code> 先利用 <code>name_segment_vocab</code> 生成补充名称种子，再进入 <code>ContextBuilder.findRelevantContext()</code>。

召回不是单一路径，而是多个通道合并：

| 通道 | 解决的问题 | 典型示例 |
|---|---|---|
| 精确名称 | 用户直接写出符号名 | <code>getUser</code> |
| 名称片段词表 | 自然语言词无法穿透 CamelCase | “state machine” → <code>OrderStateMachine</code> |
| FTS5 | 名称、限定名、docstring、signature 的词项和前缀检索 | “token refresh” |
| 定义前缀与词干 | 查询写的是概念前缀或词形变化 | “allocation” → <code>AllocationService</code> |
| CamelCase 子串 | FTS tokenizer 把复合标识符看成一个 token | “Search” → <code>TransportSearchAction</code> |
| compound 多词共现 | 一个名称同时包含多个查询概念 | “search shard request” → <code>SearchShardsRequest</code> |
| LIKE/fuzzy 兜底 | FTS 没有结果时处理子串或轻微拼写错误 | <code>signIn</code> → <code>signInWithGoogle</code> |

同一节点被多个通道命中时保留最高分。之后还会应用：

- 同文件多符号共现加分；
- 多个独立查询词命中同一符号或路径的加分；
- 测试文件降权；
- 核心目录加分；
- 项目名和 <code>deprioritize</code> 目录降权；
- 普通常用词的精确同名碰撞降权。

最终保留的入口节点上限为 <code>searchLimit=8</code>。这不是最终结果数量，而是图扩展的根节点数量。入口过多会把固定图遍历预算分散到每个根上，导致每个入口只扩出很浅的邻域。

### 2.4.1 为什么必须多通道

不同查询形态的失败方式不同：

- 只做精确名称，会漏掉自然语言和部分名称；
- 只做 FTS，会漏掉 CamelCase 内部片段；
- 只做 LIKE，会召回大量包含同一短词的噪声；
- 只做词干，会把相关概念和具体代码符号混在一起；
- 只做图遍历，没有入口就无图可走。

多通道的价值不只是增加数量，而是用不同证据相互校验。例如“PmsProductController getList”同时命中类和方法且位于同一文件，比仅命中一个叫 list 的通用方法可信得多。

## 2.5 第二阶段：从入口节点扩展相关子图

Explore 对 <code>findRelevantContext</code> 使用的主要参数为：

| 参数 | 值 |
|---|---:|
| searchLimit | 8 |
| traversalDepth | 3 |
| maxNodes | 200 |
| minScore | 0.2 |

扩展分两部分。

### 2.5.1 类型层级优先扩展

如果入口是 class、interface、struct、trait 或 protocol，先单独展开 extends 和 implements 层级，并做第二轮父类型扩展以发现兄弟实现。

原因是普通 BFS 很容易从 class 经过 contains 走到大量方法，提前耗尽预算，导致真正重要的父类型和实现类型没有进入结果。

### 2.5.2 从每个入口执行双向 BFS

每个入口在图上进行 direction=both 的有界 BFS。双向意味着既可以看到“它调用谁”，也可以看到“谁调用它”。结果合并后再执行：

- maxNodes 总量裁剪，优先保留 roots 和一跳邻居；
- 单文件节点数上限，默认约为 maxNodes 的 20%；
- 非生产文件节点上限，默认约为 maxNodes 的 15%；
- 在已经选中的节点之间恢复遗漏的 calls、extends、implements、references、overrides 边。

子图最终由三个部分组成：

~~~text
Subgraph
├── nodes: Map<nodeId, Node>
├── edges: Edge[]
└── roots: nodeId[]
~~~

roots 表示查询入口，nodes 是后续文件聚合的候选实体，edges 同时服务于关系展示、RWR 排序、Flow 和代码区间选择。

## 2.6 第三阶段：命名符号与调用桥补强

通用召回和 BFS 后，Explore 还进行两类补强。

### 2.6.1 胶水节点

对 roots 的 callers 和 callees 再做一次查询。如果邻居位于已经出现的文件中、但因子图裁剪没有进入 nodes，则把它补入，最多 60 个。

它不会引入新文件，只补全已经准备展示文件中的连接方法。例如两个命名方法之间有一个很短的桥接函数，桥接函数本身不包含查询词，纯文本召回不会找到它，但如果不补入，读者看到的调用关系会断裂。

### 2.6.2 命名符号强制种子

Explore 再从 query 中提取最多 16 个标识符形状 token，直接查找同名函数、方法、组件、变量和常量。

对于重载或大量同名方法：

- 如果候选很少，保留多个实质定义；
- 如果候选很多，使用查询中同时出现的类型名或限定名选择上下文一致的候选；
- 如果没有上下文，退回到最具实质性的少量定义；
- camelCase 字段名没有独立节点时，可尝试找包含该字段片段的方法或变量。

命名种子即使已经由 FTS 找到，也会被标记为“用户明确点名”，因为这个身份会在文件排序和代码区间选择中获得最高优先级。

## 2.7 第四阶段：从节点相关性转成文件相关性

Explore 的交付单位是文件，因此必须把节点证据聚合成文件分数。

基础分层如下：

| 节点角色 | 基础权重 |
|---|---:|
| 用户命名种子 | 50 × kind weight |
| 查询入口 root | 10 × kind weight |
| root 一跳邻居 | 3 × kind weight |
| 更外围节点 | kind weight，单文件累计最多 5 |

kind weight 反映“命中这种符号是否足以说明文件相关”：

- function、method、class、interface、route 等约为 1；
- property、field、file 较低；
- variable、constant 更低；
- 完全没有使用边的弱类型节点会进一步降到 0.08。

这样可以避免一个大文件因为包含很多外围节点而自动变得更相关，也可以抑制普通英文词与局部变量同名造成的误召回。

### 2.7.1 图相关度：Random Walk with Restart

在已经得到的相关子图上，Explore 从所有 roots 和命名种子出发计算个性化 PageRank 风格的 Random Walk with Restart：

- 使用 calls、references、extends、implements、overrides、instantiates、returns、type_of、imports；
- 图按无向邻接处理，以便同时传播到调用方和被调用方；
- restart 概率 alpha=0.25；
- 固定迭代 25 次；
- 初始和回跳概率均匀分布在种子节点。

直观公式为：

~~~text
下一轮质量 = 0.75 × 从邻居传播来的质量 + 0.25 × 查询种子分布
~~~

每个文件的图分数等于文件内节点 RWR 质量之和。

RWR 解决的是文本分数无法解决的问题：一个文件可能没有多少查询词，但它连接多个入口或位于调用链中间，应该获得高分；另一个文件可能只因出现一个相同单词被召回，却与问题涉及的图簇完全不连接，图质量会很低。

但 RWR 只在已经召回的子图中运行。因此它能改善精排，不能弥补入口召回和图扩展完全漏掉的节点。

### 2.7.2 过滤、降权与最终排序

文件还会接受以下处理：

- 默认排除测试、spec、icon、i18n 等低价值文件；如果它们是唯一信号或查询明确询问测试，则保留；
- 生成代码分数和图质量乘 0.3；
- 孤立 ambient declaration 文件乘 0.5；
- 低价值文件保留时乘 0.5；
- 相对分数门槛为 <code>clamp(topScore × 0.2, 1, 10)</code>；
- 图相关度门槛通常为最高图分数的 6%，但入口、命名文件、中心文件、多词强命中和 pinned 文件豁免。

最终排序是分层而非单一加权和：

1. 查询按路径 pin 的文件，且保持查询中的出现顺序；
2. 定义用户命名符号的文件；
3. 同时具备结构相关和至少两个查询词证据的文件；
4. RWR 图质量；
5. 独立查询词命中数；
6. 低价值、生成文件等惩罚；
7. 基础文件分数和节点数。

这个排序表达了明确的产品意图：用户的显式指向优先于算法推断，结构相关优先于单纯文本相似。

## 2.8 第五阶段：Flow 主干与动态边界

相关文件列表仍然只是“哪些文件重要”，还没有回答“流程怎样经过这些文件”。因此 Explore 从查询中明确出现的可调用符号构造 Flow spine。

算法要点：

- 提取查询中的符号 token；
- 对简单重名方法，使用查询中同时出现的类或容器名消歧；
- 从每个命名种子沿 calls 边 BFS；
- 只接受终点也是用户命名符号的路径；
- 最多 7 跳；
- 最多允许 1 个连续未命名桥接节点，避免沿 god function 漫游；
- 选择命名符号之间最长的可解释链；
- heuristic calls 边会标为动态分发，并保留注册点信息。

Flow 不足 3 个节点时通常不打印主调用链，但命名符号仍然会影响源码区间优先级。

如果命名符号没有完整静态路径，Explore 不会简单猜一条边，而是补充：

- 命名符号相邻的 heuristic 动态边；
- 对 disconnected 方法体扫描反射、computed member、event bus、注册表等动态调用点；
- 当同名方法分布在大量实现类型中时，提示接口或策略分发边界，并列出若干具体实现。

因此，Flow 的作用不是证明整个程序的真实运行轨迹，而是给出“当前静态图中最可解释的主干”，并对静态分析到达边界的地方做诚实标注。

## 2.9 第六阶段：按相关度分配源码预算

候选文件排序后不会简单给每个文件相同字符数。<code>allocateExploreBudget()</code> 先为每个文件计算权重：

~~~text
weight = max(score, 0)
       × 文件内容价值 worth
       × Flow 文件加成
~~~

其中：

- pinned 文件至少获得与最强候选相同的权重；
- Flow spine 文件权重乘 2，且不会被相关度 cliff 丢弃；
- 生成或低价值内容会降低 worth；
- 低于最高权重 15% 的弱文件通常只返回指针，不占源码文件名额；
- 每个真正展示的文件先获得约 700 字符最低预算；
- 剩余预算再按权重比例分配；
- 单个文件原则上不超过总预算的 70%。

这个设计防止两个常见问题：

1. 先排到前面的文件把总预算吃光，后面的高价值文件一个字节也得不到；
2. 较小但较弱的文件因为能够整文件返回，反而比真正核心的大文件占用更多上下文。

渲染阶段还会把前面文件未花完的预算顺序转交给后续文件，并为“几乎能够整文件返回”的文件提供有限超支池，但不能侵占后续已承诺文件的预算。

## 2.10 第七阶段：读取当前磁盘源码并选择展示策略

文件通过排序和预算准入后，Explore 才读取磁盘内容。数据库在此处只提供：

- 文件路径；
- 相关符号名；
- 符号起止行；
- 调用点行号；
- 文件索引时 hash。

源码正文来自当前文件系统，并按配置添加 <code>行号 + Tab + 原始行</code>。

共有四种主要展示策略：

| 模式 | 适用场景 | 返回内容 |
|---|---|---|
| whole | 文件较小，且其预算已经覆盖大部分或全部文件 | 整个当前文件 |
| clusters | 普通大文件 | 围绕相关符号和调用点聚合的若干完整代码区间 |
| focused | 多态家族或 on-spine god file，且有必须完整展示的方法 | 命名或 Flow 方法完整体，其余符号只给签名 |
| skeleton | 大量可互换实现，当前文件不在 Flow 且没有唯一命名方法 | 签名骨架，具体 body 留给下一次 Explore |

### 2.10.1 Cluster 的形成

Cluster 以相关节点范围和边发生行作为候选区间：

- 去掉覆盖文件大半内容的 class、module 等 envelope 节点，避免一个大类把整个文件合成一个巨型区间；
- 合并相互重叠或相距不远的范围；
- root、命名符号、Flow 节点具有更高 importance；
- 优先选择 Flow cluster、命名 cluster 和高密度 cluster；
- 尽量保留完整方法体；
- 单个超大方法超过预算时才按完整行窗口化，而不是在字符中间硬切断；
- 多个非连续区间之间添加 gap 标记。

### 2.10.2 磁盘漂移保护

如果当前文件 hash 与 files.content_hash 不一致，数据库记录的行区间可能已经错位：

- 小文件若能整文件返回，则返回当前完整内容，并提示符号列表可能过期；
- 大文件不再按旧行号切片，而是明确省略源码并提示先同步或直接读取该特定文件。

这是“源码当前、结构可能过期”这一双数据源架构的必要保护。

### 2.10.3 会话级去重

如果同一会话此前已经收到某文件的相同 fingerprint 和相同区间，本次会用反向指针替换重复源码。若去重后整次响应没有任何新源码，则恢复最高排名的一个已抑制文件，避免返回纯指针让调用者误以为 Explore 没有找到内容。

## 2.11 检索结果的组成与作用

最终结果不是固定每次都包含所有部分。项目规模、是否存在相关边、是否形成 Flow、预算是否饱和都会影响实际段落。完整结构如下：

~~~text
可选：Flow / 动态分发链接 / 动态边界
Exploration 标题
结果摘要
可选：Blast radius
可选：Relationships
Source Code
  ├── 文件标题与相关符号
  ├── 当前源码或会话反向指针
  └── 整文件 / clusters / focused / skeleton
可选：磁盘漂移警告
可选：Not shown above 文件指针
可选：完整性说明与 Explore 调用预算提示
~~~

下面分别说明每一部分的来源和作用。

### 2.11.1 Flow

示意：

~~~text
Flow (call path among the symbols you queried)
1. Controller.getList (controller.ts:20)
   ↓ calls
2. ProductService.list (service.ts:42)
   ↓ dynamic: interface → impl
3. ProductServiceImpl.list (service-impl.ts:58)
~~~

来源：查询中明确命名的可调用符号、calls 边和 heuristic 动态边。

作用：

- 为读者提供跨文件阅读顺序；
- 把“相关文件集合”转成“执行主线”；
- 让源码预算优先覆盖主线方法；
- 显示静态调用和动态分发的区别。

边界：它是命名符号之间的最长可解释链，不是运行时 trace，也不保证覆盖所有分支。

### 2.11.2 Dynamic-dispatch links / Dynamic boundaries / Interface dispatch

来源：heuristic 边、方法体动态调用扫描、实现类型家族分析。

作用：

- 解释静态调用链为何中断；
- 标出事件总线、反射、注册表、函数指针或策略接口的运行时选择点；
- 给出 wiring site 和候选继续方向；
- 避免把无法静态确定的目标伪装成确定调用边。

对后续优化而言，这部分是衡量 CodeGraph 相比 grep 的关键差异点，但也是误报风险最高的区域。

### 2.11.3 Exploration 标题与结果摘要

示意：

~~~text
Exploration: token refresh flow
Found 18 symbols across 4 files. 1 file pinned from the query.
~~~

来源：最终真正保留在响应中的文件和这些文件的去重后符号数。

作用：

- 给出本次交付范围；
- 区分原始候选池与最终展示内容；
- 明确路径 pin 是否成功；
- 对未唯一匹配的路径做提示。

摘要统计的是最终幸存文件，而不是中间召回的全部节点，避免让读者误以为需要手工筛选上百个候选。

### 2.11.4 Blast radius

示意：

~~~text
Blast radius — what depends on these
- refreshToken (auth/service.ts:41) — 6 callers in api.ts, session.ts; tests: auth.test.ts
~~~

来源：最多 5 个 root 的 callers，外加最多 3 跳内的间接测试调用方。

作用：

- 在修改前提示潜在受影响生产文件；
- 提示应验证的直接或间接测试；
- 把 Explore 从“理解实现”扩展到“支持安全修改”。

它只列位置，不占用这些调用方的源码预算。没有依赖者的 root 不显示。

### 2.11.5 Relationships

示意：

~~~text
calls:
- getList → list

implements:
- ProductServiceImpl → ProductService
~~~

来源：相关子图中除 contains 外的边，按 kind 分组并限制每类数量。

作用：

- 快速说明调用、引用、继承和实现关系；
- 在没有形成单一 Flow 时提供局部结构；
- 帮助判断某文件为何被召回。

小项目默认可能省略这一段，因为同样信息已能从紧凑源码和 Flow 中看出。

### 2.11.6 Source Code

每个文件段一般包含：

~~~text
文件路径
相关符号名及 kind
展示模式或漂移说明
带行号源码代码块
~~~

来源：排序后获得预算的文件、数据库中的节点范围、当前磁盘文件。

作用：

- 这是 Explore 的主要交付物；
- 让调用者无需再次 Read 已展示文件；
- 保留真实语法、注释和局部上下文，避免只看摘要造成误判；
- 行号可直接用于后续编辑和引用。

整文件模式提供完整上下文；clusters 保留相关方法体；focused 和 skeleton 控制多态家族或 god file 的上下文成本。

### 2.11.7 Already sent earlier

来源：会话历史记录的文件 fingerprint 和已发送区间。

作用：

- 避免连续 Explore 重复消耗上下文；
- 把预算转移给尚未出现的文件；
- 保证只有文件未变化时才复用历史内容。

它不是“结果缺失”，而是指向同一会话中仍然有效的源码副本。

### 2.11.8 磁盘漂移警告

来源：当前文件内容 hash 与初始化或最近 sync 时的 hash 对比。

作用：

- 区分“源码是当前的”和“索引行号是当前的”；
- 防止按过期行号切出另一个方法的代码；
- 提醒 Flow、Blast radius、符号列表中的行号可能偏移。

### 2.11.9 Not shown above

示意：

~~~text
Not shown above:
- src/auth/repository.ts — findSession(method:88), revoke(method:120)
~~~

来源：已排名但没有得到源码预算的文件，以及分数门槛下方的部分外围文件。

作用：

- 让预算裁剪保持可解释；
- 告诉调用者下一次 Explore 应该点名什么；
- 避免“没有展示”被误解成“没有找到”。

低于 allocation cliff 的文件不消耗源码文件名额，但必须尽量在这里保留可继续查询的路径和符号。

### 2.11.10 完整性与预算提示

来源：项目规模对应的 Explore 策略和本次是否发生裁剪。

作用：

- 说明已经返回的源码可视为已读取，不应重复 Read；
- 提示在问题跨越更多文件时继续使用更具体的 Explore；
- 对大项目给出建议调用次数，限制无边界探索。

## 2.12 端到端示例

查询：

~~~text
PmsProductController getList PmsProductService list PmsProductServiceImpl
~~~

### 步骤一：召回入口

- 精确名称找到 <code>PmsProductController</code>、<code>getList</code>、<code>PmsProductService</code>、<code>PmsProductServiceImpl</code>；
- <code>list</code> 可能有大量重名方法；
- 查询中的类名作为容器上下文，将 list 候选收敛到 service 接口和实现。

### 步骤二：图扩展

- contains 找到类内方法；
- calls 找到 controller 到 service 的调用；
- implements 找到实现类；
- references、type_of 等补充 DTO、repository 或返回类型。

### 步骤三：文件排序

- controller、service、service impl 因为定义命名符号进入最高层；
- 调用链上的 repository 即使查询词较少，也会通过 RWR 获得图质量；
- 同名 list 的其他业务模块因缺少容器共命名和图连接被降权；
- 测试与生成文件默认排到后面或被过滤。

### 步骤四：Flow

~~~text
PmsProductController.getList
  → PmsProductService.list
  → PmsProductServiceImpl.list
~~~

如果接口到实现通过运行时分发连接，结果会明确标记 dynamic，而不是伪装成直接静态 calls。

### 步骤五：源码交付

- 小型 controller 文件可能整文件返回；
- service 接口可能只需签名和类型关系；
- service impl 返回 list 的完整方法体；
- repository 若预算不足，至少出现在 Not shown above；
- Blast radius 列出调用 controller 或 service 的上层入口与测试。

读者因此获得的是“入口—接口—实现—数据访问”的有序故事，而不是若干孤立搜索命中。

## 2.13 Explore 阶段的优化观察

### 2.13.1 召回是最终效果的上限

当前召回主要依赖手工设计的词法通道和名称统计，优势是本地、确定、快速、可解释；局限是：

- 查询和代码完全不同词时较弱；
- 非 Latin 技术名的 segment 词表能力有限；
- 大量启发式规则之间可能出现叠加或互相抵消；
- FTS、LIKE、prefix 和 compound 通道存在重复扫描。

优化时应先构建按查询类型分层的 recall 基准：

- 精确符号查询；
- 多个符号组成的流程查询；
- 纯自然语言概念查询；
- 显式路径查询；
- 重载、同名、多语言和框架动态调用查询。

没有入口 recall 指标，只看最终人工体验很难定位是“没找着节点”还是“找着后排错了文件”。

### 2.13.2 图扩展存在预算与结构偏差

双向 BFS 简单可靠，但：

- contains 会把一个类的兄弟方法快速铺开；
- 每个 root 平均分配 maxNodes，弱 root 会消耗强 root 的预算；
- 深度 3 和单文件 20% cap 可能截断真实长流程；
- edge recovery 只能恢复已选节点之间的边，不能找回被裁掉的桥接节点。

可以考虑按边类型、种子置信度和新信息增益动态分配扩展预算，而不是每个 root 等额 BFS。

### 2.13.3 RWR 是精排器，不是全局检索器

RWR 只在最多约 200 个节点的相关子图中运行。优点是成本可控，缺点是图质量高度依赖前面的候选集。

后续可评估：

- 在更大的候选图上先做廉价近似传播，再裁剪；
- 对 calls、implements、references 使用不同转移权重，而不是全部等权；
- 保留有向信息，分别计算 caller relevance 与 callee relevance；
- 为高出度工具函数或 god class 做度归一化和 hub 惩罚；
- 用离线 query-relevance 数据学习部分权重，但保留 pinned 和命名符号的硬优先级。

### 2.13.4 文件排序规则多且存在断层

当前排序包含命名层、共现层、RWR、词数、生成文件、测试文件、ambient declaration、分数门槛和图门槛。规则都对应真实失败案例，但长期累积会带来：

- 某个阈值附近的小变化导致文件从完整源码变成只给指针；
- 新规则修复一个仓库后影响另一类查询；
- 基础 score 和 fileGraphScore 被分别惩罚，理解成本较高；
- 排序、准入和预算分配使用的信号部分重复。

建议利用现有 Explore trace，把每个文件的召回通道、分数组成、准入理由、最终排名、预算和渲染模式记录为可回放样本，建立回归评测而不是继续只靠单案例调常数。

### 2.13.5 Flow 对查询表达方式敏感

Flow 只围绕用户明确命名的符号寻找主干，并且只允许一个连续未命名桥。这能抑制错误漫游，但也会漏掉：

- 用户只写自然语言、没有写符号名的流程；
- 真实链路中存在两个以上胶水方法；
- 跨消息总线、依赖注入或反射的多段动态链；
- 调用方向不是单一 caller → callee 的数据流问题。

可把“Flow 是否形成、覆盖多少命名 token、静态断点位置、动态边界候选数”作为单独指标，并探索基于高置信路径搜索而不是固定未命名桥数的方案。

### 2.13.6 字符预算不等于模型 token 预算

当前预算以字符数为主，易实现且与宿主 25K 字符限制直接对应，但不同语言和内容的 token 密度不同。长标识符、Unicode、压缩代码和大量注释可能使相同字符数产生不同模型成本。

在不突破宿主字符上限的前提下，可以增加轻量 token 估计作为第二约束，并用“有效完整方法数、Flow 覆盖率、重复源码比例”衡量单位预算价值。

### 2.13.7 当前源码与索引快照的双源一致性

Explore 返回当前磁盘正文是正确的产品选择，但行号与关系来自上次索引。现有 hash 漂移保护避免错误切片，却会在大文件漂移时直接省略内容。

可优化方向包括：

- 查询前更快的增量同步；
- 只对目标文件做轻量重解析并更新内存范围；
- 基于符号签名或内容锚点重新定位区间，而不完全依赖旧行号；
- 在结果中区分 graph freshness 和 source freshness。

## 2.14 建议的 Explore 评测指标

| 层级 | 指标 | 目的 |
|---|---|---|
| 节点召回 | root recall@8 | 判断是否找到正确入口 |
| 子图 | 关键路径节点覆盖率 | 判断 BFS 和 cap 是否截断主线 |
| 文件排序 | answer file recall@K、MRR | 判断核心文件是否排在前面 |
| Flow | 命名端点覆盖、路径边准确率、动态边界准确率 | 判断故事线是否可信 |
| 源码 | 完整目标方法覆盖率 | 判断是否仍需额外 Read |
| 预算 | 新源码字符占比、重复占比、单位 token 有效方法数 | 判断上下文利用效率 |
| 安全修改 | blast radius caller/test recall | 判断修改影响提示是否充分 |
| 稳定性 | 相同索引和查询结果差异 | 防止启发式排序抖动 |
| 端到端 | 使用 Explore 后额外 grep/Read 次数 | 衡量产品最终价值 |

---

# 第三章：从初始化到 Explore 的端到端理解

初始化和 Explore 不是两套独立逻辑。Explore 的每一个核心能力都能回溯到初始化中的一类数据：

| Explore 能力 | 依赖的初始化产物 |
|---|---|
| 精确名称、限定名检索 | nodes 及 name/qualified_name 索引 |
| 自然语言词触达 CamelCase | name_segment_vocab |
| 文本与签名检索 | nodes_fts |
| callers、callees、Flow | edges.calls/references 及调用点 line |
| 类型实现和多态家族 | edges.extends/implements/overrides |
| 动态分发提示 | provenance=heuristic 的边和 metadata |
| 文件级排序 | nodes.file_path、files.generated、子图边 |
| 当前源码切片 | nodes.start_line/end_line + 磁盘文件 |
| 漂移保护 | files.content_hash |
| 影响面 | roots 的入边和测试调用链 |
| 失败后的可恢复性 | project_metadata.index_state |

这张映射对优化工作非常重要：

- Explore 漏掉符号，不一定是 Explore 的召回规则问题，也可能是初始化根本没有抽取该节点；
- Flow 断裂，不一定要直接加路径搜索深度，也可能是 resolver 没有建立 calls 边或 callback synthesis 漏边；
- 返回了错误代码区间，可能是同步延迟或节点范围抽取问题，而不是排序问题；
- 生成文件压过业务代码，既涉及 files.generated 的识别，也涉及 Explore 的惩罚和预算分配。

建议后续任何优化 issue 都沿下面的诊断链定位：

~~~text
文件是否进入 files？
  → 正确节点是否进入 nodes？
  → 正确关系是否进入 edges？
  → 查询是否召回正确 roots？
  → 关键节点是否留在 subgraph？
  → 关键文件是否通过准入并排在前面？
  → 关键方法是否获得源码预算？
  → 最终响应是否因 hard ceiling 或漂移被裁掉？
~~~

只有明确问题落在哪一层，优化才不会以增加更多启发式规则的方式掩盖上游数据缺口。

# 结论

CodeGraph 的核心架构可以概括为“SQLite 持久化的本地静态代码图 + 查询时的词法召回和图推理 + 当前磁盘源码交付”。

初始化阶段最重要的不是目录创建，而是两段式建图：

1. 单文件解析生成节点、局部边和待解析引用；
2. 全局解析与后处理把引用和动态语义变成真正可遍历的边。

其数据库也不是普通搜索缓存，而是职责清晰的多层模型：

- nodes 和 edges 保存代码图；
- files 管理增量和新鲜度；
- unresolved_refs 管理延迟绑定与失败重试；
- nodes_fts 和 name_segment_vocab 提供互补检索入口；
- project_metadata 管理索引完整性和版本。

Explore 阶段最重要的不是某一个打分公式，而是从节点到文件再到源码的逐层收敛：

1. 多通道召回保证不同查询形态都能找到入口；
2. 图扩展和 RWR 把“词相似”提升为“结构相关”；
3. Flow 与动态边界把文件集合组织成可解释主线；
4. 相关度预算和多种渲染模式尽量在一次调用中交付足够的当前源码；
5. Blast radius、未展示指针、漂移和会话去重让结果能够支持真实修改工作流。

后续优化不应只追求“索引更快”或“返回更多代码”，而应围绕两个最终目标：

- 用更低成本构建更完整、更准确、更容易增量收敛的代码图；
- 用更少上下文稳定返回真正解释问题的文件、调用链和完整方法。

# 关键源码导航

| 主题 | 文件与入口 |
|---|---|
| CLI init / explore | <code>src/bin/codegraph.ts</code> |
| CodeGraph 生命周期与 indexAll | <code>src/index.ts</code>：<code>CodeGraph.init</code>、<code>indexAll</code>、<code>findRelevantContext</code> |
| 数据库 schema | <code>src/db/schema.sql</code> |
| 数据库连接、批量模式和自愈 | <code>src/db/index.ts</code> |
| 数据库 CRUD 和检索 SQL | <code>src/db/queries.ts</code> |
| schema 迁移 | <code>src/db/migrations.ts</code> |
| 文件扫描、解析调度和文件级落库 | <code>src/extraction/index.ts</code> |
| 通用 Tree-sitter 抽取 | <code>src/extraction/tree-sitter.ts</code> |
| 节点 ID 生成 | <code>src/extraction/tree-sitter-helpers.ts</code>、<code>codegraph-kernel/src/ids.rs</code> |
| 解析结果过滤与 store worker | <code>src/extraction/store-writer.ts</code>、<code>src/extraction/store-worker.ts</code> |
| 全局引用解析与动态边合成 | <code>src/resolution/index.ts</code>、<code>src/resolution/callback-synthesizer.ts</code> |
| 混合召回与相关子图 | <code>src/context/index.ts</code> |
| 图遍历 | <code>src/graph/traversal.ts</code> |
| 查询词、词干和名称分段 | <code>src/search/query-utils.ts</code>、<code>src/search/identifier-segments.ts</code> |
| 路径识别与 pin | <code>src/search/query-paths.ts</code> |
| Explore 主流程、RWR、Flow、预算与源码拼装 | <code>src/mcp/tools.ts</code> |
| Explore 会话去重 | <code>src/mcp/explore-session-state.ts</code>、<code>src/mcp/explore-dedup.ts</code> |
| Explore 可观测性 | <code>src/explore-trace.ts</code>、<code>src/mcp/explore-diagnostics.ts</code> |

