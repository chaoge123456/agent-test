# Docker 底层机制、文件系统与构建流程分析报告

## 一、结论先行：Docker 到底是什么

Docker 并不是虚拟机，也不是一个独立操作系统。它的本质是：

> 使用 Linux 内核已有的隔离、资源控制和文件系统能力，把一个普通进程包装成“看起来像独立机器”的运行单元。

容器内的应用进程仍然使用宿主机内核；不同的是，Docker 为它准备了：

- 独立的进程、网络、挂载等视图；
- 受限的资源使用范围；
- 一棵由镜像层、容器写层和额外挂载拼接而成的文件系统树；
- 标准化的镜像构建与启动流程。

因此，理解 Docker 最有效的路径不是先记命令，而是从下面这条链条出发：

```text
Linux 文件系统与挂载
        ↓
Namespace 与资源隔离
        ↓
OverlayFS 的分层合并
        ↓
镜像层与容器可写层
        ↓
Volume / bind mount / tmpfs
        ↓
containerd / runc 启动容器进程
```

---

# 二、Docker 运行的底层核心机制

## 2.1 容器为什么“像一台独立机器”？

一台虚拟机通常模拟硬件，并在虚拟硬件上运行一个完整的客户机内核：

```text
应用
客户机操作系统内核
虚拟硬件
Hypervisor
宿主机内核
```

Docker 容器则没有独立内核：

```text
容器应用进程
Linux 内核
宿主机硬件
```

这带来两个直接结果：

- 容器通常启动更快、占用更少资源；
- Linux 容器不能脱离 Linux 内核能力运行，例如 Linux Docker 容器无法直接使用 Windows 内核。

那么，同一个内核如何让不同容器彼此“看不见”？

答案是 Linux Namespace。

---

## 2.2 Namespace：为进程制造独立视图

Namespace 不是把资源真的复制一份，而是让不同进程对同一类系统资源看到不同视图。

| Namespace | 它隔离的内容 | 容器中的表现 |
|---|---|---|
| PID Namespace | 进程编号与进程树 | 容器中常把主进程看作 PID 1 |
| Network Namespace | 网卡、IP、端口、路由 | 容器有自己的网络接口与网络栈 |
| Mount Namespace | 挂载点与文件系统树 | 容器拥有自己的 `/` |
| UTS Namespace | 主机名、域名 | 容器可有独立 hostname |
| IPC Namespace | 共享内存、消息队列等 | IPC 不与其他容器混用 |
| User Namespace | UID/GID 映射 | 容器 root 可映射为宿主非 root 用户 |

其中，文件系统相关的关键是 Mount Namespace。

严谨地说，容器不是“真的拥有一块独立硬盘”，而是：

> 容器进程在独立的 Mount Namespace 中运行，因此它看到的是一棵独立组织的挂载树。

宿主机进程看到的 `/` 是宿主根目录；容器进程看到的 `/` 则是 Docker 为该容器装配出来的根目录。

---

## 2.3 cgroups：隔离不等于资源限制

Namespace 解决“看见什么”，但不限制“能用多少”。

如果只有 Namespace，一个容器依然可能耗尽宿主机 CPU、内存或进程号。cgroups 则用于限制和统计资源：

```bash
docker run \
  --cpus=1 \
  --memory=512m \
  --pids-limit=100 \
  nginx
```

逻辑上：

```text
Namespace
  → 容器看见独立世界

cgroups
  → 容器只能使用被分配的资源额度
```

两者共同构成容器运行时隔离的基础。

---

## 2.4 containerd 与 runc：谁真正启动了容器？

简化后的运行链路是：

```text
docker CLI
   ↓
Docker daemon
   ↓
containerd
   ↓
containerd-shim
   ↓
runc
   ↓
Linux 内核
```

它们的职责可以这样理解：

- Docker：镜像构建、命令行、网络、Volume 等高层用户体验；
- containerd：容器生命周期管理；
- runc：根据 OCI 规范创建 Namespace、挂载文件系统、设置资源与安全限制，并启动目标进程；
- Linux 内核：最终执行 `clone`、`unshare`、`mount`、`execve` 等系统调用。

OCI 规范相当于容器的标准说明书，描述：

```text
运行什么进程
根文件系统在哪里
挂载哪些目录
使用哪些 Namespace
资源限制是什么
用户与权限是什么
```

runc 将这份说明书落实为内核操作。

---

# 三、Docker 文件系统和存储挂载机制

## 3.1 先理解：路径不是文件本身

Linux 中，路径只是定位文件的入口：

```text
路径名
  ↓
目录项 dentry
  ↓
inode
  ↓
文件数据块
```

VFS（虚拟文件系统）向应用提供统一接口，使程序无需关心文件到底来自 ext4、XFS、NFS、tmpfs 还是 OverlayFS。

这为 Docker 的文件系统拼装提供了前提：只要能挂载到目录树中，不同来源的文件都能以普通路径形式供进程访问。

---

## 3.2 Mount：让一个路径通向另一套内容

mount 的本质不是复制，而是改变路径解析结果。

```text
挂载前：

/data
└── old-file.txt

将新文件系统挂载到 /data 后：

/data
└── new-file.txt
```

原来的 `old-file.txt` 没有删除，只是被新挂载遮住。

这一规则直接解释了 Docker 中的常见现象：

```bash
docker run -v "$PWD":/app my-image
```

如果镜像原本已有 `/app` 内容，宿主机目录挂载到 `/app` 后，镜像内原有内容会被遮住，而非被删除。

---

## 3.3 镜像层与容器可写层：共享与隔离的平衡

镜像必须可复用。如果每启动一个容器就复制整套 Ubuntu、Python 和应用依赖，空间和启动时间都会迅速失控。

Docker 因此将镜像设计为多层只读文件系统：

```text
Layer 1：基础操作系统
Layer 2：运行时与依赖
Layer 3：应用文件
```

多个容器可共享这些层：

```text
容器 A ─┐
容器 B ─┼── 共享同一组镜像只读层
容器 C ─┘
```

但容器又需要写入日志、临时文件与运行状态。因此每个容器额外拥有一层独立可写层：

```text
共享镜像只读层
        +
容器私有可写层
        =
容器看到的根文件系统 /
```

这个合并过程通常由 OverlayFS 完成，现代 Docker Linux 环境中最常见的存储驱动是 `overlay2`。

---

## 3.4 OverlayFS：用“透明玻璃片”理解分层文件系统

可以把镜像层和容器写层想象成多张透明玻璃片：

```text
最上层：容器可写层
中间层：镜像应用层
底层：基础镜像层
```

从上往下看，最先遇到的文件版本就是容器最终看到的版本。

OverlayFS 的核心结构是：

```text
lowerdir：镜像只读层
upperdir：当前容器可写层
workdir ：OverlayFS 工作目录
merged  ：合并后的目录树
```

读取一个文件时：

```text
先查 upperdir
   ↓ 未找到
再查 lowerdir
```

新建文件时，直接写入 `upperdir`。

修改镜像中的文件时，不能直接改 `lowerdir`，因为它只读且可能被多个容器共享。因此会发生 copy-up：

```text
镜像层存在 /app/main.py
        ↓
容器修改它
        ↓
复制到当前容器 upperdir
        ↓
修改 upperdir 副本
        ↓
合并视图优先显示新版本
```

删除镜像文件时，则通过 whiteout 标记隐藏下层文件：

```text
lowerdir：仍有 /app/main.py
upperdir：记录“该文件已删除”
merged：容器看不到 /app/main.py
```

因此，容器删除镜像文件并不会修改镜像本身。

---

## 3.5 容器最终的 `/` 是一棵拼接树

OverlayFS 只负责生成容器的基础 rootfs。真正启动容器前，Docker 还要将不同来源挂载到容器的 Mount Namespace 中：

```text
/
├── bin、etc、usr、var     ← 镜像层 + 容器可写层，OverlayFS 合并
├── app                    ← bind mount，宿主机目录或文件
├── data                   ← Docker Volume
├── tmp                    ← tmpfs
├── proc                   ← procfs
├── sys                    ← sysfs
└── dev                    ← 设备节点与运行时设备挂载
```

所以不能简单说“文件在容器里”或“文件在宿主机里”。更准确的提问是：

> 这个容器路径最终命中了哪一个挂载？

---

## 3.6 四类常见存储位置

| 容器路径来源 | 物理或逻辑位置 | 容器删除后 | 适合场景 |
|---|---|---:|---|
| 容器可写层 | OverlayFS `upperdir` | 通常消失 | 临时运行状态 |
| Named Volume | Docker 管理的持久化存储 | 保留 | 数据库、上传文件 |
| Bind mount | 宿主机指定路径 | 保留 | 开发源码、配置注入 |
| tmpfs | 内存文件系统 | 消失 | 高速临时数据、短期敏感数据 |

### 容器可写层

```bash
docker run --name demo ubuntu \
  sh -c 'echo hello > /data.txt; sleep infinity'
```

`/data.txt` 写入容器可写层；删除 `demo` 后，通常不再保留。

### Named Volume

```bash
docker volume create app-data

docker run --rm \
  --mount type=volume,src=app-data,dst=/data \
  ubuntu \
  sh -c 'echo hello > /data/message.txt'
```

之后即使换一个容器挂载 `app-data`，也能读取该文件。

### Bind mount

```bash
docker run --rm \
  --mount type=bind,src="$PWD",dst=/app \
  ubuntu \
  ls /app
```

容器 `/app` 与宿主当前目录是同一份内容，不是复制或同步。

### tmpfs

```bash
docker run --rm \
  --tmpfs /tmp:size=64m \
  ubuntu \
  sh -c 'echo cache > /tmp/cache.txt'
```

数据主要存于内存，容器停止后消失。

---

# 四、Docker 镜像和容器的构建流程

## 4.1 Dockerfile 是可复现的构建说明书

例如：

```dockerfile
FROM python:3.12-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD ["python", "main.py"]
```

它表达的不是“运行时如何修改容器”，而是：

> 如何从一个基础镜像，稳定地构建出一个新的只读镜像。

构建可抽象为：

```text
基础镜像
   ↓
设置工作目录
   ↓
复制依赖描述文件
   ↓
安装依赖
   ↓
复制应用源码
   ↓
定义默认启动命令
   ↓
生成新镜像
```

---

## 4.2 每一步为什么能形成层和缓存？

传统 Docker 构建中，很多 Dockerfile 指令会形成新的镜像层或构建缓存节点：

```text
FROM python:3.12-slim
      ↓
COPY requirements.txt .
      ↓
RUN pip install ...
      ↓
COPY . .
```

Docker 会根据构建上下文、指令和前序结果判断某一步能否复用缓存。

这解释了一个常见最佳实践：

```dockerfile
# 更利于缓存复用
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
```

如果只是修改业务源码，依赖文件没有变：

```text
requirements.txt 未变
        ↓
依赖安装层可复用
        ↓
只重新执行 COPY . .
        ↓
构建更快
```

反过来，如果先执行：

```dockerfile
COPY . .
RUN pip install -r requirements.txt
```

任何源码变化都可能导致依赖安装步骤缓存失效。

---

## 4.3 镜像构建与容器运行是两件事

这两个概念必须严格区分：

```text
docker build
  → 生成只读镜像

docker run
  → 基于镜像创建一个具体容器
```

关系如下：

```text
Dockerfile
   ↓ docker build
镜像（可复用、只读、分层）
   ↓ docker run
容器（镜像 + 独立可写层 + 运行时挂载 + 进程）
```

同一个镜像可以启动多个互不影响的容器：

```text
my-app:1.0
  ├── container-a：独立写层、独立 Namespace
  ├── container-b：独立写层、独立 Namespace
  └── container-c：独立写层、独立 Namespace
```

它们共享镜像层，但不会共享各自的运行时修改，除非显式挂载同一 Volume 或宿主目录。

---

## 4.4 从 `docker run` 到进程启动的完整推理

假设执行：

```bash
docker run --rm -it \
  --mount type=volume,src=app-data,dst=/data \
  --mount type=bind,src="$PWD/config.yaml",dst=/app/config.yaml,readonly \
  --tmpfs /tmp:size=64m \
  my-app:1.0
```

运行时逻辑可以按以下顺序理解：

```text
1. 找到 my-app:1.0 的镜像层
        ↓
2. 创建这个新容器专属的可写层
        ↓
3. 使用 OverlayFS 合并镜像层与可写层
        ↓
4. 得到容器的基础 rootfs
        ↓
5. 创建新的 Mount Namespace
        ↓
6. 让该 rootfs 成为容器进程看到的 /
        ↓
7. 挂载 /proc、/sys、/dev 等运行时文件系统
        ↓
8. 将 app-data 挂到 /data
        ↓
9. 将宿主 config.yaml 挂到 /app/config.yaml
        ↓
10. 将 tmpfs 挂到 /tmp
        ↓
11. 配置网络、PID、用户、资源限制与安全策略
        ↓
12. 执行 ENTRYPOINT / CMD，启动应用进程
```

最终，应用执行：

```python
open("/data/orders.db")
```

并不需要知道底层细节。内核会根据挂载表决定：

```text
/data 命中 Volume 挂载
        ↓
文件实际写入 app-data 对应的持久化存储
```

同理：

```text
/app/config.yaml → bind mount → 宿主机文件
/tmp/cache.db    → tmpfs      → 内存
/usr/bin/python  → OverlayFS  → 镜像层或容器写层
```

---

# 五、关键设计原则与实践结论

## 5.1 不要把关键数据放进容器可写层

容器写层适合短期运行状态，但不适合作为数据库或业务持久化目录。

优先级通常是：

```text
数据库数据、上传文件
  → Named Volume 或外部持久化存储

本地开发源码、明确的宿主配置
  → bind mount

短期缓存或临时敏感文件
  → tmpfs

可随时重建的临时状态
  → 容器可写层
```

---

## 5.2 挂载会遮住镜像同路径内容

如果镜像中已有 `/app`，但运行时挂载：

```bash
-v "$PWD":/app
```

容器看到的是宿主目录，而不是镜像的 `/app` 内容。

这不是镜像文件丢失，而是 mount 的正常遮蔽行为。

---

## 5.3 镜像应不可变，数据应外置

理想的生产部署模式是：

```text
镜像
  → 仅包含应用程序与运行依赖
  → 可重复构建、可版本化、可快速替换

运行配置
  → 环境变量、只读配置挂载、Secret

业务数据
  → Volume、数据库服务、对象存储、PVC
```

因此，`docker commit` 虽可将容器当前状态固化成镜像，但通常不应作为常规交付方式；它不易复现，也容易意外包含日志、缓存或敏感信息。

---

# 六、最终心智模型

Docker 的文件系统不是一块“容器硬盘”，而是一棵运行时拼接出来的目录树：

```text
镜像只读层
      +
容器私有写层
      ↓ OverlayFS
容器基础根文件系统 /
      ↓ Mount Namespace
容器独立文件系统视图
      ↓ 额外挂载
Volume / bind mount / tmpfs / proc / sys / dev
      ↓
以该目录树为环境启动容器进程
```

把这条链理解透之后，绝大多数 Docker 存储问题都能顺着路径反推：

```text
某个文件在哪？
  ↓
先看容器路径
  ↓
确认该路径命中何种挂载
  ↓
判断它属于 OverlayFS、Volume、bind mount 或 tmpfs
  ↓
推导数据位置、生命周期、权限和性能特征
```

Docker 的核心价值，不是创造了一种新的操作系统，而是把 Linux 内核原本分散的能力——文件系统、挂载、Namespace、cgroups、OCI 运行时——组织成了可构建、可分发、可复现、可运行的应用交付模型。