# CubeSandbox 创建、文件系统挂载与文件操作流程分析报告

> 适用范围：本文依据本仓库当前 `CubeAPI`、`CubeMaster`、`Cubelet`、`CubeShim`、Guest agent 和 SDK 源码梳理。重点解释 **Cube runtime** 下创建沙箱、构造文件系统、挂载卷和通过 SDK 操作文件的实际链路。

## 1. 整体结论

CubeSandbox 不是“在宿主机上直接启动一个容器”。一次沙箱创建会跨越控制面、节点运行面和 MicroVM 数据面：调用方先向 CubeAPI 表达“需要什么样的沙箱”，CubeMaster 选择节点，目标节点上的 Cubelet 准备镜像、卷、网络和 OCI 配置；CubeShim 启动 MicroVM；Guest agent 再在虚拟机内部挂载设备、拼出容器根文件系统、并启动一个或多个容器。

文件路径也因此经历多层视图。以将宿主机 `/srv/project` 挂到容器 `/workspace` 为例，数据不是一次性“复制”进去，而是经过宿主机受控中转目录、virtiofs 虚拟文件系统和 Guest 内 bind mount，最终让容器看见 `/workspace`。用户随后调用 SDK 的 `files.write()`，请求先到沙箱内的 `envd` 服务；envd 在容器文件系统视图中写入目标路径，内核再沿着该路径命中的挂载关系把数据落到 OverlayFS 可写层、临时卷，或宿主机共享目录。

## 2. 全局流程图

![CubeSandbox 创建、文件系统挂载与文件操作流程图](D:/code/sandbox/choose_sandbox/cubesandbox-创建与文件系统流程图.png)

阅读图的诀窍是区分三个层次：

1. **Host（宿主机）**：Cubelet 能看到真实磁盘、目录、containerd 和 Hypervisor。
2. **Guest（MicroVM 内部）**：有自己的 Linux 内核、挂载表和进程空间；它不是宿主机。
3. **容器**：运行在 Guest 内，拥有自己的进程和挂载命名空间，但共享 Guest 内核。

## 3. 角色、责任与因果关系

| 角色 | 所在位置 | 主要责任 | 为什么需要它 |
|---|---|---|---|
| CubeAPI | 控制面 | 对外 HTTP API、认证、请求转换 | 调用方不必知道节点、磁盘路径或虚拟化细节 |
| CubeMaster | 控制面 | 选节点、维护全局状态、协调创建/删除/快照 | 多节点系统必须有统一调度者 |
| Cubelet | 每个节点 | 准备镜像/卷/网络，生成 OCI 配置，驱动 containerd | 只有节点本地进程能操作本机磁盘、网络与运行时 |
| CubeShim | 宿主机 | containerd 与 MicroVM 的运行时桥梁 | 将 OCI task 生命周期映射到 VM 生命周期 |
| MicroVM | 虚拟化边界 | 向用户工作负载提供独立 Guest 内核与设备 | 相比直接宿主容器，多一道内核级隔离边界 |
| Guest agent | Guest 内 | 处理挂载请求、组装 rootfs、创建 Guest 内容器 | 宿主机不能直接在 Guest 内调用 `mount(2)` |
| virtiofs | Host ↔ Guest | 将受控宿主路径以虚拟文件系统形式提供给 Guest | VM 默认看不到宿主文件系统 |
| envd | 容器/Guest 数据面 | 为 SDK 提供命令、读写文件等 HTTP/Connect API | 用户不需要 SSH 或直接访问节点 |

这是一条严格的责任链：

```text
用户表达意图
  → CubeAPI 接收
  → CubeMaster 决定在哪执行
  → Cubelet 准备本机资源
  → CubeShim 启动虚拟机
  → Guest agent 在 Guest 内完成挂载和容器启动
  → envd 让用户实际使用该容器
```

## 4. 阶段一：从创建请求到 Cubelet 工作流

### 4.1 请求的两类信息

`RunCubeSandboxRequest` 中最关键的是：

- `containers`：要运行的一个或多个 Guest 内容器；
- `volumes`：卷的来源；
- `volume_mounts`：某个卷应该出现在哪个容器路径；
- 镜像、资源、网络、注解等。

一个 Guest 可以运行多个容器；它们共享同一个 Guest 内核，但各自仍可拥有独立的进程/挂载命名空间。

Volume 类型的协议定义如下：

```proto
message VolumeSource {
  EmptyDirVolumeSource empty_dir = 1;
  SandboxPathVolumeSource sandbox_path = 5;
  HostDirVolumeSources host_dir_volumes = 7;
  ImageVolumeSource image = 9;
  PluginVolumeSource plugin_volume = 11;
}
```

来源：[cubebox.proto](CubeSandbox/Cubelet/api/services/cubebox/v1/cubebox.proto:497)。

### 4.2 Cubelet 建立创建上下文

Cubelet 的服务入口验证请求、补默认值，然后把请求包装为 `CreateContext`，其中会逐步收集存储、网络、cgroup 等阶段性结果：

```go
createInfo := &workflow.CreateContext{
    ReqInfo:  req,
    Failover: true,
}
...
if constants.IsCubeRuntime(ctx) {
    createErr = s.engine.Create(ctx, createInfo)
}
```

来源：[service.go](CubeSandbox/Cubelet/services/cubebox/service.go:303)。

这里的逻辑是：**创建不是一个单一函数，而是一张施工单经过多个专业步骤**。后续步骤共享同一个 `CreateContext`，因此容器创建阶段能得到存储阶段产出的卷路径和 virtiofs 配置。

### 4.3 工作流先后关系

Cubelet 的创建工作流由配置定义：

```toml
[plugins."io.cubelet.workflow.v1.workflow".flows.create]
actions = [
  ["createid", "appsnapshot"],
  ["images", "volume", "storage", "network", "netfile", "cube-sandbox-store"],
  ["cgroup"],
  ["cubebox"]
]
```

来源：[config.toml](CubeSandbox/Cubelet/config/config.toml:164)。

数组内同一组可以并行，组与组之间串行。换言之，创建容器之前，镜像、存储和网络必须已经准备好；这是因为 MicroVM 的设备和 OCI spec 都依赖这些资源。

## 5. 阶段二：准备存储与卷

### 5.1 Cubelet 如何按类型分派 Volume

存储插件遍历用户请求的卷，并按来源调用相应准备逻辑：

```go
for _, v := range realReq.Volumes {
    if err := l.prepareDefaultMedium(ctx, opts, v, result); err != nil { ... }
    if err := l.prepareImageVolume(ctx, opts, v, result); err != nil { ... }
    if err := l.prepareHostDirVolume(ctx, opts, v, result); err != nil { ... }
    if err := l.attachPluginVolume(ctx, opts, v, result); err != nil { ... }
}
```

来源：[local.go](CubeSandbox/Cubelet/storage/local.go:853)。

可将其理解为“先问卷从哪里来，再决定怎样带进 Guest”：

| 来源 | Cubelet 先做什么 | 最终介质 |
|---|---|---|
| `empty_dir: default` | 创建本地块存储/CoW 卷 | Guest 块设备上的可写文件系统 |
| `empty_dir: memory` | 不创建持久块卷 | 容器路径上的 tmpfs |
| `host_dir_volumes` | 建中转目录并 bind mount 宿主路径 | virtiofs 共享目录 |
| `plugin_volume` | 调用 NFS/COS/CFS 等插件完成节点侧挂载 | 受控路径后再进入 virtiofs |
| `sandbox_path` | 不引入 Host 路径 | 直接绑定 Guest 已存在路径 |

### 5.2 host-dir：为何一定要有中转目录

假设用户声明：

```text
host_path      = /srv/project
container_path = /workspace
```

Cubelet 不会将 `/srv/project` 整体授权给 VM，而是在该沙箱专属路径建立中转点：

```text
/srv/project
  └─ rbind → /data/cubelet/hostdir/<sandbox-id>/rw/project
```

实现如下：

```go
shareDir := filepath.Join(hostDirBasePath, sandboxID, roStr)
bindDest := filepath.Join(shareDir, src.GetName())

if err := os.MkdirAll(bindDest, 0755); err != nil { ... }
if err := bindHostDir(ctx, src.GetHostPath(), bindDest, readOnly); err != nil { ... }
```

来源：[hostdir.go](CubeSandbox/Cubelet/storage/hostdir.go:109)。

实际的绑定使用递归 bind mount：

```go
runHostDirCommand(mountCtx, hostDirMountBinary, "--rbind", srcPath, bindDest)
if readOnly {
    runHostDirCommand(remountCtx, hostDirMountBinary,
        "-o", "remount,bind,ro", bindDest)
}
```

来源：[hostdir.go](CubeSandbox/Cubelet/storage/hostdir.go:76)。

这样设计可推出三个安全和运维收益：

1. **授权最小化**：virtiofs 仅共享 Cubelet 选择的中转目录，而不是任意宿主路径。
2. **实例隔离**：不同沙箱的中转路径不同。
3. **可回收**：销毁时 Cubelet 只卸载并移除 `<sandbox-id>` 目录，不删除用户原始 `host_path`。

## 6. 阶段三：将 Host 文件系统送入 MicroVM（virtiofs）

### 6.1 virtiofs 的必要性

Guest 是另一套操作系统，它不能直接解析 Host 的 `/srv/project`。因此仅做宿主 bind mount 不够；还必须将结果作为虚拟设备提供给 Guest。这个设备就是 virtiofs。

```text
Host VFS → virtiofs 后端 → virtio 设备 → Guest virtiofs 驱动 → Guest VFS
```

Cubelet 将同一沙箱的 RO/RW 中转目录分组为 virtiofs 通道：

```go
cfg := &virtiofs.VirtiofsConfig{
    VirtioBackendFsConfig: virtiofs.VirtioBackendFsConfig{
        SharedDir:   k.shareDir,
        AllowedDirs: v.bindPaths,
        ReadOnly:    k.readOnly,
        Cache:       constants.VirtiofsCacheNone,
    },
}
```

来源：[virtiofs.go](CubeSandbox/Cubelet/plugins/cbri/cubeboxcbri/virtiofs.go:31)。

`AllowedDirs` 是关键：它限定该 virtiofs 后端能够提供哪些中转目录。`ReadOnly` 让 RO 卷和 RW 卷成为不同的 Guest 共享通道；`CacheNone` 则倾向于减少跨 Host/Guest 共享工作区的缓存可见性问题。

### 6.2 CubeShim 把配置交给 Guest

CubeShim 读取 virtiofs 配置并形成 Guest agent 的存储请求：

```rust
let mut virtiofs = agent::Storage {
    driver: "virtio-fs".to_string(),
    source: fs.id.clone(),
    fstype: "virtiofs".to_string(),
    options: vec![].into(),
    ..Default::default()
};
```

来源：[sb.rs](CubeSandbox/CubeShim/shim/src/sandbox/sb.rs:298)。

Guest 中，普通 virtiofs 可挂在 `/run/virtiofs/<id>`；传播通道使用 `/mnt/virtio-ro` 和 `/mnt/virtio-rw`。这些不是用户最终访问的路径，而是 Guest 内部的共享入口。

### 6.3 Guest agent 执行真正的挂载

Guest agent 创建挂载点、解析选项，并在 **Guest 内核** 中调用 mount：

```rust
baremount(
    source,
    mount_path,
    storage.fstype.as_str(),
    flags,
    options.as_str(),
    &logger,
)
```

来源：[mount.rs](agent/src/mount.rs:714)。

这里必须与宿主机 bind mount 区分开：

```text
Cubelet 的 mount：准备 Host 的中转目录。
Guest agent 的 mount：把 virtiofs 设备挂入 Guest 文件系统。
```

## 7. 阶段四：构造容器根文件系统

一个容器并不是直接把镜像目录作为 `/` 使用。CubeSandbox 将镜像层作为只读 lowerdir，并在 Guest 内通过 OverlayFS 组合出每个容器的 rootfs：

```text
镜像 layer 1（只读） ┐
镜像 layer 2（只读） ├─ lowerdir
镜像 layer 3（只读） ┘
容器独立 upperdir       ← 写入这里
容器独立 workdir
           ↓
容器根目录 /
```

Cubelet 先取得镜像层并转为可共享路径：

```go
localImage, err := l.criImage.LocalResolve(ctxTmp, containerReq.GetImage().GetImage())
ovlDir, err := rootfs.GenImageSharedDirs(localImage.HostLayers)
ovlShare = append(ovlShare, ovlDir...)
mountsConfig.Overlay = virtiofs.GenOverlayMountConfig(ovlShare)
```

来源：[cube_container_create.go](CubeSandbox/Cubelet/services/cubebox/cube_container_create.go:668)。

Guest agent 组装并挂载 OverlayFS：

```rust
opt = fmt::format(format_args!(
    "workdir={},upperdir={},lowerdir={}",
    work_dir.to_str().unwrap(),
    upper_dir.to_str().unwrap(),
    lowerdir,
));
baremount(Path::new("overlay2"), &rootfs_path, "overlay", MsFlags::empty(), opt.as_str(), &sl!())?;
```

来源：[rpc.rs](agent/src/rpc.rs:2285)。

逻辑结果是：镜像层可被多个沙箱复用，但用户向普通容器路径写文件时只修改自己的 `upperdir`，不会修改镜像层。

## 8. 阶段五：将 Guest 中的共享目录挂进容器

此刻 Guest 能看到类似下列入口：

```text
/mnt/virtio-rw/project
```

但用户的容器需要看到的是 `/workspace`。Guest agent 必须进入目标容器的 mount namespace，再执行 bind mount：

```rust
let mnt_ns_path = format!("/proc/{}/ns/mnt", pid);
let ret = unsafe { libc::setns(file.unwrap().as_raw_fd(), libc::CLONE_NEWNS) };

mount(
    Some(m.source.as_str()),
    m.dest.as_str(),
    None::<&str>,
    MsFlags::MS_BIND | MsFlags::MS_REC,
    None::<&str>,
)
```

来源：[rootfs.rs](agent/cube/src/rootfs.rs:82)。

`setns` 的含义是“切换到该容器看到的挂载世界”。如果没有这一步，挂载只会出现在 Guest 自身的 mount namespace，不会出现在用户容器内。

在这个例子中：

```text
Guest /mnt/virtio-rw/project
  └─ bind mount → Container /workspace
```

因此容器进程打开 `/workspace/a.txt`，就是在访问 Guest virtiofs 中的 `project/a.txt`。

## 9. 阶段六：containerd 启动容器和 MicroVM

Cubelet 在准备完 OCI 选项后，通过 containerd 创建容器对象和 task：

```go
c, err := l.client.NewContainer(ctx, ci.ID, cOpts...)
task, err := c.NewTask(ctx, ioCreater, taskOpts...)
if err := task.Start(ctx); err != nil {
    return ret.Err(errorcode.ErrorCode_StartTaskFailed, err.Error())
}
```

来源：[cube_container_create.go](CubeSandbox/Cubelet/services/cubebox/cube_container_create.go:1313)。

对第一个 Sandbox/Pod 容器而言，task 会建立 CubeShim 与 MicroVM；后续容器则作为同一个 Guest 内的附加容器创建。因而正确的关系是：

```text
一个 Sandbox ≈ 一个 MicroVM + 一个 Guest + 一个或多个容器
```

容器和 Guest 不是同一实体：Guest 是一套操作系统环境，容器是它里面的隔离进程环境。

## 10. 阶段七：用户如何进行文件操作

### 10.1 控制面与数据面分离

创建沙箱走控制面：

```text
SDK → CubeAPI → CubeMaster → Cubelet
```

创建成功后，读写文件走数据面，不需要每次经过 Cubelet：

```text
SDK → 沙箱数据面地址 / CubeProxy → envd:49983 → 容器文件系统
```

Python SDK 的读取逻辑：

```python
resp = self._sandbox._client.get(
    f"http://{self._sandbox.get_host(ENVD_PORT)}/files",
    params={"path": path, "username": effective_user},
    headers=headers,
)
```

来源：[\_filesystem.py](CubeSandbox/sdk/python/cubesandbox/_filesystem.py:69)。

写入逻辑：

```python
resp = self._sandbox._client.post(
    f"http://{self._sandbox.get_host(ENVD_PORT)}/files",
    params=params,
    headers=headers,
    content=body,
)
```

来源：[\_filesystem.py](CubeSandbox/sdk/python/cubesandbox/_filesystem.py:91)。

目录操作则通过：

```text
/filesystem.Filesystem/ListDir
/filesystem.Filesystem/Stat
/filesystem.Filesystem/MakeDir
/filesystem.Filesystem/Move
/filesystem.Filesystem/Remove
/filesystem.Filesystem/WatchDir
```

来源：[\_filesystem.py](CubeSandbox/sdk/python/cubesandbox/_filesystem.py:42)。

### 10.2 一次写文件的严密因果链

调用：

```python
sandbox.files.write("/workspace/result.txt", "hello")
```

会发生：

```text
1. SDK 向 envd 的 POST /files 发请求，包含 path、用户和内容。
2. envd 在沙箱容器环境中打开 /workspace/result.txt。
3. 容器的 VFS 路径解析发现 /workspace 是 bind mount。
4. 访问转到 Guest 的 /mnt/virtio-rw/project。
5. Guest virtiofs 驱动把文件操作发往 Host 的 virtiofs 后端。
6. 后端定位到 Cubelet 创建的中转路径。
7. 中转路径是宿主 /srv/project 的 rbind 视图。
8. 数据最终写入宿主 /srv/project/result.txt。
```

若写入 `/app/result.txt`，路径通常不会命中 host-dir 挂载，而会命中容器 OverlayFS，数据进入该容器的独立 `upperdir`。

> 说明：该仓库包含 envd 的注入、路由和 SDK 客户端，但不包含 envd 服务端本身的完整文件处理实现。因此 envd 对路径穿越、符号链接、UID/GID 的最终策略必须以实际运行的 envd 镜像/版本为准，不能仅凭 Cubelet 源码断言。

## 11. 文件系统映射总结

以 RW host-dir `/srv/project → /workspace` 为例，映射依次为：

| 序号 | 层级 | 路径/对象 | 映射方式 | 作用 |
|---:|---|---|---|---|
| 1 | Host | `/srv/project` | 用户指定 `host_path` | 原始数据目录 |
| 2 | Host | `/data/cubelet/hostdir/<sid>/rw/project` | `mount --rbind` | Cubelet 受控的沙箱专属中转点 |
| 3 | Host → Guest | virtiofs `virtio_rw` 设备 | 虚拟设备 + `AllowedDirs` | 跨越 VM 边界共享文件系统 |
| 4 | Guest | `/mnt/virtio-rw/project` | `mount -t virtiofs` | Guest 内共享入口 |
| 5 | Guest → Container | `/workspace` | 在容器 mount namespace 中 `MS_BIND|MS_REC` | 用户程序可见的最终路径 |
| 6 | 数据面 | `envd POST /files?path=/workspace/...` | HTTP/Connect | 让 SDK 调用实际触发文件系统操作 |

将它压缩成一条路径：

```text
Host /srv/project
  → Host /data/cubelet/hostdir/<sid>/rw/project
  → virtiofs virtio_rw
  → Guest /mnt/virtio-rw/project
  → Container /workspace
  → envd /files
```

不同写入位置的落点如下：

| 容器路径类型 | 数据落点 | 销毁沙箱后的典型结果 |
|---|---|---|
| 普通镜像路径，如 `/app/x` | OverlayFS `upperdir` | 随沙箱或快照策略处理 |
| 默认 `empty_dir` | 沙箱专属块存储/CoW 卷 | 通常随沙箱回收 |
| 内存 `empty_dir` | tmpfs | 释放内存即消失 |
| RW host-dir，如 `/workspace/x` | 宿主原始 `host_path` | 保留 |
| RO host-dir | 写入失败 | 原始数据保留 |

## 12. 收束：如何建立正确心智模型

不要把“沙箱”理解为一个单独容器。对 CubeSandbox，更准确的表达是：

```text
沙箱 = 由 Cubelet 创建的一台 MicroVM
     + 该 VM 内的 Guest OS
     + 一个或多个 Guest 容器
     + 通过 virtiofs/块设备提供的文件系统
     + envd 暴露的数据面能力
```

从这个模型可自然推导出所有现象：

- 宿主目录必须经 virtiofs 才能被 Guest 看见；
- Guest 看见后仍需进入容器 mount namespace 才能成为 `/workspace`；
- 镜像层和用户写层通过 OverlayFS 分离；
- SDK 写文件不是直接改 Cubelet 本地目录，而是请求容器内 envd；
- 删除沙箱会清理中转挂载和沙箱私有资源，但不会删除用户原始 host-dir。
