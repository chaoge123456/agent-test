# OpenSandbox 源码架构与 Agent 语义工作流分析

## 一、定位：面向 Agent 的“协议化沙箱平台”

OpenSandbox 的核心价值不在于发明一种新的底层隔离技术，而在于把 Docker 与 Kubernetes 等运行时包装成一套面向 AI Agent 的统一沙箱协议。它将“创建一段隔离计算环境”与“在该环境中执行命令、编辑文件、维持交互会话、暴露服务端口”组织为稳定的服务接口。

因此，它尤其适合作为 Harness（智能体编排框架）下方的执行平台：Harness 负责模型推理、任务拆分、工具选择和策略；OpenSandbox 负责提供生命周期受控、可观察、可访问的执行环境。两者之间的边界比较清楚。

## 二、系统架构

OpenSandbox 可以理解为四层架构。

```text
┌──────────────────────────────────────────────────────────────┐
│ Agent / Harness                                               │
│ 任务规划、上下文管理、策略、工具调用、结果评估                 │
└───────────────────────┬──────────────────────────────────────┘
                        │ 生命周期 API + 数据面 Endpoint
┌───────────────────────▼──────────────────────────────────────┐
│ OpenSandbox 控制层                                            │
│ Lifecycle Server：认证、租户、资源约束、创建/停止/续期/删除   │
│ Provider Factory：选择 Docker 或 Kubernetes 后端              │
└───────────────┬───────────────────────────────┬──────────────┘
                │                               │
┌───────────────▼──────────────┐  ┌─────────────▼─────────────┐
│ Docker Provider               │  │ Kubernetes Provider        │
│ 本机容器、端口映射、网络策略   │  │ CRD、池化、调度、Ingress   │
└───────────────┬──────────────┘  └─────────────┬─────────────┘
                └───────────────┬───────────────┘
                                │
┌───────────────────────────────▼──────────────────────────────┐
│ 沙箱数据层                                                     │
│ Workload / Workspace + execd + 可选 Egress、Jupyter 等组件    │
└──────────────────────────────────────────────────────────────┘
```

### 1. 控制层：生命周期而非业务执行

服务端的主入口将 API 挂载在 `/v1` 下。生命周期路由接收创建、查询、暂停、恢复、删除和续期等请求，再通过工厂选择 Docker 或 Kubernetes 实现。控制层主要解决：

- 这个沙箱属于谁、可使用多久、允许使用多少 CPU/内存；
- 使用何种镜像、工作区和网络策略；
- 沙箱是否已就绪，及如何向调用方返回可访问端点；
- Kubernetes 场景下如何用 Pool、BatchSandbox 等对象承接批量和预热需求。

这一层不应成为 Agent 每次读文件或执行命令的必经中转。它管“沙箱是否存在以及如何被治理”。

### 2. Provider 层：同一语义，不同运行底座

Docker Provider 适合单机开发、轻量本地部署和调试；它创建运行容器，并可通过共享网络命名空间的附属容器实施网络出口策略。Kubernetes Provider 则面向多租户、资源调度、池化与集群入口治理。

这说明 OpenSandbox 的可移植性来源于协议边界，而不是要求每一种后端具有相同实现。对 Harness 来说，只要生命周期与数据面协议稳定，本地 Docker 与远端 Kubernetes 可以使用同一套适配器。

### 3. 数据层：execd 是沙箱内的交互代理

`execd` 是运行在沙箱工作负载内的服务进程，通常监听沙箱内部端口。它将原本需要 SSH、`docker exec` 或 Kubernetes exec 的操作变成 HTTP、SSE 和 WebSocket 能力：

- 运行命令与获取状态、日志；
- 执行代码；
- 读写文件、管理目录；
- 建立持续 Session；
- 提供 PTY 交互终端；
- 上报度量与运行状态。

所谓 **execd Endpoint**，即 Lifecycle Server 在沙箱就绪后返回的“可以访问这个 execd 的 URL 和必要请求头”。Docker 可能映射到本机端口；Kubernetes 可能经过 Ingress 或服务端代理。Harness 必须使用返回的地址和头部，不应自行拼接容器 IP 或固定端口。

### 4. 网络与附属能力

OpenSandbox 将网络看作平台能力的一部分。Kubernetes/Docker 后端可以注入 Egress 组件，控制外部访问并减少主工作负载直接拥有网络治理权限；端口访问则可通过 Ingress 或代理暴露。隔离 Session、可选 Jupyter 等能力也是以组件化方式叠加在数据层上。

## 三、核心运行机制

一个典型沙箱从申请到执行，分为“控制面准备”和“数据面工作”两段。

```text
Harness 请求创建
  → Lifecycle Server 校验身份、规格、镜像与策略
  → Provider 创建容器或 Kubernetes 工作负载
  → 注入/启动 execd 与可选网络组件
  → 健康检查通过，返回 sandbox_id + execd Endpoint
  → Harness 调用 execd 执行、读写、会话与端口访问
  → 到期、显式释放或策略回收
```

### 1. 创建与就绪

创建请求通常是异步的：服务端先接受申请，后端完成容器或 Pod 的拉起、卷挂载、网络设置和 `execd` 就绪检查。Harness 应将“已创建”与“可执行”区分开，轮询或订阅状态，直到 Endpoint 可用后才发出实际操作。

### 2. 执行与会话

短命令可用一次性 command 接口；需要持续上下文的 REPL、调试器或终端任务应使用 Session/PTY。两者的区别很重要：一次性命令是无状态工具调用，Session 则是有状态资源，需要超时、取消、并发控制和回收。

### 3. 文件与服务访问

文件操作和命令执行都由 `execd` 数据面完成。对于启动 Web 服务、Notebook 或测试报告服务的任务，Harness 还可以请求端口 Endpoint；OpenSandbox 再依据后端能力生成可访问路径。这样 Agent 无需了解 Docker bridge 网络或 Kubernetes Service/Ingress 的细节。

### 4. 生命周期与恢复

暂停、恢复、销毁、续期与池化由控制层管理。Kubernetes 场景还可通过预热池降低创建延迟。需要注意的是：生命周期对象的身份稳定，并不自动意味着数据面地址永久稳定；恢复、迁移或重建之后，Harness 应重新解析 Endpoint。

## 四、如何与 Harness 协作

建议 Harness 将 OpenSandbox 封装为两类客户端，而不要把底层 API 直接暴露给每一个 Agent 工具。

```text
SandboxLifecycleClient
  create / waitReady / renew / pause / resume / destroy

SandboxExecutionClient
  resolveEndpoint / run / session / readFile / writeFile / exposePort
```

Harness 维护 `sandbox_id`、租户、能力令牌、生命周期状态与 Endpoint 缓存；执行客户端只在已就绪状态下工作。一次任务的推荐闭环是：

1. 根据风险、镜像、资源和网络权限申请沙箱；
2. 等待就绪并保存 `sandbox_id` 与 execd Endpoint/Headers；
3. 为 Agent 提供有限工具，例如受控命令、受控文件操作、测试运行和结果读取；
4. 对输出做截断、结构化、脱敏和 Token 预算控制；
5. 任务结束后收集工件、审计记录并销毁或归还池。

这种分层避免了模型知道 Docker/Kubernetes 实现细节，也让同一 Harness 可以按风险路由：可信的简单任务跑本地 Docker，不可信或多人并发任务跑 Kubernetes。

## 五、集成 Agent 文件系统语义视图

### 1. 目标：从“读取字节”变为“查询工作区知识”

传统 Agent 会反复执行 `ls`、`find`、`grep`、`cat`，并把大片源代码塞入上下文。语义视图把工作区预处理为可按需查询的知识：目录摘要、符号表、定义与引用、依赖影响、编译诊断、测试失败与变更摘要。

它不替代原始文件系统，而是在其上增加投影层。OpenSandbox 最适合把这一层以 sidecar 或沙箱内常驻服务方式部署。

### 2. 推荐组件

```text
Agent
  │ SemanticSandboxClient
  ▼
Harness Semantic Gateway
  ├─ 鉴权、路径策略、结果裁剪、审计、缓存
  ▼
Projection Service（与工作负载同 Pod / 同容器环境）
  ├─ 文件变更监听与周期性校验
  ├─ Tree-sitter / LSP / 构建诊断适配器
  ├─ 符号、依赖、诊断、执行结果索引
  └─ /views/* 查询 API
  ▼
共享 Workspace + execd 执行事件
```

在 Kubernetes 中，Projection Service 推荐为与工作负载共享工作区卷的 sidecar；在本地 Docker 中，可与 `execd` 共置或使用共享卷的独立容器。索引存放在独立可写卷中，避免污染用户项目，并方便按策略清理。

### 3. 语义视图工作流程

```text
文件写入 / Git 切换 / 命令执行
  → execd 或文件监听产生变更事件
  → Projection Service 增量解析受影响文件
  → 更新 AST、符号、依赖、诊断和执行摘要索引
  → Agent 查询最小必要视图
  → Gateway 做权限过滤与 Token 裁剪
  → Agent 形成下一步计划或提交受控修改
```

典型查询可以是：

- “`createSandbox` 的定义、调用者和相关测试是什么？”
- “修改这个配置文件可能影响哪些服务？”
- “上一次测试失败的根因摘要和最相关的三个文件是什么？”
- “给出 `src/api` 的模块地图，不返回全文源码。”

初期应以 JSON 查询接口为主，如 `/views/symbols`、`/views/impact`、`/views/diagnostics`、`/views/execution/latest`。将它们映射为 `/views/ast/...` 等虚拟目录可以作为兼容层，而不是首要目标。

### 4. 安全边界：语义视图必须与原始能力匹配

语义视图只有在 Agent 不能绕过它时，才能成为信息安全边界。若 Agent 同时拥有任意 `execd` shell、全量文件读取与 `/views/*` 脱敏接口，它仍可直接读取敏感内容。

建议使用能力分离：

- Agent 默认只获得语义查询、受保护的文件摘要及受控补丁接口；
- Projection Service 可读取工作区以构建索引，但不将原文默认返回；
- Trusted Executor 仅在获批操作时拥有原始 shell/文件能力；
- Gateway 按租户、路径、数据类型和操作类型实施策略。

还应将 `.env`、凭据、私钥、个人数据和受保护目录做摘要化或直接隐藏；对删除、依赖升级、网络访问和敏感路径修改实施类型门控；对每次视图查询、执行和补丁保存审计记录。

## 六、结论与实施优先级

OpenSandbox 是构建第一版 Agent 文件系统语义视图的优先底座：它已有清晰的数据面入口 `execd`、Docker/Kubernetes 适配层、sidecar/网络组件的部署形态，以及面向 Harness 的统一协议。

推荐按以下顺序推进：

1. 基于 Docker Provider 完成 Projection Service、目录/符号/诊断三类只读视图；
2. 让 Harness 优先调用语义查询，保留受控 `execd` 执行作为回退；
3. 接入文件变更与执行结果的增量索引；
4. 加入能力令牌、脱敏、审计和语义事务验证；
5. 再迁移至 Kubernetes sidecar、共享卷、池化与多租户治理。

它的优势是工程切入点清晰；代价是底层隔离强度取决于所选 Docker/Kubernetes 运行时。对高风险代码执行，仍需结合更强的运行时隔离或改用 MicroVM 类后端。
