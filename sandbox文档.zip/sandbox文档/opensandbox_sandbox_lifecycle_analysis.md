# OpenSandbox 沙箱创建、文件系统挂载与文件操作流程分析

> 分析基线：OpenSandbox `main` 分支（2026-08-25）。本文以默认 Docker runtime 为主线，并在文末说明 Kubernetes runtime 的等价映射。源码链接均指向上游仓库，便于逐段核对。

## 一、整体流程概述

一次 OpenSandbox 沙箱创建，本质上是一次“**在计算隔离环境中拼装文件系统视图，并在其上部署执行代理**”的过程。调用方通过 SDK 提交镜像、启动命令、资源约束和 `volumes[]`；OpenSandbox Server 校验这些意图，把卷模型转换成 Docker 可识别的 bind/named-volume 规格，再让 Docker 以镜像的只读层为底座、以该容器独有的可写层为增量创建容器。容器尚未启动时，Server 从独立的 `execd` 镜像提取执行代理和启动脚本，注入新容器的可写层；随后以 `bootstrap.sh` 作为入口启动容器。

启动后的 `execd` 在容器内部监听 HTTP API。SDK 的上传、下载、列目录、移动、删除等操作都先到达 `execd`，再由它在容器的挂载命名空间中执行普通的文件系统操作。因此，写入究竟是临时的还是持久的，取决于目标路径属于容器可写层，还是属于被挂载的 host directory、Docker named volume 或 Kubernetes PVC。容器删除后，仅容器可写层随之消失；外部卷仍然保留。

## 二、端到端流程图

```mermaid
sequenceDiagram
    autonumber
    participant SDK as SDK / Client
    participant S as OpenSandbox Server
    participant D as Docker daemon
    participant I as Image store & overlay filesystem
    participant V as Host path / named volume
    participant C as Sandbox container
    participant E as execd (:44772)

    SDK->>S: POST /v1/sandboxes\nimage, entrypoint, env, volumes[]
    S->>S: 校验资源、镜像、host 路径、subPath、卷类型
    S->>D: inspect / pull application image
    D->>I: 复用镜像只读 layers
    S->>S: volumes[] → Docker binds
    S->>D: create_container(image, host_config.binds, ...)
    D->>I: 创建此容器独有 writable layer
    D->>V: 在容器 mount namespace 挂载卷到 mountPath
    S->>D: 将 execd + bootstrap.sh 注入 /opt/opensandbox
    S->>D: start container
    D->>C: bootstrap 启动 execd 与用户 entrypoint
    C->>E: execd 提供 /files、/directories、/command
    SDK->>E: upload / download / list / move / delete
    E->>C: 在容器看到的文件系统中执行操作
    alt 写入挂载路径
        C->>V: 数据持久化到卷或宿主目录
    else 写入普通路径
        C->>I: 写入容器 writable layer
    end
```

图中有两条严格分开的职责链：Docker 负责 **root filesystem、namespace 和 mount**；OpenSandbox 负责 **声明校验、运行时装配与 API 代理**。把二者混为一谈，是理解存储持久性和安全边界时最常见的误区。

## 三、阶段 1：SDK 请求被转化为创建意图

调用方并不直接调用 Docker，而是提交运行时无关的 `CreateSandboxRequest`。例如：

```python
from opensandbox import Sandbox
from opensandbox.models.sandboxes import Host, Volume

sandbox = await Sandbox.create(
    image="python:3.12-slim",
    entrypoint=["sleep", "infinity"],
    volumes=[
        Volume(
            name="workspace",
            host=Host(path="/data/opensandbox/alice"),
            mountPath="/workspace",
            readOnly=False,
            subPath="task-001",
        )
    ],
)
```

这段请求表达的是意图，而不是 Docker 命令：将一个存储后端挂到容器内的 `/workspace`。其中 `name` 是请求内标识；`host`、`pvc`、`ossfs` 等字段是后端类型；`mountPath`、`readOnly`、`subPath` 是各后端共享的挂载语义。这个模型使同一 SDK 请求可以由 Docker 或 Kubernetes provider 分别翻译。

在 Docker provider 中，`DockerSandboxService` 组合了容器生命周期、卷、网络和运行时注入等 mixin：

```python
# server/opensandbox_server/services/docker/docker_service.py
class DockerSandboxService(
    DockerDiagnosticsMixin, DockerRuntimeMixin, DockerVolumesMixin,
    DockerNetworkingMixin, DockerContainerOpsMixin, OSSFSMixin,
    SandboxService, ExtensionService,
):
    """Docker-based implementation of SandboxService."""
```

这说明 Server 的工作并不是重写容器技术，而是在 Docker API 前添加一层一致的生命周期模型与安全策略。[源码](https://github.com/opensandbox-group/OpenSandbox/blob/main/server/opensandbox_server/services/docker/docker_service.py)

## 四、阶段 2：确保镜像存在，建立可复用的只读底座

创建容器前，服务端先检查镜像是否已存在；不存在才 pull：

```python
# server/.../docker/container_ops.py
def _ensure_image_available(self, image_uri, auth_config, sandbox_id, platform=None):
    try:
        image = self.docker_client.images.get(image_uri)
        # 已命中缓存时还会校验镜像平台
        ...
    except ImageNotFound:
        self._pull_image(image_uri, auth_config, sandbox_id, platform)

def _pull_image(self, image_uri, auth_config, sandbox_id, platform=None):
    self.docker_client.images.pull(image_uri, **pull_kwargs)
```

此处的关键推论是：**OpenSandbox 不会为每个 sandbox 复制完整镜像。** Docker 会将 OCI image 的多层内容保存为可复用的只读 layer。典型 Linux Docker 环境借助 overlay2（具体取决于 Docker storage driver）为容器构成 union filesystem：

```text
lowerdir: 镜像的只读层（/usr、/bin、/lib、/etc …）
upperdir: sandbox-<id> 独有的可写层
merged:   sandbox 进程实际看到的 /
```

读取未修改的 `/usr/bin/python` 时来自 `lowerdir`；一旦修改镜像已有文件，Docker 触发 copy-on-write，将副本放入 `upperdir`。新建的 `/tmp/a.txt` 也只进入该容器的 `upperdir`。因此两个 sandbox 使用同一个镜像，不代表能互相看见文件改动。[源码](https://github.com/opensandbox-group/OpenSandbox/blob/main/server/opensandbox_server/services/docker/container_ops.py)

## 五、阶段 3：卷校验——先确定“允许挂什么”，再讨论“怎样挂”

卷的安全边界从校验开始。Server 调用共享校验，并把服务端的 `storage.allowed_host_paths` 作为 host bind mount 的允许前缀：

```python
# server/.../docker/volumes.py
allowed_prefixes = self.app_config.storage.allowed_host_paths
ensure_volumes_valid(request.volumes, allowed_host_prefixes=allowed_prefixes)

for volume in request.volumes:
    if volume.host is not None:
        self._validate_host_volume(volume, allowed_prefixes)
    elif volume.pvc is not None:
        vol_info, was_created = self._validate_pvc_volume(volume)
    elif volume.ossfs is not None:
        self._validate_ossfs_volume(volume)
```

### 5.1 Host 路径和 `subPath`

实现会先拼接并规范化 `host.path + subPath`，然后做两层检查：字面路径检查与 `realpath` 后的符号链接检查。

```python
resolved_path = volume.host.path
if volume.sub_path:
    resolved_path = os.path.normpath(
        os.path.join(resolved_path, volume.sub_path)
    )

if allowed_prefixes:
    canonical = os.path.realpath(resolved_path)
    canonical_prefixes = [os.path.realpath(p) for p in allowed_prefixes]
    ensure_valid_host_path(canonical, canonical_prefixes)
```

第二层尤其重要：单纯允许 `/data/opensandbox` 并不安全，如果其中的 `link` 是指向 `/` 的符号链接，字面字符串仍在前缀内，但 Docker 最终会解析链接，造成挂载越界。源码通过 `realpath` 重新验证来缓解这一类路径穿透。

若目标不是一个已有文件，当前 Docker 实现还会确保目录存在：

```python
if os.path.isfile(resolved_path):
    return
os.makedirs(resolved_path, exist_ok=True)
```

这意味着生产环境应把 allowlist 收紧为平台专用根目录，而不应允许用户传递任意宿主机路径。[源码](https://github.com/opensandbox-group/OpenSandbox/blob/main/server/opensandbox_server/services/docker/volumes.py)

### 5.2 PVC 在 Docker 中的含义

`pvc.claimName` 在 Docker provider 中等价于 Docker named volume，而非 Kubernetes API 调用：

```python
# server/.../docker/volumes.py
vol_info = self.docker_client.api.inspect_volume(volume_name)
...
if volume.pvc.create_if_not_exists:
    self.docker_client.api.create_volume(
        name=volume_name,
        labels={SANDBOX_MANAGED_VOLUMES_LABEL: "server"},
    )
```

当卷没有 `subPath`，Docker 可以直接通过 volume name 挂载；有 `subPath` 时，服务端必须先查出 `Mountpoint`，拼成普通 bind mount。因此 `subPath` 只能在 local driver 下可靠使用，并需要防止其逃出 volume mountpoint。

## 六、阶段 4：把统一 Volume 模型翻译成 Docker 挂载规格

经过校验后，OpenSandbox 生成 Docker `binds` 字符串。这是“平台无关意图”落到“Docker 实现细节”的边界：

```python
# server/.../docker/volumes.py
container_path = volume.mount_path
mode = "ro" if volume.read_only else "rw"

if volume.host is not None:
    binds.append(f"{host_path}:{container_path}:{mode}")
elif volume.pvc is not None:
    binds.append(f"{volume.pvc.claim_name}:{container_path}:{mode}")
elif volume.ossfs is not None:
    _, host_path = self._resolve_ossfs_paths(volume)
    binds.append(f"{host_path}:{container_path}:{mode}")
```

对于前述请求，结果近似为：

```text
/data/opensandbox/alice/task-001:/workspace:rw
```

PVC 无 `subPath` 时则近似为：

```text
team-workspace:/workspace:rw
```

之后服务端将配置级固定挂载与本次请求挂载合并，并放入 Docker host config：

```python
# server/.../docker/docker_service.py
all_binds = list(self.app_config.docker.sandbox_binds or []) + (volume_binds or [])
if all_binds:
    host_config_kwargs["binds"] = all_binds
```

Docker 在创建容器时于其 mount namespace 中挂载这些路径。挂载点会**遮蔽**镜像/可写层在同路径原有内容：如果镜像有 `/workspace/template.py`，而挂入空卷到 `/workspace`，该文件在本次容器中不再可见；卸载后才重新可见。这不是文件删除，而是 Linux mount 的目录覆盖语义。[源码](https://github.com/opensandbox-group/OpenSandbox/blob/main/server/opensandbox_server/services/docker/volumes.py)

## 七、阶段 5：创建“未运行”的容器并注入 execd

OpenSandbox 先调用 Docker `create_container`，再向这个尚未启动的容器注入运行时组件，最后启动：

```python
# server/.../docker/container_ops.py
container_kwargs = {
    "image": image_uri,
    "command": bootstrap_command,
    "name": f"sandbox-{sandbox_id}",
    "environment": environment,
    "labels": labels,
    "host_config": host_config,
}
container_kwargs["entrypoint"] = [BOOTSTRAP_PATH]

response = self.docker_client.api.create_container(**container_kwargs)
container = self.docker_client.containers.get(response["Id"])
self._prepare_sandbox_runtime(container, sandbox_id, runtime_platform)
container.start()
```

这里的顺序不能颠倒：`put_archive` 在启动前发生，所以 `execd` 与 bootstrap 文件也成为该 sandbox writable layer 的一部分；但用户镜像不必预置这些文件。

### 7.1 execd 从何而来

Server 会为 `execd_image` 启动一个临时容器，从中导出 `/execd` 和 `/bootstrap.sh` 的 archive，并缓存在内存中：

```python
# server/.../docker/runtime.py
container = self.docker_client.containers.create(
    image=self.execd_image,
    command=["tail", "-f", "/dev/null"],
    ...
)
container.start()

stream, _ = container.get_archive("/execd")
data = b"".join(stream)

bs_stream, _ = container.get_archive("/bootstrap.sh")
self._bootstrap_script_cache[cache_key] = b"".join(bs_stream)
```

再写入目标容器：

```python
target_parent = "/opt/opensandbox"
self._ensure_directory(container, target_parent, sandbox_id)
container.put_archive(path=target_parent, data=archive)
```

最终注入顺序是：

```python
def _prepare_sandbox_runtime(self, container, sandbox_id, platform=None):
    self._copy_execd_to_container(container, sandbox_id, platform)
    self._install_bootstrap_script(container, sandbox_id, platform)
    self._copy_bwrap_to_container(container, sandbox_id, platform)
    self._copy_session_gate_to_container(container, sandbox_id, platform)
    self._copy_launcher_to_container(container, sandbox_id, platform)
```

其中 bwrap、session gate 和 launcher 是隔离 session 或 hardening 的可选辅助组件。它们的存在不改变主容器文件系统的根本语义，但可以为用户代码再创建更窄的执行边界。[源码](https://github.com/opensandbox-group/OpenSandbox/blob/main/server/opensandbox_server/services/docker/runtime.py)

## 八、阶段 6：容器启动与 `execd` 的职责

Linux sandbox 的 Docker entrypoint 会被设为 `/opt/opensandbox/bootstrap.sh`，而用户提交的 `entrypoint` 被作为 bootstrap 的 command。其意图是让容器启动时既拉起 OpenSandbox 的 API daemon，也保留用户业务进程。

`execd` 是容器内的执行 daemon，公开命令、文件、目录、PTY 和隔离 session API：

```text
HTTP :44772
├── /command、/session          命令与会话
├── /files、/directories        文件系统操作
├── /files/upload、/download    数据传入和取回
└── /v1/isolated/session        bwrap 隔离会话
```

OpenSandbox 官方说明明确把它定义为 sandbox 内的 runtime daemon，而不是宿主机文件代理。[execd 组件说明](https://github.com/opensandbox-group/OpenSandbox/blob/main/docs/components/execd.md)

## 九、阶段 7：文件操作怎样真正落盘

SDK 的文件操作经由 sandbox 暴露的 execd HTTP endpoint。在协议层，上传使用 multipart；下载支持 byte range 和按行读取：

```yaml
# specs/execd-api.yaml（节选）
/files/upload:
  post:
    summary: Upload files to sandbox
    # metadata: {"path":"/workspace/file.txt", "mode":755}
    # file: binary

/files/download:
  get:
    summary: Download file from sandbox
    # path=/workspace/data.csv
    # 支持 Range: bytes=0-1023
```

另外还有以下与文件系统直接相关的 API：

```text
GET    /files/info         元数据（属主、权限、大小、时间）
DELETE /files              删除普通文件
POST   /files/mv           重命名或移动
POST   /files/replace      文本替换
POST   /files/permissions  chmod / chown / chgrp
GET    /directories/list   列目录（符号链接不递归跟随）
POST   /directories        mkdir -p
DELETE /directories        递归删除目录
```

这里必须沿着路径判断真实存储位置：

| execd 写入的容器路径 | 文件系统归属 | sandbox 删除后的结果 |
|---|---|---|
| `/tmp/out.txt` | 容器 writable layer | 删除 |
| `/opt/opensandbox/state` | 容器 writable layer | 删除 |
| `/workspace/app.py`（已 host bind） | 宿主机目录 | 保留 |
| `/mnt/cache/a`（Docker named volume） | Docker volume | 保留 |
| `/mnt/data/a`（Kubernetes PVC） | 后端持久存储 | 保留 |

因此 `execd.files.upload("/workspace/a.py")` 不是“上传到 OpenSandbox Server 数据库”，而是等价于在该容器命名空间中写 `/workspace/a.py`。若 `/workspace` 是可写 bind mount，写入会透传到宿主机对应目录；若是只读挂载，内核会拒绝写操作；若未挂载，则写入容器 upperdir。

完整协议：[execd-api.yaml](https://github.com/opensandbox-group/OpenSandbox/blob/main/specs/execd-api.yaml)。

## 十、阶段 8：删除、持久性与存算分离含义

销毁 sandbox 时，Docker container 和其 writable layer 被回收，未挂载路径中的代码、依赖安装和临时产物随之消失。与之相反，host bind、named volume 和 PVC 的生命周期独立于 container；删除 sandbox 通常只是 unmount。

OpenSandbox 对自动创建卷做了额外保护：仅当卷带有 `server` 管理标签时才会在清理流程中删除，预先存在的卷不会被误删：

```python
# server/.../docker/volumes.py
vol_info = self.docker_client.api.inspect_volume(name)
vol_labels = vol_info.get("Labels") or {}
if vol_labels.get(SANDBOX_MANAGED_VOLUMES_LABEL) != "server":
    continue
self.docker_client.api.remove_volume(name)
```

这也是将 OpenSandbox 演进为“存算分离沙箱”的基础：计算实例可以短生命周期，workspace、模型和产物则放在独立卷或对象存储中。但共享可写卷不等于并发协调；当前模型的 `subPath` 提供的是路径隔离，不提供文件锁、事务或冲突解决。生产方案应为任务分配独立目录/卷，数据集默认只读，并通过权限、配额、生命周期规则与审计守住存储边界。

## 十一、Kubernetes runtime 的等价映射

Kubernetes provider 改变的是资源创建者，而不改变本文的逻辑分层：

| Docker 语义 | Kubernetes 对应物 |
|---|---|
| OCI image + Docker writable layer | kubelet/container runtime 的 image snapshot + writable snapshot |
| `host.path` bind mount | `hostPath` volume（节点本地） |
| Docker named volume（`pvc` backend） | `persistentVolumeClaim` |
| `mountPath` | `volumeMounts.mountPath` |
| `subPath` | `volumeMounts.subPath` |
| 删除 container | 删除 Pod/工作负载；PVC 通常保留 |

需要特别注意：Kubernetes `hostPath` 只属于当前节点。Pod 被调度到另一节点后，不能把它当作可靠的跨节点持久化工作区；这类需求应使用 PVC 或平台管理的远程存储。

## 十二、结论：用三个边界理解 OpenSandbox

1. **镜像边界**：镜像层是共享、只读的；容器改动写入每个 sandbox 自己的 writable layer。
2. **挂载边界**：显式 volume 决定某个容器路径是否连接到外部持久存储；挂载会遮蔽同路径镜像内容。
3. **API 边界**：SDK 不直接访问宿主机。它访问容器内 `execd`；`execd` 能触及的最终数据范围由容器 rootfs、Docker mount 与 OpenSandbox 的卷校验共同决定。

把这三层分开，就能可靠地判断任意一个文件“为何可见、写到哪里、何时消失、谁有权限访问”。

