#!/usr/bin/env node
/**
 * Real-agent evaluation for CodeGraph in Codex.
 *
 * It intentionally runs the same task set in two instruction modes:
 *   unprompted  - the agent sees the MCP but is free to select tools;
 *   guided      - the agent is asked to start source discovery with CodeGraph.
 *
 * The distinction matters: a repository rule that mandates CodeGraph would
 * make raw "did it call CodeGraph?" adoption 100% and therefore meaningless.
 * This runner ignores project rules and reports both adoption and sufficiency.
 *
 * Usage:
 *   node scripts/agent-eval/django-codex-adoption-eval.mjs <django-root>
 *     [--arm baseline|local|both] [--mode unprompted|guided|both]
 *     [--offset N] [--limit N] [--timeout-ms N] [--concurrency N] [--dry-run]
 *
 * This runner invokes the globally installed CodeGraph baseline and the local
 * built CLI without changing the user's persistent Codex MCP configuration.
 */
import { appendFileSync, existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const thisDir = dirname(fileURLToPath(import.meta.url));
const repoRoot = resolve(thisDir, '..', '..');
const localCli = join(repoRoot, 'dist', 'bin', 'codegraph.js');
const casesPath = join(thisDir, 'django-codex-adoption-cases.json');
const argv = process.argv.slice(2);
const targetArg = argv.find((arg) => !arg.startsWith('--') && !/^\d+$/.test(arg));
const valueAfter = (flag, fallback) => {
  const index = argv.indexOf(flag);
  return index >= 0 && argv[index + 1] ? argv[index + 1] : fallback;
};
const armArg = valueAfter('--arm', 'both');
const modeArg = valueAfter('--mode', 'both');
const offset = Math.max(0, Number(valueAfter('--offset', '0')) || 0);
const limit = Number(valueAfter('--limit', '0')) || 0;
const timeoutMs = Number(valueAfter('--timeout-ms', '45000')) || 45000;
const concurrency = Math.max(1, Math.min(4, Number(valueAfter('--concurrency', '1')) || 1));
const dryRun = argv.includes('--dry-run');
const resultsFileArg = valueAfter('--results-file', '');

if (!targetArg) {
  console.error('Usage: node scripts/agent-eval/django-codex-adoption-eval.mjs <django-root> [--arm baseline|local|both] [--mode unprompted|guided|both] [--offset N] [--limit N] [--timeout-ms N] [--concurrency N] [--results-file PATH] [--dry-run]');
  process.exit(2);
}
if (!['baseline', 'local', 'both'].includes(armArg) || !['unprompted', 'guided', 'both'].includes(modeArg)) {
  console.error('--arm and --mode must be baseline/local/both and unprompted/guided/both.');
  process.exit(2);
}

const targetRoot = resolve(targetArg);
const baselineShim = join(
  process.env.APPDATA || '', 'npm', 'node_modules', '@colbymchenry', 'codegraph', 'npm-shim.js',
);
if (!existsSync(join(targetRoot, '.codegraph'))) {
  console.error(`Django checkout is not indexed: ${join(targetRoot, '.codegraph')}`);
  process.exit(2);
}
if (!existsSync(localCli)) {
  console.error(`Local CLI is not built: ${localCli}. Run npm run build first.`);
  process.exit(2);
}
if (process.platform === 'win32' && !existsSync(baselineShim)) {
  console.error(`Installed baseline npm shim was not found: ${baselineShim}`);
  process.exit(2);
}

const fixture = JSON.parse(readFileSync(casesPath, 'utf8'));
const testCases = limit ? fixture.cases.slice(offset, offset + limit) : fixture.cases.slice(offset);
const arms = armArg === 'both' ? ['baseline', 'local'] : [armArg];
const modes = modeArg === 'both' ? ['unprompted', 'guided'] : [modeArg];
const resultsFile = resultsFileArg ? resolve(resultsFileArg) : null;

function tomlString(value) {
  return JSON.stringify(value);
}

function eventStream(text) {
  return text.split(/\r?\n/).flatMap((line) => {
    try { return [JSON.parse(line)]; } catch { return []; }
  });
}

function finalAnswer(events) {
  const messages = events
    .filter((event) => event.type === 'item.completed' && event.item?.type === 'agent_message')
    .map((event) => event.item.text || '');
  return messages.at(-1) || '';
}

function nativeInvestigationCalls(events) {
  return events.filter((event) => {
    if (event.type !== 'item.completed' || !event.item) return false;
    const type = String(event.item.type || '');
    return /command|exec|read|grep|glob|search/i.test(type) && type !== 'mcp_tool_call';
  });
}

function extractMcpCalls(events) {
  return events.filter((event) => (
    event.type === 'item.completed'
    && event.item?.type === 'mcp_tool_call'
    && event.item.server === 'codegraph'
    && event.item.status === 'completed'
    && !event.item.error
  ));
}

function quality(answer, requiredGroups) {
  const text = answer.toLowerCase();
  const matched = requiredGroups.filter((group) => group.every((term) => text.includes(term.toLowerCase())));
  return { matched: matched.length, total: requiredGroups.length };
}

function promptFor(testCase, mode) {
  const toolPolicy = mode === 'guided'
    ? 'Start source-code discovery with the available CodeGraph MCP. Use native tools only when CodeGraph has identified a specific candidate or when the needed evidence is outside indexed source code.'
    : 'Work autonomously with the available tools; use the CodeGraph MCP when it helps.';
  return [
    'Perform a read-only code investigation in this Django checkout. Do not modify files.',
    toolPolicy,
    'Answer concisely with production file paths, symbol names, and line references where available. State uncertainty rather than inventing facts.',
    `Task: ${testCase.task}`,
  ].join('\n\n');
}

function evaluateRun(arm, mode, testCase, result) {
  const events = eventStream(result.stdout || '');
  const calls = extractMcpCalls(events);
  const nativeCalls = nativeInvestigationCalls(events);
  const answer = finalAnswer(events);
  const answerQuality = quality(answer, testCase.required);
  const stderr = (result.stderr || '').trim().slice(-2000);
  // In the desktop harness a rejected native tool call is emitted to stderr,
  // not as an item.completed event. It is still evidence that CodeGraph was
  // insufficient for the agent's next step, so never count it as CG-only.
  const blockedNativeAttempts = (stderr.match(/exec_command failed:.*?blocked by policy/gi) || []).length;
  return {
    arm,
    mode,
    id: testCase.id,
    exitCode: result.status,
    timedOut: result.timedOut,
    codegraphCalls: calls.length,
    codegraphPayloadChars: calls.reduce((sum, call) => sum + JSON.stringify(call.item.result || '').length, 0),
    nativeInvestigationCalls: nativeCalls.length,
    blockedNativeAttempts,
    answerQuality,
    answerAvailable: Boolean(answer),
    stderr: stderr.slice(-500),
  };
}

function runOne(arm, mode, testCase) {
  const codegraphArgs = arm === 'baseline'
    ? [baselineShim, 'serve', '--mcp']
    : [localCli, 'serve', '--mcp'];
  const command = process.execPath;
  const codexArgs = [
    'exec',
    '--ephemeral',
    '--ignore-user-config',
    '--ignore-rules',
    '--json',
    '--color',
    'never',
    '--sandbox',
    'read-only',
    '-C',
    targetRoot,
    '-c',
    `mcp_servers.codegraph.command=${tomlString(command)}`,
    '-c',
    `mcp_servers.codegraph.args=${JSON.stringify(codegraphArgs)}`,
    promptFor(testCase, mode),
  ];
  return new Promise((resolve) => {
    const child = spawn('codex', codexArgs, { cwd: targetRoot, windowsHide: true });
    let stdout = '';
    let stderr = '';
    let timedOut = false;
    const timer = setTimeout(() => {
      timedOut = true;
      child.kill();
    }, timeoutMs);
    child.stdout.on('data', (chunk) => { stdout += chunk; });
    child.stderr.on('data', (chunk) => { stderr += chunk; });
    // Unlike spawnSync, async spawn keeps its stdin pipe open. Codex treats an
    // open pipe as additional prompt input and waits forever unless we signal
    // EOF explicitly.
    child.stdin.end();
    child.on('error', (error) => {
      clearTimeout(timer);
      resolve(evaluateRun(arm, mode, testCase, { stdout, stderr: `${stderr}\n${error.message}`, status: 1, timedOut }));
    });
    child.on('close', (status) => {
      clearTimeout(timer);
      resolve(evaluateRun(arm, mode, testCase, { stdout, stderr, status, timedOut }));
    });
  });
}

function percent(value, total) {
  return total ? `${(value / total * 100).toFixed(1)}%` : 'n/a';
}

function summarize(results) {
  const groups = new Map();
  for (const result of results) {
    const key = `${result.arm}/${result.mode}`;
    const group = groups.get(key) || { key, runs: [] };
    group.runs.push(result);
    groups.set(key, group);
  }
  for (const group of groups.values()) {
    const runs = group.runs;
    const adopted = runs.filter((run) => run.codegraphCalls > 0).length;
    const answered = runs.filter((run) => run.answerAvailable).length;
    const settled = runs.filter((run) => run.exitCode === 0 && !run.timedOut).length;
    const sufficient = runs.filter((run) => (
      run.codegraphCalls > 0
      && run.nativeInvestigationCalls === 0
      && run.blockedNativeAttempts === 0
      && !run.timedOut
    )).length;
    const cgCalls = runs.reduce((sum, run) => sum + run.codegraphCalls, 0);
    const nativeCalls = runs.reduce((sum, run) => sum + run.nativeInvestigationCalls, 0);
    const blockedNative = runs.reduce((sum, run) => sum + run.blockedNativeAttempts, 0);
    const matched = runs.reduce((sum, run) => sum + run.answerQuality.matched, 0);
    const required = runs.reduce((sum, run) => sum + run.answerQuality.total, 0);
    const payload = runs.reduce((sum, run) => sum + run.codegraphPayloadChars, 0);
    console.log(`\n${group.key}`);
    console.log(`  CodeGraph adoption: ${adopted}/${runs.length} (${percent(adopted, runs.length)})`);
    console.log(`  CodeGraph-only sufficiency: ${sufficient}/${runs.length} (${percent(sufficient, runs.length)})`);
    console.log(`  Primary investigation share: ${cgCalls}/${cgCalls + nativeCalls + blockedNative} (${percent(cgCalls, cgCalls + nativeCalls + blockedNative)})`);
    console.log(`  Process settled: ${settled}/${runs.length}; answer available: ${answered}/${runs.length}; required-fact coverage: ${matched}/${required} (${percent(matched, required)})`);
    console.log(`  Tool usage: ${cgCalls} CodeGraph calls, ${nativeCalls} recorded native calls, ${blockedNative} policy-blocked native attempts, ${payload} CodeGraph response chars`);
  }
}

console.log(`Codex adoption evaluation: ${targetRoot}`);
console.log(`Cases: ${testCases.length} (offset ${offset}); arms: ${arms.join(', ')}; modes: ${modes.join(', ')}; timeout: ${timeoutMs}ms; concurrency: ${concurrency}`);
console.log('Metrics: adoption = at least one CodeGraph call; sufficiency = a settled task using CG with no native discovery request; primary share counts both recorded and policy-blocked native discovery attempts.');
if (resultsFile) {
  mkdirSync(dirname(resultsFile), { recursive: true });
  writeFileSync(resultsFile, `${JSON.stringify({
    type: 'metadata',
    startedAt: new Date().toISOString(),
    targetRoot,
    arms,
    modes,
    caseIds: testCases.map((testCase) => testCase.id),
    timeoutMs,
    concurrency,
  })}\n`);
  console.log(`Incremental result log: ${resultsFile}`);
}

if (dryRun) {
  for (const testCase of testCases) console.log(`  ${testCase.id}: ${testCase.category}`);
  process.exit(0);
}

const jobs = [];
for (const arm of arms) {
  for (const mode of modes) {
    for (const testCase of testCases) {
      jobs.push({ arm, mode, testCase });
    }
  }
}
const results = [];
let nextJob = 0;
async function worker() {
  while (true) {
    const jobIndex = nextJob++;
    const job = jobs[jobIndex];
    if (!job) return;
    process.stdout.write(`Running ${job.arm}/${job.mode}: ${job.testCase.id} ... `);
    const result = await runOne(job.arm, job.mode, job.testCase);
    const recorded = { ...result, order: jobIndex };
    results.push(recorded);
    if (resultsFile) appendFileSync(resultsFile, `${JSON.stringify(recorded)}\n`);
    console.log(`CG=${result.codegraphCalls}, native=${result.nativeInvestigationCalls}+${result.blockedNativeAttempts} blocked, facts=${result.answerQuality.matched}/${result.answerQuality.total}, exit=${result.exitCode}${result.timedOut ? ' (timeout)' : ''}`);
  }
}
await Promise.all(Array.from({ length: Math.min(concurrency, jobs.length) }, worker));
results.sort((a, b) => a.order - b.order).forEach((result) => { delete result.order; });

summarize(results);
console.log('\nMachine-readable results:');
console.log(JSON.stringify(results));
