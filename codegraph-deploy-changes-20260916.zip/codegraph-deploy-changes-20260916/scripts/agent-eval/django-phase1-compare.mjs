#!/usr/bin/env node
/**
 * Compare an installed CodeGraph baseline with this checkout's built CLI on a
 * pre-indexed Django checkout. This is intentionally a deterministic tool
 * evaluation: it measures tool payloads and locator/read-plan coverage, not a
 * model's prose answer.
 *
 * Usage:
 *   node scripts/agent-eval/django-phase1-compare.mjs <django-root> [--strict]
 *
 * Optional environment variables:
 *   CODEGRAPH_BASELINE_BIN  Absolute path to the installed baseline CLI.
 *   CODEGRAPH_LOCAL_BIN     Node executable used for the local dist CLI.
 */
import { readFileSync, existsSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const thisDir = dirname(fileURLToPath(import.meta.url));
const repoRoot = resolve(thisDir, '..', '..');
const casesPath = join(thisDir, 'django-phase1-cases.json');
const localCli = join(repoRoot, 'dist', 'bin', 'codegraph.js');
const args = process.argv.slice(2);
const strict = args.includes('--strict');
const targetArg = args.find((arg) => arg !== '--strict');

if (!targetArg) {
  console.error('Usage: node scripts/agent-eval/django-phase1-compare.mjs <django-root> [--strict]');
  process.exit(2);
}

const targetRoot = resolve(targetArg);
const windowsNpmShim = join(
  process.env.APPDATA || '',
  'npm',
  'node_modules',
  '@colbymchenry',
  'codegraph',
  'npm-shim.js',
);
// Node cannot spawn a .cmd file directly. On Windows the global npm launcher
// delegates to this JS shim, so invoke that exact baseline without a shell.
const baselineBin = process.env.CODEGRAPH_BASELINE_BIN || (
  process.platform === 'win32' ? process.execPath : 'codegraph'
);
const baselinePrefix = process.env.CODEGRAPH_BASELINE_BIN
  ? []
  : (process.platform === 'win32' ? [windowsNpmShim] : []);
const localNode = process.env.CODEGRAPH_LOCAL_BIN || process.execPath;

if (!existsSync(join(targetRoot, '.codegraph'))) {
  console.error(`Django checkout is not indexed: ${join(targetRoot, '.codegraph')}`);
  process.exit(2);
}
if (!existsSync(localCli)) {
  console.error(`Local CLI is not built: ${localCli}. Run npm run build first.`);
  process.exit(2);
}
if (process.platform === 'win32' && !process.env.CODEGRAPH_BASELINE_BIN && !existsSync(windowsNpmShim)) {
  console.error(`Baseline npm shim does not exist: ${windowsNpmShim}`);
  process.exit(2);
}
if (process.env.CODEGRAPH_BASELINE_BIN && baselineBin.includes('\\') && !existsSync(baselineBin)) {
  console.error(`Baseline CLI does not exist: ${baselineBin}`);
  process.exit(2);
}

const fixture = JSON.parse(readFileSync(casesPath, 'utf8'));

function invoke(label, command, commandArgs) {
  const result = spawnSync(command, commandArgs, {
    cwd: targetRoot,
    encoding: 'utf8',
    maxBuffer: 32 * 1024 * 1024,
    windowsHide: true,
  });
  if (result.error || result.status !== 0) {
    const detail = result.error?.message || result.stderr || `exit code ${result.status}`;
    throw new Error(`${label} invocation failed: ${detail.trim()}`);
  }
  return result.stdout;
}

function count(text, pattern) {
  return (text.match(pattern) || []).length;
}

function coverage(text, expected) {
  const found = expected.filter((item) => text.includes(item));
  return { found, missed: expected.filter((item) => !found.includes(item)) };
}

function reportCoverage(label, result) {
  return `${label} ${result.found.length}/${result.found.length + result.missed.length}`;
}

function payloadMetrics(text) {
  return {
    chars: text.length,
    codeBlocks: count(text, /^```/gm) / 2,
    hasSourceDump: text.includes('**Source Code**'),
    hasReadPlan: text.includes('**Recommended reads**'),
  };
}

console.log(`Django phase-1 comparison: ${targetRoot}`);
console.log(`Baseline: ${baselineBin} ${baselinePrefix.join(' ')}`);
console.log(`Local:    ${localNode} ${localCli}`);
console.log('');

let strictFailures = 0;
const totals = {
  baselineChars: 0,
  localChars: 0,
  baselineFilesFound: 0,
  localFilesFound: 0,
  localHintsFound: 0,
  expectedFiles: 0,
  expectedHints: 0,
};

for (const testCase of fixture.cases) {
  const baseline = invoke('baseline', baselineBin, [
    ...baselinePrefix,
    'explore',
    '--path',
    'django',
    '--max-files',
    '6',
    testCase.query,
  ]);
  const local = invoke('local', localNode, [
    localCli,
    'explore',
    '--path',
    'django',
    '--max-results',
    '6',
    '--evidence',
    'none',
    testCase.query,
  ]);
  const baselineFiles = coverage(baseline, testCase.expectedFiles);
  const localFiles = coverage(local, testCase.expectedFiles);
  const localHints = coverage(local, testCase.expectedReadHints);
  const baselineMetrics = payloadMetrics(baseline);
  const localMetrics = payloadMetrics(local);
  const reduction = baselineMetrics.chars === 0
    ? 0
    : (1 - localMetrics.chars / baselineMetrics.chars) * 100;
  const localPass = localFiles.missed.length === 0 && localHints.missed.length === 0;

  totals.baselineChars += baselineMetrics.chars;
  totals.localChars += localMetrics.chars;
  totals.baselineFilesFound += baselineFiles.found.length;
  totals.localFilesFound += localFiles.found.length;
  totals.localHintsFound += localHints.found.length;
  totals.expectedFiles += testCase.expectedFiles.length;
  totals.expectedHints += testCase.expectedReadHints.length;
  if (!localPass) strictFailures += 1;

  console.log(`[${localPass ? 'PASS' : 'GAP'}] ${testCase.id} — ${testCase.title}`);
  console.log(`  ground-truth files: ${reportCoverage('baseline', baselineFiles)}, ${reportCoverage('local', localFiles)}`);
  console.log(`  local read hints: ${reportCoverage('matched', localHints)}`);
  console.log(`  payload: baseline ${baselineMetrics.chars} chars / ${baselineMetrics.codeBlocks} code blocks; local ${localMetrics.chars} chars / ${localMetrics.codeBlocks} code blocks; reduction ${reduction.toFixed(1)}%`);
  console.log(`  contract: local source dump=${localMetrics.hasSourceDump}, read plan=${localMetrics.hasReadPlan}`);
  if (localFiles.missed.length) console.log(`  missing files: ${localFiles.missed.join(', ')}`);
  if (localHints.missed.length) console.log(`  missing read hints: ${localHints.missed.join(', ')}`);
  console.log('');
}

const totalReduction = totals.baselineChars === 0
  ? 0
  : (1 - totals.localChars / totals.baselineChars) * 100;
console.log('Summary');
console.log(`  payload: ${totals.baselineChars} -> ${totals.localChars} chars (${totalReduction.toFixed(1)}% reduction)`);
console.log(`  expected file coverage: baseline ${totals.baselineFilesFound}/${totals.expectedFiles}; local ${totals.localFilesFound}/${totals.expectedFiles}`);
console.log(`  local read-hint coverage: ${totals.localHintsFound}/${totals.expectedHints}`);
console.log(`  strict status: ${strictFailures === 0 ? 'PASS' : `${strictFailures} case(s) still have locator/read-plan gaps`}`);

if (strict && strictFailures > 0) process.exit(1);
