# CodeGraph Explore 第一阶段优化方案

**阶段定位：** 代码检索优先、非代码检索保持原生、暂不扩展实验框架  
**主要场景：** Claude Code + CodeGraph + DeepSWE/SWE-bench  
**核心目标：** 让 `codegraph_explore` 成为代码定位的首选工具，替代大部分面向代码的 Grep/Glob，同时避免大响应和重复读取造成 token 增长。

---

## 1. 本阶段的取舍

第一阶段主动缩小范围，只处理最有可能快速产生收益的部分。

### 1.1 本阶段要做

1. 优化 CodeGraph 对代码文件、代码符号、调用关系和影响范围的定位能力；
2. 提高 Claude Code 在代码探索阶段对 `codegraph_explore` 的自然采用率；
3. 尽可能替代用于代码定位的 Glob、Grep 和源码搜索型 Bash；
4. 将 Explore 默认响应从“大量源码上下文”改为“结构化定位结果 + 精确读取计划”；
5. 减少 Explore 之后对相同文件、符号和范围的重复搜索；
6. 保持 Read、Edit、测试和运行时调试的正常工作流。

### 1.2 本阶段明确不做

- 不索引 Markdown、RST、TXT、AsciiDoc 等非代码文档；
- 不尝试用 CodeGraph 替代针对非代码文件的 Glob、Grep、Read；
- 不建设统一的文档检索、向量检索或文档知识图谱；
- 不修改 DeepSWE 或 SWE-bench 的标准评分方式；
- 不在本方案中展开重复次数、统计检验、任务抽样和评测 harness 细节；
- 不要求 CodeGraph 替代精确 Read、Edit、Bash、编译器和测试工具；
- 不以“CodeGraph 调用次数越多越好”为目标。

### 1.3 明确的工具边界

```text
代码定位、符号搜索、调用关系、影响范围
                    → CodeGraph 优先

README、设计文档、说明文字、未索引配置
                    → Glob / Grep / Read

已知文件的精确内容、准备编辑、编辑后确认
                    → Read

运行、测试、日志、编译错误和环境检查
                    → Bash / Test 工具
```

这不是过渡期的缺陷，而是第一阶段有意保留的职责分工。CodeGraph 的工具说明必须诚实表达该边界，不能用“不要使用 Grep/Read”这样的绝对规则阻止非代码检索。

---

## 2. 产品定位

第一阶段建议将 `codegraph_explore` 定位为：

> **面向代码的统一定位与结构检索入口。它负责找出相关文件、符号、调用路径、实现与测试，并告诉 agent 下一步应该读取或修改哪些精确范围。**

它不是完整源码阅读器，也不是整个仓库所有文件类型的搜索引擎。

理想工作流为：

```text
issue / 错误文本 / 文件线索 / 符号 / 自然语言问题
                         ↓
               codegraph_explore
       候选文件 + 符号 + 关系 + 行范围
       置信度 + 未解析项 + 推荐读取范围
                         ↓
                  精确 Read
                         ↓
                 Edit / Test / Debug
```

目标不是消灭 Read，而是让 Read 从“探索性阅读多个文件”变成“确认性读取少量精确范围”。

---

## 3. Claude Code 的路由规则

### 3.1 应优先调用 CodeGraph

遇到以下情况时，Claude Code 应首先使用 `codegraph_explore`：

- 不知道实现位于哪个代码文件；
- 需要查找类、函数、方法、常量或接口定义；
- 需要查找代码中的引用、调用者、被调用者或实现类；
- 需要理解跨文件调用链、回调、动态分派或框架入口；
- 需要从自然语言需求定位实现模块和相关测试；
- 需要从异常文本、函数名或代码 literal 定位源码；
- 需要判断修改某个符号可能影响哪些代码和测试；
- 原本准备对代码目录执行 Glob、Grep 或源码搜索型 Bash。

### 3.2 应直接使用原生工具

以下情况不需要先调用 CodeGraph：

- 查询目标明确是 `.md`、`.rst`、`.txt`、`.adoc` 等说明文档；
- 查询目标是 CodeGraph 未索引的 JSON、YAML、TOML、INI、XML 或其他配置/规格文件；
- 已知准确文件和行范围，只需查看当前内容；
- 准备编辑前需要完整确认局部源码；
- 文件刚被修改，需要确认最新磁盘内容；
- 需要搜索运行日志、测试输出、构建产物或生成文件；
- CodeGraph 明确返回低置信度、未索引或未覆盖。

### 3.3 混合问题

一个任务可能同时涉及代码和文档，例如“按照 README 描述实现新的认证流程”。此时应并行保留两条证据路径：

```text
README 中的行为要求       → Read/Grep
认证流程的实现与调用关系   → CodeGraph
```

不能因为任务包含文档就完全放弃 CodeGraph，也不能因为仓库已建立代码图就忽略文档。

---

## 4. Explore 需要补齐的代码检索能力

仅修改提示词不足以替代 Glob/Grep。Explore 必须在代码域内覆盖原生定位工具的主要用途。

### 4.1 文件与路径定位

支持并正确排序：

- basename：`resolver.py`、`auth.ts`；
- 部分路径：`middleware/auth`；
- glob-like pattern：`**/*resolver*.py`；
- 目录范围：`src/auth/**`；
- 扩展名和语言；
- source/test/generated 分类；
- 同名文件消歧；
- 文件名拼写纠正和模糊匹配。

该能力直接替代针对代码文件的多数 Glob。

### 4.2 符号定位

支持：

- 精确符号和 qualified symbol；
- 定义、引用、调用者和被调用者；
- interface/trait 的实现；
- override、继承和组合关系；
- 同名符号消歧；
- 拼写错误和近似名称；
- 文件路径与符号组合查询。

### 4.3 代码 literal 与错误文本

符号图不能覆盖所有 Grep 场景。第一阶段应增加仅针对已索引代码文件的 exact/literal search：

- 字符串常量；
- 错误消息；
- feature flag；
- route/path；
- 配置 key 在代码中的使用；
- 注释或 docstring 中的关键文字；
- 测试名称和断言文本。

结果需要映射回所在符号、文件和行范围，再与结构关系共同排序。这样才是真正的“代码域 Grep parity”。

### 4.4 自然语言查询

Explore 应从自然语言中抽取：

- 可能的模块或领域词；
- 动作和数据对象；
- 错误现象；
- 代码标识符和路径片段；
- 入口、转换过程和预期终点；
- 实现与测试意图。

低置信度时返回多个短候选和未解析概念，不应通过扩大源码输出掩盖不确定性。

### 4.5 结构关系

保留 CodeGraph 相对 Grep 的主要优势：

- 跨文件调用路径；
- callback、observer、handler registration；
- interface/trait 多实现；
- framework dispatch；
- blast radius；
- 相关测试与实现的连接关系。

结构关系应服务于定位和决策，不应重复打印为 Flow、Relationships 和多个完整源码块。

---

## 5. 返回结果设计

### 5.1 保持单一工具

继续只向模型暴露一个 `codegraph_explore`，由内部 query planner 自动判断模式，避免增加工具选择负担。

建议参数：

```json
{
  "query": "where is request authentication performed",
  "mode": "auto",
  "scope": ["src/**", "tests/**"],
  "maxResults": 5,
  "evidence": "none"
}
```

- `mode`：`auto | locate | flow | impact`；
- `scope`：可选代码路径约束；
- `maxResults`：候选数量上限；
- `evidence`：`none | snippet`，默认 `none`。

第一阶段不建议增加多个 MCP 工具，也不建议让模型手工选择复杂检索算法。

### 5.2 默认采用 locator-first

默认响应不返回完整文件或完整函数体，只返回：

1. 查询理解；
2. 前几个候选文件；
3. 候选符号及行范围；
4. 主结构路径；
5. 相关实现或测试；
6. 置信度和未解析概念；
7. 推荐 Read 范围；
8. 索引/stale/truncation 状态。

这与第一阶段“把 CodeGraph 当作定位工具”的定位一致，也能直接解决大块源码进入上下文后又被 Read 一次的问题。

### 5.3 证据片段只按需返回

`evidence=snippet` 只返回用于解释排序的短片段，例如：

- 符号签名；
- 命中 literal 的前后少量行；
- 调用边附近的关键语句；
- interface 与实现的声明；
- 错误文本或测试断言所在位置。

不返回整个文件，也不为了填满预算而增加源码。需要修改时，Claude Code 使用推荐范围执行 Read。

### 5.4 推荐响应结构

```text
Query interpretation
  intent: locate
  concepts: authentication, incoming request
  confidence: 0.82

Primary candidates
  1. src/http/auth.ts:42-96
     symbol: authenticateRequest
     reason: called by request middleware; matches authentication concepts
  2. src/http/middleware.ts:18-51
     symbol: handleRequest
     reason: request entry point; calls authenticateRequest

Main flow
  handleRequest → authenticateRequest → verifyToken

Related tests
  tests/http/auth.test.ts:30-118

Recommended reads
  Read src/http/middleware.ts:18-51
  Read src/http/auth.ts:42-96
  Read tests/http/auth.test.ts:30-118

Coverage
  resolved: authentication, request entry, token verification
  unresolved: session fallback
  indexed-code-only: true
```

### 5.5 必须明确完整性

Explore 不能只说“找到 8 个结果”，还要表达：

- 查询中的哪些概念已解析；
- 哪些概念未解析；
- 主调用路径是否闭合；
- 是否有候选因预算未展示；
- 是否只覆盖已索引代码；
- 是否存在 stale 或磁盘漂移；
- 推荐继续 Explore、精确 Read，还是回退原生搜索。

### 5.6 去重原则

- 同一调用内，Flow 已出现的关系不再在 Relationships 完整重复；
- 同一文件只出现一次，符号和范围归并展示；
- 多个候选重叠行范围应合并；
- 后续 Explore 不重复返回相同结构包，除非查询范围或文件状态发生变化；
- 去重必须绑定当前 session/context，不能让新会话收到无法访问的“之前已经发送”引用。

---

## 6. 提高 Explore 使用率

使用率低通常不是单一提示词问题，而是工具可见性、能力完整性、响应成本和结果可信度共同造成的。

### 6.1 重写工具描述

建议使用简短、任务导向的描述：

> Search and locate indexed code before using Glob/Grep for source discovery. Returns ranked files, symbols, call paths and exact Read ranges. Use native Glob/Grep/Read for non-code documents, unindexed files, logs and exact post-edit verification.

描述需要同时说明优势和边界。过长的宣传、绝对成本承诺和“禁止使用其他工具”的措辞会降低信任。

### 6.2 项目规则

建议在 Claude Code 项目规则中使用条件化指令：

```text
When locating or understanding indexed source code, use codegraph_explore
before Glob/Grep. Use the returned paths and ranges for targeted Read/Edit.

For Markdown, documentation, unindexed config, logs, generated files, or
post-edit verification, use native Glob/Grep/Read directly.

Do not call CodeGraph for a file and line range already known unless structural
context or impact analysis is needed.
```

规则的目标是改变代码定位入口，而不是阻断 Claude Code 的自主判断。

### 6.3 保证工具可见与可用

- Claude Code 启动时确认 MCP 工具成功注册；
- 项目存在有效 `.codegraph/` 时才加载规则；
- 索引不存在、失效或失败时不要继续提示 agent 使用；
- 工具名和 description 在主 agent、子 agent 中保持一致；
- 首次调用延迟和失败率应足够低，避免模型在一次失败后回到原生工具；
- Native 对照环境必须同时移除 MCP、CLI 和 CodeGraph 规则，避免隐藏污染。

### 6.4 采用软路由，不做硬拦截

可在 agent 准备针对代码连续执行多次 Glob/Grep 时提示一次：

```text
This appears to be indexed source-code discovery. Consider one
codegraph_explore query for ranked files, symbols and call paths.
```

不 deny 原生工具，不对文档搜索触发提示，同一阶段只提示一次。

### 6.5 用结果质量维持采用

模型只有在以下条件持续成立时才会重复使用 Explore：

- 第一批候选通常包含真正相关代码；
- 行范围可以直接用于 Read/Edit；
- 低置信度时不伪装成确定结果；
- 不返回大量无关源码；
- 不要求模型再 Grep 一次验证；
- 未索引或 stale 时给出明确回退；
- 下一步行动清晰且成本可预期。

因此，提高使用率的优先顺序应是“能力充分 → 输出轻量 → 结果可信 → 提示显著”，而不是先增加强制规则。

---

## 7. Token 优化策略

第一阶段 token 优化围绕四个来源展开。

### 7.1 降低单次 Explore 响应

- 默认 `evidence=none`；
- 限制主要候选数量；
- 只展示主路径和少量关键分支；
- blast radius 只在 impact/edit 意图下展开；
- 不返回完整源码；
- 不重复 Flow、Relationships 和候选说明。

### 7.2 降低后续重复检索

- 推荐精确 Read 范围；
- 输出 candidate reason，减少验证性 Grep；
- 显式列出 alternatives，减少相近 query 重试；
- 返回 unresolved，帮助下一次查询只补缺口；
- 记录本 session 已返回的文件、符号和范围。

### 7.3 避免错误采用

以下情况调用 Explore 反而可能增加 token，应主动跳过：

- issue 已给出准确文件和行号；
- 只需读取一个很短的已知文件；
- 明确搜索 README 或文档；
- 已进入反复修改与测试阶段，只需确认当前源码；
- 查询只针对测试日志和运行时输出。

### 7.4 关注总任务成本

不能只统计 Explore 返回 token。需要关注完整轨迹中：

```text
Explore 输出
+ 后续 Read
+ 后续 Grep/Glob
+ 因上下文常驻导致的后续输入 token
+ 重复 Explore
```

第一阶段的成功不是“单次响应更短”，而是标准任务流程中的总 token/cost 不上升，并且在正确率不下降的前提下减少代码定位成本。

---

## 8. 实现优先级

### P0：收敛返回协议

1. 默认 locator-first，不返回完整源码；
2. 返回候选文件、符号、行范围和推荐 Read；
3. 合并 Flow/Relationships 重复信息；
4. 增加 confidence、resolved、unresolved、truncated；
5. 增加 `indexed-code-only` 和明确原生工具回退；
6. 修正 stale、pending 和磁盘漂移说明；
7. 为响应设置与任务意图相关的预算。

这是最优先的改动，因为它可以直接验证当前 token 增长是否主要来自 Explore 大响应及后续重复 Read。

### P1：补齐代码域 Glob/Grep parity

1. 已索引代码文件的路径与文件名查询；
2. qualified symbol 和同名消歧；
3. typo/fuzzy symbol；
4. 代码 literal/error text 搜索；
5. 自然语言实体抽取；
6. source/test/generated 分类；
7. 查询意图感知排序；
8. alternative candidates。

这是降低 Explore 后 Grep/Glob fallback 的基础。

### P2：提高 Claude Code 采用率

1. 缩短 MCP tool description；
2. 重写 CodeGraph 项目规则；
3. 明确代码与非代码路由边界；
4. 检查主 agent 和子 agent 的工具可见性；
5. 可选一次性软路由提示；
6. 移除绝对化的“不要 Read/Grep”和成本承诺。

### P3：上下文和可观测性

1. session/context-aware 去重；
2. 记录 Explore 响应大小、候选和范围；
3. 记录后续 Read/Grep/Glob fallback；
4. 记录 returned-file reread 和范围重叠；
5. 区分定位、实现和调试阶段的采用；
6. 保留本地诊断日志，不上传源码与查询。

---

## 9. 建议的代码改动范围

| 模块 | 第一阶段修改 |
|---|---|
| `src/mcp/tools.ts` | locator-first renderer、模式/预算、结构化返回、推荐 Read、完整性字段 |
| `src/mcp/server-instructions.ts` | 代码优先、非代码原生回退、移除绝对化提示 |
| `src/mcp/explore-session-state.ts` | session/context 状态、已返回符号和范围 |
| `src/mcp/explore-dedup.ts` | 同调用与跨调用安全去重 |
| file/search 层 | 已索引代码路径、basename、glob-like 和 literal 查询 |
| symbol/search 层 | qualified、fuzzy、自然语言实体和消歧 |
| ranking 层 | intent、路径、符号、关系、测试相关性联合排序 |
| installer/Claude target | 条件化项目规则、工具注册和启动自检 |
| 本地 diagnostics | response、fallback、overlap、phase adoption 事件 |

建议将当前 Explore 大方法拆分为：

```text
parseQuery
→ classifyCodeIntent
→ retrieveCodeCandidates
→ buildStructuralEvidence
→ rankCandidates
→ assessCoverage
→ planReadRanges
→ renderCompactResult
```

非代码文档路径只参与“识别并回退”，不进入第一阶段索引与排序实现。

---

## 10. 验证原则

本阶段不自定义新的 benchmark 评分体系。实现完成后直接按照 DeepSWE 或 SWE-bench 的标准运行与 verifier 流程比较 Native、Current 和 Optimized 配置即可。

需要保留的判断原则只有：

- 标准 verifier 的任务通过率不能下降；
- 代码定位阶段的 Explore 采用率应提高；
- 针对代码的 Grep/Glob 和源码搜索型 Bash 应减少；
- Explore 后重复 Grep、重复 Read 和重复范围应减少；
- 首次有效 Edit 前的定位成本应降低；
- 完整任务 token、cost 和耗时不能因为增加一个工具而系统性恶化；
- 非代码文档任务仍能正常使用原生工具，不能被 CodeGraph 规则抑制；
- Current 与 Optimized 的差异应只来自明确记录的实现和规则变化。

DeepSWE 使用 Harbor/Pier 标准输出，SWE-bench 使用其标准 harness 和 grader。具体抽样、重复次数、置信区间和统计方法留到后续实验设计阶段，不阻塞当前优化实现。

---

## 11. 第一阶段 MVP

如果进一步压缩范围，建议首先完成以下 MVP：

1. 保留一个 `codegraph_explore`；
2. 默认只返回结构化定位信息，不返回完整源码；
3. 返回前几个候选文件、符号和精确行范围；
4. 返回主调用路径和相关测试；
5. 返回 recommended reads、confidence 和 unresolved；
6. 支持已索引代码的 basename/path、symbol 和 literal 查询；
7. 明确标注 `indexed-code-only`；
8. 对文档和未索引文件明确推荐 Glob/Grep/Read；
9. 重写 Claude Code 工具描述和项目规则；
10. 记录 Explore 后的 Grep/Glob/Read 与范围重叠。

MVP 暂不实现：

- document index；
- embedding/vector search；
- 非代码文件统一检索；
- 硬路由或禁止原生工具；
- 多个新的 MCP 工具；
- 复杂实验平台和自定义评分器。

---

## 12. 最终建议

第一阶段最合理的策略不是让 CodeGraph 接管 Claude Code 的全部检索，而是先建立一个清晰且可信的分工：

```text
CodeGraph：代码在哪里、符号如何连接、下一步读哪里
Read：     查看准备修改的精确源码
Grep/Glob：非代码文档、未索引文件和必要的原生回退
Bash/Test：运行时事实和行为验证
```

实现顺序应为：

1. 先把 Explore 的默认大响应改成轻量定位结果；
2. 再补齐代码文件、符号、literal 和自然语言检索；
3. 然后优化 Claude Code 的工具描述、规则和可见性；
4. 最后根据标准 DeepSWE/SWE-bench 运行结果决定是否进入文档检索和更复杂实验设计阶段。

这一阶段的核心发布判断是：

> **CodeGraph 是否真正替代了代码定位过程中的原生搜索，并在不损害任务正确率的情况下减少完整任务的检索负担。**
