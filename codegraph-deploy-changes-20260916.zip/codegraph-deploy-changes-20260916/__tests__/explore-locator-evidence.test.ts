/**
 * Locator-first evidence must keep a concrete implementation actionable when
 * the agent cannot immediately use a native Read call.
 */
import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import CodeGraph from '../src/index';
import { ToolHandler } from '../src/mcp/tools';

describe('codegraph_explore — locator evidence', () => {
  let testDir: string;
  let cg: CodeGraph;
  let handler: ToolHandler;

  beforeEach(async () => {
    testDir = fs.mkdtempSync(path.join(os.tmpdir(), 'codegraph-locator-evidence-'));
    const src = path.join(testDir, 'src');
    fs.mkdirSync(src, { recursive: true });
    fs.writeFileSync(path.join(src, 'backends.ts'), `
export class BaseBackend {
  authenticate(request: unknown) {
    return null;
  }
}

export class ModelBackend {
  authenticate(request: unknown, username?: string) {
    if (!username) {
      return null;
    }
    const user = { username };
    if (user.username === 'disabled') {
      return null;
    }
    return user;
  }
}

export function invalidLoginError() {
  return 'Please enter a correct %(username)s and password. Note that both fields may be case-sensitive.';
}
`);
    fs.writeFileSync(path.join(src, 'backends.test.ts'), `
import { ModelBackend } from './backends';

export function modelBackendRegressionTest() {
  return new ModelBackend().authenticate({}, 'test') !== null;
}
`);
    cg = CodeGraph.initSync(testDir, { config: { include: ['**/*.ts'], exclude: [] } });
    await cg.indexAll();
    handler = new ToolHandler(cg);
  });

  afterEach(() => {
    if (cg) cg.destroy();
    if (fs.existsSync(testDir)) fs.rmSync(testDir, { recursive: true, force: true });
  });

  it('recommends the concrete implementation before a thin base declaration', async () => {
    const res = await handler.execute('codegraph_explore', {
      query: 'authenticate', evidence: 'snippet', maxResults: 1,
    });
    const text = res.content[0].text;

    expect(text).toMatch(/\*\*Recommended reads\*\*[\s\S]*backends\.ts:9-18/);
    expect(text).toContain('**Evidence snippets**');
    // The evidence shows the decision and its action, rather than only the
    // declaration line, so a tracing agent has useful context without Read.
    expect(text).toContain('if (!username)');
    expect(text).toContain('return user;');
    expect(text).not.toContain('**Source Code**');
  });

  it('treats a qualified member as one exact identity', async () => {
    const res = await handler.execute('codegraph_explore', {
      query: 'ModelBackend.authenticate', maxResults: 1,
    });
    const text = res.content[0].text;

    // `authenticate` exists on both classes. Dot notation must resolve to the
    // ModelBackend member rather than relying on generic same-name ranking.
    expect(text).toMatch(/\*\*Primary candidates\*\*[\s\S]*backends\.ts:9-18/);
    expect(text).toMatch(/\*\*Recommended reads\*\*[\s\S]*backends\.ts:9-18.*named match/);
  });

  it('surfaces a close explicit identifier typo above broad lexical matches', async () => {
    const res = await handler.execute('codegraph_explore', {
      query: 'ModelBacken', maxResults: 1,
    });
    const text = res.content[0].text;

    expect(text).toMatch(/\*\*Primary candidates\*\*[\s\S]*backends\.ts:8-19/);
    expect(text).toMatch(/\*\*Recommended reads\*\*[\s\S]*backends\.ts:8-19.*close symbol spelling/);
  });

  it('maps an exact source literal back to its owning symbol and read range', async () => {
    const res = await handler.execute('codegraph_explore', {
      query: 'Please enter a correct username and password', maxResults: 1,
    });
    const text = res.content[0].text;

    expect(text).toContain('**Literal matches**');
    expect(text).toMatch(/backends\.ts:22.*invalidLoginError/);
    expect(text).toMatch(/\*\*Recommended reads\*\*[\s\S]*backends\.ts:21-23.*literal match/);
  });

  it('labels indexed code candidates by source or test role', async () => {
    const res = await handler.execute('codegraph_explore', {
      query: 'backends.test.ts', maxResults: 1,
    });
    const text = res.content[0].text;

    expect(text).toMatch(/src\/backends\.test\.ts`:\d+-\d+ \[test\]/);
  });

  it('prioritizes a related test when the query asks for tests', async () => {
    const res = await handler.execute('codegraph_explore', {
      query: 'tests for ModelBackend', maxResults: 1,
    });
    const text = res.content[0].text;

    expect(text).toMatch(/\*\*Primary candidates\*\*[\s\S]*src\/backends\.test\.ts`:\d+-\d+ \[test\]/);
  });

  it('labels a close filename spelling as a path correction', async () => {
    const res = await handler.execute('codegraph_explore', {
      query: 'backend.ts', maxResults: 1,
    });
    const text = res.content[0].text;

    expect(text).toMatch(/src\/backends\.ts`:\d+-\d+ \[source\]/);
    expect(text).toContain('close spelling of path');
    expect(text).toContain('close path spelling');
  });
});
