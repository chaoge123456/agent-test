# CodeGraph deployment replacement bundle

- Baseline commit: `3ed73bc127323e63153bf6ec8354afa82ce36aaf`
- Source commit: `07d9482b89d7450823fafcc9e0373a18c6562493`
- Scope: every changed code file and code-associated test/evaluation input from
  the baseline to the source commit. Generated evaluation results and logs are
  intentionally excluded.

Copy this directory's contents into the root of an equivalent CodeGraph source
checkout, preserving paths and replacing matching files:

```text
__tests__/explore-locator-evidence.test.ts
__tests__/query-paths.test.ts
package.json
scripts/agent-eval/django-codex-adoption-cases.json
scripts/agent-eval/django-codex-adoption-eval.mjs
scripts/agent-eval/django-phase1-cases.json
scripts/agent-eval/django-phase1-compare.mjs
src/bin/codegraph.ts
src/context/index.ts
src/db/queries.ts
src/index.ts
src/installer/instructions-template.ts
src/mcp/server-instructions.ts
src/mcp/tools.ts
src/search/query-paths.ts
```

The following changed files are generated evaluation artifacts rather than
source code, so they are not included: files under
`scripts/agent-eval/results/`.

After replacement, run the target checkout's dependency install and build steps
before deployment.
