/**
 * Server-level instructions emitted in the MCP `initialize` response.
 *
 * Keep this concise: it is injected into every MCP session. The default MCP
 * surface exposes only `codegraph_explore`; the other internal tools remain
 * available only when an installation explicitly enables them.
 */
export const SERVER_INSTRUCTIONS = `# CodeGraph — indexed code locator

Use \`codegraph_explore\` first when locating or understanding indexed source
code: symbols, implementation files, references, call paths, dispatch, tests,
or change impact. It returns ranked files, symbols, exact Read ranges, and
structural evidence. Its default is intentionally locator-first, not a source
reader.

Use the returned paths and ranges for targeted Read/Edit. With
\`evidence: "snippet"\`, the shown current-source excerpts are already read:
do not Read those exact lines again. Use snippets to confirm a literal hit or
ranking decision; when understanding a candidate implementation, following a
path, or preparing an edit, Read the recommended exact range. Use a focused
follow-up Explore only when its coverage explicitly identifies an unresolved
symbol, path, or impact question.

Use native Glob/Grep/Read directly for Markdown and other documentation,
unindexed configuration, logs, generated artifacts, a known file/line range,
and post-edit verification. Do not call CodeGraph just to re-read current disk
content.

For mixed tasks, keep both evidence paths: native tools for the document or
configuration requirement, CodeGraph for the related code structure. A stale,
pending, or unindexed result is a signal to fall back to native tools for the
affected files.

CodeGraph indexes code only and does not replace compilers, tests, debuggers,
or runtime logs. If no \`.codegraph/\` index exists, use built-in tools; indexing
is the project owner's decision.`;

/**
 * Instructions variant sent when the server's own root has no CodeGraph index.
 * Tools remain visible because a caller can pass `projectPath` for an indexed
 * subproject.
 */
export const SERVER_INSTRUCTIONS_NO_ROOT_INDEX = `# CodeGraph — per-project indexed code locator

This server has no default \`.codegraph/\` index. To query an indexed
sub-project, call \`codegraph_explore\` with its \`projectPath\`. The locator
returns code files, symbols, structural paths, and exact Read ranges.

For a project without an index, use built-in Glob/Grep/Read. Do not initialize
an index unless the project owner asks; indexing is their decision.`;
