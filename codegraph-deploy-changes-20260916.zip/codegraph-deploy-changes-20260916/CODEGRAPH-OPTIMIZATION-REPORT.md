# CodeGraph Explore 第一阶段优化：设计、实现与验证说明

## 1. 范围和结论摘要

本文对照最初的《CodeGraph Explore 第一阶段优化方案》与实际源码，说明本次优化的目标、
实现流程、能力边界和验证结论。

改动起点是 GitHub 原始基线提交 `3ed73bc127323e63153bf6ec8354afa82ce36aaf`，终点是
当前提交 `07d9482b89d7450823fafcc9e0373a18c6562493`。10 个提交依次完成紧凑定位协议、
读取锚点修正、literal 搜索、路径/glob 搜索、限定符号、相近拼写、结构相关测试排序和
MCP/安装说明更新。

本次的核心变化是将 `codegraph_explore` 的默认职责从“展开已经找到的大段源码”改为
“**定位相关代码，并给出带理由的精确 Read 计划**”。目标并非禁止 `Read`、`Grep`、
`Glob` 或追求 CodeGraph 调用次数，而是在正确率不下降的条件下，降低代码探索过程的总
检索成本和重复上下文。

## 2. 设计问题：为什么不能只改提示词

原始方案观察到的低效路径是：

```text
自然语言问题
  -> 对代码目录重复 Glob/Grep
  -> 打开多个候选文件确认
  -> 再靠 Grep/Read 拼出调用链
  -> 编辑前重新读同样的源码
```

早期 `explore` 已能返回图关系和源码，但默认 source-heavy 响应存在两个结构性缺口：

1. 返回的大段源码会占用上下文，编辑前却仍需读当前工作树的精确文本；
2. 如果无法处理路径、文件名、错误文本、拼写偏差、限定符号和测试关系，代理仍会回退到
   原生 Glob/Grep，工具描述再强也不会提高自然采用率。

因此第一阶段保留了如下职责边界：

| 任务 | 优先入口 |
| --- | --- |
| 不知道代码位置、找符号/调用链/影响范围 | `codegraph_explore` |
| 已知准确文件与行范围、编辑前确认当前内容 | `Read` |
| Markdown、文档、未索引配置、日志、生成物 | `Glob` / `Grep` / `Read` |
| 构建、测试、运行时事实 | Bash / Test |

衡量对象应是完整任务成本，而不是单一工具次数：

```text
Explore 输出 + 后续 Read + 后续代码 Grep/Glob + 重复 Explore
+ 上述内容常驻上下文产生的输入 token
```

## 3. 目标架构：locator-first

优化后的预期流程：

```text
issue / 错误文本 / 文件线索 / 符号 / 自然语言问题
                         |
                         v
                 codegraph_explore
    候选文件、符号、结构关系、行范围、置信度、未解析项
                         |
                         v
           Recommended reads（精确且可验证的读取计划）
                         |
                         v
                   Read -> Edit -> Test
```

Explore 回答“应该读哪里、为什么”，Read 回答“当前精确文本是什么”。后者不能被取代：索引
可能滞后于工作树，且编辑前应确认实时源码。

仍只暴露一个 `codegraph_explore` MCP 工具，新增/启用的控制参数为：

```text
mode       auto | locate | flow | impact
scope      可选代码路径 glob，如 ["src/**", "tests/**"]
maxResults 返回候选上限，默认 5
evidence   none | snippet，默认 none
```

默认响应包括查询和推断意图、置信度、`indexed-code-only` 标志、候选文件/符号/行范围、
命中理由、可用时的调用流/测试/literal、最多四项推荐 Read，以及 resolved/unresolved 覆盖
信息。`evidence="snippet"` 才返回很短的源码证据；长函数仅保留首尾。旧的 source-heavy
渲染器仅保留在 `CODEGRAPH_EXPLORE_LEGACY_SOURCE=1` 的维护对照开关之后。

## 4. 实际代码执行流程

下面的顺序对应 `src/mcp/tools.ts` 中 `handleExplore()` 的实际路径：

```text
参数校验
  -> 查询拼写规范化
  -> 原始 query 的路径提取和锁定
  -> 图上下文检索与结构候选补强
  -> 文件归组和多信号排序
  -> scope 过滤显示候选
  -> flow、literal 和精确 Read 锚点选择
  -> 紧凑 locator 输出（或内部 legacy renderer）
```

### 4.1 参数和符号写法规范化

工具先校验 `mode`、`evidence`、`scope`、`maxResults`。`scope` 限制为少量非空路径模式，
避免异常输入无界扩大搜索面。

`normalizeQuerySpelling()` 对少数语言写法进行兼容。例如 Erlang 的 `module:function/3`
转换为已有查询管线可理解的限定名样式；它避开 URL、Windows 路径及 `kind:` 等查询字段。
因此后续的文本匹配、flow 构建和排序使用相同的符号语义。

### 4.2 路径优先和代码域 Glob parity

路径提取在常规文本检索**之前**，并基于未经规范化的原始 query 执行，防止路径中的数字等
信息被误处理。`src/search/query-paths.ts` 将匹配文件标记为 `pinnedFiles`：

- 先精确路径匹配，再按路径段边界进行后缀匹配；
- 支持部分路径、无扩展名末段，例如 `middleware/auth`；
- 支持 basename 以及 `*resolver*.py` 一类 glob；无目录的 glob 会隐式尝试递归目录；
- 支持无扩展名 kebab basename，例如 `background-image-table`；
- 对带扩展名的 basename，在精确失败后进行有界编辑距离纠错，例如 `middelware.py`；
- 对明显但未解析的路径记录 `unresolved`，而不是让路径碎片成为普通检索词。

解析只针对**已索引代码文件**。模糊匹配要求相同扩展名且距离上限为 1 或 2；多个部分路径
命中返回有上限的候选，而不是直接强制代理回退 Glob。被锁定的路径会从普通匹配 query 中
移除，避免 `[id]`、`(group)` 等框架路径被拆成虚假符号词；其节点无条件进入候选子图，并
在最终排序中优先。

### 4.3 图上下文和结构补强

对剥离路径后的查询调用 `findRelevantContext()`，以相对宽松的搜索与遍历参数收集候选；
最终上下文由紧凑 renderer 控制，而不是直接输出所有节点的源代码。

之后的补强解决文本搜索无法稳定处理的结构问题：

- **显式符号种子**：将 query 中点名的符号定义放入子图，避免高频词淹没低频但关键的叶子
  实现；
- **限定名精确匹配**：`context/index.ts` 保留 `Class.method` / `Namespace::method` 整体，
  `db/queries.ts` 新增 `getNodesByQualifiedNameExact()`，不再仅分别搜索容器和成员；
- **相近符号拼写**：精确不足时提供有界模糊候选，并在输出理由中明确标为 close spelling；
- **桥接节点**：为根节点补入已入选文件中的 caller/callee，补齐两个命名节点之间的调用
  方法，同时不把无关文件拉入结果；
- **测试意图**：查询包含 test/spec 时，从顶层匹配符号的调用者中加入测试文件节点，因此
  相关测试来自实际结构关系而不是文件名猜测；
- **代码 literal**：对引号文本、错误消息、路由、断言等明确 literal 形状，在已索引且有
  语言标识的代码文件中搜索当前磁盘内容。依次尝试精确、忽略大小写、格式占位符/模板插值
  归一化后的短窗口匹配，再映射到包含命中行的最小符号。

literal 只为显式 literal-shaped query 启动，不对普通自然语言扫描全仓库，也不索引文档。
它补的是“错误消息或配置键出现在代码中、但不在符号名中”的代码域 Grep 缺口。

### 4.4 排序：明确证据优先于泛化相关度

节点按文件归组后，排序的主要层级为：

```text
query 直接点名的路径（pinned）
  > query 点名的符号/相近拼写纠正
  > 明确 test 意图下的结构相关测试
  > 同时具备结构入口/中心性和多个词命中的文件
  > 图相关性（Random Walk with Restart）
  > 词命中、低价值/生成文件惩罚、原有分数和节点数
```

关键保护包括：直接点名的叶子符号不会因图中心性低而被裁掉；只有一个共享词、但没有结构
关系的偶发文本命中会被相关性门限压低；生成、低价值目录和环境声明文件被降权但不完全
隐藏；薄的接口/基类签名不应压过具体实现。`scope` 在全局图排序之后才过滤展示结果，
所以指定 `src/**` 不会妨碍先利用全图找到调用路径。

### 4.5 精确 Read 锚点：解决“文件正确、行范围错误”

文件排序与文件内目标选择是两件事。实现刻意分离：

1. 对已进入候选的文件补齐该文件的实体节点，但不扩大候选文件集合；
2. literal 命中时，优先选择包含该行的最小符号；
3. 否则按照精确名称、限定名、主 flow、显式符号种子、词匹配和具体 callable 为节点评分；
4. 最高分节点生成 `Read file:start-end`。

这是 `6806bf4` 的关键修正。此前若直接取文件分组的第一个节点，locator 可能建议读相邻
辅助函数或整类定义；现在读取计划必须有明确的文本、符号、literal 或结构 flow 证据。

`mode=auto` 在存在 flow 时推断为 `flow`，否则为 `locate`；`impact` 会检查相关测试是否
进入锚点。confidence 是面向代理的启发式信号，不是统计学概率：显式符号、主路径、相关
测试和多词命中均会提高它。输出还会说明未解析路径、缺少 flow/测试候选及因 `maxResults`
未显示的低排名候选。

## 5. 设计提案与当前实现对照

| 提案项 | 状态 | 对应实现 |
| --- | --- | --- |
| P0：默认 locator-first、避免完整源码 | 已实现 | `tools.ts` 紧凑分支；legacy renderer 仅维护开关。 |
| P0：候选、行范围、Read 计划、覆盖信息 | 已实现 | Primary candidates、Recommended reads、Coverage。 |
| P0：按需 evidence snippet | 已实现 | `evidence=snippet`。 |
| P1：路径、basename、部分路径、glob | 已实现 | `query-paths.ts`，新增 `picomatch`。 |
| P1：无扩展名与文件名拼写纠错 | 已实现 | 扩展名去除解析和有界 basename 编辑距离。 |
| P1：qualified/fuzzy symbol | 已实现 | `context/index.ts` 与 `db/queries.ts`。 |
| P1：代码 literal / 错误文本 | 已实现 | `tools.ts` 的受控代码文件扫描。 |
| P1：测试意图排序 | 已实现 | 命中符号的测试 caller。 |
| P1：完整自然语言实体抽取/语义模型 | 部分实现 | 当前是规则、词干和图证据；未引入向量/语义索引。 |
| P2：MCP/项目规则的条件化路由 | 已实现 | `server-instructions.ts`、`installer/instructions-template.ts`。 |
| P3：compact 接入 session 去重/诊断 | 暂未实现 | 按本轮决策暂缓；紧凑分支提前返回，未接入旧路径完整跨调用记录。 |
| P3：产品运行期 adoption/fallback 遥测 | 暂未实现 | 目前只有评测脚本，不是稳定产品遥测。 |
| 文档索引、配置统一检索、硬禁原生工具 | 明确不做 | 与第一阶段边界一致。 |

## 6. 采用率：为什么修改工具说明和安装规则

算法足够好也需要让代理知道何时使用。MCP description 和安装到项目内的规则都改为条件化
表述：有 `.codegraph/` 索引时，定位或理解**代码**优先 Explore；再根据返回的路径/范围做
定向 Read/Edit。文档、未索引文件、日志和编辑后验证直接走原生工具。

这种写法刻意避免两种反效果：一是不宣称 CodeGraph 可替代已知文件的精确 Read；二是不使用
“永远不要 Grep/Read”的硬规则阻断非代码检索或调试。`server-instructions.ts` 与
`instructions-template.ts` 使用同一边界，避免 MCP 提示和项目规则互相冲突。

## 7. 文件职责

| 文件 | 改动职责 |
| --- | --- |
| `src/mcp/tools.ts` | 主请求管线、literal、结构补强、排序、locator、Read 锚点、evidence。 |
| `src/context/index.ts` | 限定引用提取与精确限定符号优先。 |
| `src/db/queries.ts` | `qualified_name` 的精确节点查询。 |
| `src/search/query-paths.ts` | 路径/basename/glob/无扩展名/模糊 basename 解析。 |
| `src/mcp/server-instructions.ts` | MCP 代码优先及非代码回退说明。 |
| `src/installer/instructions-template.ts` | 安装到目标仓库时的同等规则。 |
| `src/bin/codegraph.ts`、`src/index.ts` | CLI/导出接入。 |
| `__tests__/explore-locator-evidence.test.ts` | 保护具体实现优先于薄基类声明的锚点行为。 |
| `__tests__/query-paths.test.ts` | 路径、glob、模糊路径及边界行为。 |
| `scripts/agent-eval/` | Django 案例、会话执行器和确定性对比。 |
| `package.json` | glob 解析依赖。 |

## 8. 验证与评测的正确解读

工程层面已运行构建和定向测试；新增 locator evidence 与路径测试用于保护本次最关键的
“具体实现 + 正确 Read 行范围”行为。

保存的 Django 核心矩阵中，10 次确定性工具级查询的响应字符数从基线 245,229 降至本地
23,441，约降低 **90.4%**，预期文件命中仍为 20/21。这支持 locator-first 对**工具输出负载**
的改善。

但 4 个无提示 Codex 会话不能证明整体可用性已提升：本地版本出现更多 Explore 调用，且
复杂案例有超时或未完成；评测还阻断了原生读取，因此统计的是“尝试回退”而非正常工程
工作流。由此不能声称 CodeGraph 使用率、任务总 token、耗时或端到端成功率已全面优于
基线。

失败模式说明的共同问题是“候选文件大致正确，但证据和下一步 Read 锚点没有闭合”，不是
应为某道 Django 题硬编码。因此后续补了 literal、生命周期/具体实现锚点、结构相关测试和
拼写纠错，而没有新增 Django 专用逻辑。

## 9. 已知限制与下一阶段建议

当前限制：

1. compact locator 尚未接入会话级去重和诊断；
2. literal 是受控的当前文件扫描，不是倒排索引，超大索引下的延迟需量化；
3. 完全没有路径、符号、领域词或结构线索的开放问题，仍可能需要更强 query planner 或原生
   回退；
4. confidence 是可解释的启发式，不是校准后的统计概率。

下一阶段最值得做的是提案 P3，而不是继续针对评测题做定制：

```text
compact locator 输出
  -> 记录已交付的 file/symbol/range/fingerprint
  -> 后续 Explore 判断与既有范围的重叠
  -> 只输出新增证据，或安全地回指已交付内容
  -> 记录后续是否 Read、Grep/Glob 回退、是否重复读同一范围
```

应观测首次有效 Edit 前的定位成本、Explore 后代码搜索回退、重复范围、候选被实际 Read 的
比例、任务阶段以及完整任务的 token/耗时/通过率。先有这些通用数据，才能判断问题来自检索
质量、提示规则、会话去重还是任务特性，避免按个例硬编码。

## 10. 部署说明

同目录 `MANIFEST.md` 列出相对上述 GitHub 基线发生变化的 15 个代码、测试和评测输入文件。
按原相对路径覆盖到同基线 clone 的目标仓库后，执行依赖安装、构建与测试即可。

`scripts/agent-eval/results/` 下是历史报告和日志，未包含在部署包中；它们不是运行优化功能
所需代码，但可用于追溯本文的评测结论。
