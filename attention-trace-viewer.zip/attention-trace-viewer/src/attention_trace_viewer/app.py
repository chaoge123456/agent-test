"""Streamlit entry point for browsing standalone ATF attention traces."""

from __future__ import annotations

import html
from pathlib import Path

import numpy as np
import plotly.express as px
import streamlit as st

from .analysis import compute_attention
from .reader import TraceFormatError, TraceSession, list_sessions


def _token_ribbon(session: TraceSession, positions: list[int], scores: np.ndarray) -> str:
    maximum = float(scores.max()) if len(scores) else 0.0
    parts = []
    for position, score in zip(positions, scores, strict=True):
        strength = 0 if maximum == 0 else int(25 + 230 * float(score) / maximum)
        label = html.escape(session.label_at(position))
        parts.append(
            f'<span title="position {position}, attention {score:.4%}" '
            f'style="background:rgb(255,{255-strength},{255-strength}); '
            'border-radius:5px;padding:3px 5px;margin:2px;display:inline-block">'
            f'{position}: {label}</span>'
        )
    return "".join(parts)


def _session_summary(session: TraceSession) -> None:
    lengths = session.manifest["lengths"]
    st.subheader(session.trace_id)
    st.caption(str(session.path))
    left, middle, right = st.columns(3)
    left.metric("Prompt tokens", lengths["prompt"])
    middle.metric("Output tokens", lengths["output"])
    right.metric("Captured layers", ", ".join(map(str, session.layers)))
    st.text_area("Prompt", session.tokens.get("prompt_text", ""), height=100, disabled=True)
    st.text_area("Output", session.tokens.get("output_text", ""), height=80, disabled=True)


def main() -> None:
    st.set_page_config(page_title="Attention Trace Viewer", page_icon="🧠", layout="wide")
    st.title("🧠 Attention Trace Viewer")
    st.caption("Standalone offline visualizer — it reads trace files only; it never imports vLLM.")
    root = st.sidebar.text_input("VLLM_ASCEND_ATTENTION_TRACE_DIR", value="/data/attention-traces")
    try:
        sessions = list_sessions(root)
    except TraceFormatError as exc:
        st.info(str(exc))
        return
    if not sessions:
        st.warning("No COMMITTED trace records were found below this directory.")
        return
    selected_id = st.sidebar.selectbox("Session", range(len(sessions)), format_func=lambda i: sessions[i].trace_id)
    session = sessions[selected_id]
    _session_summary(session)
    records = session.prediction_records
    if not records:
        st.warning("This trace has no prediction record with a captured Q row.")
        return

    st.divider()
    left, middle, right = st.columns(3)
    output_index = left.selectbox(
        "Output token to explain",
        range(len(records)),
        format_func=lambda i: f"y{i}: {session.label_at(int(records[i]['target_position']))}",
    )
    selected_layers = middle.multiselect("Layers (equal-weight mean)", session.layers, default=session.layers)
    num_heads = int(session.manifest["attention"]["num_attention_heads"])
    selected_heads = right.multiselect("Query heads (equal-weight mean)", range(num_heads), default=list(range(num_heads)))
    source = st.radio("Explain attention paid to", ["input", "context"], horizontal=True)
    if not selected_layers or not selected_heads:
        st.warning("Select at least one layer and one query head.")
        return
    result = compute_attention(session, output_index, layers=selected_layers, heads=selected_heads, source=source)
    positions = list(result.source_positions)
    labels = [session.label_at(position) for position in positions]
    top_indices = np.argsort(result.scores)[::-1][: min(12, len(positions))]
    st.subheader(f"Why did the model emit y{output_index} = {session.label_at(result.target_position)!r}?")
    st.caption(
        f"Q at position {result.query_position}; mean of {len(result.layers)} layer(s) × "
        f"{len(result.heads)} head(s). Visible {source} mass: {result.retained_probability_mass:.2%}."
    )
    st.markdown(_token_ribbon(session, positions, result.scores), unsafe_allow_html=True)
    chart = px.bar(
        x=[labels[index] for index in top_indices][::-1],
        y=[float(result.scores[index]) for index in top_indices][::-1],
        orientation="v",
        labels={"x": "source token", "y": "attention probability"},
        color=[float(result.scores[index]) for index in top_indices][::-1],
        color_continuous_scale="OrRd",
    )
    chart.update_layout(coloraxis_showscale=False)
    st.plotly_chart(chart, use_container_width=True)

    st.subheader("Output → input attention map")
    matrix = []
    output_labels = []
    input_positions = None
    for index, record in enumerate(records):
        row = compute_attention(session, index, layers=selected_layers, heads=selected_heads, source="input")
        if input_positions is None:
            input_positions = list(row.source_positions)
        matrix.append(row.scores)
        output_labels.append(f"y{index}: {session.label_at(int(record['target_position']))}")
    heatmap = px.imshow(
        np.asarray(matrix),
        x=[f"{pos}: {session.label_at(pos)}" for pos in input_positions or []],
        y=output_labels,
        color_continuous_scale="YlOrRd", aspect="auto", labels={"x": "input token", "y": "output token", "color": "attention"},
    )
    st.plotly_chart(heatmap, use_container_width=True)
    st.info("Attention probability is a routing signal, not a causal attribution score. The heatmap uses an explicit equal-weight average over the selected layers and heads.")


if __name__ == "__main__":
    main()
