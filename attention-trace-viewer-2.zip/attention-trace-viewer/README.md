# Attention Trace Viewer

一个与 vLLM、vLLM-Ascend 完全解耦的离线可视化模块。它只读取
`VLLM_ASCEND_ATTENTION_TRACE_DIR` 下已经原子提交（含 `COMMITTED`）的
ATF trace 目录：`manifest.json`、`tokens.json` 和 safetensors。不会导入 vLLM，
也不会连接或修改在线推理服务。

## 安装与启动

```bash
cd attention-trace-viewer
python -m pip install -e .
attention-trace-viewer
```

`streamlit run` 以顶层脚本方式加载页面；先执行上述 editable install，随后再运行它：

```bash
streamlit run src/attention_trace_viewer/app.py
```

浏览器打开 Streamlit 显示的本地地址，在侧栏填入：

```text
/data/attention-traces/qwen3-4b
```

也可以直接启动：

```bash
streamlit run src/attention_trace_viewer/app.py
```

如从另一台机器访问服务器，将监听所有网卡，例如：

```bash
attention-trace-viewer --server.address 0.0.0.0 --server.port 8501
```

随后在浏览器访问 `http://<服务器-IP>:8501`。若服务器部署在容器或集群中，还需
放通/映射该端口。

## 页面内容

1. 自动扫描目录树中全部含 `COMMITTED` 的会话；每个会话独立展示模型、路径、
   prompt、output、token 数和已采样 layer。
2. 选择一个输出 token `y_t`。页面正确使用记录的 prediction query（首个输出为
   `Q(P-1)`）重新计算 `softmax(QK^T / sqrt(d))`。
3. 以 token 热力带和 Top-K 柱状图展示该输出对输入 token 的注意力；token hover
   会显示 logical position 与百分比。
4. 以“输出 token × 输入 token”热图展示整个会话的注意力轨迹。
5. layer 和 query head 均可选择；若多选，页面明确标注为**等权平均 attention**。

`输入` 模式会先在完整因果上下文（prompt + 已生成 token）上计算 softmax，再只
显示 prompt 部分。因此页面的 “Visible input mass” 小于 100% 时，差值就是模型
分给先前输出 token 的注意力，不会被隐藏。

## 独立分析 API

```python
from attention_trace_viewer import TraceSession, compute_attention

trace = TraceSession.open('/data/attention-traces/qwen3-4b/<trace-id>')
result = compute_attention(trace, prediction_index=0, layers=[35], heads=[0])
for position, score in zip(result.source_positions, result.scores):
    print(position, trace.label_at(position), f'{score:.2%}')
```

## 数据与边界

- 当前 v0.1 读取 ATF v1、`rank-000`（即当前 TP=1 trace）。它根据 shard index
  定位 safetensors，而非依赖写入端私有类。
- 使用 Qwen3 GQA 映射 `kv_head = q_head // (Hq / Hkv)`，且按 manifest 的 scale
  和 causal mask 重建概率。
- 该工具展示的是 attention probability，不应直接解释成“某输入 token 对输出的
  因果贡献”。需要因果结论时，应另行做 token ablation、activation patching 或
  integrated gradients。
