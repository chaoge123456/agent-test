import json
from pathlib import Path

import torch
from safetensors.torch import save_file

from attention_trace_viewer import TraceSession, compute_attention, list_sessions


def _write_trace(root: Path) -> Path:
    trace = root / "request-a"
    rank = trace / "tensors" / "rank-000"
    rank.mkdir(parents=True)
    (trace / "COMMITTED").touch()
    (trace / "manifest.json").write_text(json.dumps({
        "format": "attention-trace", "trace_id": "request-a",
        "capture": {"layers": [0]}, "lengths": {"prompt": 2, "output": 1},
        "attention": {"num_attention_heads": 2, "num_kv_heads": 1, "scale": 1.0},
    }))
    (trace / "tokens.json").write_text(json.dumps({
        "sequence": [
            {"logical_position": 0, "token_id": 1, "decoded_text": "A"},
            {"logical_position": 1, "token_id": 2, "decoded_text": "B"},
            {"logical_position": 2, "token_id": 3, "decoded_text": "C"},
        ],
        "prediction_records": [{"prediction_index": 0, "query_position": 1, "target_position": 2}],
        "layers": {"0": {"q_positions": [1], "kv_positions": [0, 1]}},
    }))
    q = torch.tensor([[[4.0], [4.0]]])
    k = torch.tensor([[[1.0]], [[0.0]]])
    save_file({"layers.0.q": q, "layers.0.k": k}, str(rank / "shard-00000.safetensors"))
    (rank / "index.json").write_text(json.dumps({"shards": [{"file": "shard-00000.safetensors", "tensors": ["layers.0.q", "layers.0.k"]}]}))
    return trace


def test_reader_and_gqa_attention(tmp_path: Path):
    _write_trace(tmp_path)
    sessions = list_sessions(tmp_path)
    assert len(sessions) == 1
    trace = TraceSession.open(sessions[0].path)
    result = compute_attention(trace, 0, layers=[0], heads=[0, 1])
    assert result.source_positions == (0, 1)
    assert result.scores[0] > 0.98
    assert result.retained_probability_mass == 1.0
