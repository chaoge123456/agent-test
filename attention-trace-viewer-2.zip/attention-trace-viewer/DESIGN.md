# 可视化功能设计

## 目标与边界

输入是一个 `VLLM_ASCEND_ATTENTION_TRACE_DIR` 根目录；工具递归发现其中所有带
`COMMITTED` 标记的会话。每个会话都是只读的分析对象。模块不 import vLLM、
vLLM-Ascend、TorchNPU，也不要求服务仍在运行，因此可以把 trace 目录复制到一台
普通 CPU 机器上查看。

```mermaid
flowchart LR
  A[trace 根目录] --> B[会话扫描器]
  B --> C[manifest / tokens reader]
  C --> D[safetensors shard reader]
  D --> E[QK + GQA + causal mask + softmax]
  E --> F[聚合器]
  F --> G[会话卡片 / token 热力带 / Top-K / 热图]
```

## Attention score 的定义

对输出 `y_t`，使用 `prediction_records` 中的 `query_position`，而不是简单把
`y_t` 自身的位置当作 query。对于每层 `l` 和 query head `h`：

```text
kv_head = h // (num_q_heads // num_kv_heads)
p(l,t,h,j) = softmax_j(scale * Q(l,t,h) · K(l,j,kv_head))
```

softmax 始终在 query 可见的完整因果上下文中计算。切换到“仅输入”视图时，只过滤
展示 prompt token，**不会重新归一化**；所以显示 `input attention mass`，让用户看见
有多少注意力实际给了已经生成的输出 token。

多选 layer/head 时，v0.1 使用明确的等权均值：

```text
score(t,j) = mean_{l in selected_layers, h in selected_heads} p(l,t,h,j)
```

它是便于浏览的聚合 attention，不是因果 attribution。界面将持续显示这层警示。

## 用户交互

1. 在侧栏输入 trace 根目录，选择一个会话。
2. 首屏阅读 prompt、output、长度、模型/采样 layers，确认选中的会话正确。
3. 选一个输出 token、若干 layer/head 和输入/上下文范围。
4. 从 token 热力带快速看全句，从 Top-K 柱状图读精确概率；鼠标悬停可查看 position。
5. 用“输出 × 输入”热图观察整段生成的注意力迁移。

## 分层实现

- `reader.py`：ATF v1 public-format reader；根据 `index.json` 找 shard，绝不触碰
  写入端 Python 类或 physical KV cache。
- `analysis.py`：纯计算 API，适合单元测试、导出 CSV/JSON 和后续 notebook。
- `app.py`：Streamlit 展示层；只调用 reader/analyzer。

## 当前限制与后续工作

- v0.1 仅支持当前采集器产生的 `rank-000`（TP=1）ATF v1；未来以 manifest 的 rank
  列表实现 TP shard merge，而不是改变 UI API。
- 当前完整热图一次读取每个输出 token的 Q/K；长会话可加 `st.cache_data`、token 窗口、
  Top-K 稀疏计算和后台预计算缓存。
- 可新增“layer × head × token”探针图、跨会话对比、JSON/CSV/HTML 导出；这些都建立在
  `compute_attention()` API 上，不改变与 vLLM 的解耦边界。
