"""Read completed attention traces without importing vLLM or vLLM-Ascend."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import torch
from safetensors.torch import load_file


class TraceFormatError(ValueError):
    """The selected directory is not a complete ATF trace the viewer can read."""


@dataclass(frozen=True)
class TraceSession:
    """A request-level trace loaded from its public, on-disk ATF contract."""

    path: Path
    manifest: dict[str, Any]
    tokens: dict[str, Any]

    @classmethod
    def open(cls, path: str | Path) -> "TraceSession":
        path = Path(path)
        if not (path / "COMMITTED").is_file():
            raise TraceFormatError(f"{path} is not a committed trace directory.")
        try:
            manifest = json.loads((path / "manifest.json").read_text(encoding="utf-8"))
            tokens = json.loads((path / "tokens.json").read_text(encoding="utf-8"))
        except FileNotFoundError as exc:
            raise TraceFormatError(f"{path} is missing {exc.filename}.") from exc
        if manifest.get("format") != "attention-trace":
            raise TraceFormatError("Unsupported or missing attention-trace format marker.")
        return cls(path=path, manifest=manifest, tokens=tokens)

    @property
    def trace_id(self) -> str:
        return str(self.manifest.get("trace_id", self.path.name))

    @property
    def layers(self) -> list[int]:
        return sorted(int(layer) for layer in self.manifest["capture"]["layers"])

    @property
    def sequence(self) -> list[dict[str, Any]]:
        return list(self.tokens["sequence"])

    @property
    def prediction_records(self) -> list[dict[str, Any]]:
        return list(self.tokens["prediction_records"])

    def label_at(self, position: int) -> str:
        token = self.sequence[position]
        text = token.get("decoded_text") or token.get("token_piece") or ""
        return str(text).replace("\n", "↵") or f"<id:{token['token_id']}>"

    def tensor(self, layer: int, component: str) -> torch.Tensor:
        """Load one tensor by following the shard index, not a vLLM private API."""
        rank_dir = self.path / "tensors" / "rank-000"
        try:
            index = json.loads((rank_dir / "index.json").read_text(encoding="utf-8"))
        except FileNotFoundError as exc:
            raise TraceFormatError("Only rank-000 ATF traces are supported by v0.1.") from exc
        tensor_name = f"layers.{layer}.{component}"
        for shard in index.get("shards", []):
            if tensor_name in shard.get("tensors", []):
                tensors = load_file(str(rank_dir / shard["file"]), device="cpu")
                return tensors[tensor_name]
        raise TraceFormatError(f"Tensor {tensor_name} is absent from trace {self.trace_id}.")


def list_sessions(trace_root: str | Path) -> list[TraceSession]:
    """Find all atomically committed request traces below ``trace_root``."""
    root = Path(trace_root)
    if not root.is_dir():
        raise TraceFormatError(f"Trace root does not exist: {root}")
    sessions: list[TraceSession] = []
    for marker in root.rglob("COMMITTED"):
        try:
            sessions.append(TraceSession.open(marker.parent))
        except TraceFormatError:
            continue
    return sorted(sessions, key=lambda session: session.path.name, reverse=True)
