"""Pure offline QK/softmax analysis for Qwen-style grouped-query attention."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np
import torch

from .reader import TraceFormatError, TraceSession


@dataclass(frozen=True)
class AttentionResult:
    """Attention probability after an explicit layer/head aggregation choice."""

    prediction_index: int
    query_position: int
    target_position: int
    source_positions: tuple[int, ...]
    scores: np.ndarray
    retained_probability_mass: float
    layers: tuple[int, ...]
    heads: tuple[int, ...]


def compute_attention(
    session: TraceSession,
    prediction_index: int,
    *,
    layers: Sequence[int] | None = None,
    heads: Sequence[int] | None = None,
    source: str = "input",
) -> AttentionResult:
    """Reconstruct probabilities for one output token from saved post-RoPE Q/K.

    ``source='input'`` returns only prompt positions, but normalizes softmax over
    the whole causal context first. This prevents hiding attention paid to prior
    output tokens. ``source='context'`` returns all visible positions.
    """
    records = session.prediction_records
    if not 0 <= prediction_index < len(records):
        raise IndexError(f"prediction_index must be in [0, {len(records) - 1}].")
    if source not in {"input", "context"}:
        raise ValueError("source must be 'input' or 'context'.")
    record = records[prediction_index]
    selected_layers = tuple(session.layers if layers is None else sorted(set(layers)))
    if not selected_layers:
        raise ValueError("Select at least one layer.")

    attention = session.manifest["attention"]
    num_q_heads = int(attention["num_attention_heads"])
    num_kv_heads = int(attention["num_kv_heads"])
    group_size = num_q_heads // num_kv_heads
    selected_heads = tuple(range(num_q_heads) if heads is None else sorted(set(heads)))
    if not selected_heads or min(selected_heads) < 0 or max(selected_heads) >= num_q_heads:
        raise ValueError(f"heads must be between 0 and {num_q_heads - 1}.")

    all_layer_scores: list[torch.Tensor] = []
    source_positions: tuple[int, ...] | None = None
    query_position = int(record["query_position"])
    prompt_len = int(session.manifest["lengths"]["prompt"])
    for layer in selected_layers:
        q = session.tensor(layer, "q").float()
        k = session.tensor(layer, "k").float()
        metadata = session.tokens["layers"][str(layer)]
        q_positions = [int(value) for value in metadata["q_positions"]]
        kv_positions = [int(value) for value in metadata["kv_positions"]]
        try:
            q_row = q_positions.index(query_position)
        except ValueError as exc:
            raise TraceFormatError(
                f"Layer {layer} has no Q row for query position {query_position}."
            ) from exc
        positions = torch.tensor(kv_positions, dtype=torch.long)
        visible = positions <= query_position
        wanted = visible & ((positions < prompt_len) if source == "input" else visible)
        current_positions = tuple(int(value) for value in positions[wanted].tolist())
        if source_positions is None:
            source_positions = current_positions
        elif source_positions != current_positions:
            raise TraceFormatError("Selected layers have inconsistent KV position maps.")

        per_head: list[torch.Tensor] = []
        for head in selected_heads:
            kv_head = head // group_size
            logits = (q[q_row, head] @ k[:, kv_head].T) * float(attention["scale"])
            logits = logits.masked_fill(~visible, float("-inf"))
            probabilities = torch.softmax(logits, dim=-1)
            per_head.append(probabilities[wanted])
        all_layer_scores.append(torch.stack(per_head).mean(dim=0))

    scores = torch.stack(all_layer_scores).mean(dim=0).numpy()
    return AttentionResult(
        prediction_index=prediction_index,
        query_position=query_position,
        target_position=int(record["target_position"]),
        source_positions=source_positions or (),
        scores=scores,
        retained_probability_mass=float(scores.sum()),
        layers=selected_layers,
        heads=selected_heads,
    )
