"""Streamlit entry point for browsing standalone ATF attention traces."""

from __future__ import annotations

import html

import numpy as np
import plotly.express as px
import streamlit as st

from attention_trace_viewer.analysis import compute_attention
from attention_trace_viewer.reader import TraceFormatError, TraceSession, list_sessions


def _apply_theme() -> None:
    st.markdown(
        """
        <style>
        .stApp { background: #050d1d; color: #e6eefc; }
        [data-testid="stSidebar"] { background: #071225; border-right: 1px solid #1b2b47; }
        [data-testid="stSidebar"] * { color: #dbe8ff; }
        h1, h2, h3 { color: #f3f7ff !important; letter-spacing: -.02em; }
        .eyebrow { color: #57c7ff; font-size: .82rem; font-weight: 700; text-transform: uppercase; letter-spacing: .08em; }
        .hero { background: linear-gradient(110deg, #0a1830, #0b1326); border: 1px solid #21375a; border-radius: 16px; padding: 18px 22px; margin: 4px 0 14px; }
        .source-card { background: #09172d; border: 1px solid #1b3151; border-radius: 12px; padding: 15px 17px; min-height: 128px; }
        .source-label { color: #6ccfff; font-size: .84rem; font-weight: 700; margin-bottom: 8px; }
        .source-text { color: #e9effa; line-height: 1.7; white-space: pre-wrap; }
        .panel-title { color: #dfeaff; font-size: 1.05rem; font-weight: 700; margin: 4px 0 8px; }
        .token-panel { background: #0a172b; border: 1px solid #21375a; border-radius: 14px; padding: 14px 16px; margin: 8px 0 12px; }
        .token { border: 1px solid rgba(255,255,255,.16); border-radius: 6px; padding: 5px 7px; margin: 3px; display: inline-block; color: #fff; font-size: .93rem; }
        .token-index { color: #9db4d5; font-size: .67rem; display: block; text-align: center; margin-top: 3px; }
        .hint { color: #a9bad3; font-size: .82rem; }
        [data-testid="stMetric"] { background: #09172d; border: 1px solid #1c3559; padding: 10px 15px; border-radius: 11px; }
        [data-testid="stMetricLabel"] { color: #9fb5d8; }
        [data-testid="stMetricValue"] { color: #4fd3ff; }
        .stSelectbox > div > div, .stMultiSelect > div > div { background: #0a172b; border-color: #294769; }
        </style>
        """,
        unsafe_allow_html=True,
    )


def _token_ribbon(session: TraceSession, positions: list[int], scores: np.ndarray) -> str:
    maximum = float(scores.max()) if len(scores) else 0.0
    parts = []
    for position, score in zip(positions, scores, strict=True):
        ratio = 0.0 if maximum == 0 else float(score) / maximum
        red, green, blue = int(22 + 238 * ratio), int(46 + 185 * ratio**1.8), int(74 * (1 - ratio))
        label = html.escape(session.label_at(position))
        parts.append(
            f'<span class="token" title="position {position}, attention {score:.4%}" '
            f'style="background:rgb({red},{green},{blue});">{label}'
            f'<span class="token-index">{position}</span></span>'
        )
    return "".join(parts)


def _summary(session: TraceSession) -> None:
    lengths = session.manifest["lengths"]
    model_id = str(session.manifest.get("model", {}).get("id", "Unknown model"))
    st.markdown('<div class="hero">', unsafe_allow_html=True)
    header, metrics = st.columns([1.4, 3])
    header.markdown("<div class='eyebrow'>Attention trace session</div>", unsafe_allow_html=True)
    header.markdown(f"### {html.escape(session.trace_id)}")
    model, prompt, output, layers = metrics.columns(4)
    model.metric("Model", model_id.rsplit("/", 1)[-1])
    prompt.metric("Prompt tokens", lengths["prompt"])
    output.metric("Output tokens", lengths["output"])
    layers.metric("Captured layers", ", ".join(map(str, session.layers)))
    st.markdown("</div>", unsafe_allow_html=True)
    prompt_col, output_col = st.columns(2)
    prompt_col.markdown(
        "<div class='source-card'><div class='source-label'>▣ 输入 Prompt</div>"
        f"<div class='source-text'>{html.escape(session.tokens.get('prompt_text', ''))}</div></div>",
        unsafe_allow_html=True,
    )
    output_col.markdown(
        "<div class='source-card'><div class='source-label'>✦ 模型生成 Output</div>"
        f"<div class='source-text'>{html.escape(session.tokens.get('output_text', ''))}</div></div>",
        unsafe_allow_html=True,
    )


def _topk_chart(labels: list[str], scores: np.ndarray) -> None:
    indices = np.argsort(scores)[::-1][: min(10, len(scores))][::-1]
    chart = px.bar(
        x=[float(scores[index]) for index in indices], y=[labels[index] for index in indices], orientation="h",
        color=[float(scores[index]) for index in indices], color_continuous_scale="Oranges",
        labels={"x": "attention probability", "y": ""},
    )
    chart.update_layout(template="plotly_dark", height=430, margin=dict(l=10, r=10, t=18, b=20), paper_bgcolor="#0a172b", plot_bgcolor="#0a172b", coloraxis_showscale=False)
    chart.update_xaxes(tickformat=".0%", gridcolor="#213554")
    chart.update_yaxes(gridcolor="#213554")
    st.plotly_chart(chart, width="stretch")


def main() -> None:
    st.set_page_config(page_title="Attention Trace Viewer", page_icon="🧠", layout="wide")
    _apply_theme()
    st.sidebar.markdown("# Attention Trace Viewer")
    st.sidebar.caption("离线读取 ATF trace · 不依赖 vLLM 运行时")
    root = st.sidebar.text_input("Trace 目录", value="/data/attention-traces")
    try:
        sessions = list_sessions(root)
    except TraceFormatError as exc:
        st.info(str(exc))
        return
    if not sessions:
        st.warning("在该目录下未找到含 COMMITTED 的会话记录。")
        return
    st.sidebar.markdown("#### 会话列表")
    selected_id = st.sidebar.selectbox("选择会话", range(len(sessions)), format_func=lambda i: sessions[i].trace_id)
    session = sessions[selected_id]
    st.sidebar.caption(f"已发现 {len(sessions)} 个已完成会话")
    st.sidebar.code(str(session.path), language=None)

    _summary(session)
    records = session.prediction_records
    if not records:
        st.warning("这条 trace 没有带已捕获 Q 行的 prediction record。")
        return

    st.markdown("<div class='panel-title'>选择要解释的输出 token</div>", unsafe_allow_html=True)
    control_a, control_b, control_c, control_d = st.columns([1.3, 1.1, 1.5, 1.1])
    output_index = control_a.selectbox("当前输出 token", range(len(records)), format_func=lambda i: f"y{i}: {session.label_at(int(records[i]['target_position']))}")
    source = control_b.radio("展示范围", ["input", "context"], horizontal=True)
    selected_layers = control_c.multiselect("Layer（等权平均）", session.layers, default=session.layers)
    num_heads = int(session.manifest["attention"]["num_attention_heads"])
    selected_heads = control_d.multiselect("Query head（等权平均）", range(num_heads), default=list(range(num_heads)))
    if not selected_layers or not selected_heads:
        st.warning("请至少选择一个 layer 和一个 query head。")
        return

    result = compute_attention(session, output_index, layers=selected_layers, heads=selected_heads, source=source)
    positions = list(result.source_positions)
    labels = [session.label_at(position) for position in positions]
    st.markdown(
        f"<div class='token-panel'><div class='panel-title'>输入 token 注意力热力带 · 输出 y{output_index} = {html.escape(session.label_at(result.target_position))}</div>"
        f"<div class='hint'>Query position {result.query_position} · {len(result.layers)} layer(s) × {len(result.heads)} head(s) 等权平均 · 可见 {source} mass: {result.retained_probability_mass:.2%}</div>"
        f"<div style='margin-top:9px'>{_token_ribbon(session, positions, result.scores)}</div></div>", unsafe_allow_html=True,
    )

    heat_col, topk_col = st.columns([3.2, 1])
    with heat_col:
        st.markdown("<div class='panel-title'>输出 token × 输入 token</div>", unsafe_allow_html=True)
        matrix, output_labels, input_positions = [], [], None
        for index, record in enumerate(records):
            row = compute_attention(session, index, layers=selected_layers, heads=selected_heads, source="input")
            if input_positions is None:
                input_positions = list(row.source_positions)
            matrix.append(row.scores)
            output_labels.append(f"y{index}: {session.label_at(int(record['target_position']))}")
        heatmap = px.imshow(np.asarray(matrix), x=[f"{pos}: {session.label_at(pos)}" for pos in input_positions or []], y=output_labels, color_continuous_scale="YlOrRd", aspect="auto", labels={"x": "input token", "y": "output token", "color": "attention"})
        heatmap.update_layout(template="plotly_dark", height=430, margin=dict(l=10, r=10, t=18, b=80), paper_bgcolor="#0a172b", plot_bgcolor="#0a172b")
        heatmap.update_xaxes(tickangle=-45, gridcolor="#243957")
        heatmap.update_yaxes(gridcolor="#243957")
        st.plotly_chart(heatmap, width="stretch")
    with topk_col:
        st.markdown("<div class='panel-title'>Top-K 注意力</div>", unsafe_allow_html=True)
        _topk_chart(labels, result.scores)
    st.caption("Attention probability 是路由信号，而非因果归因；跨 layer/head 的结果为显式等权平均。")


if __name__ == "__main__":
    main()
