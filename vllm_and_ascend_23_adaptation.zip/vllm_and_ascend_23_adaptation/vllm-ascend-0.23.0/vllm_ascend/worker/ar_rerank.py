# Copyright (c) 2026 Huawei Technologies Co., Ltd. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0
"""Tensor scoring primitive for ARRanker's paged-K runner bridge."""

import torch


def score_ar_heads_causal_attention_validated(
    queries: torch.Tensor,
    keys: torch.Tensor,
    query_positions: torch.Tensor,
    document_starts: torch.Tensor,
    document_ends: torch.Tensor,
    *,
    max_query_position: int,
) -> torch.Tensor:
    """Return causal attention mass, shaped ``[head, document]``.

    Inputs are validated by ``NPUModelRunner`` so no device-to-host checks are
    performed in this hot path.
    """
    visible_keys = keys[:, : max_query_position + 1]
    logits = torch.bmm(queries, visible_keys.transpose(1, 2))
    logits.mul_(visible_keys.shape[-1] ** -0.5)
    positions = torch.arange(max_query_position + 1, device=keys.device)
    mask = positions.unsqueeze(0) <= query_positions.unsqueeze(1)
    probabilities = torch.softmax(logits.masked_fill(~mask.unsqueeze(0), -torch.inf), dim=-1)
    prefix_sums = torch.cat(
        (torch.zeros_like(probabilities[..., :1]), probabilities.cumsum(dim=-1)), dim=-1
    )
    document_mass = prefix_sums[..., document_ends] - prefix_sums[..., document_starts]
    return document_mass.mean(dim=1)
