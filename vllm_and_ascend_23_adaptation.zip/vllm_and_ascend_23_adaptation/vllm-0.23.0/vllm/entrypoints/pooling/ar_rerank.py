# SPDX-License-Identifier: Apache-2.0
"""Prompt construction and result validation for listwise AR reranking."""

from dataclasses import dataclass
from typing import Any, Protocol, Sequence


class OffsetTokenizer(Protocol):
    is_fast: bool

    def __call__(self, text: str, **kwargs: Any) -> Any: ...


@dataclass(frozen=True)
class ARRerankRequest:
    query: str
    documents: tuple[str, ...]


@dataclass(frozen=True)
class ARPreparedPoolingRequest:
    prompt: dict[str, Any]
    pooling_params: dict[str, Any]


def prepare_ar_pooling_request(
    tokenizer: OffsetTokenizer, request: ARRerankRequest, *, max_model_len: int
) -> ARPreparedPoolingRequest:
    if not getattr(tokenizer, "is_fast", False):
        raise ValueError("tokenizer must be a fast tokenizer with offset mapping")
    if not request.query.strip() or not request.documents:
        raise ValueError("query and documents must not be empty")
    if any(not document.strip() for document in request.documents):
        raise ValueError("documents must not contain empty strings")
    prompt = "<|im_start|>user\nHere are some retrieved chunks:\n\n"
    document_chars: list[tuple[int, int]] = []
    for index, document in enumerate(request.documents, start=1):
        prompt += f"[{index}]"
        start = len(prompt)
        prompt += f" : {document.strip()}"
        document_chars.append((start, len(prompt)))
        prompt += "\n\n"
    prompt += "Use the retrieved chunks to answer the user's query.\n\nQuery: "
    query_start = len(prompt)
    prompt += request.query
    encoded = tokenizer(prompt, add_special_tokens=False, return_offsets_mapping=True)
    input_ids = _single(encoded["input_ids"])
    offsets = _single(encoded["offset_mapping"], pairs=True)
    if len(input_ids) != len(offsets) or len(input_ids) > max_model_len:
        raise ValueError("AR prompt tokenization is invalid or exceeds max_model_len")
    document_ranges = [_token_range(offsets, span, "document") for span in document_chars]
    query_range = _token_range(offsets, (query_start, len(prompt)), "query")
    return ARPreparedPoolingRequest(
        prompt={"prompt": prompt, "prompt_token_ids": input_ids},
        pooling_params={
            "task": "classify",
            "skip_reading_prefix_cache": True,
            "extra_kwargs": {
                "ar_rerank": {
                    "document_ranges": [list(span) for span in document_ranges],
                    "query_range": list(query_range),
                }
            },
        },
    )


def scores_from_pooling_output(data: Any, *, document_count: int) -> tuple[float, ...]:
    scores = data.tolist() if hasattr(data, "tolist") else data
    if not isinstance(scores, Sequence) or len(scores) != document_count:
        raise RuntimeError(f"expected {document_count} AR scores, received {len(scores) if isinstance(scores, Sequence) else 'non-sequence'}")
    return tuple(float(score) for score in scores)


def _single(values: Any, *, pairs: bool = False) -> list[Any]:
    if hasattr(values, "tolist"):
        values = values.tolist()
    if not isinstance(values, Sequence) or not values:
        raise ValueError("tokenizer returned no token data")
    first = values[0]
    if pairs and isinstance(first, Sequence) and len(first) == 2 and all(
        isinstance(value, int) for value in first
    ):
        return list(values)
    if isinstance(first, Sequence) and not isinstance(first, (str, bytes)):
        return list(first)
    return list(values)


def _token_range(offsets: Sequence[Sequence[int]], span: tuple[int, int], field: str) -> tuple[int, int]:
    start, end = span
    tokens = [i for i, (token_start, token_end) in enumerate(offsets) if token_end > start and token_start < end]
    if not tokens:
        raise ValueError(f"{field} does not map to any token")
    return tokens[0], tokens[-1] + 1
