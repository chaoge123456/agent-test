# SPDX-License-Identifier: Apache-2.0
"""Qwen3 ARRanker model wrapper.

The device-specific runner computes attention-mass scores and deposits them in
the pooler.  This module deliberately contains no Ascend cache assumptions.
"""

from collections.abc import Iterable, Set

import torch
from torch import nn

from vllm.config import VllmConfig
from vllm.model_executor.layers.pooler import Pooler
from vllm.model_executor.models.qwen3 import Qwen3Attention, Qwen3ForCausalLM
from vllm.model_executor.models.qwen3_ar_config import ARModelSpec
from vllm.model_executor.models.qwen3_ar_weights import map_ar_checkpoint_name
from vllm.tasks import PoolingTask
from vllm.v1.outputs import PoolerOutput


class ARNoFinalNorm(nn.Module):
    """Retain Qwen's fused-residual ABI while omitting ARRanker's final norm."""

    def forward(
        self, hidden_states: torch.Tensor, residual: torch.Tensor | None
    ) -> tuple[torch.Tensor, torch.Tensor | None]:
        return (hidden_states + residual, residual) if residual is not None else (hidden_states, residual)


class ARScorePooler(Pooler):
    """Return per-request vectors supplied by the Ascend model runner."""

    def __init__(self) -> None:
        super().__init__()
        self._scores: dict[str, torch.Tensor] = {}

    def set_scores(self, scores_by_request: dict[str, torch.Tensor]) -> None:
        self._scores.update(scores_by_request)

    def get_supported_tasks(self) -> Set[PoolingTask]:
        # ``score`` was removed from PoolingTask in v0.23.  Classify keeps the
        # normal pooling plumbing while the dedicated AR API owns the vector.
        return {"classify"}

    def forward(self, hidden_states: torch.Tensor, pooling_metadata) -> PoolerOutput:
        outputs: list[torch.Tensor] = []
        for params in pooling_metadata.pooling_params:
            payload = (params.extra_kwargs or {}).get("ar_rerank")
            if payload is None:
                outputs.append(hidden_states.new_zeros(1))
                continue
            request_key = payload.get("request_key")
            if not isinstance(request_key, str) or not request_key:
                raise RuntimeError("AR pooling request is missing request_key")
            score = self._scores.pop(request_key, None)
            if score is None:
                raise RuntimeError(f"AR runner bridge did not deposit {request_key=}")
            outputs.append(score)
        return outputs


class Qwen3ARAttention(Qwen3Attention):
    """Qwen3 attention exposing selected post-RoPE Q vectors."""

    def enable_ar_capture(
        self, *, ar_layer: int, ar_heads: list[int], capture: dict[int, torch.Tensor]
    ) -> None:
        self.ar_layer = ar_layer
        self.register_buffer(
            "ar_head_indices", torch.tensor(ar_heads, dtype=torch.long), persistent=False
        )
        self.capture = capture
        self.capture_rows: torch.Tensor | None = None

    def forward(self, positions: torch.Tensor, hidden_states: torch.Tensor) -> torch.Tensor:
        qkv, _ = self.qkv_proj(hidden_states)
        q, k, v = qkv.split([self.q_size, self.kv_size, self.kv_size], dim=-1)
        q_by_head = self.q_norm(q.view(*q.shape[:-1], self.num_heads, self.head_dim))
        k_by_head = self.k_norm(k.view(*k.shape[:-1], self.num_kv_heads, self.head_dim))
        q, k = self.rotary_emb(positions, q_by_head.reshape_as(q), k_by_head.reshape_as(k))
        if self.capture_rows is not None:
            q_after_rope = q.view(*q.shape[:-1], self.num_heads, self.head_dim)
            captured = q_after_rope.index_select(0, self.capture_rows)
            self.capture[self.ar_layer] = captured.index_select(1, self.ar_head_indices).transpose(0, 1).contiguous()
        attn_output = self.attn(q, k, v)
        output, _ = self.o_proj(attn_output)
        return output


class Qwen3ARForRerank(Qwen3ForCausalLM):
    """Pooling-only ARRanker with Ascend-owned paged-K score reduction."""

    is_pooling_model = True

    def __init__(self, *, vllm_config: VllmConfig, prefix: str = "") -> None:
        hf_config = vllm_config.model_config.hf_config
        hf_config.num_labels = 1
        super().__init__(vllm_config=vllm_config, prefix=prefix)
        self.ar_spec = ARModelSpec.from_config(hf_config)
        self.model.layers = self.model.layers[: self.ar_spec.executable_layer_count]
        self.model.end_layer = min(self.model.end_layer, self.ar_spec.executable_layer_count)
        self.model.norm = ARNoFinalNorm()
        self.pooler = ARScorePooler()
        self._ar_q_capture: dict[int, torch.Tensor] = {}
        heads_by_layer: dict[int, list[int]] = {}
        for layer, head in self.ar_spec.selected_layer_heads:
            heads_by_layer.setdefault(layer, []).append(head)
        for layer_id, layer in enumerate(self.model.layers):
            if layer_id in heads_by_layer:
                attention = layer.self_attn
                attention.__class__ = Qwen3ARAttention
                attention.enable_ar_capture(ar_layer=layer_id, ar_heads=heads_by_layer[layer_id], capture=self._ar_q_capture)

    def set_ar_q_capture_rows(self, rows: torch.Tensor) -> None:
        if rows.ndim != 1 or rows.dtype != torch.long:
            raise ValueError("AR Q capture rows must be a one-dimensional torch.long tensor")
        if rows.device != next(self.parameters()).device:
            raise ValueError("AR Q capture rows must be on the model device")
        for layer in self.model.layers:
            if isinstance(layer.self_attn, Qwen3ARAttention):
                layer.self_attn.capture_rows = rows

    def clear_ar_q_capture(self) -> None:
        self._reset_ar_q_capture()

    def consume_ar_q_capture(self) -> dict[int, torch.Tensor]:
        captured = self._ar_q_capture
        self._reset_ar_q_capture()
        return captured

    def _reset_ar_q_capture(self) -> None:
        self._ar_q_capture = {}
        for layer in self.model.layers:
            if isinstance(layer.self_attn, Qwen3ARAttention):
                layer.self_attn.capture = self._ar_q_capture
                layer.self_attn.capture_rows = None

    def load_weights(self, weights: Iterable[tuple[str, torch.Tensor]]) -> set[str]:
        mapped = ((map_ar_checkpoint_name(name, executable_layer_count=self.ar_spec.executable_layer_count), weight) for name, weight in weights)
        return super().load_weights(mapped)
