# SPDX-License-Identifier: Apache-2.0
"""Checkpoint-name validation for truncated Qwen3 ARRanker models."""

import re

_LAYER_NAME = re.compile(r"^layers\\.(\\d+)\\.")
_ABSENT_COMPONENTS = ("norm.", "lm_head.")


def map_ar_checkpoint_name(name: str, *, executable_layer_count: int) -> str:
    if executable_layer_count < 1:
        raise ValueError("executable_layer_count must be positive")
    if name.startswith(_ABSENT_COMPONENTS):
        raise ValueError(f"{name} is not part of the AR execution model")
    layer_match = _LAYER_NAME.match(name)
    if layer_match and int(layer_match.group(1)) >= executable_layer_count:
        raise ValueError(f"{name} is not part of the AR execution model")
    return f"model.{name}"
