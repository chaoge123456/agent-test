# SPDX-License-Identifier: Apache-2.0

import pytest

from vllm.model_executor.models.qwen3_ar_config import ARModelSpec
from vllm.model_executor.models.qwen3_ar_weights import map_ar_checkpoint_name


def test_ar_model_spec_validates_checkpoint_contract():
    spec = ARModelSpec.from_config(
        {
            "architectures": ["Qwen3ARForRerank"],
            "num_hidden_layers": 4,
            "ar_end_layer": 2,
            "num_attention_heads": 8,
            "num_key_value_heads": 2,
            "ar_head_list": [[0, 0], [1, 7]],
        }
    )
    assert spec.executable_layer_count == 2
    assert spec.q_heads_per_kv_head == 4


@pytest.mark.parametrize("name", ["norm.weight", "layers.2.self_attn.q_proj.weight"])
def test_ar_weight_mapping_rejects_unexecuted_parameters(name: str):
    with pytest.raises(ValueError):
        map_ar_checkpoint_name(name, executable_layer_count=2)


def test_ar_weight_mapping_adds_model_prefix():
    assert map_ar_checkpoint_name("layers.0.mlp.gate_proj.weight", executable_layer_count=2) == "model.layers.0.mlp.gate_proj.weight"
