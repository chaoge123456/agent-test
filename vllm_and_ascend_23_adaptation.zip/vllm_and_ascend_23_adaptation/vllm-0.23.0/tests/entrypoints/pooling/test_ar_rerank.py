# SPDX-License-Identifier: Apache-2.0

import pytest

from vllm.entrypoints.pooling.ar_rerank import (
    ARRerankRequest,
    prepare_ar_pooling_request,
    scores_from_pooling_output,
)


class _Tokenizer:
    is_fast = True

    def __call__(self, text, **kwargs):
        offsets = [(index, index + 1) for index in range(len(text))]
        return {"input_ids": list(range(len(text))), "offset_mapping": offsets}


def test_ar_prompt_preserves_one_listwise_request():
    prepared = prepare_ar_pooling_request(
        _Tokenizer(), ARRerankRequest("where", ("first", "second")), max_model_len=1024
    )
    payload = prepared.pooling_params["extra_kwargs"]["ar_rerank"]
    assert prepared.pooling_params["task"] == "classify"
    assert len(payload["document_ranges"]) == 2
    assert payload["query_range"][0] > payload["document_ranges"][-1][1]


def test_ar_scores_require_one_value_per_document():
    assert scores_from_pooling_output([0.1, 0.2], document_count=2) == (0.1, 0.2)
    with pytest.raises(RuntimeError):
        scores_from_pooling_output([0.1], document_count=2)
