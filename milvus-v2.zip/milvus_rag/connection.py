"""
Milvus 连接管理器
=================
提供 Milvus 连接的单例管理和数据库切换功能。
"""

import logging
from contextlib import contextmanager
from typing import Optional

from pymilvus import connections, db

from .config import config

logger = logging.getLogger(__name__)


class MilvusConnection:
    """Milvus 连接管理器"""
    
    _instance: Optional["MilvusConnection"] = None
    _alias: str = "default"
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        self._connected = False
    
    def connect(self, 
                host: Optional[str] = None,
                port: Optional[int] = None,
                user: Optional[str] = None,
                password: Optional[str] = None,
                db_name: Optional[str] = None,
                timeout: Optional[float] = None) -> None:
        """
        建立 Milvus 连接
        
        Args:
            host: Milvus 主机地址
            port: Milvus 端口
            user: 用户名（可选）
            password: 密码（可选）
            db_name: 数据库名
            timeout: 超时时间（秒）
        """
        host = host or config.milvus_host
        port = port or config.milvus_port
        user = user or config.milvus_user
        password = password or config.milvus_password
        db_name = db_name or config.milvus_db
        timeout = timeout or config.milvus_timeout
        
        # 如果已经连接，先断开
        if self._connected:
            self.disconnect()
        
        logger.info(f"正在连接 Milvus: {host}:{port}")
        
        # 建立连接
        connections.connect(
            alias=self._alias,
            host=host,
            port=port,
            user=user,
            password=password,
            timeout=timeout
        )
        
        # 切换数据库
        if db_name and db_name != "default":
            self.use_database(db_name)
        
        self._connected = True
        logger.info(f"Milvus 连接成功，当前数据库: {db_name}")
    
    def disconnect(self) -> None:
        """断开 Milvus 连接"""
        if self._connected:
            connections.disconnect(alias=self._alias)
            self._connected = False
            logger.info("Milvus 连接已断开")
    
    def use_database(self, db_name: str) -> None:
        """
        切换数据库
        
        Args:
            db_name: 数据库名
        """
        db.using_database(db_name)
        logger.info(f"已切换到数据库: {db_name}")
    
    @property
    def is_connected(self) -> bool:
        """检查是否已连接"""
        try:
            return connections.has_connection(self._alias) and self._connected
        except Exception:
            return False
    
    @property
    def alias(self) -> str:
        """获取连接别名"""
        return self._alias


# 全局连接实例
_milvus_conn = MilvusConnection()


def get_connection() -> MilvusConnection:
    """获取全局连接实例"""
    return _milvus_conn


def connect_milvus(**kwargs) -> None:
    """快捷连接函数"""
    _milvus_conn.connect(**kwargs)


def disconnect_milvus() -> None:
    """快捷断开连接函数"""
    _milvus_conn.disconnect()


@contextmanager
def using_database(db_name: str):
    """
    上下文管理器，临时切换数据库
    
    Usage:
        with using_database("my_db"):
            # 在 my_db 中执行操作
            collection = Collection("my_collection")
    """
    original_db = _get_current_database()
    try:
        if db_name != original_db:
            _milvus_conn.use_database(db_name)
        yield
    finally:
        if db_name != original_db:
            _milvus_conn.use_database(original_db)


def _get_current_database() -> str:
    """获取当前数据库名"""
    try:
        return db.database_info().get("DBName", "default")
    except Exception:
        return "default"


# 便捷的连接检查装饰器
def require_connection(func):
    """确保已连接的装饰器"""
    def wrapper(*args, **kwargs):
        if not _milvus_conn.is_connected:
            _milvus_conn.connect()
        return func(*args, **kwargs)
    return wrapper