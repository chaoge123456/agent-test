"""
页级摘要向量表管理器
====================
实现页级摘要向量表的 CRUD、索引构建等操作。
"""

import logging
from typing import Any, Dict, List, Optional, Union

from .base_table import BaseTable
from .config import get_config
from .models import PageSummary, PageSummarySchema

logger = logging.getLogger(__name__)


class PageSummaryTable(BaseTable):
    """
    页级摘要向量表管理器
    
    存储页面的 VLM 摘要信息和多模态 embedding。
    支持按文档 (doc_id) 和页面 (page_id) 进行过滤查询。
    """
    
    PRIMARY_FIELD = PageSummarySchema.ROW_ID
    VECTOR_FIELD = PageSummarySchema.VECTOR
    
    def __init__(self, vector_dim: Optional[int] = None):
        cfg = get_config()
        table_name = cfg.get_table_config("page_summary").get("collection_name", "page_summary")
        super().__init__(table_name, vector_dim)
    
    # ==================== 初始化 ====================
    
    def init_schema(self, 
                    vector_dim: Optional[int] = None,
                    recreate: bool = False) -> "PageSummaryTable":
        """初始化表结构"""
        if vector_dim:
            self._vector_dim = vector_dim
        
        if recreate and self.exists():
            self.drop_collection()
        
        fields = PageSummarySchema.get_fields(self._vector_dim)
        self.create_collection(fields=fields)
        self.create_index()
        
        return self
    
    # ==================== 插入操作 ====================
    
    def insert(self, 
               data: Union[PageSummary, Dict[str, Any], List[Dict[str, Any]]],
               batch_size: Optional[int] = None) -> List[int]:
        """插入页面摘要数据"""
        if isinstance(data, PageSummary):
            data = [self._to_dict(data)]
        elif isinstance(data, dict):
            data = [data]
        
        return super().insert(data, batch_size)
    
    def insert_page_summary(self,
                            doc_id: int,
                            abstract: str,
                            page_id: int,
                            vector: List[float],
                            page_path: str,
                            row_id: Optional[int] = None,
                            keyword: Optional[List[str]] = None,
                            metadata: Optional[Dict[str, Any]] = None) -> int:
        """
        插入单条页面摘要记录
        
        Args:
            doc_id: 所属文档ID
            abstract: VLM 生成的页面描述
            page_id: 文档第几页
            vector: 多模态 embedding 向量
            page_path: 页面存储路径
            row_id: 指定的主键ID
            keyword: 关键词
            metadata: 页面元素信息 (文本、表格、图片等)
            
        Returns:
            插入的页面ID
        """
        data = {
            PageSummarySchema.ROW_ID: row_id or self._generate_id(),
            PageSummarySchema.DOC_ID: doc_id,
            PageSummarySchema.ABSTRACT: abstract,
            PageSummarySchema.PAGE_ID: page_id,
            PageSummarySchema.VECTOR: vector,
            PageSummarySchema.PAGE_PATH: page_path,
            PageSummarySchema.KEYWORD: keyword or [],
            PageSummarySchema.METADATA: metadata or {},
        }
        
        result = self.insert(data)
        return result[0] if result else -1
    
    def insert_batch(self,
                     doc_id: int,
                     pages: List[Dict[str, Any]]) -> List[int]:
        """
        批量插入页面摘要
        
        Args:
            doc_id: 文档ID
            pages: 页面列表，每个元素包含:
                - page_id: 页码
                - abstract: 摘要
                - vector: 向量
                - page_path: 路径
                - keyword: 关键词 (可选)
                - metadata: 元数据 (可选)
                
        Returns:
            插入的主键列表
        """
        data = []
        for page in pages:
            data.append({
                PageSummarySchema.ROW_ID: self._generate_id(),
                PageSummarySchema.DOC_ID: doc_id,
                PageSummarySchema.ABSTRACT: page.get("abstract", ""),
                PageSummarySchema.PAGE_ID: page["page_id"],
                PageSummarySchema.VECTOR: page["vector"],
                PageSummarySchema.PAGE_PATH: page.get("page_path", ""),
                PageSummarySchema.KEYWORD: page.get("keyword", []),
                PageSummarySchema.METADATA: page.get("metadata", {}),
            })
        
        return self.insert(data)
    
    def _to_dict(self, page: PageSummary) -> Dict[str, Any]:
        """转换为字典"""
        return {
            PageSummarySchema.ROW_ID: page.row_id,
            PageSummarySchema.DOC_ID: page.doc_id,
            PageSummarySchema.ABSTRACT: page.abstract,
            PageSummarySchema.PAGE_ID: page.page_id,
            PageSummarySchema.VECTOR: page.vector,
            PageSummarySchema.PAGE_PATH: page.page_path,
            PageSummarySchema.KEYWORD: page.keyword or [],
            PageSummarySchema.METADATA: page.metadata or {},
        }
    
    def _generate_id(self) -> int:
        """生成唯一ID"""
        import time
        return int(time.time() * 1000)
    
    # ==================== 查询操作 ====================
    
    def get_by_id(self, row_id: int) -> Optional[PageSummary]:
        """根据ID获取页面摘要"""
        results = super().get_by_id(row_id)
        if results:
            return self._from_dict(results[0])
        return None
    
    def get_by_page(self, doc_id: int, page_id: int) -> Optional[PageSummary]:
        """
        根据文档和页码获取页面摘要
        
        Args:
            doc_id: 文档ID
            page_id: 页码
            
        Returns:
            PageSummary 或 None
        """
        filter_expr = f"{PageSummarySchema.DOC_ID} == {doc_id} and {PageSummarySchema.PAGE_ID} == {page_id}"
        results = self.query(filter_expr, limit=1)
        if results:
            return self._from_dict(results[0])
        return None
    
    def list_by_doc(self, doc_id: int, limit: Optional[int] = None) -> List[PageSummary]:
        """
        列出某个文档的所有页面摘要
        
        Args:
            doc_id: 文档ID
            limit: 限制数量
            
        Returns:
            页面摘要列表
        """
        filter_expr = f"{PageSummarySchema.DOC_ID} == {doc_id}"
        results = self.query(filter_expr, limit=limit)
        return [self._from_dict(r) for r in results]
    
    def list_by_page_range(self, 
                           doc_id: int, 
                           start_page: int, 
                           end_page: int) -> List[PageSummary]:
        """
        获取页面范围内的摘要
        
        Args:
            doc_id: 文档ID
            start_page: 起始页
            end_page: 结束页
            
        Returns:
            页面摘要列表
        """
        filter_expr = f"{PageSummarySchema.DOC_ID} == {doc_id} and {PageSummarySchema.PAGE_ID} >= {start_page} and {PageSummarySchema.PAGE_ID} <= {end_page}"
        results = self.query(filter_expr)
        return [self._from_dict(r) for r in results]
    
    def list_all(self, limit: Optional[int] = None) -> List[PageSummary]:
        """列出所有页面摘要"""
        results = self.query(filter_expr="", limit=limit)
        return [self._from_dict(r) for r in results]
    
    def search_by_vector(self,
                         vector: List[float],
                         doc_id: Optional[int] = None,
                         limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        向量搜索页面
        
        Args:
            vector: 查询向量
            doc_id: 可选，按文档过滤
            limit: 返回数量
        """
        filter_expr = f"{PageSummarySchema.DOC_ID} == {doc_id}" if doc_id else None
        
        return self.search(
            vectors=vector,
            filter_expr=filter_expr,
            limit=limit
        )[0]
    
    def _from_dict(self, data: Dict[str, Any]) -> PageSummary:
        """从字典创建 PageSummary"""
        return PageSummary(
            row_id=data[PageSummarySchema.ROW_ID],
            doc_id=data[PageSummarySchema.DOC_ID],
            abstract=data[PageSummarySchema.ABSTRACT],
            page_id=data[PageSummarySchema.PAGE_ID],
            vector=data[PageSummarySchema.VECTOR],
            page_path=data[PageSummarySchema.PAGE_PATH],
            keyword=data.get(PageSummarySchema.KEYWORD),
            metadata=data.get(PageSummarySchema.METADATA),
        )
    
    # ==================== 更新操作 ====================
    
    def update(self, row_id: int, update_data: Dict[str, Any]) -> bool:
        """更新页面摘要"""
        filter_expr = f"{PageSummarySchema.ROW_ID} == {row_id}"
        data = {PageSummarySchema.ROW_ID: row_id}
        data.update(update_data)
        
        try:
            self.upsert(data)
            return True
        except Exception as e:
            logger.error(f"更新页面摘要失败: {e}")
            return False
    
    def update_abstract(self, row_id: int, abstract: str) -> bool:
        return self.update(row_id, {PageSummarySchema.ABSTRACT: abstract})
    
    def update_vector(self, row_id: int, vector: List[float]) -> bool:
        return self.update(row_id, {PageSummarySchema.VECTOR: vector})
    
    def update_metadata(self, row_id: int, metadata: Dict[str, Any]) -> bool:
        return self.update(row_id, {PageSummarySchema.METADATA: metadata})
    
    def update_keywords(self, row_id: int, keyword: List[str]) -> bool:
        return self.update(row_id, {PageSummarySchema.KEYWORD: keyword})
    
    # ==================== 删除操作 ====================
    
    def delete(self, row_id: int) -> bool:
        """删除页面摘要"""
        try:
            filter_expr = f"{PageSummarySchema.ROW_ID} == {row_id}"
            super().delete(filter_expr)
            return True
        except Exception as e:
            logger.error(f"删除页面摘要失败: {e}")
            return False
    
    def delete_by_doc(self, doc_id: int) -> int:
        """
        删除某个文档的所有页面摘要
        
        Returns:
            删除数量
        """
        filter_expr = f"{PageSummarySchema.DOC_ID} == {doc_id}"
        return super().delete(filter_expr)
    
    def delete_by_page(self, doc_id: int, page_id: int) -> bool:
        """删除指定页面的摘要"""
        filter_expr = f"{PageSummarySchema.DOC_ID} == {doc_id} and {PageSummarySchema.PAGE_ID} == {page_id}"
        try:
            super().delete(filter_expr)
            return True
        except Exception as e:
            logger.error(f"删除页面摘要失败: {e}")
            return False
    
    # ==================== 统计操作 ====================
    
    def count(self, doc_id: Optional[int] = None) -> int:
        """获取页面数量"""
        if doc_id:
            filter_expr = f"{PageSummarySchema.DOC_ID} == {doc_id}"
            return super().count(filter_expr)
        return super().count()
    
    def get_stats(self, doc_id: Optional[int] = None) -> Dict[str, Any]:
        """获取统计信息"""
        stats = super().get_stats()
        stats["type"] = "page_summary"
        stats["count"] = self.count(doc_id)
        return stats


# 便捷函数
def create_page_summary_table(vector_dim: Optional[int] = None) -> PageSummaryTable:
    """创建页级摘要表管理器并初始化"""
    table = PageSummaryTable(vector_dim)
    table.init_schema()
    return table