"""
文档元数据表管理器
==================
实现文档元数据表的 CRUD、索引构建等操作。
"""

import logging
from typing import Any, Dict, List, Optional, Union

from .base_table import BaseTable
from .config import get_config
from .models import DocumentMetadata, DocumentMetadataSchema

logger = logging.getLogger(__name__)


class DocumentTable(BaseTable):
    """
    文档元数据表管理器
    
    提供文档的创建、查询、更新、删除、索引构建等操作。
    支持按知识库 (kb_id) 进行过滤查询。
    """
    
    PRIMARY_FIELD = DocumentMetadataSchema.DOC_ID
    VECTOR_FIELD = DocumentMetadataSchema.VECTOR
    
    def __init__(self, vector_dim: Optional[int] = None):
        cfg = get_config()
        table_name = cfg.get_table_config("document_metadata").get("collection_name", "document_metadata")
        super().__init__(table_name, vector_dim)
    
    # ==================== 初始化 ====================
    
    def init_schema(self, 
                    vector_dim: Optional[int] = None,
                    recreate: bool = False) -> "DocumentTable":
        """
        初始化表结构
        
        Args:
            vector_dim: 向量维度
            recreate: 是否重建表
        """
        if vector_dim:
            self._vector_dim = vector_dim
        
        if recreate and self.exists():
            self.drop_collection()
        
        fields = DocumentMetadataSchema.get_fields(self._vector_dim)
        self.create_collection(fields=fields)
        self.create_index()
        
        return self
    
    # ==================== 插入操作 ====================
    
    def insert(self, 
               data: Union[DocumentMetadata, Dict[str, Any], List[Dict[str, Any]]],
               batch_size: Optional[int] = None) -> List[int]:
        """
        插入文档数据
        """
        if isinstance(data, DocumentMetadata):
            data = [self._to_dict(data)]
        elif isinstance(data, dict):
            data = [data]
        
        return super().insert(data, batch_size)
    
    def insert_document(self,
                        kb_id: int,
                        doc_name: str,
                        tags: List[str],
                        organize: List[str],
                        metadata: Dict[str, Any],
                        doc_id: Optional[int] = None,
                        keywords: Optional[List[str]] = None,
                        abstract: Optional[str] = None,
                        vector: Optional[List[float]] = None,
                        relation: Optional[Dict[str, Any]] = None) -> int:
        """
        插入单条文档记录
        
        Args:
            kb_id: 所属知识库ID
            doc_name: 文档名
            tags: 标签列表
            organize: 组织方式 (tree, page, chunk)
            metadata: 元数据 (存储路径、入库时间、文档类型、页数等)
            doc_id: 指定的主键ID
            keywords: 关键词
            abstract: 文档摘要
            vector: 向量
            relation: 文档关联信息
            
        Returns:
            插入的文档ID
        """
        data = {
            DocumentMetadataSchema.DOC_ID: doc_id or self._generate_id(),
            DocumentMetadataSchema.KB_ID: kb_id,
            DocumentMetadataSchema.DOC_NAME: doc_name,
            DocumentMetadataSchema.TAGS: tags,
            DocumentMetadataSchema.KEYWORDS: keywords or [],
            DocumentMetadataSchema.ABSTRACT: abstract or "",
            DocumentMetadataSchema.VECTOR: vector or [0.0] * self._vector_dim,
            DocumentMetadataSchema.ORGANIZE: organize,
            DocumentMetadataSchema.METADATA: metadata,
            DocumentMetadataSchema.RELATION: relation or {},
        }
        
        result = self.insert(data)
        return result[0] if result else -1
    
    def _to_dict(self, doc: DocumentMetadata) -> Dict[str, Any]:
        """转换为字典"""
        return {
            DocumentMetadataSchema.DOC_ID: doc.doc_id,
            DocumentMetadataSchema.KB_ID: doc.kb_id,
            DocumentMetadataSchema.DOC_NAME: doc.doc_name,
            DocumentMetadataSchema.TAGS: doc.tags,
            DocumentMetadataSchema.KEYWORDS: doc.keywords or [],
            DocumentMetadataSchema.ABSTRACT: doc.abstract or "",
            DocumentMetadataSchema.VECTOR: doc.vector or [0.0] * self._vector_dim,
            DocumentMetadataSchema.ORGANIZE: doc.organize,
            DocumentMetadataSchema.METADATA: doc.metadata,
            DocumentMetadataSchema.RELATION: doc.relation or {},
        }
    
    def _generate_id(self) -> int:
        """生成唯一ID"""
        import time
        return int(time.time() * 1000)
    
    # ==================== 查询操作 ====================
    
    def get_by_id(self, doc_id: int) -> Optional[DocumentMetadata]:
        """根据ID获取文档"""
        results = super().get_by_id(doc_id)
        if results:
            return self._from_dict(results[0])
        return None
    
    def get_by_name(self, doc_name: str, kb_id: Optional[int] = None) -> Optional[DocumentMetadata]:
        """
        根据名称获取文档
        
        Args:
            doc_name: 文档名称
            kb_id: 可选，按知识库过滤
        """
        if kb_id:
            filter_expr = f'{DocumentMetadataSchema.DOC_NAME} == "{doc_name}" and {DocumentMetadataSchema.KB_ID} == {kb_id}'
        else:
            filter_expr = f'{DocumentMetadataSchema.DOC_NAME} == "{doc_name}"'
        
        results = self.query(filter_expr)
        if results:
            return self._from_dict(results[0])
        return None
    
    def list_by_kb(self, kb_id: int, limit: Optional[int] = None) -> List[DocumentMetadata]:
        """
        列出某个知识库下的所有文档
        
        Args:
            kb_id: 知识库ID
            limit: 限制数量
            
        Returns:
            文档列表
        """
        filter_expr = f"{DocumentMetadataSchema.KB_ID} == {kb_id}"
        results = self.query(filter_expr, limit=limit)
        return [self._from_dict(r) for r in results]
    
    def list_all(self, limit: Optional[int] = None) -> List[DocumentMetadata]:
        """列出所有文档"""
        results = self.query(filter_expr="", limit=limit)
        return [self._from_dict(r) for r in results]
    
    def search_by_vector(self,
                         vector: List[float],
                         kb_id: Optional[int] = None,
                         limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        向量搜索文档
        
        Args:
            vector: 查询向量
            kb_id: 可选，按知识库过滤
            limit: 返回数量
        """
        filter_expr = f"{DocumentMetadataSchema.KB_ID} == {kb_id}" if kb_id else None
        
        return self.search(
            vectors=vector,
            filter_expr=filter_expr,
            limit=limit
        )[0]
    
    def search_by_keyword(self,
                          keyword: str,
                          kb_id: Optional[int] = None,
                          limit: Optional[int] = None) -> List[DocumentMetadata]:
        """
        按关键词搜索文档
        
        Args:
            keyword: 关键词
            kb_id: 可选，按知识库过滤
            limit: 限制数量
        """
        filter_parts = [f'{DocumentMetadataSchema.KEYWORDS} contains "{keyword}"']
        if kb_id:
            filter_parts.append(f"{DocumentMetadataSchema.KB_ID} == {kb_id}")
        
        filter_expr = " and ".join(filter_parts)
        results = self.query(filter_expr, limit=limit)
        return [self._from_dict(r) for r in results]
    
    def _from_dict(self, data: Dict[str, Any]) -> DocumentMetadata:
        """从字典创建 DocumentMetadata"""
        return DocumentMetadata(
            doc_id=data[DocumentMetadataSchema.DOC_ID],
            kb_id=data[DocumentMetadataSchema.KB_ID],
            doc_name=data[DocumentMetadataSchema.DOC_NAME],
            tags=data.get(DocumentMetadataSchema.TAGS, []),
            keywords=data.get(DocumentMetadataSchema.KEYWORDS),
            abstract=data.get(DocumentMetadataSchema.ABSTRACT),
            vector=data.get(DocumentMetadataSchema.VECTOR),
            organize=data.get(DocumentMetadataSchema.ORGANIZE, []),
            metadata=data.get(DocumentMetadataSchema.METADATA, {}),
            relation=data.get(DocumentMetadataSchema.RELATION),
        )
    
    # ==================== 更新操作 ====================
    
    def update(self, doc_id: int, update_data: Dict[str, Any]) -> bool:
        """更新文档"""
        filter_expr = f"{DocumentMetadataSchema.DOC_ID} == {doc_id}"
        data = {DocumentMetadataSchema.DOC_ID: doc_id}
        data.update(update_data)
        
        try:
            self.upsert(data)
            return True
        except Exception as e:
            logger.error(f"更新文档失败: {e}")
            return False
    
    def update_name(self, doc_id: int, doc_name: str) -> bool:
        return self.update(doc_id, {DocumentMetadataSchema.DOC_NAME: doc_name})
    
    def update_abstract(self, doc_id: int, abstract: str) -> bool:
        return self.update(doc_id, {DocumentMetadataSchema.ABSTRACT: abstract})
    
    def update_keywords(self, doc_id: int, keywords: List[str]) -> bool:
        return self.update(doc_id, {DocumentMetadataSchema.KEYWORDS: keywords})
    
    def update_vector(self, doc_id: int, vector: List[float]) -> bool:
        return self.update(doc_id, {DocumentMetadataSchema.VECTOR: vector})
    
    def update_metadata(self, doc_id: int, metadata: Dict[str, Any]) -> bool:
        return self.update(doc_id, {DocumentMetadataSchema.METADATA: metadata})
    
    def update_tags(self, doc_id: int, tags: List[str]) -> bool:
        return self.update(doc_id, {DocumentMetadataSchema.TAGS: tags})
    
    def update_relation(self, doc_id: int, relation: Dict[str, Any]) -> bool:
        return self.update(doc_id, {DocumentMetadataSchema.RELATION: relation})
    
    # ==================== 删除操作 ====================
    
    def delete(self, doc_id: int) -> bool:
        """删除文档"""
        try:
            filter_expr = f"{DocumentMetadataSchema.DOC_ID} == {doc_id}"
            super().delete(filter_expr)
            return True
        except Exception as e:
            logger.error(f"删除文档失败: {e}")
            return False
    
    def delete_by_kb(self, kb_id: int) -> int:
        """
        删除某个知识库下的所有文档
        
        Returns:
            删除数量
        """
        filter_expr = f"{DocumentMetadataSchema.KB_ID} == {kb_id}"
        return super().delete(filter_expr)
    
    def delete_by_name(self, doc_name: str, kb_id: Optional[int] = None) -> bool:
        """根据名称删除文档"""
        doc = self.get_by_name(doc_name, kb_id)
        if doc:
            return self.delete(doc.doc_id)
        return False
    
    # ==================== 统计操作 ====================
    
    def count(self, kb_id: Optional[int] = None) -> int:
        """获取文档数量"""
        if kb_id:
            filter_expr = f"{DocumentMetadataSchema.KB_ID} == {kb_id}"
            return super().count(filter_expr)
        return super().count()
    
    def get_stats(self, kb_id: Optional[int] = None) -> Dict[str, Any]:
        """获取统计信息"""
        stats = super().get_stats()
        stats["type"] = "document_metadata"
        stats["count"] = self.count(kb_id)
        return stats


# 便捷函数
def create_document_table(vector_dim: Optional[int] = None) -> DocumentTable:
    """创建文档表管理器并初始化"""
    table = DocumentTable(vector_dim)
    table.init_schema()
    return table