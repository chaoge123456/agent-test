"""
知识库表管理器
==============
实现知识库表的 CRUD、索引构建等操作。
"""

import logging
from typing import Any, Dict, List, Optional, Union

from .base_table import BaseTable
from .config import get_config
from .models import KnowledgeBase, KnowledgeBaseSchema

logger = logging.getLogger(__name__)


class KnowledgeBaseTable(BaseTable):
    """
    知识库表管理器
    
    提供知识库的创建、查询、更新、删除、索引构建等操作。
    """
    
    PRIMARY_FIELD = KnowledgeBaseSchema.KB_ID
    VECTOR_FIELD = KnowledgeBaseSchema.VECTOR
    
    def __init__(self, vector_dim: Optional[int] = None):
        cfg = get_config()
        table_name = cfg.get_table_config("knowledge_base").get("collection_name", "knowledge_base")
        super().__init__(table_name, vector_dim)
    
    # ==================== 初始化 ====================
    
    def init_schema(self, 
                    vector_dim: Optional[int] = None,
                    recreate: bool = False) -> "KnowledgeBaseTable":
        """
        初始化表结构
        
        Args:
            vector_dim: 向量维度，覆盖默认配置
            recreate: 是否重建表（删除重建）
            
        Returns:
            self
        """
        if vector_dim:
            self._vector_dim = vector_dim
        
        if recreate and self.exists():
            self.drop_collection()
        
        fields = KnowledgeBaseSchema.get_fields(self._vector_dim)
        self.create_collection(fields=fields)
        self.create_index()
        
        return self
    
    # ==================== 插入操作 ====================
    
    def insert(self, 
               data: Union[KnowledgeBase, Dict[str, Any], List[Dict[str, Any]]],
               batch_size: Optional[int] = None) -> List[int]:
        """
        插入知识库数据
        
        Args:
            data: 知识库数据
            batch_size: 批量大小
            
        Returns:
            主键列表
        """
        # 转换为字典格式
        if isinstance(data, KnowledgeBase):
            data = [self._to_dict(data)]
        elif isinstance(data, dict):
            data = [data]
        
        return super().insert(data, batch_size)
    
    def insert_knowledge_base(self,
                               kb_name: str,
                               description: str,
                               tags: List[str],
                               vector: List[float],
                               metadata: Optional[Dict[str, Any]] = None,
                               kb_id: Optional[int] = None) -> int:
        """
        插入单条知识库记录
        
        Args:
            kb_name: 知识库名称
            description: 知识库描述
            tags: 标签列表
            vector: 向量
            metadata: 元数据
            kb_id: 指定的主键ID，若为 None 则自动生成
            
        Returns:
            插入的知识库ID
        """
        from pymilvus import DataType
        
        # 构建数据
        data = {
            KnowledgeBaseSchema.KB_ID: kb_id or self._generate_id(),
            KnowledgeBaseSchema.KB_NAME: kb_name,
            KnowledgeBaseSchema.DESCRIPTION: description,
            KnowledgeBaseSchema.TAGS: tags,
            KnowledgeBaseSchema.VECTOR: vector,
            KnowledgeBaseSchema.METADATA: metadata or {},
        }
        
        result = self.insert(data)
        return result[0] if result else -1
    
    def _to_dict(self, kb: KnowledgeBase) -> Dict[str, Any]:
        """将 KnowledgeBase 转换为字典"""
        return {
            KnowledgeBaseSchema.KB_ID: kb.kb_id,
            KnowledgeBaseSchema.KB_NAME: kb.kb_name,
            KnowledgeBaseSchema.DESCRIPTION: kb.description,
            KnowledgeBaseSchema.TAGS: kb.tags,
            KnowledgeBaseSchema.VECTOR: kb.vector,
            KnowledgeBaseSchema.METADATA: kb.metadata or {},
        }
    
    def _generate_id(self) -> int:
        """生成唯一ID"""
        import time
        return int(time.time() * 1000)
    
    # ==================== 查询操作 ====================
    
    def get_by_id(self, kb_id: int) -> Optional[KnowledgeBase]:
        """
        根据ID获取知识库
        
        Args:
            kb_id: 知识库ID
            
        Returns:
            KnowledgeBase 或 None
        """
        results = super().get_by_id(kb_id)
        if results:
            return self._from_dict(results[0])
        return None
    
    def get_by_name(self, kb_name: str) -> Optional[KnowledgeBase]:
        """
        根据名称获取知识库
        
        Args:
            kb_name: 知识库名称
            
        Returns:
            KnowledgeBase 或 None
        """
        filter_expr = f'{KnowledgeBaseSchema.KB_NAME} == "{kb_name}"'
        results = self.query(filter_expr)
        
        if results:
            return self._from_dict(results[0])
        return None
    
    def list_all(self, limit: Optional[int] = None) -> List[KnowledgeBase]:
        """
        列出所有知识库
        
        Args:
            limit: 限制数量
            
        Returns:
            知识库列表
        """
        results = self.query(
            filter_expr="",
            limit=limit
        )
        return [self._from_dict(r) for r in results]
    
    def search_by_vector(self,
                         vector: List[float],
                         limit: Optional[int] = None,
                         filter_expr: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        向量搜索知识库
        
        Args:
            vector: 查询向量
            limit: 返回数量
            filter_expr: 过滤表达式
            
        Returns:
            搜索结果
        """
        return self.search(
            vectors=vector,
            filter_expr=filter_expr,
            limit=limit
        )[0]
    
    def _from_dict(self, data: Dict[str, Any]) -> KnowledgeBase:
        """从字典创建 KnowledgeBase"""
        return KnowledgeBase(
            kb_id=data[KnowledgeBaseSchema.KB_ID],
            kb_name=data[KnowledgeBaseSchema.KB_NAME],
            description=data[KnowledgeBaseSchema.DESCRIPTION],
            tags=data.get(KnowledgeBaseSchema.TAGS, []),
            vector=data[KnowledgeBaseSchema.VECTOR],
            metadata=data.get(KnowledgeBaseSchema.METADATA),
        )
    
    # ==================== 更新操作 ====================
    
    def update(self, kb_id: int, update_data: Dict[str, Any]) -> bool:
        """
        更新知识库
        
        Args:
            kb_id: 知识库ID
            update_data: 更新数据
            
        Returns:
            是否成功
        """
        filter_expr = f"{KnowledgeBaseSchema.KB_ID} == {kb_id}"
        
        # 转换为 update 格式
        data = {KnowledgeBaseSchema.KB_ID: kb_id}
        data.update(update_data)
        
        try:
            self.upsert(data)
            return True
        except Exception as e:
            logger.error(f"更新知识库失败: {e}")
            return False
    
    def update_name(self, kb_id: int, kb_name: str) -> bool:
        """更新知识库名称"""
        return self.update(kb_id, {KnowledgeBaseSchema.KB_NAME: kb_name})
    
    def update_description(self, kb_id: int, description: str) -> bool:
        """更新知识库描述"""
        return self.update(kb_id, {KnowledgeBaseSchema.DESCRIPTION: description})
    
    def update_tags(self, kb_id: int, tags: List[str]) -> bool:
        """更新知识库标签"""
        return self.update(kb_id, {KnowledgeBaseSchema.TAGS: tags})
    
    def update_vector(self, kb_id: int, vector: List[float]) -> bool:
        """更新知识库向量"""
        return self.update(kb_id, {KnowledgeBaseSchema.VECTOR: vector})
    
    def update_metadata(self, kb_id: int, metadata: Dict[str, Any]) -> bool:
        """更新知识库元数据"""
        return self.update(kb_id, {KnowledgeBaseSchema.METADATA: metadata})
    
    # ==================== 删除操作 ====================
    
    def delete(self, kb_id: int) -> bool:
        """
        删除知识库
        
        Args:
            kb_id: 知识库ID
            
        Returns:
            是否成功
        """
        try:
            filter_expr = f"{KnowledgeBaseSchema.KB_ID} == {kb_id}"
            super().delete(filter_expr)
            return True
        except Exception as e:
            logger.error(f"删除知识库失败: {e}")
            return False
    
    def delete_by_name(self, kb_name: str) -> bool:
        """根据名称删除知识库"""
        kb = self.get_by_name(kb_name)
        if kb:
            return self.delete(kb.kb_id)
        return False
    
    # ==================== 统计操作 ====================
    
    def count(self) -> int:
        """获取知识库总数"""
        return super().count()
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        stats = super().get_stats()
        stats["type"] = "knowledge_base"
        return stats


# 便捷函数
def create_knowledge_base_table(vector_dim: Optional[int] = None) -> KnowledgeBaseTable:
    """创建知识库表管理器并初始化"""
    table = KnowledgeBaseTable(vector_dim)
    table.init_schema()
    return table