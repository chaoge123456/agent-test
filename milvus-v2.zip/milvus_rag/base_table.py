"""
Milvus 表基类
=============
提供通用的 CRUD 索引构建等基础功能。
"""

import logging
import time
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Tuple, Union

from pymilvus import (
    Collection,
    CollectionSchema,
    Index,
    IndexType,
    connections,
    utility,
)

# 度量类型常量
METRIC_TYPES = {
    "L2": "L2",
    "IP": "IP", 
    "COSINE": "IP"  # Milvus 中 COSINE 等同于归一化后的 IP
}

from .config import config, get_config

logger = logging.getLogger(__name__)


class BaseTable(ABC):
    """
    Milvus 表基类
    
    提供通用的集合管理、索引构建、CRUD 操作。
    """
    
    # 子类必须覆盖
    PRIMARY_FIELD: str = "id"
    VECTOR_FIELD: str = "vector"
    
    def __init__(self, table_name: str, vector_dim: Optional[int] = None):
        """
        初始化表管理器
        
        Args:
            table_name: 表名
            vector_dim: 向量维度，若为 None 则从配置读取
        """
        self._table_name = table_name
        self._vector_dim = vector_dim
        self._collection: Optional[Collection] = None
        self._cfg = get_config()
        
        # 从配置获取向量维度
        if self._vector_dim is None:
            table_cfg = self._cfg.get_table_config(table_name)
            self._vector_dim = table_cfg.get("vector_dim", 1024)
    
    @property
    def table_name(self) -> str:
        return self._table_name
    
    @property
    def vector_dim(self) -> int:
        return self._vector_dim
    
    @property
    def collection(self) -> Collection:
        """获取 Collection 对象"""
        if self._collection is None:
            self._collection = Collection(self._table_name)
        return self._collection
    
    def _get_collection_config(self) -> Dict[str, Any]:
        """获取集合配置"""
        return self._cfg.get_collection_config(self._table_name)
    
    # ==================== 集合操作 ====================
    
    def exists(self) -> bool:
        """检查集合是否存在"""
        return utility.has_collection(self._table_name, using=self._cfg.get("milvus.db_name", "default"))
    
    def create_collection(self, 
                         fields: List[Dict[str, Any]],
                         description: str = "",
                         shard_num: Optional[int] = None,
                         consistency_level: Optional[str] = None,
                         **kwargs) -> Collection:
        """
        创建集合
        
        Args:
            fields: 字段定义列表
            description: 集合描述
            shard_num: 分片数
            consistency_level: 一致性级别
            **kwargs: 其他参数
            
        Returns:
            Collection 对象
        """
        if self.exists():
            logger.warning(f"集合 {self._table_name} 已存在，跳过创建")
            return self.collection
        
        cfg = self._get_collection_config()
        
        shard_num = shard_num or cfg.get("shard_num", 2)
        consistency_level = consistency_level or cfg.get("consistency_level", "Bounded")
        
        schema = CollectionSchema(
            fields=fields,
            description=description or cfg.get("description", ""),
            **kwargs
        )
        
        collection = Collection(
            name=self._table_name,
            schema=schema,
            shard_num=shard_num,
            consistency_level=consistency_level
        )
        
        logger.info(f"集合 {self._table_name} 创建成功，分片数: {shard_num}")
        self._collection = collection
        return collection
    
    def drop_collection(self) -> bool:
        """
        删除集合
        
        Returns:
            是否成功
        """
        if not self.exists():
            logger.warning(f"集合 {self._table_name} 不存在")
            return False
        
        utility.drop_collection(self._table_name)
        self._collection = None
        logger.info(f"集合 {self._table_name} 已删除")
        return True
    
    def get_collection(self, refresh: bool = False) -> Collection:
        """
        获取集合
        
        Args:
            refresh: 是否强制刷新
            
        Returns:
            Collection 对象
        """
        if refresh or self._collection is None:
            self._collection = Collection(self._table_name)
        return self._collection
    
    def load_collection(self, refresh: bool = False) -> None:
        """
        加载集合到内存
        
        Args:
            refresh: 是否强制刷新
        """
        collection = self.get_collection(refresh=refresh)
        collection.load()
        logger.info(f"集合 {self._table_name} 已加载")
    
    def release_collection(self) -> None:
        """释放集合内存"""
        if self._collection:
            self._collection.release()
            logger.info(f"集合 {self._table_name} 已释放")
    
    def flush_collection(self) -> None:
        """刷新集合数据"""
        if self._collection:
            self._collection.flush()
            logger.debug(f"集合 {self._table_name} 已刷新")
    
    # ==================== 索引操作 ====================
    
    def create_index(self, 
                     index_type: Optional[str] = None,
                     metric_type: Optional[str] = None,
                     params: Optional[Dict[str, Any]] = None) -> bool:
        """
        创建向量索引
        
        Args:
            index_type: 索引类型 (FLAT, IVF_FLAT, IVF_PQ, HNSW, DISKANN)
            metric_type: 度量类型 (L2, IP, COSINE)
            params: 索引参数字典
            
        Returns:
            是否成功
        """
        cfg = self._get_collection_config()
        index_cfg = cfg.get("index", {})
        
        index_type = index_type or index_cfg.get("vector_index_type", "HNSW")
        metric_type = metric_type or index_cfg.get("metric_type", "COSINE")
        
        # 构建索引参数
        index_params = params or self._build_index_params(index_type, index_cfg)
        
        logger.info(f"为 {self._table_name} 创建索引: {index_type}, 参数: {index_params}")
        
        index = Index(
            collection=self.collection,
            field_name=self.VECTOR_FIELD,
            index_type=index_type,
            metric_type=metric_type,
            params=index_params
        )
        
        index.wait_for_completion()
        logger.info(f"集合 {self._table_name} 索引创建完成")
        return True
    
    def _build_index_params(self, index_type: str, index_cfg: Dict) -> Dict[str, Any]:
        """构建索引参数"""
        if index_type == "HNSW":
            return {
                "M": index_cfg.get("M", 16),
                "efConstruction": index_cfg.get("efConstruction", 256)
            }
        elif index_type == "IVF_FLAT":
            return {
                "nlist": index_cfg.get("nlist", 128)
            }
        elif index_type == "IVF_PQ":
            return {
                "nlist": index_cfg.get("nlist", 128),
                "m": index_cfg.get("m", 16)
            }
        elif index_type == "DISKANN":
            return {}
        else:  # FLAT
            return {}
    
    def drop_index(self) -> bool:
        """删除索引"""
        try:
            self.collection.drop_index()
            logger.info(f"集合 {self._table_name} 索引已删除")
            return True
        except Exception as e:
            logger.warning(f"删除索引失败: {e}")
            return False
    
    # ==================== 插入操作 ====================
    
    def insert(self, 
               data: Union[Dict[str, Any], List[Dict[str, Any]]],
               batch_size: Optional[int] = None) -> List[int]:
        """
        插入数据
        
        Args:
            data: 要插入的数据，单条或批量
            batch_size: 批量大小
            
        Returns:
            插入的主键列表
        """
        if not isinstance(data, list):
            data = [data]
        
        batch_size = batch_size or self._cfg.batch_size
        
        # 分批插入
        primary_values = []
        for i in range(0, len(data), batch_size):
            batch = data[i:i + batch_size]
            result = self.collection.insert(batch)
            primary_values.extend(result.primary_keys)
        
        logger.info(f"已插入 {len(primary_values)} 条数据到 {self._table_name}")
        return primary_values
    
    def insert_flush(self, 
                     data: Union[Dict[str, Any], List[Dict[str, Any]]],
                     batch_size: Optional[int] = None,
                     auto_flush: bool = True) -> List[int]:
        """
        插入数据并刷新
        
        Args:
            data: 要插入的数据
            batch_size: 批量大小
            auto_flush: 是否自动刷新
            
        Returns:
            插入的主键列表
        """
        primary_values = self.insert(data, batch_size)
        
        if auto_flush:
            self.flush_collection()
        
        return primary_values
    
    # ==================== 查询操作 ====================
    
    def search(self,
               vectors: Union[List[List[float]], List[float]],
               filter_expr: Optional[str] = None,
               output_fields: Optional[List[str]] = None,
               limit: Optional[int] = None,
               metric_type: Optional[str] = None,
               params: Optional[Dict[str, Any]] = None,
               **kwargs) -> List[List[Dict[str, Any]]]:
        """
        向量搜索
        
        Args:
            vectors: 查询向量
            filter_expr: 过滤表达式
            output_fields: 输出字段
            limit: 返回结果数
            metric_type: 度量类型
            params: 搜索参数
            **kwargs: 其他参数
            
        Returns:
            搜索结果列表
        """
        # 确保 vectors 是列表的列表
        if isinstance(vectors[0], (int, float)):
            vectors = [vectors]
        
        limit = limit or self._cfg.default_limit
        
        # 搜索参数
        search_params = params or self._get_search_params()
        
        # 构建 output_fields
        if output_fields is None:
            output_fields = ["*"]
        
        results = self.collection.search(
            data=vectors,
            anns_field=self.VECTOR_FIELD,
            param=search_params,
            expr=filter_expr,
            output_fields=output_fields,
            limit=limit,
            metric_type=metric_type,
            **kwargs
        )
        
        # 格式化结果
        formatted_results = []
        for hits in results:
            formatted_results.append([hit.to_dict() for hit in hits])
        
        return formatted_results
    
    def _get_search_params(self, ef: Optional[int] = None) -> Dict[str, Any]:
        """获取搜索参数"""
        cfg = self._get_collection_config()
        index_cfg = cfg.get("index", {})
        metric_type = index_cfg.get("metric_type", "COSINE")
        
        if metric_type == "COSINE":
            metric_type = "IP"  # Milvus 中 COSINE 等同于归一化后的 IP
        
        params = {"metric_type": metric_type}
        
        # 根据索引类型添加参数
        index_type = index_cfg.get("vector_index_type", "HNSW")
        if index_type == "HNSW":
            params["ef"] = ef or index_cfg.get("ef", 64)
        elif index_type.startswith("IVF"):
            params["nprobe"] = index_cfg.get("nprobe", 16)
        
        return params
    
    def query(self,
              filter_expr: str,
              output_fields: Optional[List[str]] = None,
              limit: Optional[int] = None,
              **kwargs) -> List[Dict[str, Any]]:
        """
        条件查询
        
        Args:
            filter_expr: 过滤表达式
            output_fields: 输出字段
            limit: 限制返回数量
            **kwargs: 其他参数
            
        Returns:
            查询结果
        """
        if output_fields is None:
            output_fields = ["*"]
        
        limit = limit or self._cfg.default_limit
        
        results = self.collection.query(
            expr=filter_expr,
            output_fields=output_fields,
            limit=limit,
            **kwargs
        )
        
        return results
    
    def get_by_id(self,
                  ids: Union[int, List[int]],
                  output_fields: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """
        根据主键查询
        
        Args:
            ids: 主键列表
            output_fields: 输出字段
            
        Returns:
            查询结果
        """
        if not isinstance(ids, list):
            ids = [ids]
        
        if output_fields is None:
            output_fields = ["*"]
        
        filter_expr = f"{self.PRIMARY_FIELD} in {ids}"
        return self.query(filter_expr, output_fields)
    
    # ==================== 更新操作 ====================
    
    def update(self,
               filter_expr: str,
               update_data: Dict[str, Any]) -> int:
        """
        更新数据
        
        Args:
            filter_expr: 过滤表达式
            update_data: 更新数据
            
        Returns:
            更新数量
        """
        try:
            result = self.collection.upsert(
                data=[update_data],
                upsert=False  # 真正的更新，不是 upsert
            )
            self.flush_collection()
            return result
        except Exception as e:
            # Milvus 2.x 不支持直接更新，可能需要删除后重新插入
            logger.warning(f"直接更新不支持，将尝试删除后重新插入: {e}")
            return 0
    
    def upsert(self,
               data: Union[Dict[str, Any], List[Dict[str, Any]]]) -> List[int]:
        """
        插入或更新 (upsert)
        
        Args:
            data: 要插入或更新的数据
            
        Returns:
            主键列表
        """
        if not isinstance(data, list):
            data = [data]
        
        # Milvus 使用 upsert 方法
        result = self.collection.upsert(data)
        self.flush_collection()
        
        return result.primary_keys if hasattr(result, 'primary_keys') else []
    
    # ==================== 删除操作 ====================
    
    def delete(self, filter_expr: str) -> int:
        """
        删除数据
        
        Args:
            filter_expr: 过滤表达式
            
        Returns:
            删除数量
        """
        result = self.collection.delete(filter_expr)
        self.flush_collection()
        logger.info(f"从 {self._table_name} 删除了 {result.delete_count} 条数据")
        return result.delete_count
    
    def delete_by_id(self, ids: Union[int, List[int]]) -> int:
        """
        根据主键删除
        
        Args:
            ids: 主键列表
            
        Returns:
            删除数量
        """
        if not isinstance(ids, list):
            ids = [ids]
        
        filter_expr = f"{self.PRIMARY_FIELD} in {ids}"
        return self.delete(filter_expr)
    
    # ==================== 统计操作 ====================
    
    def count(self, filter_expr: Optional[str] = None) -> int:
        """
        统计数量
        
        Args:
            filter_expr: 过滤表达式
            
        Returns:
            数量
        """
        if filter_expr:
            result = self.collection.query(
                expr=filter_expr,
                output_fields=["count(*)"]
            )
            return result[0].get("count(*)", 0) if result else 0
        else:
            return self.collection.num_entities
    
    def get_stats(self) -> Dict[str, Any]:
        """获取集合统计信息"""
        return {
            "name": self._table_name,
            "num_entities": self.collection.num_entities,
            "partitions": self.collection.partitions,
            "indexes": self.collection.indexes,
        }
    
    # ==================== 事务操作 ====================
    
    def begin(self) -> None:
        """开始事务"""
        self.collection.begin()
    
    def commit(self) -> None:
        """提交事务"""
        self.collection.commit()
    
    def rollback(self) -> None:
        """回滚事务"""
        self.collection.rollback()