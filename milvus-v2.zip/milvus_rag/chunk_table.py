"""
文档切片向量表管理器
====================
实现文档切片向量表的 CRUD、索引构建等操作。
用于存储 OCR 提取并 chunk 后的文本内容。
"""

import logging
from typing import Any, Dict, List, Optional, Union

from .base_table import BaseTable
from .config import get_config
from .models import Chunk, ChunkSchema

logger = logging.getLogger(__name__)


class ChunkTable(BaseTable):
    """
    文档切片向量表管理器
    
    存储文档文本内容的信息，通过 OCR 模型提取后，
    经过 chunk 切分存储到向量表中。
    支持按文档 (doc_id) 和页面 (page_id) 进行过滤查询。
    """
    
    PRIMARY_FIELD = ChunkSchema.CHUNK_ID
    VECTOR_FIELD = ChunkSchema.VECTOR
    
    def __init__(self, vector_dim: Optional[int] = None):
        cfg = get_config()
        table_name = cfg.get_table_config("chunk").get("collection_name", "chunk")
        super().__init__(table_name, vector_dim)
    
    # ==================== 初始化 ====================
    
    def init_schema(self, 
                    vector_dim: Optional[int] = None,
                    recreate: bool = False) -> "ChunkTable":
        """初始化表结构"""
        if vector_dim:
            self._vector_dim = vector_dim
        
        if recreate and self.exists():
            self.drop_collection()
        
        fields = ChunkSchema.get_fields(self._vector_dim)
        self.create_collection(fields=fields)
        self.create_index()
        
        return self
    
    # ==================== 插入操作 ====================
    
    def insert(self, 
               data: Union[Chunk, Dict[str, Any], List[Dict[str, Any]]],
               batch_size: Optional[int] = None) -> List[int]:
        """插入切片数据"""
        if isinstance(data, Chunk):
            data = [self._to_dict(data)]
        elif isinstance(data, dict):
            data = [data]
        
        return super().insert(data, batch_size)
    
    def insert_chunk(self,
                     doc_id: int,
                     type: str,
                     content: str,
                     vector: List[float],
                     chunk_id: Optional[int] = None,
                     page_id: Optional[int] = None,
                     metadata: Optional[Dict[str, Any]] = None,
                     keyword: Optional[List[str]] = None) -> int:
        """
        插入单条切片记录
        
        Args:
            doc_id: 所属文档ID
            type: 类型 (text, table, image caption 等)
            content: 块文本内容
            vector: embedding 向量
            chunk_id: 指定的主键ID
            page_id: 文档第几页
            metadata: 显示和隐式引用、pre、next
            keyword: 关键词
            
        Returns:
            插入的切片ID
        """
        data = {
            ChunkSchema.CHUNK_ID: chunk_id or self._generate_id(),
            ChunkSchema.DOC_ID: doc_id,
            ChunkSchema.PAGE_ID: page_id,
            ChunkSchema.TYPE: type,
            ChunkSchema.CONTENT: content,
            ChunkSchema.VECTOR: vector,
            ChunkSchema.METADATA: metadata or {},
            ChunkSchema.KEYWORD: keyword or [],
        }
        
        result = self.insert(data)
        return result[0] if result else -1
    
    def insert_batch(self,
                     doc_id: int,
                     chunks: List[Dict[str, Any]]) -> List[int]:
        """
        批量插入切片
        
        Args:
            doc_id: 文档ID
            chunks: 切片列表，每个元素包含:
                - type: 类型 (text, table, image caption)
                - content: 内容
                - vector: 向量
                - page_id: 页码 (可选)
                - metadata: 元数据 (可选)
                - keyword: 关键词 (可选)
                
        Returns:
            插入的主键列表
        """
        data = []
        for chunk in chunks:
            data.append({
                ChunkSchema.CHUNK_ID: self._generate_id(),
                ChunkSchema.DOC_ID: doc_id,
                ChunkSchema.PAGE_ID: chunk.get("page_id"),
                ChunkSchema.TYPE: chunk["type"],
                ChunkSchema.CONTENT: chunk["content"],
                ChunkSchema.VECTOR: chunk["vector"],
                ChunkSchema.METADATA: chunk.get("metadata", {}),
                ChunkSchema.KEYWORD: chunk.get("keyword", []),
            })
        
        return self.insert(data)
    
    def insert_text_chunks(self,
                           doc_id: int,
                           texts: List[str],
                           vectors: List[List[float]],
                           chunk_type: str = "text",
                           page_id: Optional[int] = None) -> List[int]:
        """
        批量插入文本切片
        
        Args:
            doc_id: 文档ID
            texts: 文本列表
            vectors: 向量列表
            chunk_type: 切片类型
            page_id: 页码
            
        Returns:
            插入的主键列表
        """
        chunks = []
        for text, vector in zip(texts, vectors):
            chunks.append({
                "type": chunk_type,
                "content": text,
                "vector": vector,
                "page_id": page_id,
            })
        
        return self.insert_batch(doc_id, chunks)
    
    def _to_dict(self, chunk: Chunk) -> Dict[str, Any]:
        """转换为字典"""
        return {
            ChunkSchema.CHUNK_ID: chunk.chunk_id,
            ChunkSchema.DOC_ID: chunk.doc_id,
            ChunkSchema.PAGE_ID: chunk.page_id,
            ChunkSchema.TYPE: chunk.type,
            ChunkSchema.CONTENT: chunk.content,
            ChunkSchema.VECTOR: chunk.vector,
            ChunkSchema.METADATA: chunk.metadata or {},
            ChunkSchema.KEYWORD: chunk.keyword or [],
        }
    
    def _generate_id(self) -> int:
        """生成唯一ID"""
        import time
        return int(time.time() * 1000)
    
    # ==================== 查询操作 ====================
    
    def get_by_id(self, chunk_id: int) -> Optional[Chunk]:
        """根据ID获取切片"""
        results = super().get_by_id(chunk_id)
        if results:
            return self._from_dict(results[0])
        return None
    
    def list_by_doc(self, 
                    doc_id: int, 
                    chunk_type: Optional[str] = None,
                    limit: Optional[int] = None) -> List[Chunk]:
        """
        列出某个文档的所有切片
        
        Args:
            doc_id: 文档ID
            chunk_type: 可选，按类型过滤
            limit: 限制数量
            
        Returns:
            切片列表
        """
        if chunk_type:
            filter_expr = f"{ChunkSchema.DOC_ID} == {doc_id} and {ChunkSchema.TYPE} == \"{chunk_type}\""
        else:
            filter_expr = f"{ChunkSchema.DOC_ID} == {doc_id}"
        
        results = self.query(filter_expr, limit=limit)
        return [self._from_dict(r) for r in results]
    
    def list_by_page(self, doc_id: int, page_id: int) -> List[Chunk]:
        """
        列出某个页面的所有切片
        
        Args:
            doc_id: 文档ID
            page_id: 页码
            
        Returns:
            切片列表
        """
        filter_expr = f"{ChunkSchema.DOC_ID} == {doc_id} and {ChunkSchema.PAGE_ID} == {page_id}"
        results = self.query(filter_expr)
        return [self._from_dict(r) for r in results]
    
    def list_by_type(self, 
                     chunk_type: str, 
                     kb_id: Optional[int] = None,
                     limit: Optional[int] = None) -> List[Chunk]:
        """
        按类型列出切片
        
        Args:
            chunk_type: 切片类型
            kb_id: 可选，按知识库过滤（需要关联文档表）
            limit: 限制数量
            
        Returns:
            切片列表
        """
        # 注意: kb_id 过滤需要关联文档表，这里简化处理
        filter_expr = f'{ChunkSchema.TYPE} == "{chunk_type}"'
        results = self.query(filter_expr, limit=limit)
        return [self._from_dict(r) for r in results]
    
    def list_all(self, limit: Optional[int] = None) -> List[Chunk]:
        """列出所有切片"""
        results = self.query(filter_expr="", limit=limit)
        return [self._from_dict(r) for r in results]
    
    def search_by_vector(self,
                         vector: List[float],
                         doc_id: Optional[int] = None,
                         chunk_type: Optional[str] = None,
                         limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        向量搜索切片
        
        Args:
            vector: 查询向量
            doc_id: 可选，按文档过滤
            chunk_type: 可选，按类型过滤
            limit: 返回数量
        """
        filter_parts = []
        if doc_id:
            filter_parts.append(f"{ChunkSchema.DOC_ID} == {doc_id}")
        if chunk_type:
            filter_parts.append(f'{ChunkSchema.TYPE} == "{chunk_type}"')
        
        filter_expr = " and ".join(filter_parts) if filter_parts else None
        
        return self.search(
            vectors=vector,
            filter_expr=filter_expr,
            limit=limit
        )[0]
    
    def search_by_keyword(self,
                          keyword: str,
                          doc_id: Optional[int] = None,
                          limit: Optional[int] = None) -> List[Chunk]:
        """
        按关键词搜索切片
        
        Args:
            keyword: 关键词
            doc_id: 可选，按文档过滤
            limit: 限制数量
        """
        filter_parts = [f'{ChunkSchema.KEYWORD} contains "{keyword}"']
        if doc_id:
            filter_parts.append(f"{ChunkSchema.DOC_ID} == {doc_id}")
        
        filter_expr = " and ".join(filter_parts)
        results = self.query(filter_expr, limit=limit)
        return [self._from_dict(r) for r in results]
    
    def get_chunks_with_context(self,
                                doc_id: int,
                                chunk_id: int,
                                context_size: int = 2) -> List[Chunk]:
        """
        获取切片的上下文（前后相邻的切片）
        
        Args:
            doc_id: 文档ID
            chunk_id: 目标切片ID
            context_size: 前后各获取多少条
            
        Returns:
            包含上下文的切片列表
        """
        # 获取目标切片
        target = self.get_by_id(chunk_id)
        if not target:
            return []
        
        # 获取同一文档的所有切片，按 chunk_id 排序
        all_chunks = self.list_by_doc(doc_id)
        all_chunks.sort(key=lambda x: x.chunk_id)
        
        # 找到目标位置
        try:
            idx = next(i for i, c in enumerate(all_chunks) if c.chunk_id == chunk_id)
        except StopIteration:
            return []
        
        # 获取上下文
        start = max(0, idx - context_size)
        end = min(len(all_chunks), idx + context_size + 1)
        
        return all_chunks[start:end]
    
    def _from_dict(self, data: Dict[str, Any]) -> Chunk:
        """从字典创建 Chunk"""
        return Chunk(
            chunk_id=data[ChunkSchema.CHUNK_ID],
            doc_id=data[ChunkSchema.DOC_ID],
            page_id=data.get(ChunkSchema.PAGE_ID),
            type=data[ChunkSchema.TYPE],
            content=data[ChunkSchema.CONTENT],
            vector=data[ChunkSchema.VECTOR],
            metadata=data.get(ChunkSchema.METADATA),
            keyword=data.get(ChunkSchema.KEYWORD),
        )
    
    # ==================== 更新操作 ====================
    
    def update(self, chunk_id: int, update_data: Dict[str, Any]) -> bool:
        """更新切片"""
        filter_expr = f"{ChunkSchema.CHUNK_ID} == {chunk_id}"
        data = {ChunkSchema.CHUNK_ID: chunk_id}
        data.update(update_data)
        
        try:
            self.upsert(data)
            return True
        except Exception as e:
            logger.error(f"更新切片失败: {e}")
            return False
    
    def update_content(self, chunk_id: int, content: str) -> bool:
        return self.update(chunk_id, {ChunkSchema.CONTENT: content})
    
    def update_vector(self, chunk_id: int, vector: List[float]) -> bool:
        return self.update(chunk_id, {ChunkSchema.VECTOR: vector})
    
    def update_metadata(self, chunk_id: int, metadata: Dict[str, Any]) -> bool:
        return self.update(chunk_id, {ChunkSchema.METADATA: metadata})
    
    def update_keywords(self, chunk_id: int, keyword: List[str]) -> bool:
        return self.update(chunk_id, {ChunkSchema.KEYWORD: keyword})
    
    # ==================== 删除操作 ====================
    
    def delete(self, chunk_id: int) -> bool:
        """删除切片"""
        try:
            filter_expr = f"{ChunkSchema.CHUNK_ID} == {chunk_id}"
            super().delete(filter_expr)
            return True
        except Exception as e:
            logger.error(f"删除切片失败: {e}")
            return False
    
    def delete_by_doc(self, doc_id: int) -> int:
        """删除某个文档的所有切片"""
        filter_expr = f"{ChunkSchema.DOC_ID} == {doc_id}"
        return super().delete(filter_expr)
    
    def delete_by_page(self, doc_id: int, page_id: int) -> int:
        """删除某个页面的所有切片"""
        filter_expr = f"{ChunkSchema.DOC_ID} == {doc_id} and {ChunkSchema.PAGE_ID} == {page_id}"
        return super().delete(filter_expr)
    
    def delete_by_type(self, doc_id: int, chunk_type: str) -> int:
        """删除某种类型的所有切片"""
        filter_expr = f"{ChunkSchema.DOC_ID} == {doc_id} and {ChunkSchema.TYPE} == \"{chunk_type}\""
        return super().delete(filter_expr)
    
    # ==================== 统计操作 ====================
    
    def count(self, doc_id: Optional[int] = None, chunk_type: Optional[str] = None) -> int:
        """获取切片数量"""
        filter_parts = []
        if doc_id:
            filter_parts.append(f"{ChunkSchema.DOC_ID} == {doc_id}")
        if chunk_type:
            filter_parts.append(f'{ChunkSchema.TYPE} == "{chunk_type}"')
        
        filter_expr = " and ".join(filter_parts) if filter_parts else None
        return super().count(filter_expr)
    
    def get_stats(self, doc_id: Optional[int] = None) -> Dict[str, Any]:
        """获取统计信息"""
        stats = super().get_stats()
        stats["type"] = "chunk"
        stats["count"] = self.count(doc_id)
        
        if doc_id:
            # 统计各类型数量
            types = ["text", "table", "image caption"]
            type_counts = {}
            for t in types:
                type_counts[t] = self.count(doc_id, t)
            stats["type_counts"] = type_counts
        
        return stats


# 便捷函数
def create_chunk_table(vector_dim: Optional[int] = None) -> ChunkTable:
    """创建切片表管理器并初始化"""
    table = ChunkTable(vector_dim)
    table.init_schema()
    return table