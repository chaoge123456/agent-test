"""
数据模型定义模块
================
定义各个数据表的字段 schema 和数据结构。
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from pymilvus import DataType


# ==================== 字段定义辅助函数 ====================

def create_varchar_field(name: str, max_length: int = 512, is_primary: bool = False, 
                         is_partition_key: bool = False, description: str = "") -> Dict[str, Any]:
    """创建 VarChar 字段定义"""
    return {
        "name": name,
        "dtype": DataType.VARCHAR,
        "max_length": max_length,
        "is_primary": is_primary,
        "is_partition_key": is_partition_key,
        "description": description
    }


def create_int64_field(name: str, is_primary: bool = False, 
                       is_partition_key: bool = False, description: str = "") -> Dict[str, Any]:
    """创建 Int64 字段定义"""
    return {
        "name": name,
        "dtype": DataType.INT64,
        "is_primary": is_primary,
        "is_partition_key": is_partition_key,
        "description": description
    }


def create_int16_field(name: str, is_primary: bool = False, 
                       is_partition_key: bool = False, description: str = "") -> Dict[str, Any]:
    """创建 Int16 字段定义"""
    return {
        "name": name,
        "dtype": DataType.INT16,
        "is_primary": is_primary,
        "is_partition_key": is_partition_key,
        "description": description
    }


def create_float_vector_field(name: str, dim: int, description: str = "") -> Dict[str, Any]:
    """创建 FloatVector 字段定义"""
    return {
        "name": name,
        "dtype": DataType.FLOAT_VECTOR,
        "dim": dim,
        "description": description
    }


def create_json_field(name: str, description: str = "") -> Dict[str, Any]:
    """创建 JSON 字段定义"""
    return {
        "name": name,
        "dtype": DataType.JSON,
        "description": description
    }


def create_array_field(name: str, element_type: DataType = DataType.VARCHAR,
                       max_capacity: int = 100, description: str = "") -> Dict[str, Any]:
    """创建 Array 字段定义"""
    return {
        "name": name,
        "dtype": DataType.ARRAY,
        "element_type": element_type,
        "max_capacity": max_capacity,
        "description": description
    }


def create_bool_field(name: str, description: str = "") -> Dict[str, Any]:
    """创建 Bool 字段定义"""
    return {
        "name": name,
        "dtype": DataType.BOOL,
        "description": description
    }


# ==================== 各表 Schema 定义 ====================

class KnowledgeBaseSchema:
    """知识库表 Schema"""
    
    TABLE_NAME = "knowledge_base"
    
    # 字段名定义
    KB_ID = "kb_id"
    KB_NAME = "kb_name"
    DESCRIPTION = "description"
    TAGS = "tags"
    VECTOR = "vector"
    METADATA = "metadata"
    
    @staticmethod
    def get_fields(vector_dim: int = 1024) -> List[Dict[str, Any]]:
        return [
            create_int64_field(KnowledgeBaseSchema.KB_ID, is_primary=True, description="知识库唯一ID"),
            create_varchar_field(KnowledgeBaseSchema.KB_NAME, max_length=512, description="知识库名称"),
            create_varchar_field(KnowledgeBaseSchema.DESCRIPTION, max_length=10000, description="知识库描述"),
            create_array_field(KnowledgeBaseSchema.TAGS, max_capacity=50, description="知识库标签"),
            create_float_vector_field(KnowledgeBaseSchema.VECTOR, dim=vector_dim, description="知识库向量"),
            create_json_field(KnowledgeBaseSchema.METADATA, description="知识库元数据"),
        ]


class DocumentMetadataSchema:
    """文档元数据表 Schema"""
    
    TABLE_NAME = "document_metadata"
    
    # 字段名定义
    DOC_ID = "doc_id"
    KB_ID = "kb_id"
    DOC_NAME = "doc_name"
    TAGS = "tags"
    KEYWORDS = "keywords"
    ABSTRACT = "abstract"
    VECTOR = "vector"
    ORGANIZE = "organize"
    METADATA = "metadata"
    RELATION = "relation"
    
    @staticmethod
    def get_fields(vector_dim: int = 1024) -> List[Dict[str, Any]]:
        return [
            create_int64_field(DocumentMetadataSchema.DOC_ID, is_primary=True, description="文档唯一ID"),
            create_int64_field(DocumentMetadataSchema.KB_ID, description="所属知识库ID"),
            create_varchar_field(DocumentMetadataSchema.DOC_NAME, max_length=512, description="文件名"),
            create_array_field(DocumentMetadataSchema.TAGS, max_capacity=50, description="标签"),
            create_array_field(DocumentMetadataSchema.KEYWORDS, max_capacity=100, description="关键词"),
            create_varchar_field(DocumentMetadataSchema.ABSTRACT, max_length=10000, description="文档摘要"),
            create_float_vector_field(DocumentMetadataSchema.VECTOR, dim=vector_dim, description="摘要向量"),
            create_array_field(DocumentMetadataSchema.ORGANIZE, max_capacity=10, description="组织方式"),
            create_json_field(DocumentMetadataSchema.METADATA, description="文档元数据"),
            create_json_field(DocumentMetadataSchema.RELATION, description="文档关联信息"),
        ]


class PageSummarySchema:
    """页级摘要向量表 Schema"""
    
    TABLE_NAME = "page_summary"
    
    # 字段名定义
    ROW_ID = "row_id"
    DOC_ID = "doc_id"
    ABSTRACT = "abstract"
    PAGE_ID = "page_id"
    VECTOR = "vector"
    PAGE_PATH = "page_path"
    KEYWORD = "keyword"
    METADATA = "metadata"
    
    @staticmethod
    def get_fields(vector_dim: int = 1024) -> List[Dict[str, Any]]:
        return [
            create_int64_field(PageSummarySchema.ROW_ID, is_primary=True, description="页面唯一ID"),
            create_int64_field(PageSummarySchema.DOC_ID, description="所属文档ID"),
            create_varchar_field(PageSummarySchema.ABSTRACT, max_length=10000, description="VLM生成的图像描述"),
            create_int16_field(PageSummarySchema.PAGE_ID, description="文档第几页"),
            create_float_vector_field(PageSummarySchema.VECTOR, dim=vector_dim, description="多模态embedding向量"),
            create_varchar_field(PageSummarySchema.PAGE_PATH, max_length=512, description="页面存储路径"),
            create_array_field(PageSummarySchema.KEYWORD, max_capacity=50, description="关键词"),
            create_json_field(PageSummarySchema.METADATA, description="页面元素信息"),
        ]


class PageMultiVectorSchema:
    """页级视觉多向量表 Schema"""
    
    TABLE_NAME = "page_multi_vector"
    
    # 字段名定义
    VEC_ID = "vec_id"
    TOKEN_VECTOR = "token_vector"
    PATCH_ID = "patch_id"
    DOC_ID = "doc_id"
    PAGE_ID = "page_id"
    METADATA = "metadata"
    
    @staticmethod
    def get_fields(vector_dim: int = 1024) -> List[Dict[str, Any]]:
        return [
            create_int64_field(PageMultiVectorSchema.VEC_ID, is_primary=True, description="主键"),
            create_float_vector_field(PageMultiVectorSchema.TOKEN_VECTOR, dim=vector_dim, description="patch的token向量"),
            create_int16_field(PageMultiVectorSchema.PATCH_ID, description="第几个patch"),
            create_int64_field(PageMultiVectorSchema.DOC_ID, description="所属文档ID"),
            create_int64_field(PageMultiVectorSchema.PAGE_ID, description="文档第几页"),
            create_json_field(PageMultiVectorSchema.METADATA, description="其他相关信息"),
        ]


class ChunkSchema:
    """文档切片向量表 Schema"""
    
    TABLE_NAME = "chunk"
    
    # 字段名定义
    CHUNK_ID = "chunk_id"
    DOC_ID = "doc_id"
    PAGE_ID = "page_id"
    TYPE = "type"
    CONTENT = "content"
    VECTOR = "vector"
    METADATA = "metadata"
    KEYWORD = "keyword"
    
    @staticmethod
    def get_fields(vector_dim: int = 1024) -> List[Dict[str, Any]]:
        return [
            create_int64_field(ChunkSchema.CHUNK_ID, is_primary=True, description="文本块唯一ID"),
            create_int64_field(ChunkSchema.DOC_ID, description="所属文档ID"),
            create_int64_field(ChunkSchema.PAGE_ID, description="文档第几页"),
            create_varchar_field(ChunkSchema.TYPE, max_length=32, description="类型"),
            create_varchar_field(ChunkSchema.CONTENT, max_length=65536, description="块文本内容"),
            create_float_vector_field(ChunkSchema.VECTOR, dim=vector_dim, description="embedding向量"),
            create_json_field(ChunkSchema.METADATA, description="引用信息"),
            create_array_field(ChunkSchema.KEYWORD, max_capacity=50, description="关键词"),
        ]


# ==================== 数据类定义 ====================

@dataclass
class KnowledgeBase:
    """知识库数据类"""
    kb_id: int
    kb_name: str
    description: str
    tags: List[str]
    vector: List[float]
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class DocumentMetadata:
    """文档元数据数据类"""
    doc_id: int
    kb_id: int
    doc_name: str
    tags: List[str]
    organize: List[str]
    metadata: Dict[str, Any]
    keywords: Optional[List[str]] = None
    abstract: Optional[str] = None
    vector: Optional[List[float]] = None
    relation: Optional[Dict[str, Any]] = None


@dataclass
class PageSummary:
    """页级摘要数据类"""
    row_id: int
    doc_id: int
    abstract: str
    page_id: int
    vector: List[float]
    page_path: str
    keyword: Optional[List[str]] = None
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class PageMultiVector:
    """页级视觉多向量数据类"""
    vec_id: int
    token_vector: List[float]
    patch_id: int
    doc_id: int
    page_id: int
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class Chunk:
    """文档切片数据类"""
    chunk_id: int
    doc_id: int
    type: str
    content: str
    vector: List[float]
    page_id: Optional[int] = None
    metadata: Optional[Dict[str, Any]] = None
    keyword: Optional[List[str]] = None


# ==================== Schema 注册表 ====================

SCHEMA_REGISTRY = {
    "knowledge_base": KnowledgeBaseSchema,
    "document_metadata": DocumentMetadataSchema,
    "page_summary": PageSummarySchema,
    "page_multi_vector": PageMultiVectorSchema,
    "chunk": ChunkSchema,
}


def get_schema(table_name: str):
    """获取表 schema 类"""
    return SCHEMA_REGISTRY.get(table_name)