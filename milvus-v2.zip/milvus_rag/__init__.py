"""
Milvus RAG 系统 - 知识库向量检索系统

这是一个基于 Milvus 向量数据库的 RAG (Retrieval Augmented Generation) 系统。

系统架构：
- 知识库表 (Knowledge Base Table): 存储知识库基本信息和语义路由向量
- 文档元数据表 (Document Metadata Table): 存储文档的元信息
- 页级摘要向量表 (Page Summary Table): 存储页面的 VLM 摘要和多模态 embedding
- 页级视觉多向量表 (Page Multi-vector Table): 存储页面的多向量表示
- 文档切片向量表 (Chunk Table): 存储文档文本切片的向量

核心功能：
- 分层语义路由
- 多向量表示支持
- 灵活的元数据管理
- 统一的配置和连接管理
- 完整的 CRUD 和索引构建

使用示例：
```python
from milvus_rag import MilvusRAGManager

# 初始化管理器
rag = MilvusRAGManager()

# 连接 Milvus
rag.connect()

# 创建知识库
rag.kb_table.insert_knowledge_base(
    kb_name="产品文档",
    description="包含产品使用说明书和技术文档",
    tags=["产品", "技术"],
    vector=[0.0] * 1024
)

# 关闭连接
rag.disconnect()
```
"""

from typing import Optional

from .config import get_config, config
from .connection import MilvusConnection, connect_milvus, disconnect_milvus
from .kb_table import KnowledgeBaseTable, create_knowledge_base_table
from .doc_table import DocumentTable, create_document_table
from .page_summary_table import PageSummaryTable, create_page_summary_table
from .page_multi_vector_table import PageMultiVectorTable, create_page_multi_vector_table
from .chunk_table import ChunkTable, create_chunk_table


__version__ = "1.0.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"
__description__ = "基于 Milvus 的 RAG 系统，支持分层语义路由和多向量表示"


class MilvusRAGManager:
    """
    Milvus RAG 系统管理器
    
    提供统一的接口来管理所有表的操作。
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        初始化 RAG 系统
        
        Args:
            config_path: 配置文件路径，未指定则使用默认路径
        """
        self._config = config
        if config_path:
            self._config.reload(config_path)
        
        self._connection = MilvusConnection()
        self._kb_table: Optional[KnowledgeBaseTable] = None
        self._doc_table: Optional[DocumentTable] = None
        self._page_summary_table: Optional[PageSummaryTable] = None
        self._page_multi_vector_table: Optional[PageMultiVectorTable] = None
        self._chunk_table: Optional[ChunkTable] = None
    
    def connect(self, **kwargs):
        """
        连接 Milvus
        
        Args:
            **kwargs: 连接参数，覆盖配置文件
        """
        self._connection.connect(**kwargs)
        
        # 初始化各个表
        if self._kb_table is None:
            self._kb_table = create_knowledge_base_table()
        
        if self._doc_table is None:
            self._doc_table = create_document_table()
        
        if self._page_summary_table is None:
            self._page_summary_table = create_page_summary_table()
        
        if self._page_multi_vector_table is None:
            self._page_multi_vector_table = create_page_multi_vector_table()
        
        if self._chunk_table is None:
            self._chunk_table = create_chunk_table()
    
    def disconnect(self):
        """断开 Milvus 连接"""
        self._connection.disconnect()
    
    @property
    def is_connected(self) -> bool:
        """检查连接状态"""
        return self._connection.is_connected
    
    @property
    def kb_table(self) -> KnowledgeBaseTable:
        if self._kb_table is None:
            self._kb_table = create_knowledge_base_table()
        return self._kb_table
    
    @property
    def doc_table(self) -> DocumentTable:
        if self._doc_table is None:
            self._doc_table = create_document_table()
        return self._doc_table
    
    @property
    def page_summary_table(self) -> PageSummaryTable:
        if self._page_summary_table is None:
            self._page_summary_table = create_page_summary_table()
        return self._page_summary_table
    
    @property
    def page_multi_vector_table(self) -> PageMultiVectorTable:
        if self._page_multi_vector_table is None:
            self._page_multi_vector_table = create_page_multi_vector_table()
        return self._page_multi_vector_table
    
    @property
    def chunk_table(self) -> ChunkTable:
        if self._chunk_table is None:
            self._chunk_table = create_chunk_table()
        return self._chunk_table
    
    def init_all_tables(self):
        """初始化所有表结构"""
        if not self.is_connected:
            self.connect()
        
        self.kb_table.init_schema()
        self.doc_table.init_schema()
        self.page_summary_table.init_schema()
        self.page_multi_vector_table.init_schema()
        self.chunk_table.init_schema()
    
    def drop_all_tables(self):
        """删除所有表（谨慎使用！）"""
        if not self.is_connected:
            self.connect()
        
        self.chunk_table.drop_collection()
        self.page_multi_vector_table.drop_collection()
        self.page_summary_table.drop_collection()
        self.doc_table.drop_collection()
        self.kb_table.drop_collection()
    
    def get_all_stats(self) -> dict:
        """获取系统整体统计信息"""
        stats = {
            "kb": self.kb_table.get_stats(),
            "document": self.doc_table.get_stats(),
            "page_summary": self.page_summary_table.get_stats(),
            "page_multi_vector": self.page_multi_vector_table.get_stats(),
            "chunk": self.chunk_table.get_stats(),
        }
        return stats
    
    def close(self):
        """关闭资源"""
        self.disconnect()


def create_rag_manager(config_path: Optional[str] = None) -> MilvusRAGManager:
    """
    创建 RAG 管理器实例
    
    Args:
        config_path: 配置文件路径
        
    Returns:
        MilvusRAGManager 实例
    """
    manager = MilvusRAGManager(config_path)
    manager.connect()
    return manager


def quick_start() -> MilvusRAGManager:
    """快速启动 RAG 系统（使用默认配置）"""
    return create_rag_manager()


if __name__ == "__main__":
    # 简单的测试
    print("Milvus RAG 系统 v1.0.0")
    print(f"配置文件: {__file__}")
    
    # 尝试连接 Milvus
    try:
        manager = quick_start()
        print("✅ Milvus 连接成功")
        
        # 初始化表
        manager.init_all_tables()
        print("✅ 表初始化完成")
        
        # 显示统计信息
        stats = manager.get_all_stats()
        print(f"📊 系统统计:")
        for table_name, info in stats.items():
            print(f"  {table_name}: {info.get('count', 0)} 条记录")
        
        manager.disconnect()
        print("✅ 连接已断开")
    except Exception as e:
        print(f"❌ 错误: {e}")
        import traceback
        print(traceback.format_exc())