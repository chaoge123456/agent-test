"""
Milvus RAG 系统配置模块
=======================
提供统一的配置管理，支持从 YAML 文件加载配置。
"""

import os
from pathlib import Path
from typing import Any, Dict, Optional

import yaml


class Config:
    """Milvus RAG 系统配置类"""
    
    _instance: Optional["Config"] = None
    _config: Dict[str, Any] = {}
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if not self._config:
            self._load_config()
    
    def _load_config(self, config_path: Optional[str] = None) -> None:
        """加载配置文件"""
        if config_path is None:
            # 默认查找当前目录或父目录的 config.yaml
            search_paths = [
                Path(__file__).parent / "config.yaml",
                Path.cwd() / "config.yaml",
                Path.cwd().parent / "config.yaml",
            ]
            for path in search_paths:
                if path.exists():
                    config_path = str(path)
                    break
        
        if config_path and os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as f:
                self._config = yaml.safe_load(f) or {}
        else:
            raise FileNotFoundError(f"配置文件未找到: {config_path}")
    
    def reload(self, config_path: Optional[str] = None) -> None:
        """重新加载配置"""
        self._config = {}
        self._load_config(config_path)
    
    def get(self, key: str, default: Any = None) -> Any:
        """获取配置项，支持点号分隔的多级键"""
        keys = key.split('.')
        value = self._config
        
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
                if value is None:
                    return default
            else:
                return default
        
        return value
    
    @property
    def milvus_host(self) -> str:
        return self.get("milvus.host", "localhost")
    
    @property
    def milvus_port(self) -> int:
        return self.get("milvus.port", 19530)
    
    @property
    def milvus_user(self) -> str:
        return self.get("milvus.user", "")
    
    @property
    def milvus_password(self) -> str:
        return self.get("milvus.password", "")
    
    @property
    def milvus_db(self) -> str:
        return self.get("milvus.db_name", "default")
    
    @property
    def milvus_timeout(self) -> int:
        return self.get("milvus.timeout", 30)
    
    @property
    def default_shard_num(self) -> int:
        return self.get("collection.default_shard_num", 2)
    
    @property
    def consistency_level(self) -> str:
        return self.get("collection.consistency_level", "Bounded")
    
    @property
    def batch_size(self) -> int:
        return self.get("ingestion.batch_size", 100)
    
    @property
    def default_limit(self) -> int:
        return self.get("ingestion.default_limit", 10)
    
    @property
    def log_level(self) -> str:
        return self.get("logging.level", "INFO")
    
    def get_table_config(self, table_name: str) -> Dict[str, Any]:
        """获取指定表的配置"""
        return self.get(f"tables.{table_name}", {})
    
    def get_collection_config(self, table_name: str) -> Dict[str, Any]:
        """获取集合级别的配置（合并默认配置和表特定配置）"""
        default = {
            "shard_num": self.default_shard_num,
            "consistency_level": self.consistency_level,
        }
        
        collection_cfg = self.get("collection", {})
        table_cfg = self.get_table_config(table_name)
        
        # 合并配置，表配置优先
        result = {**default, **collection_cfg, **table_cfg}
        
        # 处理索引配置
        index_cfg = table_cfg.get("index", collection_cfg.get("index", {}))
        result["index"] = index_cfg
        
        return result
    
    @property
    def all_config(self) -> Dict[str, Any]:
        """获取完整配置"""
        return self._config.copy()


def get_config(config_path: Optional[str] = None) -> Config:
    """获取配置单例"""
    config = Config()
    if config_path:
        config.reload(config_path)
    return config


# 全局配置实例
config = get_config()