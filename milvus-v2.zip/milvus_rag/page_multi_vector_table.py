"""
页级视觉多向量表管理器
=====================
实现页级视觉多向量表的 CRUD、索引构建等操作。
用于存储 ColPali/ColQwen 等多向量表示。
"""

import logging
from typing import Any, Dict, List, Optional, Union

from .base_table import BaseTable
from .config import get_config
from .models import PageMultiVector, PageMultiVectorSchema

logger = logging.getLogger(__name__)


class PageMultiVectorTable(BaseTable):
    """
    页级视觉多向量表管理器
    
    存储页面的多向量表示（类似 ColPali/ColQwen）。
    单个页面会编码为多个向量，通过 patch_id 标识，
    通过 (doc_id, page_id) 聚合同一页面的所有向量。
    """
    
    PRIMARY_FIELD = PageMultiVectorSchema.VEC_ID
    VECTOR_FIELD = PageMultiVectorSchema.TOKEN_VECTOR
    
    def __init__(self, vector_dim: Optional[int] = None):
        cfg = get_config()
        table_name = cfg.get_table_config("page_multi_vector").get("collection_name", "page_multi_vector")
        super().__init__(table_name, vector_dim)
    
    # ==================== 初始化 ====================
    
    def init_schema(self, 
                    vector_dim: Optional[int] = None,
                    recreate: bool = False) -> "PageMultiVectorTable":
        """初始化表结构"""
        if vector_dim:
            self._vector_dim = vector_dim
        
        if recreate and self.exists():
            self.drop_collection()
        
        fields = PageMultiVectorSchema.get_fields(self._vector_dim)
        self.create_collection(fields=fields)
        self.create_index()
        
        return self
    
    # ==================== 插入操作 ====================
    
    def insert(self, 
               data: Union[PageMultiVector, Dict[str, Any], List[Dict[str, Any]]],
               batch_size: Optional[int] = None) -> List[int]:
        """插入多向量数据"""
        if isinstance(data, PageMultiVector):
            data = [self._to_dict(data)]
        elif isinstance(data, dict):
            data = [data]
        
        return super().insert(data, batch_size)
    
    def insert_patch(self,
                     doc_id: int,
                     page_id: int,
                     token_vector: List[float],
                     patch_id: int,
                     vec_id: Optional[int] = None,
                     metadata: Optional[Dict[str, Any]] = None) -> int:
        """
        插入单个 patch 的向量
        
        Args:
            doc_id: 所属文档ID
            page_id: 文档第几页
            token_vector: patch 的 token 向量
            patch_id: 第几个 patch (从 0 开始)
            vec_id: 指定的主键ID
            metadata: 其他相关信息
            
        Returns:
            插入的向量ID
        """
        data = {
            PageMultiVectorSchema.VEC_ID: vec_id or self._generate_id(),
            PageMultiVectorSchema.DOC_ID: doc_id,
            PageMultiVectorSchema.PAGE_ID: page_id,
            PageMultiVectorSchema.TOKEN_VECTOR: token_vector,
            PageMultiVectorSchema.PATCH_ID: patch_id,
            PageMultiVectorSchema.METADATA: metadata or {},
        }
        
        result = self.insert(data)
        return result[0] if result else -1
    
    def insert_page_vectors(self,
                            doc_id: int,
                            page_id: int,
                            token_vectors: List[List[float]],
                            start_patch_id: int = 0) -> List[int]:
        """
        插入单个页面的所有向量
        
        Args:
            doc_id: 文档ID
            page_id: 页码
            token_vectors: 向量列表
            start_patch_id: 起始 patch_id
            
        Returns:
            插入的主键列表
        """
        data = []
        for i, vector in enumerate(token_vectors):
            data.append({
                PageMultiVectorSchema.VEC_ID: self._generate_id(),
                PageMultiVectorSchema.DOC_ID: doc_id,
                PageMultiVectorSchema.PAGE_ID: page_id,
                PageMultiVectorSchema.TOKEN_VECTOR: vector,
                PageMultiVectorSchema.PATCH_ID: start_patch_id + i,
                PageMultiVectorSchema.METADATA: {},
            })
        
        return self.insert(data)
    
    def insert_multi_pages(self,
                           doc_id: int,
                           pages: List[Dict[str, Any]]) -> List[int]:
        """
        批量插入多个页面的多向量
        
        Args:
            doc_id: 文档ID
            pages: 页面列表，每个元素包含:
                - page_id: 页码
                - token_vectors: 向量列表
                - metadata: 元数据 (可选)
                
        Returns:
            插入的主键列表
        """
        data = []
        vec_id = self._generate_id()
        
        for page in pages:
            page_id = page["page_id"]
            token_vectors = page["token_vectors"]
            metadata = page.get("metadata", {})
            
            for patch_id, vector in enumerate(token_vectors):
                data.append({
                    PageMultiVectorSchema.VEC_ID: vec_id,
                    PageMultiVectorSchema.DOC_ID: doc_id,
                    PageMultiVectorSchema.PAGE_ID: page_id,
                    PageMultiVectorSchema.TOKEN_VECTOR: vector,
                    PageMultiVectorSchema.PATCH_ID: patch_id,
                    PageMultiVectorSchema.METADATA: metadata,
                })
                vec_id += 1
        
        return self.insert(data)
    
    def _to_dict(self, pmv: PageMultiVector) -> Dict[str, Any]:
        """转换为字典"""
        return {
            PageMultiVectorSchema.VEC_ID: pmv.vec_id,
            PageMultiVectorSchema.DOC_ID: pmv.doc_id,
            PageMultiVectorSchema.PAGE_ID: pmv.page_id,
            PageMultiVectorSchema.TOKEN_VECTOR: pmv.token_vector,
            PageMultiVectorSchema.PATCH_ID: pmv.patch_id,
            PageMultiVectorSchema.METADATA: pmv.metadata or {},
        }
    
    def _generate_id(self) -> int:
        """生成唯一ID"""
        import time
        return int(time.time() * 1000)
    
    # ==================== 查询操作 ====================
    
    def get_by_id(self, vec_id: int) -> Optional[PageMultiVector]:
        """根据ID获取向量"""
        results = super().get_by_id(vec_id)
        if results:
            return self._from_dict(results[0])
        return None
    
    def get_page_vectors(self, doc_id: int, page_id: int) -> List[PageMultiVector]:
        """
        获取某个页面的所有向量
        
        Args:
            doc_id: 文档ID
            page_id: 页码
            
        Returns:
            多向量列表（按 patch_id 排序）
        """
        filter_expr = f"{PageMultiVectorSchema.DOC_ID} == {doc_id} and {PageMultiVectorSchema.PAGE_ID} == {page_id}"
        results = self.query(filter_expr)
        
        # 按 patch_id 排序
        page_vectors = [self._from_dict(r) for r in results]
        page_vectors.sort(key=lambda x: x.patch_id)
        return page_vectors
    
    def get_page_vector_list(self, doc_id: int, page_id: int) -> List[List[float]]:
        """
        获取页面向量列表（仅向量）
        
        Args:
            doc_id: 文档ID
            page_id: 页码
            
        Returns:
            向量列表
        """
        filter_expr = f"{PageMultiVectorSchema.DOC_ID} == {doc_id} and {PageMultiVectorSchema.PAGE_ID} == {page_id}"
        output_fields = [PageMultiVectorSchema.TOKEN_VECTOR, PageMultiVectorSchema.PATCH_ID]
        results = self.query(filter_expr, output_fields=output_fields)
        
        # 按 patch_id 排序并提取向量
        results.sort(key=lambda x: x.get(PageMultiVectorSchema.PATCH_ID, 0))
        return [r[PageMultiVectorSchema.TOKEN_VECTOR] for r in results]
    
    def list_by_doc(self, doc_id: int, limit: Optional[int] = None) -> List[PageMultiVector]:
        """列出某个文档的所有向量"""
        filter_expr = f"{PageMultiVectorSchema.DOC_ID} == {doc_id}"
        results = self.query(filter_expr, limit=limit)
        return [self._from_dict(r) for r in results]
    
    def list_all(self, limit: Optional[int] = None) -> List[PageMultiVector]:
        """列出所有向量"""
        results = self.query(filter_expr="", limit=limit)
        return [self._from_dict(r) for r in results]
    
    def search_by_vector(self,
                         vector: List[float],
                         doc_id: Optional[int] = None,
                         page_id: Optional[int] = None,
                         limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        向量搜索
        
        Args:
            vector: 查询向量
            doc_id: 可选，按文档过滤
            page_id: 可选，按页面过滤
            limit: 返回数量
        """
        filter_parts = []
        if doc_id:
            filter_parts.append(f"{PageMultiVectorSchema.DOC_ID} == {doc_id}")
        if page_id:
            filter_parts.append(f"{PageMultiVectorSchema.PAGE_ID} == {page_id}")
        
        filter_expr = " and ".join(filter_parts) if filter_parts else None
        
        return self.search(
            vectors=vector,
            filter_expr=filter_expr,
            limit=limit
        )[0]
    
    def search_by_multi_vectors(self,
                                token_vectors: List[List[float]],
                                doc_id: Optional[int] = None,
                                page_id: Optional[int] = None,
                                limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        多向量搜索（类似 ColPali 的融合搜索）
        
        Args:
            token_vectors: 多个查询向量
            doc_id: 可选，按文档过滤
            page_id: 可选，按页面过滤
            limit: 返回数量
        """
        # 对多个向量取平均作为查询向量
        import numpy as np
        avg_vector = np.mean(token_vectors, axis=0).tolist()
        
        return self.search_by_vector(avg_vector, doc_id, page_id, limit)
    
    def _from_dict(self, data: Dict[str, Any]) -> PageMultiVector:
        """从字典创建 PageMultiVector"""
        return PageMultiVector(
            vec_id=data[PageMultiVectorSchema.VEC_ID],
            token_vector=data[PageMultiVectorSchema.TOKEN_VECTOR],
            patch_id=data[PageMultiVectorSchema.PATCH_ID],
            doc_id=data[PageMultiVectorSchema.DOC_ID],
            page_id=data[PageMultiVectorSchema.PAGE_ID],
            metadata=data.get(PageMultiVectorSchema.METADATA),
        )
    
    # ==================== 更新操作 ====================
    
    def update(self, vec_id: int, update_data: Dict[str, Any]) -> bool:
        """更新向量"""
        filter_expr = f"{PageMultiVectorSchema.VEC_ID} == {vec_id}"
        data = {PageMultiVectorSchema.VEC_ID: vec_id}
        data.update(update_data)
        
        try:
            self.upsert(data)
            return True
        except Exception as e:
            logger.error(f"更新向量失败: {e}")
            return False
    
    def update_metadata(self, vec_id: int, metadata: Dict[str, Any]) -> bool:
        return self.update(vec_id, {PageMultiVectorSchema.METADATA: metadata})
    
    # ==================== 删除操作 ====================
    
    def delete(self, vec_id: int) -> bool:
        """删除向量"""
        try:
            filter_expr = f"{PageMultiVectorSchema.VEC_ID} == {vec_id}"
            super().delete(filter_expr)
            return True
        except Exception as e:
            logger.error(f"删除向量失败: {e}")
            return False
    
    def delete_by_doc(self, doc_id: int) -> int:
        """删除某个文档的所有向量"""
        filter_expr = f"{PageMultiVectorSchema.DOC_ID} == {doc_id}"
        return super().delete(filter_expr)
    
    def delete_by_page(self, doc_id: int, page_id: int) -> int:
        """删除某个页面的所有向量"""
        filter_expr = f"{PageMultiVectorSchema.DOC_ID} == {doc_id} and {PageMultiVectorSchema.PAGE_ID} == {page_id}"
        return super().delete(filter_expr)
    
    # ==================== 统计操作 ====================
    
    def count(self, doc_id: Optional[int] = None, page_id: Optional[int] = None) -> int:
        """获取向量数量"""
        filter_parts = []
        if doc_id:
            filter_parts.append(f"{PageMultiVectorSchema.DOC_ID} == {doc_id}")
        if page_id:
            filter_parts.append(f"{PageMultiVectorSchema.PAGE_ID} == {page_id}")
        
        filter_expr = " and ".join(filter_parts) if filter_parts else None
        return super().count(filter_expr)
    
    def get_page_count(self, doc_id: int) -> int:
        """获取某个文档的页面数（有向量的页面）"""
        filter_expr = f"{PageMultiVectorSchema.DOC_ID} == {doc_id}"
        output_fields = [PageMultiVectorSchema.PAGE_ID]
        results = self.query(filter_expr, output_fields=output_fields)
        
        # 统计不同的 page_id
        page_ids = set(r[PageMultiVectorSchema.PAGE_ID] for r in results)
        return len(page_ids)
    
    def get_stats(self, doc_id: Optional[int] = None) -> Dict[str, Any]:
        """获取统计信息"""
        stats = super().get_stats()
        stats["type"] = "page_multi_vector"
        stats["count"] = self.count(doc_id)
        if doc_id:
            stats["page_count"] = self.get_page_count(doc_id)
        return stats


# 便捷函数
def create_page_multi_vector_table(vector_dim: Optional[int] = None) -> PageMultiVectorTable:
    """创建页级多向量表管理器并初始化"""
    table = PageMultiVectorTable(vector_dim)
    table.init_schema()
    return table