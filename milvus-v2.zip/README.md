# Milvus RAG 系统

基于 Milvus 向量数据库的 RAG (Retrieval Augmented Generation) 系统，支持分层语义路由和多向量表示。

## 系统架构

### 核心设计原则

1. **分层路由策略**: 知识库表 → 文档元数据表 → 内容表（页级/切片级）
2. **多向量表示支持**: 页级视觉多向量表采用"一条patch一条记录"的设计，通过 patch_id 和 page_id 聚合
3. **灵活的元数据设计**: 大量使用 JSON 字段存储动态属性，避免表结构频繁变更
4. **外键关联查询**: 通过 kb_id → doc_id → page_id 的层级关系实现精确过滤

### 数据表结构

#### 1. 知识库表 (Knowledge Base)
存储知识库的基本信息和语义路由向量。

#### 2. 文档元数据表 (Document Metadata)
存储文档的元信息，包括文件名、标签、关键词、摘要等。

#### 3. 页级摘要向量表 (Page Summary)
存储页面的 VLM 摘要信息和多模态 embedding。

#### 4. 页级视觉多向量表 (Page Multi-vector)
存储页面的多向量表示，支持 ColPali/ColQwen 等模型的多向量编码。

#### 5. 文档切片向量表 (Chunk)
存储文档文本内容的切片，这些内容通过 OCR 提取并进行 chunk 切分。

## 安装

```bash
# 使用 pip 安装
pip install milvus-rag

# 或者从源码安装
git clone https://github.com/your-repo/milvus-rag.git
cd milvus-rag
pip install -e .[dev]
```

## 配置

系统使用 YAML 配置文件 `config.yaml`，可配置以下参数：

```yaml
milvus:
  host: "localhost"          # Milvus 主机地址
  port: 19530                # Milvus 端口
  user: ""                   # 用户名（可选）
  password: ""               # 密码（可选）
  db_name: "default"         # 数据库名

collection:
  default_shard_num: 2       # 默认分片数
  consistency_level: "Bounded" # 一致性级别
  index:
    vector_index_type: "HNSW"
    M: 16
    efConstruction: 256

tables:
  knowledge_base:
    collection_name: "knowledge_base"
    vector_dim: 1024

# 更多配置...
```

## 使用示例

### 基础使用

```python
from milvus_rag import MilvusRAGManager

# 初始化管理器
rag = MilvusRAGManager()

# 连接 Milvus
rag.connect()

# 创建知识库
kb_id = rag.kb_table.insert_knowledge_base(
    kb_name="产品文档",
    description="包含产品使用说明书和技术文档",
    tags=["产品", "技术"],
    vector=[0.0] * 1024
)

# 插入文档
doc_id = rag.doc_table.insert_document(
    kb_id=kb_id,
    doc_name="产品使用说明",
    tags=["用户手册"],
    organize=["page"],
    metadata={
        "path": "/docs/manual.pdf",
        "size": 1024000,
        "pages": 50,
        "language": "zh-CN"
    }
)

# 插入页面摘要
page_id = rag.page_summary_table.insert_page_summary(
    doc_id=doc_id,
    abstract="产品概述和基本功能介绍",
    page_id=1,
    vector=[0.0] * 1024,
    page_path="/docs/manual/page_1.jpg"
)

# 搜索
results = rag.kb_table.search_by_vector([0.0] * 1024)

# 关闭连接
rag.disconnect()
```

### 批量操作

```python
from milvus_rag import MilvusRAGManager

rag = MilvusRAGManager()
rag.connect()

# 批量插入文档
doc_ids = []
for i in range(10):
    doc_id = rag.doc_table.insert_document(
        kb_id=1,
        doc_name=f"文档{i}",
        tags=["测试"],
        organize=["page"],
        metadata={}
    )
    doc_ids.append(doc_id)

# 批量插入页面摘要
pages = []
for doc_id in doc_ids:
    pages.extend([
        {
            "doc_id": doc_id,
            "abstract": f"页面摘要{i}",
            "page_id": i,
            "vector": [0.0] * 1024,
            "page_path": f"/docs/page_{i}.jpg"
        }
        for i in range(5)
    ])

rag.page_summary_table.insert_batch(pages)

# 搜索
results = rag.doc_table.search_by_vector([0.0] * 1024, limit=5)
print(f"搜索结果: {len(results)} 条")

rag.disconnect()
```

## API 参考

### MilvusRAGManager

系统的统一入口类，提供所有表的访问和管理。

#### 方法

- `connect()`: 连接到 Milvus
- `disconnect()`: 断开连接
- `init_all_tables()`: 初始化所有表结构
- `drop_all_tables()`: 删除所有表
- `get_all_stats()`: 获取系统统计信息

#### 属性

- `kb_table`: 知识库表管理器
- `doc_table`: 文档元数据表管理器
- `page_summary_table`: 页级摘要向量表管理器
- `page_multi_vector_table`: 页级视觉多向量表管理器
- `chunk_table`: 文档切片向量表管理器

### 表管理器

所有表管理器继承自 `BaseTable`，包含以下方法：

- `init_schema()`: 初始化表结构
- `insert()`: 插入数据
- `query()`: 查询数据
- `search()`: 向量搜索
- `update()`: 更新数据
- `delete()`: 删除数据
- `count()`: 统计数量
- `get_stats()`: 获取统计信息

## 开发

### 运行测试

```bash
pytest tests/ -v -xvs
```

### 代码风格

使用 `black` 进行代码格式化：

```bash
black milvus_rag/ tests/
```

使用 `flake8` 检查代码风格：

```bash
flake8 milvus_rag/ tests/
```

## 文档

使用 Sphinx 构建文档：

```bash
cd docs/
make html
```

## 许可证

MIT 许可证

## 贡献

欢迎提交 Pull Request 和 Issue！