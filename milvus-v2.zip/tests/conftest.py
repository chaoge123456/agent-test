"""
测试配置
========
"""

import pytest

from milvus_rag import MilvusRAGManager


@pytest.fixture(scope="session")
def rag_manager():
    """创建 RAG 系统管理器实例"""
    manager = MilvusRAGManager()
    manager.connect()
    
    yield manager
    
    manager.disconnect()


@pytest.fixture(scope="function")
def fresh_rag_manager():
    """创建一个干净的 RAG 系统（每次测试都重新初始化）"""
    manager = MilvusRAGManager()
    manager.connect()
    
    # 删除所有表
    for table in [
        manager.chunk_table,
        manager.page_multi_vector_table,
        manager.page_summary_table,
        manager.doc_table,
        manager.kb_table
    ]:
        if table.exists():
            table.drop_collection()
    
    # 初始化表
    manager.init_all_tables()
    
    yield manager
    
    manager.disconnect()