"""
知识库表测试
===========
"""

import pytest

from milvus_rag import MilvusRAGManager


class TestKnowledgeBaseTable:
    """知识库表测试类"""
    
    @pytest.fixture(scope="function")
    def test_manager(self, fresh_rag_manager):
        """测试用的管理器"""
        return fresh_rag_manager
    
    def test_table_initialization(self, test_manager):
        """测试表初始化"""
        assert test_manager.kb_table.exists()
        assert test_manager.kb_table.vector_dim == 1024
    
    def test_insert(self, test_manager):
        """测试插入操作"""
        kb_id = test_manager.kb_table.insert_knowledge_base(
            kb_name="测试知识库",
            description="这是一个用于测试的知识库",
            tags=["测试"],
            vector=[0.0] * 1024
        )
        
        assert kb_id > 0
        
        # 查询插入的数据
        kb = test_manager.kb_table.get_by_id(kb_id)
        assert kb is not None
        assert kb.kb_name == "测试知识库"
    
    def test_list_all(self, test_manager):
        """测试列出所有"""
        # 插入几个知识库
        for i in range(3):
            test_manager.kb_table.insert_knowledge_base(
                kb_name=f"知识库{i}",
                description=f"测试知识库{i}",
                tags=["测试"],
                vector=[0.0] * 1024
            )
        
        all_kbs = test_manager.kb_table.list_all()
        assert len(all_kbs) >= 3
    
    def test_search_by_vector(self, test_manager):
        """测试向量搜索"""
        # 插入数据
        for i in range(3):
            test_manager.kb_table.insert_knowledge_base(
                kb_name=f"知识库{i}",
                description=f"测试知识库{i}",
                tags=["测试"],
                vector=[0.1 + i * 0.2] * 1024
            )
        
        # 搜索
        result = test_manager.kb_table.search_by_vector([0.1] * 1024, limit=2)
        assert len(result) == 2
    
    def test_count(self, test_manager):
        """测试统计"""
        # 插入数据
        for i in range(3):
            test_manager.kb_table.insert_knowledge_base(
                kb_name=f"知识库{i}",
                description=f"测试知识库{i}",
                tags=["测试"],
                vector=[0.0] * 1024
            )
        
        count = test_manager.kb_table.count()
        assert count == 3
    
    def test_delete(self, test_manager):
        """测试删除"""
        kb_id = test_manager.kb_table.insert_knowledge_base(
            kb_name="测试知识库",
            description="测试",
            tags=["测试"],
            vector=[0.0] * 1024
        )
        
        # 删除
        result = test_manager.kb_table.delete(kb_id)
        assert result
        
        # 验证删除
        kb = test_manager.kb_table.get_by_id(kb_id)
        assert kb is None