"""
Milvus RAG 系统使用示例
======================
演示各个表的 CRUD 和索引构建操作。
"""

import logging
import sys
import time

from milvus_rag import MilvusRAGManager


def setup_logging():
    """配置日志"""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        stream=sys.stdout
    )
    logger = logging.getLogger(__name__)
    return logger


def test_connection():
    """测试 Milvus 连接"""
    logger.info("测试 Milvus 连接...")
    
    manager = MilvusRAGManager()
    
    try:
        manager.connect()
        logger.info("✅ Milvus 连接成功")
    except Exception as e:
        logger.error(f"❌ Milvus 连接失败: {e}")
        return False
    
    manager.disconnect()
    logger.info("✅ 连接已断开")
    return True


def test_kb_table(manager: MilvusRAGManager):
    """测试知识库表"""
    logger.info("测试知识库表...")
    
    # 删除旧数据
    if manager.kb_table.exists():
        manager.kb_table.drop_collection()
    
    # 初始化表
    manager.kb_table.init_schema()
    
    # 插入数据
    kb_ids = []
    for i in range(3):
        kb_id = manager.kb_table.insert_knowledge_base(
            kb_name=f"知识库{i}",
            description=f"这是第{i}个知识库的描述",
            tags=[f"标签{i}", "测试"],
            vector=[0.1 + i * 0.2] * 1024  # 简化向量
        )
        kb_ids.append(kb_id)
        logger.info(f"✅ 插入知识库: {kb_id}")
    
    # 查询数据
    all_kbs = manager.kb_table.list_all()
    logger.info(f"✅ 查询到 {len(all_kbs)} 个知识库")
    for kb in all_kbs:
        logger.info(f"  - {kb.kb_id}: {kb.kb_name}")
    
    # 搜索
    if all_kbs:
        search_result = manager.kb_table.search_by_vector([0.1] * 1024, limit=2)
        logger.info(f"✅ 搜索到 {len(search_result)} 个匹配结果")
    
    # 统计
    count = manager.kb_table.count()
    logger.info(f"✅ 知识库总数: {count}")
    
    # 删除测试数据
    for kb_id in kb_ids:
        manager.kb_table.delete(kb_id)
    
    return True


def test_doc_table(manager: MilvusRAGManager):
    """测试文档元数据表"""
    logger.info("测试文档元数据表...")
    
    # 删除旧数据
    if manager.doc_table.exists():
        manager.doc_table.drop_collection()
    
    # 初始化表
    manager.doc_table.init_schema()
    
    # 先创建一个知识库
    kb_id = manager.kb_table.insert_knowledge_base(
        kb_name="测试知识库",
        description="用于测试的知识库",
        tags=["测试"],
        vector=[0.0] * 1024
    )
    
    # 插入文档
    doc_ids = []
    for i in range(2):
        doc_id = manager.doc_table.insert_document(
            kb_id=kb_id,
            doc_name=f"文档{i}",
            tags=[f"标签{i}", "测试"],
            organize=["page", "chunk"],
            metadata={
                "path": f"/docs/doc{i}.pdf",
                "size": 1024 * 1000,
                "pages": 50 + i * 10,
                "language": "zh-CN"
            },
            keywords=["关键词1", "关键词2"]
        )
        doc_ids.append(doc_id)
        logger.info(f"✅ 插入文档: {doc_id}")
    
    # 查询数据
    all_docs = manager.doc_table.list_by_kb(kb_id)
    logger.info(f"✅ 查询到 {len(all_docs)} 个文档")
    for doc in all_docs:
        logger.info(f"  - {doc.doc_id}: {doc.doc_name}")
    
    # 搜索
    search_result = manager.doc_table.search_by_vector([0.0] * 1024, kb_id, limit=1)
    logger.info(f"✅ 搜索到 {len(search_result)} 个匹配结果")
    
    # 关键词搜索
    keyword_result = manager.doc_table.search_by_keyword("关键词1")
    logger.info(f"✅ 关键词搜索到 {len(keyword_result)} 个结果")
    
    # 统计
    count = manager.doc_table.count()
    logger.info(f"✅ 文档总数: {count}")
    
    # 删除测试数据
    for doc_id in doc_ids:
        manager.doc_table.delete(doc_id)
    
    manager.kb_table.delete(kb_id)
    
    return True


def test_page_summary_table(manager: MilvusRAGManager):
    """测试页级摘要向量表"""
    logger.info("测试页级摘要向量表...")
    
    if manager.page_summary_table.exists():
        manager.page_summary_table.drop_collection()
    
    manager.page_summary_table.init_schema()
    
    # 创建测试数据
    kb_id = manager.kb_table.insert_knowledge_base(
        kb_name="测试知识库",
        description="用于测试的知识库",
        tags=["测试"],
        vector=[0.0] * 1024
    )
    
    doc_id = manager.doc_table.insert_document(
        kb_id=kb_id,
        doc_name="测试文档",
        tags=["测试"],
        organize=["page"],
        metadata={"pages": 3}
    )
    
    # 插入页面摘要
    for i in range(3):
        row_id = manager.page_summary_table.insert_page_summary(
            doc_id=doc_id,
            abstract=f"第{i}页的摘要",
            page_id=i,
            vector=[i * 0.1] * 1024,
            page_path=f"/docs/page{i}.jpg",
            keyword=[f"页{i}", "测试"],
            metadata={
                "text_count": 100 + i * 50,
                "image_count": 2 + i
            }
        )
        logger.info(f"✅ 插入页面摘要: {row_id}")
    
    # 查询
    all_pages = manager.page_summary_table.list_by_doc(doc_id)
    logger.info(f"✅ 查询到 {len(all_pages)} 个页面摘要")
    for page in all_pages:
        logger.info(f"  - 第{page.page_id}页: {page.abstract}")
    
    # 搜索
    search_result = manager.page_summary_table.search_by_vector([0.1] * 1024, doc_id, limit=2)
    logger.info(f"✅ 搜索到 {len(search_result)} 个匹配结果")
    
    # 统计
    count = manager.page_summary_table.count()
    logger.info(f"✅ 页面摘要总数: {count}")
    
    # 清理
    manager.page_summary_table.delete_by_doc(doc_id)
    manager.doc_table.delete(doc_id)
    manager.kb_table.delete(kb_id)
    
    return True


def test_page_multi_vector_table(manager: MilvusRAGManager):
    """测试页级视觉多向量表"""
    logger.info("测试页级视觉多向量表...")
    
    if manager.page_multi_vector_table.exists():
        manager.page_multi_vector_table.drop_collection()
    
    manager.page_multi_vector_table.init_schema()
    
    # 创建测试数据
    kb_id = manager.kb_table.insert_knowledge_base(
        kb_name="测试知识库",
        description="用于测试的知识库",
        tags=["测试"],
        vector=[0.0] * 1024
    )
    
    doc_id = manager.doc_table.insert_document(
        kb_id=kb_id,
        doc_name="测试文档",
        tags=["测试"],
        organize=["page"],
        metadata={"pages": 2}
    )
    
    # 插入页面向量
    for page_id in range(2):
        vectors = []
        for patch_id in range(4):
            vector = [(page_id + patch_id) * 0.1] * 1024
            vectors.append(vector)
        
        vec_ids = manager.page_multi_vector_table.insert_page_vectors(
            doc_id, page_id, vectors
        )
        logger.info(f"✅ 页面{page_id} 插入 {len(vec_ids)} 个向量")
    
    # 查询
    for page_id in range(2):
        page_vectors = manager.page_multi_vector_table.get_page_vectors(doc_id, page_id)
        logger.info(f"✅ 页面{page_id} 有 {len(page_vectors)} 个向量")
    
    # 搜索
    search_result = manager.page_multi_vector_table.search_by_vector([0.1] * 1024, doc_id, limit=3)
    logger.info(f"✅ 搜索到 {len(search_result)} 个匹配结果")
    
    # 统计
    count = manager.page_multi_vector_table.count()
    logger.info(f"✅ 多向量总数: {count}")
    
    # 清理
    manager.page_multi_vector_table.delete_by_doc(doc_id)
    manager.doc_table.delete(doc_id)
    manager.kb_table.delete(kb_id)
    
    return True


def test_chunk_table(manager: MilvusRAGManager):
    """测试文档切片向量表"""
    logger.info("测试文档切片向量表...")
    
    if manager.chunk_table.exists():
        manager.chunk_table.drop_collection()
    
    manager.chunk_table.init_schema()
    
    # 创建测试数据
    kb_id = manager.kb_table.insert_knowledge_base(
        kb_name="测试知识库",
        description="用于测试的知识库",
        tags=["测试"],
        vector=[0.0] * 1024
    )
    
    doc_id = manager.doc_table.insert_document(
        kb_id=kb_id,
        doc_name="测试文档",
        tags=["测试"],
        organize=["chunk"],
        metadata={"pages": 2}
    )
    
    # 插入切片
    for i in range(5):
        chunk_id = manager.chunk_table.insert_chunk(
            doc_id=doc_id,
            page_id=i // 3,
            type="text" if i % 2 == 0 else "table",
            content=f"这是第{i}个文本切片的内容",
            vector=[i * 0.1] * 1024,
            keyword=[f"切片{i}", "测试"],
            metadata={
                "start_pos": i * 100,
                "end_pos": (i + 1) * 100
            }
        )
        logger.info(f"✅ 插入切片: {chunk_id}")
    
    # 查询
    all_chunks = manager.chunk_table.list_by_doc(doc_id)
    logger.info(f"✅ 查询到 {len(all_chunks)} 个切片")
    for chunk in all_chunks:
        logger.info(f"  - {chunk.chunk_id}: {chunk.type}")
    
    # 按类型查询
    text_chunks = manager.chunk_table.list_by_type("text")
    logger.info(f"✅ 查询到 {len(text_chunks)} 个文本切片")
    
    # 搜索
    search_result = manager.chunk_table.search_by_vector([0.2] * 1024, doc_id, limit=3)
    logger.info(f"✅ 搜索到 {len(search_result)} 个匹配结果")
    
    # 关键词搜索
    keyword_result = manager.chunk_table.search_by_keyword("切片")
    logger.info(f"✅ 关键词搜索到 {len(keyword_result)} 个结果")
    
    # 统计
    count = manager.chunk_table.count()
    logger.info(f"✅ 切片总数: {count}")
    
    # 清理
    manager.chunk_table.delete_by_doc(doc_id)
    manager.doc_table.delete(doc_id)
    manager.kb_table.delete(kb_id)
    
    return True


def run_all_tests():
    """运行所有测试"""
    global logger
    logger = setup_logging()
    
    logger.info("开始测试 Milvus RAG 系统...")
    
    try:
        manager = MilvusRAGManager()
        manager.connect()
        
        # 删除所有旧数据
        for table in [
            manager.chunk_table,
            manager.page_multi_vector_table,
            manager.page_summary_table,
            manager.doc_table,
            manager.kb_table
        ]:
            if table.exists():
                table.drop_collection()
        
        # 初始化所有表
        manager.init_all_tables()
        
        # 运行测试
        test_functions = [
            test_kb_table,
            test_doc_table,
            test_page_summary_table,
            test_page_multi_vector_table,
            test_chunk_table
        ]
        
        all_passed = True
        for test_func in test_functions:
            try:
                test_func(manager)
            except Exception as e:
                logger.error(f"❌ 测试失败: {e}")
                import traceback
                logger.error(traceback.format_exc())
                all_passed = False
        
        if all_passed:
            logger.info("✅ 所有测试通过")
        else:
            logger.error("❌ 部分测试失败")
        
        manager.disconnect()
        
        return all_passed
        
    except Exception as e:
        logger.error(f"❌ 测试过程中发生错误: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return False


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)