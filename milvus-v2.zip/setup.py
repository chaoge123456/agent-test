"""
Milvus RAG 系统 - 安装配置
========================
"""

from setuptools import setup, find_packages

with open('README.md', 'r', encoding='utf-8') as f:
    long_description = f.read()

setup(
    name="milvus-rag",
    version="1.0.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="基于 Milvus 的 RAG 系统，支持分层语义路由和多向量表示",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/your-repo/milvus-rag",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "pymilvus>=2.4.0",
        "pyyaml>=6.0",
        "pydantic>=2.0",
        "numpy>=1.24.0",
        "python-dotenv>=1.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "pytest-cov>=4.0",
            "black>=23.0",
            "flake8>=6.0",
            "mypy>=1.0",
        ],
        "docs": [
            "sphinx>=7.0",
            "sphinx-rtd-theme>=2.0",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: Apache Software License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Database",
    ],
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "milvus-rag=milvus_rag.cli:main",
        ],
    },
)