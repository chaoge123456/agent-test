# SPDX-License-Identifier: Apache-2.0

import importlib.util
from pathlib import Path

import pytest


_MODULE_PATH = Path(__file__).parents[2] / "vllm_ascend" / "worker" / "ar_rerank.py"
_SPEC = importlib.util.spec_from_file_location("ascend_ar_rerank_under_test", _MODULE_PATH)
assert _SPEC is not None
assert _SPEC.loader is not None
_MODULE = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_MODULE)

ARPagedKVLayout = _MODULE.ARPagedKVLayout
ARBatchExecutionContext = _MODULE.ARBatchExecutionContext
ARBatchRequest = _MODULE.ARBatchRequest
build_finished_ar_scoring_jobs = _MODULE.build_finished_ar_scoring_jobs


def test_resolves_logical_tokens_through_the_request_block_table():
    """Catches a runner adapter that treats logical block IDs as physical IDs."""
    layout = ARPagedKVLayout(block_size=128, num_kv_heads=8, head_dim=128)

    assert layout.physical_location([9, 3, 7], token_position=0, num_physical_blocks=10) == (9, 0)
    assert layout.physical_location([9, 3, 7], token_position=129, num_physical_blocks=10) == (3, 1)
    assert layout.physical_location([9, 3, 7], token_position=383, num_physical_blocks=10) == (7, 127)


def test_rejects_invalid_block_table_and_kv_head_indices():
    """Catches invalid request metadata before it can read an unrelated KV block."""
    layout = ARPagedKVLayout(block_size=2, num_kv_heads=2, head_dim=4)

    with pytest.raises(ValueError, match="physical block"):
        layout.physical_location([4], token_position=0, num_physical_blocks=4)
    with pytest.raises(ValueError, match="token_position"):
        layout.physical_location([0], token_position=2, num_physical_blocks=4)
    with pytest.raises(ValueError, match="kv_head"):
        layout.validate_kv_head(2)


def test_locates_query_rows_and_block_table_for_each_request_in_a_packed_batch():
    """Catches AR Q capture being associated with another request's packed rows."""
    context = ARBatchExecutionContext(
        requests=(
            ARBatchRequest(
                request_id="request-a",
                packed_row_range=(0, 5),
                query_range=(3, 5),
                document_ranges=((0, 2),),
                block_table=(8,),
            ),
            ARBatchRequest(
                request_id="request-b",
                packed_row_range=(5, 9),
                query_range=(2, 4),
                document_ranges=((0, 1),),
                block_table=(3,),
            ),
        )
    )

    assert context.request_for_packed_row(4).request_id == "request-a"
    assert context.request_for_packed_row(5).request_id == "request-b"
    assert context.query_packed_rows("request-b") == (7, 8)
    assert context.request("request-a").block_table == (8,)


def test_rejects_overlapping_packed_rows_and_query_ranges_outside_a_request():
    """Catches ambiguous packed-Q ownership before model forward starts."""
    with pytest.raises(ValueError, match="packed_row_range"):
        ARBatchExecutionContext(
            requests=(
                ARBatchRequest("a", (0, 2), (0, 1), ((0, 1),), (0,)),
                ARBatchRequest("b", (1, 3), (1, 2), ((0, 1),), (1,)),
            )
        )
    with pytest.raises(ValueError, match="query_range"):
        ARBatchRequest("a", (0, 2), (0, 3), ((0, 1),), (0,))


def test_builds_scoring_jobs_only_for_finished_requests_with_request_local_state():
    """Catches a runner bridge that scores incomplete prompts or loses block tables."""
    context = ARBatchExecutionContext(
        requests=(
            ARBatchRequest("a", (0, 4), (2, 4), ((0, 1),), (5,)),
            ARBatchRequest("b", (4, 7), (1, 3), ((0, 1),), (9,)),
        )
    )

    jobs = build_finished_ar_scoring_jobs(context, finished_request_ids={"b"})

    assert len(jobs) == 1
    assert jobs[0].request_id == "b"
    assert jobs[0].query_packed_rows == (5, 6)
    assert jobs[0].document_ranges == ((0, 1),)
    assert jobs[0].block_table == (9,)


def test_rejects_a_finished_request_id_not_owned_by_the_current_batch():
    """Catches completion state leaking from an earlier scheduler batch."""
    context = ARBatchExecutionContext(
        requests=(ARBatchRequest("a", (0, 2), (1, 2), ((0, 1),), (0,)),)
    )

    with pytest.raises(ValueError, match="not owned"):
        build_finished_ar_scoring_jobs(context, finished_request_ids={"unknown"})


def test_runner_deposits_ar_scores_before_calling_the_standard_pooler():
    """Catches bypassing AR scoring and reaching pooler with an empty score map."""
    runner_path = _MODULE_PATH.with_name("model_runner_v1.py")
    source = runner_path.read_text(encoding="utf-8")

    bridge_call = source.index("self._deposit_ar_scores_before_pooling(")
    pool_call = source.index("output = self._pool(", bridge_call)
    assert bridge_call < pool_call
    assert "def _deposit_ar_scores_before_pooling(" in source
    assert "def _score_ar_request(" in source


def test_runner_unwraps_the_virtual_engine_kv_cache_before_reading_k():
    """Ascend binds an attention cache as ``[(K_cache, V_cache)]``.

    The runner must select virtual engine zero and then select K from that
    pair; indexing only once returns the ``(K_cache, V_cache)`` tuple.
    """
    runner_path = _MODULE_PATH.with_name("model_runner_v1.py")
    source = runner_path.read_text(encoding="utf-8")

    assert "layer_kv_cache = kv_cache_by_engine[0]" in source
    assert "key_cache = layer_kv_cache[0]" in source


def test_vectorized_scorer_matches_per_token_causal_reference():
    """All AR heads must retain the former causal attention semantics."""
    scorer = getattr(_MODULE, "score_ar_heads_causal_attention", None)
    assert scorer is not None, "the vectorized AR scorer must be declared"

    torch = pytest.importorskip("torch")
    queries = torch.tensor(
        [
            [[0.5, 1.0], [1.0, -0.5]],
            [[-0.25, 0.75], [0.75, 0.25]],
        ],
        dtype=torch.float32,
    )
    keys = torch.tensor(
        [
            [[1.0, 0.0], [0.0, 1.0], [1.0, 1.0], [-0.5, 0.5], [0.5, -1.0]],
            [[0.5, 0.5], [1.0, -0.5], [0.0, 1.0], [1.0, 1.0], [-1.0, 0.0]],
        ],
        dtype=torch.float32,
    )
    document_ranges = ((0, 2), (2, 3))
    query_positions = torch.tensor([3, 4])

    actual = scorer(queries, keys, document_ranges, query_positions)

    expected_per_head = []
    scale = keys.shape[-1] ** -0.5
    for head in range(queries.shape[0]):
        document_totals = []
        for start, end in document_ranges:
            per_token = []
            for offset, position in enumerate(query_positions.tolist()):
                logits = keys[head, : position + 1] @ queries[head, offset] * scale
                per_token.append(torch.softmax(logits, dim=0)[start:end].sum())
            document_totals.append(torch.stack(per_token).mean())
        expected_per_head.append(torch.stack(document_totals))
    expected = torch.stack(expected_per_head)

    torch.testing.assert_close(actual, expected, rtol=1e-6, atol=1e-6)
