# Copyright (c) 2026 Huawei Technologies Co., Ltd. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0

"""NPU-independent ARRanker paged-K cache layout contract.

The target-host runner adapter owns tensor access; this module owns only the
logical-token to physical-block mapping shared with AR scoring.
"""

from dataclasses import dataclass
from collections.abc import Sequence


@dataclass(frozen=True)
class ARPagedKVLayout:
    block_size: int
    num_kv_heads: int
    head_dim: int

    def __post_init__(self) -> None:
        if self.block_size < 1:
            raise ValueError("block_size must be positive")
        if self.num_kv_heads < 1:
            raise ValueError("num_kv_heads must be positive")
        if self.head_dim < 1:
            raise ValueError("head_dim must be positive")

    def physical_location(
        self,
        block_table: Sequence[int],
        *,
        token_position: int,
        num_physical_blocks: int,
    ) -> tuple[int, int]:
        if token_position < 0:
            raise ValueError("token_position must be non-negative")
        logical_block, block_offset = divmod(token_position, self.block_size)
        if logical_block >= len(block_table):
            raise ValueError("token_position is outside the request block_table")
        physical_block = block_table[logical_block]
        if physical_block < 0 or physical_block >= num_physical_blocks:
            raise ValueError("block_table contains an invalid physical block")
        return physical_block, block_offset

    def validate_kv_head(self, kv_head: int) -> None:
        if kv_head < 0 or kv_head >= self.num_kv_heads:
            raise ValueError("kv_head is outside the KV cache head range")


@dataclass(frozen=True)
class ARBatchRequest:
    """One AR request's ownership boundaries inside a packed model forward."""

    request_id: str
    packed_row_range: tuple[int, int]
    query_range: tuple[int, int]
    document_ranges: tuple[tuple[int, int], ...]
    block_table: tuple[int, ...]

    def __post_init__(self) -> None:
        packed_start, packed_end = self.packed_row_range
        if packed_start < 0 or packed_start >= packed_end:
            raise ValueError("packed_row_range must be a non-empty half-open interval")
        request_length = packed_end - packed_start
        _validate_range(self.query_range, request_length, "query_range")
        if not self.block_table:
            raise ValueError("block_table must not be empty")
        for document_range in self.document_ranges:
            _validate_range(document_range, request_length, "document_ranges")


@dataclass(frozen=True)
class ARBatchExecutionContext:
    """Validated lookup for request-local AR state in a packed vLLM batch."""

    requests: tuple[ARBatchRequest, ...]

    def __post_init__(self) -> None:
        if not self.requests:
            raise ValueError("requests must not be empty")
        request_ids = [item.request_id for item in self.requests]
        if len(request_ids) != len(set(request_ids)):
            raise ValueError("request_id values must be unique")
        ordered = sorted(self.requests, key=lambda item: item.packed_row_range[0])
        for previous, current in zip(ordered, ordered[1:]):
            if previous.packed_row_range[1] > current.packed_row_range[0]:
                raise ValueError("packed_row_range values must not overlap")

    def request(self, request_id: str) -> ARBatchRequest:
        for item in self.requests:
            if item.request_id == request_id:
                return item
        raise KeyError(request_id)

    def request_for_packed_row(self, packed_row: int) -> ARBatchRequest:
        for item in self.requests:
            start, end = item.packed_row_range
            if start <= packed_row < end:
                return item
        raise KeyError(f"no AR request owns packed row {packed_row}")

    def query_packed_rows(self, request_id: str) -> tuple[int, ...]:
        item = self.request(request_id)
        packed_start, _ = item.packed_row_range
        query_start, query_end = item.query_range
        return tuple(range(packed_start + query_start, packed_start + query_end))


@dataclass(frozen=True)
class ARScoringJob:
    """Request-local inputs that the target-host runner passes to AR scoring."""

    request_id: str
    query_packed_rows: tuple[int, ...]
    document_ranges: tuple[tuple[int, int], ...]
    block_table: tuple[int, ...]


def build_finished_ar_scoring_jobs(
    context: ARBatchExecutionContext, *, finished_request_ids: set[str]
) -> tuple[ARScoringJob, ...]:
    """Create scoring jobs only after a AR prompt's final token is available."""
    owned_request_ids = {item.request_id for item in context.requests}
    unknown_request_ids = finished_request_ids - owned_request_ids
    if unknown_request_ids:
        raise ValueError("finished request IDs are not owned by the current batch")

    return tuple(
        ARScoringJob(
            request_id=item.request_id,
            query_packed_rows=context.query_packed_rows(item.request_id),
            document_ranges=item.document_ranges,
            block_table=item.block_table,
        )
        for item in context.requests
        if item.request_id in finished_request_ids
    )


def score_ar_heads_causal_attention(
    queries: "torch.Tensor",
    keys: "torch.Tensor",
    document_ranges: Sequence[tuple[int, int]],
    query_positions: "torch.Tensor",
) -> "torch.Tensor":
    """Return causal document attention mass for every supplied AR head.

    ``queries`` is ``[head, query_token, dim]`` and ``keys`` is
    ``[head, key_token, dim]``.  The returned tensor is ``[head, document]``
    after averaging each document's attention mass over the query tokens.
    The torch import is deliberately local so the layout-only contracts in
    this module remain importable on development hosts without torch.
    """
    import torch

    if queries.ndim != 3 or keys.ndim != 3:
        raise ValueError("queries and keys must have shape [head, token, dim]")
    if queries.shape[0] != keys.shape[0] or queries.shape[2] != keys.shape[2]:
        raise ValueError("queries and keys must have matching head and dim sizes")
    if queries.shape[1] < 1:
        raise ValueError("queries must contain at least one query token")
    if not document_ranges:
        raise ValueError("document_ranges must not be empty")

    positions = torch.as_tensor(query_positions, device=keys.device, dtype=torch.long)
    if positions.ndim != 1 or positions.shape[0] != queries.shape[1]:
        raise ValueError("query_positions must contain one position per query token")
    if torch.any(positions < 0) or torch.any(positions >= keys.shape[1]):
        raise ValueError("query_positions are outside the key sequence")

    earliest_query_position = int(positions.min().item())
    for start, end in document_ranges:
        if start < 0 or start >= end or end > earliest_query_position:
            raise ValueError("document_ranges must precede every query token")

    max_query_position = int(positions.max().item())
    visible_keys = keys[:, : max_query_position + 1]
    scale = visible_keys.shape[-1] ** -0.5
    logits = torch.bmm(queries, visible_keys.transpose(1, 2)) * scale

    key_positions = torch.arange(max_query_position + 1, device=keys.device)
    causal_mask = key_positions.unsqueeze(0) <= positions.unsqueeze(1)
    probabilities = torch.softmax(logits.masked_fill(~causal_mask.unsqueeze(0), -torch.inf), dim=-1)

    prefix_sums = torch.cat(
        (torch.zeros_like(probabilities[..., :1]), probabilities.cumsum(dim=-1)), dim=-1
    )
    starts = torch.tensor([start for start, _ in document_ranges], device=keys.device)
    ends = torch.tensor([end for _, end in document_ranges], device=keys.device)
    document_mass = prefix_sums[..., ends] - prefix_sums[..., starts]
    return document_mass.mean(dim=1)


def _validate_range(value: tuple[int, int], limit: int, field: str) -> None:
    start, end = value
    if start < 0 or start >= end or end > limit:
        raise ValueError(f"{field} must be within the request token range")
