# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""Call ARRanker's listwise online reranking endpoint.

Start a dedicated ARRanker vLLM server before running this example. The P0
implementation requires a complete prefill and does not share batches with
ordinary pooling or rerank requests.
"""

import json

import requests

URL = "http://127.0.0.1:8000/v1/ar-rerank"
HEADERS = {"accept": "application/json", "Content-Type": "application/json"}
REQUEST = {
    "model": "MindscapeRAG/ARRanker",
    "query": "What is the capital of France?",
    "documents": [
        "The capital of Brazil is Brasilia.",
        "Paris is the capital and largest city of France.",
        "Horses and cows are both animals.",
    ],
    "top_n": 2,
}


def main() -> None:
    response = requests.post(URL, headers=HEADERS, json=REQUEST, timeout=60)
    response.raise_for_status()
    print(json.dumps(response.json(), indent=2))


if __name__ == "__main__":
    main()
