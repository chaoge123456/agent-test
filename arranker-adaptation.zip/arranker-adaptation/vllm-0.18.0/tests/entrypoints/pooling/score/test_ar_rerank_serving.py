# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project

from types import SimpleNamespace

import pytest

from vllm.entrypoints.pooling.score.api_router import router
from vllm.entrypoints.pooling.score.protocol import RerankRequest
from vllm.entrypoints.pooling.score.serving import ServingScores


def test_serving_scores_exposes_a_dedicated_ar_rerank_method():
    """The AR endpoint must not reuse the document-per-request rerank path."""
    assert hasattr(ServingScores, "do_ar_rerank")


def test_score_router_exposes_the_dedicated_ar_rerank_path():
    assert any(route.path == "/v1/ar-rerank" for route in router.routes)


class CharacterTokenizer:
    is_fast = True

    def __call__(self, text, **_kwargs):
        return {
            "input_ids": [list(range(len(text)))],
            "offset_mapping": [[(index, index + 1) for index in range(len(text))]],
        }


class FakeEngineClient:
    def __init__(self, scores):
        self.calls = []
        self.scores = scores

    async def encode(self, prompt, pooling_params, request_id, **kwargs):
        self.calls.append((prompt, pooling_params, request_id, kwargs))
        yield SimpleNamespace(
            request_id=request_id,
            outputs=SimpleNamespace(data=self.scores),
            prompt_token_ids=prompt["prompt_token_ids"],
        )


class ScoreVector:
    def __init__(self, values):
        self.values = values

    def tolist(self):
        return self.values


def make_serving(scores):
    serving = object.__new__(ServingScores)
    serving.architecture = "Qwen3ARForRerank"
    serving.model_config = SimpleNamespace(max_model_len=1024)
    serving.models = SimpleNamespace(model_name=lambda: "ar-model")
    serving.renderer = SimpleNamespace(get_tokenizer=lambda: CharacterTokenizer())
    serving.engine_client = FakeEngineClient(ScoreVector(scores))
    serving._maybe_get_adapters = lambda _request: None
    serving._base_request_id = lambda _raw_request: "unit-test"

    async def check_model(_request):
        return None

    serving._check_model = check_model
    return serving


@pytest.mark.asyncio
async def test_ar_rerank_submits_one_listwise_prompt_and_sorts_the_score_vector():
    serving = make_serving([0.2, 0.9, 0.5])
    request = RerankRequest(
        model="ar-model",
        query="Which document is relevant?",
        documents=["first", "second", "third"],
        top_n=2,
    )

    response = await serving.do_ar_rerank(request)

    assert len(serving.engine_client.calls) == 1
    prompt, pooling_params, request_id, _kwargs = serving.engine_client.calls[0]
    assert prompt["prompt"].count("[1]") == 1
    assert prompt["prompt"].count("[2]") == 1
    assert prompt["prompt"].count("[3]") == 1
    assert pooling_params.task == "score"
    assert pooling_params.extra_kwargs["ar_rerank"]["request_key"]
    assert request_id == "ar-rerank-unit-test"
    assert [result.index for result in response.results] == [1, 2]
    assert [result.relevance_score for result in response.results] == [0.9, 0.5]
    assert response.usage.prompt_tokens == len(prompt["prompt_token_ids"])


@pytest.mark.asyncio
async def test_ar_rerank_rejects_a_score_vector_with_wrong_document_count():
    serving = make_serving([0.2])
    request = RerankRequest(
        model="ar-model",
        query="Which document is relevant?",
        documents=["first", "second"],
    )

    response = await serving.do_ar_rerank(request)

    assert response.error.code == 500
    assert "expected 2 scores, received 1" in response.error.message
