# SPDX-License-Identifier: Apache-2.0

import importlib.util
from pathlib import Path
import re

import pytest


_MODULE_PATH = (
    Path(__file__).parents[4]
    / "vllm"
    / "entrypoints"
    / "pooling"
    / "ar_rerank.py"
)
_SPEC = importlib.util.spec_from_file_location("ar_rerank_under_test", _MODULE_PATH)
assert _SPEC is not None
assert _SPEC.loader is not None
_MODULE = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_MODULE)

ARRerankRequest = _MODULE.ARRerankRequest
build_ar_prompt_and_metadata = _MODULE.build_ar_prompt_and_metadata


class CharacterTokenizer:
    """A deterministic fast-tokenizer stand-in: one visible character per token."""

    is_fast = True

    def __init__(self):
        self.calls = []

    def __call__(self, text, **kwargs):
        self.calls.append((text, kwargs))
        return {
            "input_ids": [list(range(len(text)))],
            "offset_mapping": [[(index, index + 1) for index in range(len(text))]],
        }


def test_builds_one_token_prompt_with_document_and_query_ranges():
    """Catches a builder that tokenizes fragments or loses listwise boundaries."""
    tokenizer = CharacterTokenizer()
    request = ARRerankRequest(query="which city?", documents=("Alpha", "Beta"))

    prompt, metadata = build_ar_prompt_and_metadata(
        tokenizer, request, max_model_len=1024
    )

    expected_text = (
        "<|im_start|>user\nHere are some retrieved chunks:\n\n"
        "[1] : Alpha\n\n"
        "[2] : Beta\n\n"
        "Use the retrieved chunks to answer the user's query.\n\n"
        "Query: which city?"
    )
    assert prompt["prompt"] == expected_text
    assert prompt["prompt_token_ids"] == list(range(len(expected_text)))
    assert metadata.document_ranges == (
        (expected_text.index(" : Alpha"), expected_text.index(" : Alpha") + len(" : Alpha")),
        (expected_text.index(" : Beta"), expected_text.index(" : Beta") + len(" : Beta")),
    )
    assert metadata.query_range == (
        expected_text.index("which city?"),
        expected_text.index("which city?") + len("which city?"),
    )
    assert len(tokenizer.calls) == 1
    assert tokenizer.calls[0][1]["return_offsets_mapping"] is True
    assert tokenizer.calls[0][1]["add_special_tokens"] is False


class FlatCharacterTokenizer(CharacterTokenizer):
    """Matches HF's single-string tokenizer output (no batch dimension)."""

    def __call__(self, text, **kwargs):
        self.calls.append((text, kwargs))
        return {
            "input_ids": list(range(len(text))),
            "offset_mapping": [(index, index + 1) for index in range(len(text))],
        }


def test_builds_metadata_from_a_single_string_tokenizer_output():
    """Catches treating HF's one-dimensional output as a malformed batch."""
    prompt, metadata = build_ar_prompt_and_metadata(
        FlatCharacterTokenizer(),
        ARRerankRequest(query="q", documents=("doc",)),
        max_model_len=1024,
    )

    assert len(prompt["prompt_token_ids"]) == len(prompt["prompt"])
    assert metadata.document_ranges
    assert metadata.query_range[1] == len(prompt["prompt"])


@pytest.mark.parametrize(
    ("ar_request", "max_model_len", "message"),
    [
        (ARRerankRequest(query="", documents=("document",)), 32, "query"),
        (ARRerankRequest(query="query", documents=()), 32, "documents"),
        (ARRerankRequest(query="query", documents=("",)), 32, "documents[0]"),
        (ARRerankRequest(query="query", documents=("document",)), 1, "max_model_len"),
    ],
)
def test_rejects_invalid_or_overlong_request_before_engine_submission(
    ar_request, max_model_len, message
):
    """Catches silent truncation and malformed document metadata."""
    with pytest.raises(ValueError, match=re.escape(message)):
        build_ar_prompt_and_metadata(
            CharacterTokenizer(), ar_request, max_model_len=max_model_len
        )
