# SPDX-License-Identifier: Apache-2.0

import importlib.util
from pathlib import Path

import pytest


_MODULE_PATH = (
    Path(__file__).parents[4]
    / "vllm"
    / "entrypoints"
    / "pooling"
    / "ar_rerank.py"
)
_SPEC = importlib.util.spec_from_file_location("ar_rerank_contract_under_test", _MODULE_PATH)
assert _SPEC is not None
assert _SPEC.loader is not None
_MODULE = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_MODULE)

ARRequestMetadata = _MODULE.ARRequestMetadata
ARRerankRequest = _MODULE.ARRerankRequest
build_ar_pooling_extra_kwargs = _MODULE.build_ar_pooling_extra_kwargs
to_ar_rerank_output = _MODULE.to_ar_rerank_output
prepare_ar_pooling_request = _MODULE.prepare_ar_pooling_request


def test_serializes_only_primitive_metadata_for_pooling_params_transport():
    """Catches accidental transport of request-local Python objects to workers."""
    metadata = ARRequestMetadata(
        document_ranges=((2, 7), (9, 12)), query_range=(14, 17)
    )

    payload = build_ar_pooling_extra_kwargs(metadata)

    assert payload == {
        "ar_rerank": {
            "document_ranges": [[2, 7], [9, 12]],
            "query_range": [14, 17],
        }
    }


def test_converts_one_score_vector_to_one_rerank_output():
    """Catches the scalar cross-encoder output assumption in listwise scoring."""
    output = to_ar_rerank_output("ar-42", [0.125, 0.875], document_count=2)

    assert output.request_id == "ar-42"
    assert output.scores == (0.125, 0.875)


def test_rejects_a_score_vector_with_the_wrong_document_count():
    """Catches truncated or cross-request-contaminated AR pooler outputs."""
    with pytest.raises(RuntimeError, match="expected 2 scores, received 1"):
        to_ar_rerank_output("ar-42", [0.125], document_count=2)


def test_prepares_one_prompt_and_pooling_params_payload_for_one_listwise_request():
    """Catches a future entrypoint that rebuilds metadata separately from its prompt."""

    class CharacterTokenizer:
        is_fast = True

        def __call__(self, text, **_kwargs):
            return {
                "input_ids": [list(range(len(text)))],
                "offset_mapping": [[(i, i + 1) for i in range(len(text))]],
            }

    prepared = prepare_ar_pooling_request(
        CharacterTokenizer(), ARRerankRequest(query="q", documents=("d1", "d2")), max_model_len=256
    )

    assert prepared.prompt["prompt"].count("[1]") == 1
    assert prepared.prompt["prompt"].count("[2]") == 1
    assert prepared.pooling_params == {
        "task": "score",
        "skip_reading_prefix_cache": True,
        "extra_kwargs": {
            "ar_rerank": {
                "document_ranges": [[53, 58], [63, 68]],
                "query_range": [131, 132],
            }
        },
    }


def test_offline_llm_exposes_an_explicit_engine_shutdown_api():
    """A short-lived AR script must not leave EngineCore cleanup to GC."""
    llm_source = (_MODULE_PATH.parents[1] / "llm.py").read_text(encoding="utf-8")

    assert "def shutdown(self) -> None:" in llm_source
    assert "self.llm_engine.engine_core.shutdown()" in llm_source
