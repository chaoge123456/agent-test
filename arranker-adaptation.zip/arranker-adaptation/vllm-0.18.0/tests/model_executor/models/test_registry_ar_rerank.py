# SPDX-License-Identifier: Apache-2.0

from pathlib import Path


def test_model_registry_resolves_arranker_architecture_to_renamed_module():
    registry_path = (
        Path(__file__).parents[3]
        / "vllm"
        / "model_executor"
        / "models"
        / "registry.py"
    )
    source = registry_path.read_text(encoding="utf-8")

    assert '"Qwen3ARForRerank": ("qwen3_ar", "Qwen3ARForRerank")' in source
