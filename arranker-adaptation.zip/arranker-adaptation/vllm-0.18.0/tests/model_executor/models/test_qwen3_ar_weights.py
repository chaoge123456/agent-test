# SPDX-License-Identifier: Apache-2.0

import importlib.util
from pathlib import Path

import pytest


_MODULE_PATH = (
    Path(__file__).parents[3]
    / "vllm"
    / "model_executor"
    / "models"
    / "qwen3_ar_weights.py"
)
_SPEC = importlib.util.spec_from_file_location("qwen3_ar_weights_under_test", _MODULE_PATH)
assert _SPEC is not None
assert _SPEC.loader is not None
_MODULE = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_MODULE)

map_ar_checkpoint_name = _MODULE.map_ar_checkpoint_name


@pytest.mark.parametrize(
    ("checkpoint_name", "expected"),
    [
        ("embed_tokens.weight", "model.embed_tokens.weight"),
        ("layers.0.self_attn.q_proj.weight", "model.layers.0.self_attn.q_proj.weight"),
        ("layers.24.mlp.down_proj.weight", "model.layers.24.mlp.down_proj.weight"),
    ],
)
def test_maps_checkpoint_weights_into_the_truncated_vllm_model_namespace(
    checkpoint_name, expected
):
    """Catches a loader that drops valid unprefixed AR checkpoint weights."""
    assert map_ar_checkpoint_name(checkpoint_name, executable_layer_count=25) == expected


@pytest.mark.parametrize(
    "checkpoint_name",
    [
        "layers.25.self_attn.q_proj.weight",
        "norm.weight",
        "lm_head.weight",
    ],
)
def test_rejects_weights_for_components_not_present_in_ar_execution_model(checkpoint_name):
    """Catches silent loading of the base model's unused tail or output heads."""
    with pytest.raises(ValueError, match="not part of the AR execution model"):
        map_ar_checkpoint_name(checkpoint_name, executable_layer_count=25)
