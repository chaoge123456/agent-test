# SPDX-License-Identifier: Apache-2.0

import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

import pytest


_MODULE_PATH = (
    Path(__file__).parents[3]
    / "vllm"
    / "model_executor"
    / "models"
    / "qwen3_ar_config.py"
)
_SPEC = importlib.util.spec_from_file_location("qwen3_ar_config_under_test", _MODULE_PATH)
assert _SPEC is not None
assert _SPEC.loader is not None
_MODULE = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_MODULE)

ARModelSpec = _MODULE.ARModelSpec


def test_derives_the_25_layer_ar_execution_contract_from_checkpoint_config():
    """Catches an adapter that uses Qwen3's nominal 36 layers instead of AR's 25."""
    config_path = Path(__file__).parents[4] / "arranker" / "config.json"
    config = json.loads(config_path.read_text(encoding="utf-8"))

    spec = ARModelSpec.from_config(config)

    assert spec.executable_layer_count == 25
    assert spec.selected_layer_heads == tuple(tuple(item) for item in config["ar_head_list"])
    assert spec.q_heads_per_kv_head == 4
    assert spec.uses_final_norm is False
    assert spec.uses_lm_head is False


def test_accepts_transformers_style_config_object():
    """vLLM passes a PretrainedConfig-like object, not a dict, to the model."""
    config = SimpleNamespace(
        architectures=["Qwen3ARForRerank"],
        num_hidden_layers=36,
        ar_end_layer=25,
        num_attention_heads=32,
        num_key_value_heads=8,
        ar_head_list=[[17, 0]],
    )

    spec = ARModelSpec.from_config(config)

    assert spec.executable_layer_count == 25
    assert spec.selected_layer_heads == ((17, 0),)


def test_rejects_a_selected_head_outside_the_executed_layers():
    """Catches a configuration that cannot be served by the truncated AR model."""
    with pytest.raises(ValueError, match="ar_head_list"):
        ARModelSpec.from_config(
            {
                "architectures": ["Qwen3ARForRerank"],
                "num_hidden_layers": 36,
                "ar_end_layer": 25,
                "num_attention_heads": 32,
                "num_key_value_heads": 8,
                "ar_head_list": [[25, 0]],
            }
        )


def test_ar_model_reuses_the_registered_attention_module():
    """Replacing Attention would register a duplicate ``.attn`` layer name."""
    model_path = _MODULE_PATH.with_name("qwen3_ar.py")
    source = model_path.read_text(encoding="utf-8")

    assert "old.__class__ = Qwen3ARAttention" in source
    assert "layer.self_attn = Qwen3ARAttention(" not in source


def test_ar_model_uses_a_residual_aware_no_final_norm():
    """The no-norm AR model still receives (hidden_states, residual)."""
    model_path = _MODULE_PATH.with_name("qwen3_ar.py")
    source = model_path.read_text(encoding="utf-8")

    assert "class ARNoFinalNorm(nn.Module):" in source
    assert "residual: torch.Tensor | None" in source
    assert "return hidden_states + residual, residual" in source
    assert "self.model.norm = ARNoFinalNorm()" in source


def test_ar_pooler_implements_vllm_pooling_task_contract():
    """V1 asks every pooling model which pooling tasks it supports."""
    model_path = _MODULE_PATH.with_name("qwen3_ar.py")
    source = model_path.read_text(encoding="utf-8")

    assert "from vllm.model_executor.layers.pooler import Pooler" in source
    assert "class ARScorePooler(Pooler):" in source
    assert "def get_supported_tasks(self)" in source
    assert 'return {"score"}' in source


def test_ar_model_marks_its_custom_score_pooler_as_single_label():
    """V1 otherwise removes ``score`` from a pooler's advertised tasks."""
    model_path = _MODULE_PATH.with_name("qwen3_ar.py")
    source = model_path.read_text(encoding="utf-8")

    assert "hf_config.num_labels = 1" in source


def test_ar_pooler_uses_transport_metadata_not_nonexistent_request_ids():
    """V1 pooling metadata carries params, but not scheduler request IDs."""
    model_path = _MODULE_PATH.with_name("qwen3_ar.py")
    source = model_path.read_text(encoding="utf-8")

    assert 'getattr(pooling_metadata, "req_ids", None)' not in source
    assert "pooling_metadata.pooling_params" in source
    assert 'payload.get("request_key")' in source
    assert "hidden_states.new_zeros(1)" in source
