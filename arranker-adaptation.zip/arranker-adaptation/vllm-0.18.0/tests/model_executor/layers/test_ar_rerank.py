# SPDX-License-Identifier: Apache-2.0

import importlib.util
import math
from pathlib import Path

import pytest


_MODULE_PATH = (
    Path(__file__).parents[3] / "vllm" / "model_executor" / "layers" / "ar_rerank.py"
)
_SPEC = importlib.util.spec_from_file_location("ar_rerank_math_under_test", _MODULE_PATH)
assert _SPEC is not None
assert _SPEC.loader is not None
_MODULE = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_MODULE)

score_one_head_paged_k = _MODULE.score_one_head_paged_k


def _materialized_score(query_vectors, keys, document_ranges, query_positions):
    """Independent, deliberately materialized causal-softmax reference."""
    document_totals = [0.0] * len(document_ranges)
    for query, query_position in zip(query_vectors, query_positions):
        logits = [sum(q * k for q, k in zip(query, key)) for key in keys[: query_position + 1]]
        max_logit = max(logits)
        weights = [math.exp(logit - max_logit) for logit in logits]
        denominator = sum(weights)
        for index, (start, end) in enumerate(document_ranges):
            document_totals[index] += sum(weights[start:end]) / denominator
    return [total / len(query_vectors) for total in document_totals]


def test_matches_causal_attention_mass_without_materializing_attention_matrix():
    """Catches a scorer that omits prefix keys or reads future keys."""
    # Physical blocks 1, 0, and 2 store logical blocks 0, 1, and 2.
    key_cache = [
        [[0.0, 1.0], [1.0, 1.0]],
        [[1.0, 0.0], [0.0, 0.0]],
        [[0.5, 0.5], [1.0, -1.0]],
    ]
    block_table = [1, 0, 2]
    query_vectors = [[1.0, 0.0], [0.0, 1.0]]
    document_ranges = [(1, 3), (3, 4)]
    query_positions = [4, 5]

    result = score_one_head_paged_k(
        query_vectors,
        key_cache,
        block_table,
        document_ranges,
        query_positions,
        block_size=2,
    )

    logical_keys = [
        key_cache[1][0], key_cache[1][1], key_cache[0][0],
        key_cache[0][1], key_cache[2][0], key_cache[2][1],
    ]
    expected = _materialized_score(
        query_vectors, logical_keys, document_ranges, query_positions
    )
    assert result == pytest.approx(expected, abs=1e-12)


def test_rejects_document_range_outside_the_causal_key_span():
    """Catches silently ignored document tokens caused by invalid metadata."""
    with pytest.raises(ValueError, match="document_ranges"):
        score_one_head_paged_k(
            [[1.0]],
            [[[1.0], [2.0]]],
            [0],
            [(0, 3)],
            [1],
            block_size=2,
        )
