# SPDX-License-Identifier: Apache-2.0
"""vLLM model wrapper for the ARRanker Qwen3 checkpoint.

The Ascend runner computes AR scores after forward and deposits them in the
pooler. Keeping that hand-off here makes the model a normal vLLM pooling model
for the offline ``LLM.ar_rerank`` entrypoint.
"""

from collections.abc import Iterable, Set
from typing import Any

import torch
from torch import nn

from vllm.config import VllmConfig
from vllm.model_executor.layers.pooler import Pooler
from vllm.model_executor.models.qwen3 import Qwen3Attention, Qwen3ForCausalLM
from vllm.model_executor.models.qwen3_ar_config import ARModelSpec
from vllm.model_executor.models.qwen3_ar_weights import map_ar_checkpoint_name
from vllm.tasks import PoolingTask


class ARNoFinalNorm(nn.Module):
    """Preserve Qwen's fused-residual interface without a AR norm weight."""

    def forward(
        self, hidden_states: torch.Tensor, residual: torch.Tensor | None
    ) -> tuple[torch.Tensor, torch.Tensor | None]:
        if residual is None:
            return hidden_states, residual
        # Qwen's decoder keeps the final MLP result separate from its residual
        # until the final norm. ARRanker omits that norm, but still needs their
        # unnormalized sum, exactly as its reference implementation returns.
        return hidden_states + residual, residual


class ARScorePooler(Pooler):
    """Returns the request-local score vector prepared by the model runner."""

    def __init__(self) -> None:
        super().__init__()
        self._scores: dict[str, torch.Tensor] = {}

    def set_scores(self, scores_by_request: dict[str, torch.Tensor]) -> None:
        self._scores.update(scores_by_request)

    def get_supported_tasks(self) -> Set[PoolingTask]:
        return {"score"}

    def forward(self, hidden_states: torch.Tensor, pooling_metadata):
        outputs: list[torch.Tensor] = []
        for params in pooling_metadata.pooling_params:
            payload = ((params.extra_kwargs or {}).get("ar_rerank"))
            if payload is None:
                # V1's engine-startup profile uses synthetic pooling metadata.
                # It has no AR request, but still must run the pooler to size
                # its output buffers.
                outputs.append(hidden_states.new_zeros(1))
                continue

            request_key = payload.get("request_key")
            if not isinstance(request_key, str) or not request_key:
                raise RuntimeError("AR pooling request is missing request_key")
            score = self._scores.pop(request_key, None)
            if score is None:
                raise RuntimeError(
                    "AR runner bridge did not deposit scores for request_key="
                    f"{request_key}"
                )
            outputs.append(score)
        return outputs


class Qwen3ARAttention(Qwen3Attention):
    """Qwen3 attention that exposes post-RoPE Q for AR scoring."""

    def enable_ar_capture(
        self, *, ar_layer: int, ar_heads: set[int], capture: dict
    ) -> None:
        """Attach AR state without constructing another registered Attention."""
        self.ar_layer = ar_layer
        self.ar_heads = ar_heads
        self.capture = capture

    def forward(self, positions: torch.Tensor, hidden_states: torch.Tensor) -> torch.Tensor:
        qkv, _ = self.qkv_proj(hidden_states)
        q, k, v = qkv.split([self.q_size, self.kv_size, self.kv_size], dim=-1)
        q_by_head = self.q_norm(q.view(*q.shape[:-1], self.num_heads, self.head_dim))
        k_by_head = self.k_norm(k.view(*k.shape[:-1], self.num_kv_heads, self.head_dim))
        q = q_by_head.reshape_as(q)
        k = k_by_head.reshape_as(k)
        q, k = self.rotary_emb(positions, q, k)
        q_after_rope = q.view(*q.shape[:-1], self.num_heads, self.head_dim)
        for head in self.ar_heads:
            self.capture[(self.ar_layer, head)] = q_after_rope[:, head, :]
        attn_output = self.attn(q, k, v)
        output, _ = self.o_proj(attn_output)
        return output


class Qwen3ARForRerank(Qwen3ForCausalLM):
    """ARRanker pooling wrapper; Ascend runner owns paged-K score reduction."""

    is_pooling_model = True

    def __init__(self, *, vllm_config: VllmConfig, prefix: str = "") -> None:
        # V1 exposes ``score`` only for one-logit pooling models. ARRanker
        # produces a custom score vector, but uses that task for transport.
        hf_config = vllm_config.model_config.hf_config
        hf_config.num_labels = 1
        super().__init__(vllm_config=vllm_config, prefix=prefix)
        self.ar_spec = ARModelSpec.from_config(vllm_config.model_config.hf_config)
        # AR checkpoints contain only layers [0, ar_end_layer). P0 uses PP=1.
        self.model.layers = self.model.layers[: self.ar_spec.executable_layer_count]
        self.model.end_layer = min(self.model.end_layer, self.ar_spec.executable_layer_count)
        # ARRanker deliberately stops after layer 24 and has no final RMSNorm.
        # Keep the inherited forward path intact while removing its parameter.
        self.model.norm = ARNoFinalNorm()
        self.pooler = ARScorePooler()
        self._ar_q_capture: dict[tuple[int, int], torch.Tensor] = {}
        heads_by_layer: dict[int, set[int]] = {}
        for layer, head in self.ar_spec.selected_layer_heads:
            heads_by_layer.setdefault(layer, set()).add(head)
        for layer_id, layer in enumerate(self.model.layers):
            if layer_id not in heads_by_layer:
                continue
            old = layer.self_attn
            # The original constructor already registered ``old.attn`` in
            # static_forward_context. Reconstructing it produces a duplicate
            # layer-name error, so preserve its parameters and registration.
            old.__class__ = Qwen3ARAttention
            old.enable_ar_capture(
                ar_layer=layer_id,
                ar_heads=heads_by_layer[layer_id],
                capture=self._ar_q_capture,
            )

    def consume_ar_q_capture(self) -> dict[tuple[int, int], torch.Tensor]:
        captured, self._ar_q_capture = self._ar_q_capture, {}
        for layer in self.model.layers:
            if isinstance(layer.self_attn, Qwen3ARAttention):
                layer.self_attn.capture = self._ar_q_capture
        return captured

    def load_weights(self, weights: Iterable[tuple[str, torch.Tensor]]) -> set[str]:
        mapped = (
            (map_ar_checkpoint_name(name, executable_layer_count=self.ar_spec.executable_layer_count), weight)
            for name, weight in weights
        )
        return super().load_weights(mapped)
