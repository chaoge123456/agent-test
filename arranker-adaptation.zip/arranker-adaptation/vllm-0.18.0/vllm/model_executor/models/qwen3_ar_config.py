# SPDX-License-Identifier: Apache-2.0

"""Device-independent structural contract for Qwen3 ARRanker checkpoints."""

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class ARModelSpec:
    """The subset of checkpoint configuration required by the vLLM adapter."""

    executable_layer_count: int
    selected_layer_heads: tuple[tuple[int, int], ...]
    q_heads_per_kv_head: int
    uses_final_norm: bool = False
    uses_lm_head: bool = False

    @classmethod
    def from_config(cls, config: Mapping[str, Any] | Any) -> "ARModelSpec":
        architectures = _config_value(config, "architectures", [])
        if "Qwen3ARForRerank" not in architectures:
            raise ValueError("architectures must contain Qwen3ARForRerank")

        total_layers = _positive_int(config, "num_hidden_layers")
        executable_layers = _positive_int(config, "ar_end_layer")
        q_heads = _positive_int(config, "num_attention_heads")
        kv_heads = _positive_int(config, "num_key_value_heads")
        if executable_layers > total_layers:
            raise ValueError("ar_end_layer must not exceed num_hidden_layers")
        if q_heads % kv_heads:
            raise ValueError("num_attention_heads must divide by num_key_value_heads")

        raw_selected_heads = _config_value(config, "ar_head_list")
        if not isinstance(raw_selected_heads, list) or not raw_selected_heads:
            raise ValueError("ar_head_list must be a non-empty list")

        selected_layer_heads: list[tuple[int, int]] = []
        for item in raw_selected_heads:
            if not isinstance(item, list) or len(item) != 2:
                raise ValueError("ar_head_list entries must be [layer, head]")
            layer, head = item
            if not isinstance(layer, int) or not isinstance(head, int):
                raise ValueError("ar_head_list entries must contain integers")
            if layer < 0 or layer >= executable_layers or head < 0 or head >= q_heads:
                raise ValueError("ar_head_list contains a layer or head outside AR execution")
            selected_layer_heads.append((layer, head))

        return cls(
            executable_layer_count=executable_layers,
            selected_layer_heads=tuple(selected_layer_heads),
            q_heads_per_kv_head=q_heads // kv_heads,
        )


def _config_value(config: Mapping[str, Any] | Any, field: str, default: Any = None) -> Any:
    """Read either a JSON-like mapping or a Transformers PretrainedConfig."""
    if isinstance(config, Mapping):
        return config.get(field, default)
    return getattr(config, field, default)


def _positive_int(config: Mapping[str, Any] | Any, field: str) -> int:
    value = _config_value(config, field)
    if not isinstance(value, int) or value < 1:
        raise ValueError(f"{field} must be a positive integer")
    return value
