# SPDX-License-Identifier: Apache-2.0

"""Reference ARRanker paged-K scoring math with no device dependency."""

import math
from collections.abc import Sequence


def score_one_head_paged_k(
    query_vectors: Sequence[Sequence[float]],
    key_cache: Sequence[Sequence[Sequence[float]]],
    block_table: Sequence[int],
    document_ranges: Sequence[tuple[int, int]],
    query_positions: Sequence[int],
    *,
    block_size: int,
) -> list[float]:
    """Return per-document causal attention mass for one layer/head.

    `block_table[logical_block]` identifies the physical key-cache block. The
    implementation keeps an online softmax denominator and one numerator per
    document, so it never creates a query-by-sequence attention matrix.
    """
    if block_size < 1:
        raise ValueError("block_size must be positive")
    if not query_vectors:
        raise ValueError("query_vectors must not be empty")
    if len(query_vectors) != len(query_positions):
        raise ValueError("query_vectors and query_positions must have equal length")
    if not block_table:
        raise ValueError("block_table must not be empty")

    max_key_position = len(block_table) * block_size - 1
    if any(position < 0 or position > max_key_position for position in query_positions):
        raise ValueError("query_positions exceed key cache capacity")
    _validate_document_ranges(document_ranges, min(query_positions) + 1)

    document_totals = [0.0] * len(document_ranges)
    for query, query_position in zip(query_vectors, query_positions):
        running_max = -math.inf
        denominator = 0.0
        numerators = [0.0] * len(document_ranges)

        for key_position in range(query_position + 1):
            key = _key_at(key_cache, block_table, key_position, block_size)
            if len(query) != len(key):
                raise ValueError("query and key head dimensions must match")
            logit = sum(float(q) * float(k) for q, k in zip(query, key))

            if logit > running_max:
                scale = 0.0 if running_max == -math.inf else math.exp(running_max - logit)
                denominator *= scale
                numerators = [value * scale for value in numerators]
                running_max = logit

            weight = math.exp(logit - running_max)
            denominator += weight
            for index, (start, end) in enumerate(document_ranges):
                if start <= key_position < end:
                    numerators[index] += weight

        document_totals = [
            total + numerator / denominator
            for total, numerator in zip(document_totals, numerators)
        ]

    return [total / len(query_vectors) for total in document_totals]


def _validate_document_ranges(
    document_ranges: Sequence[tuple[int, int]], causal_key_count: int
) -> None:
    for start, end in document_ranges:
        if start < 0 or start >= end or end > causal_key_count:
            raise ValueError("document_ranges must be within every causal key span")


def _key_at(
    key_cache: Sequence[Sequence[Sequence[float]]],
    block_table: Sequence[int],
    key_position: int,
    block_size: int,
) -> Sequence[float]:
    logical_block, offset = divmod(key_position, block_size)
    physical_block = block_table[logical_block]
    if physical_block < 0 or physical_block >= len(key_cache):
        raise ValueError("block_table contains an invalid physical block")
    block = key_cache[physical_block]
    if offset >= len(block):
        raise ValueError("key_cache block is shorter than block_size")
    return block[offset]
