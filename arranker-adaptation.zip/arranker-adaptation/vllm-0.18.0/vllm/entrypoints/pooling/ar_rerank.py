# SPDX-License-Identifier: Apache-2.0

"""Platform-independent request construction for ARRanker offline scoring."""

from dataclasses import dataclass
from typing import Any, Protocol, Sequence


class OffsetTokenizer(Protocol):
    """The small fast-tokenizer surface required by ARRanker input building."""

    is_fast: bool

    def __call__(self, text: str, **kwargs: Any) -> Any: ...


@dataclass(frozen=True)
class ARRerankRequest:
    """One listwise ARRanker request before it enters the vLLM engine."""

    query: str
    documents: tuple[str, ...]


@dataclass(frozen=True)
class ARRequestMetadata:
    """Token intervals used by the AR attention-mass scorer."""

    document_ranges: tuple[tuple[int, int], ...]
    query_range: tuple[int, int]


@dataclass(frozen=True)
class ARRerankOutput:
    """The listwise scores produced by one ARRanker engine request."""

    request_id: str
    scores: tuple[float, ...]


@dataclass(frozen=True)
class ARPreparedPoolingRequest:
    """The exact prompt and pooling fields an offline vLLM entrypoint submits."""

    prompt: dict[str, Any]
    pooling_params: dict[str, Any]


def build_ar_pooling_extra_kwargs(metadata: ARRequestMetadata) -> dict[str, Any]:
    """Return msgpack-safe metadata for ``PoolingParams.extra_kwargs``."""
    return {
        "ar_rerank": {
            "document_ranges": [list(item) for item in metadata.document_ranges],
            "query_range": list(metadata.query_range),
        }
    }


def ar_metadata_from_extra_kwargs(extra_kwargs: dict[str, Any] | None) -> ARRequestMetadata:
    """Rebuild validated request metadata on the worker side."""
    try:
        payload = extra_kwargs["ar_rerank"]  # type: ignore[index]
        document_ranges = tuple(tuple(item) for item in payload["document_ranges"])
        query_range = tuple(payload["query_range"])
    except (KeyError, TypeError) as error:
        raise ValueError("missing ar_rerank metadata") from error
    if len(query_range) != 2 or any(len(item) != 2 for item in document_ranges):
        raise ValueError("invalid ar_rerank metadata ranges")
    return ARRequestMetadata(document_ranges=document_ranges, query_range=query_range)  # type: ignore[arg-type]


def to_ar_rerank_output(
    request_id: str, scores: Sequence[float], *, document_count: int
) -> ARRerankOutput:
    """Validate a model score vector before exposing it to the caller."""
    if len(scores) != document_count:
        raise RuntimeError(
            f"expected {document_count} scores, received {len(scores)}"
        )
    return ARRerankOutput(request_id=request_id, scores=tuple(float(score) for score in scores))


def prepare_ar_pooling_request(
    tokenizer: OffsetTokenizer,
    request: ARRerankRequest,
    *,
    max_model_len: int,
) -> ARPreparedPoolingRequest:
    """Prepare the one prompt/one pooling-request contract for ARRanker."""
    prompt, metadata = build_ar_prompt_and_metadata(
        tokenizer, request, max_model_len=max_model_len
    )
    return ARPreparedPoolingRequest(
        prompt=prompt,
        pooling_params={
            "task": "score",
            "skip_reading_prefix_cache": True,
            "extra_kwargs": build_ar_pooling_extra_kwargs(metadata),
        },
    )


def build_ar_prompt_and_metadata(
    tokenizer: OffsetTokenizer,
    request: ARRerankRequest,
    *,
    max_model_len: int,
) -> tuple[dict[str, Any], ARRequestMetadata]:
    """Build exactly one ARRanker prompt and its token-level score metadata."""
    _validate_request(tokenizer, request, max_model_len)

    prompt, document_char_ranges, query_char_range = _build_prompt(request)
    encoded = tokenizer(
        prompt,
        add_special_tokens=False,
        return_offsets_mapping=True,
    )
    input_ids = _first_batch(encoded["input_ids"], item_is_pair=False)
    offsets = _first_batch(encoded["offset_mapping"], item_is_pair=True)

    if len(input_ids) != len(offsets):
        raise ValueError("tokenizer returned mismatched input_ids and offset_mapping")
    if len(input_ids) > max_model_len:
        raise ValueError(
            f"max_model_len={max_model_len} is shorter than prompt tokens={len(input_ids)}"
        )

    document_ranges = tuple(
        _character_range_to_token_range(offsets, char_range, f"documents[{index}]")
        for index, char_range in enumerate(document_char_ranges)
    )
    query_range = _character_range_to_token_range(offsets, query_char_range, "query")

    return (
        {"prompt": prompt, "prompt_token_ids": input_ids},
        ARRequestMetadata(document_ranges=document_ranges, query_range=query_range),
    )


def _validate_request(
    tokenizer: OffsetTokenizer, request: ARRerankRequest, max_model_len: int
) -> None:
    if not getattr(tokenizer, "is_fast", False):
        raise ValueError("tokenizer must be a fast tokenizer with offset mapping")
    if not request.query.strip():
        raise ValueError("query must not be empty")
    if not request.documents:
        raise ValueError("documents must not be empty")
    for index, document in enumerate(request.documents):
        if not document.strip():
            raise ValueError(f"documents[{index}] must not be empty")
    if max_model_len < 1:
        raise ValueError("max_model_len must be positive")


def _build_prompt(
    request: ARRerankRequest,
) -> tuple[str, list[tuple[int, int]], tuple[int, int]]:
    prompt = "<|im_start|>user\nHere are some retrieved chunks:\n\n"
    document_char_ranges: list[tuple[int, int]] = []
    for index, document in enumerate(request.documents, start=1):
        prompt += f"[{index}]"
        start = len(prompt)
        prompt += f" : {document.strip()}"
        document_char_ranges.append((start, len(prompt)))
        prompt += "\n\n"

    prompt += "Use the retrieved chunks to answer the user's query.\n\nQuery: "
    query_start = len(prompt)
    prompt += request.query
    return prompt, document_char_ranges, (query_start, len(prompt))


def _first_batch(values: Any, *, item_is_pair: bool) -> list[Any]:
    """Normalize HF tokenizer outputs for either one string or a batch."""
    if hasattr(values, "tolist"):
        values = values.tolist()
    if not isinstance(values, Sequence) or not values:
        raise ValueError("tokenizer returned an empty batch")
    first = values[0]
    if hasattr(first, "tolist"):
        first = first.tolist()
    if not isinstance(first, Sequence):
        # ``input_ids`` for one string is a flat sequence of integers.
        return list(values)
    if item_is_pair and (not first or not isinstance(first[0], Sequence)):
        # ``offset_mapping`` for one string is a flat sequence of pairs.
        return list(values)
    return list(first)


def _character_range_to_token_range(
    offsets: Sequence[Sequence[int]], char_range: tuple[int, int], field: str
) -> tuple[int, int]:
    char_start, char_end = char_range
    token_indices = [
        index
        for index, (token_start, token_end) in enumerate(offsets)
        if token_end > char_start and token_start < char_end
    ]
    if not token_indices:
        raise ValueError(f"{field} does not map to any token")
    return token_indices[0], token_indices[-1] + 1
