# ARRanker Adaptation Renaming Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Create a replacement-ready ARRanker adaptation payload with behavior identical to the QRRanker source adaptation except for the approved global naming migration.

**Architecture:** Copy only the QRRanker-specific source, test, and example files into `arranker-adaptation/` while preserving both repository-relative directory roots. Rename module paths and all code-level contracts coherently so imports, public APIs, endpoint, model architecture, checkpoint configuration keys, worker metadata, and tests resolve only through AR names.

**Tech Stack:** Python 3, pytest, vLLM 0.18.0, vLLM Ascend 0.18.0, PowerShell.

## Global Constraints

- Write only beneath `D:\code\vllm-ascend\arranker-adaptation\`; do not modify source repositories.
- Include only files sourced from `vllm-0.18.0/` and `vllm-ascend-0.18.0/`; exclude `qrranker-monitor/`.
- Apply the approved mapping exactly: `QRRanker`→`ARRanker`, `QRRerank`→`ARRerank`, `qr_rerank`→`ar_rerank`, `qr-rerank`→`ar-rerank`, `Qwen3QR`→`Qwen3AR`, `QRModelSpec`→`ARModelSpec`, `qr_end_layer`→`ar_end_layer`, and `qr_layer_head_map`→`ar_layer_head_map`.
- Preserve all executable logic and numerical behavior; no refactoring or algorithm changes.

---

### Task 1: Establish the renamed test contract

**Files:**
- Create: `vllm-0.18.0/tests/model_executor/layers/test_ar_rerank.py`
- Create: `vllm-0.18.0/tests/model_executor/models/test_qwen3_ar_config.py`
- Create: `vllm-0.18.0/tests/model_executor/models/test_qwen3_ar_weights.py`
- Create: `vllm-0.18.0/tests/entrypoints/pooling/score/test_ar_rerank_serving.py`
- Create: `vllm-0.18.0/tests/entrypoints/pooling/ar_rerank/test_prompt.py`
- Create: `vllm-0.18.0/tests/entrypoints/pooling/ar_rerank/test_contract.py`
- Create: `vllm-ascend-0.18.0/tests/worker/test_ar_rerank.py`

**Interfaces:**
- Consumes: Existing QRRanker tests and the approved naming map.
- Produces: Tests importing `ar_rerank.py` and `qwen3_ar*.py`, requiring `Qwen3ARForRerank`, `ar_end_layer`, `ar_layer_head_map`, `LLM.ar_rerank`, and `/v1/ar-rerank`.

- [ ] **Step 1: Copy test files into mirrored AR paths and apply only the naming map.**
- [ ] **Step 2: Run one representative direct-module test before production copies exist.**

Run: `pytest arranker-adaptation/vllm-0.18.0/tests/model_executor/models/test_qwen3_ar_config.py -q`

Expected: FAIL because `qwen3_ar_config.py` does not yet exist.

### Task 2: Build the upstream vLLM ARRanker payload

**Files:**
- Create: `vllm-0.18.0/vllm/entrypoints/llm.py`
- Create: `vllm-0.18.0/vllm/entrypoints/pooling/score/serving.py`
- Create: `vllm-0.18.0/vllm/entrypoints/pooling/score/api_router.py`
- Create: `vllm-0.18.0/vllm/entrypoints/pooling/ar_rerank.py`
- Create: `vllm-0.18.0/vllm/model_executor/layers/ar_rerank.py`
- Create: `vllm-0.18.0/vllm/model_executor/models/qwen3_ar.py`
- Create: `vllm-0.18.0/vllm/model_executor/models/qwen3_ar_config.py`
- Create: `vllm-0.18.0/vllm/model_executor/models/qwen3_ar_weights.py`
- Create: `vllm-0.18.0/examples/pooling/score/ar_rerank_api_online.py`

**Interfaces:**
- Consumes: Task 1 test contract.
- Produces: `LLM.ar_rerank`, `ServingScores.do_ar_rerank`, `/v1/ar-rerank`, `ARRerankRequest`, `Qwen3ARForRerank`, and checkpoint configuration keys `ar_end_layer` and `ar_layer_head_map`.

- [ ] **Step 1: Copy each source file to its mirrored AR path and apply only the naming map.**
- [ ] **Step 2: Compile all copied upstream Python files.**

Run: `python -m compileall -q arranker-adaptation/vllm-0.18.0`

Expected: exit code 0.

- [ ] **Step 3: Run the renamed upstream direct-module test group.**

Run: `pytest arranker-adaptation/vllm-0.18.0/tests/model_executor/layers/test_ar_rerank.py arranker-adaptation/vllm-0.18.0/tests/model_executor/models/test_qwen3_ar_config.py arranker-adaptation/vllm-0.18.0/tests/model_executor/models/test_qwen3_ar_weights.py arranker-adaptation/vllm-0.18.0/tests/entrypoints/pooling/ar_rerank/test_prompt.py arranker-adaptation/vllm-0.18.0/tests/entrypoints/pooling/ar_rerank/test_contract.py -q`

Expected: PASS.

### Task 3: Build the vLLM Ascend ARRanker payload

**Files:**
- Create: `vllm-ascend-0.18.0/vllm_ascend/worker/ar_rerank.py`
- Create: `vllm-ascend-0.18.0/vllm_ascend/worker/model_runner_v1.py`

**Interfaces:**
- Consumes: upstream `ar_rerank` metadata key and `Qwen3ARForRerank` runtime contract.
- Produces: the equivalent NPU worker score deposition path using only `ar_rerank` identifiers.

- [ ] **Step 1: Copy the two Ascend source files into mirrored paths and apply only the naming map.**
- [ ] **Step 2: Compile the copied Ascend files.**

Run: `python -m compileall -q arranker-adaptation/vllm-ascend-0.18.0`

Expected: exit code 0.

- [ ] **Step 3: Run the renamed standalone Ascend worker test.**

Run: `pytest arranker-adaptation/vllm-ascend-0.18.0/tests/worker/test_ar_rerank.py -q`

Expected: PASS.

### Task 4: Verify replacement integrity

**Files:**
- Verify: every non-document file beneath `arranker-adaptation/vllm-0.18.0/` and `arranker-adaptation/vllm-ascend-0.18.0/`.

**Interfaces:**
- Consumes: copied payload and original source files.
- Produces: evidence that source trees are unchanged, old identifiers are absent from the payload, and each output is exactly its source after approved substitutions.

- [ ] **Step 1: Compare source-repository modification times and hashes recorded before execution against the current source files.**
- [ ] **Step 2: Search the payload for legacy `qrranker`, `qr_rerank`, `qr-rerank`, `Qwen3QR`, `QRRanker`, `qr_end_layer`, and `qr_layer_head_map` identifiers.**
- [ ] **Step 3: Programmatically normalize approved AR spellings back to QR spellings and compare every payload source/test/example file byte-for-byte with its original.**
- [ ] **Step 4: Run a final Python compilation and all standalone renamed tests.**
