# ARRanker Adaptation Renaming Design

## Goal

Produce a replacement-ready, isolated directory containing the existing QRRanker adaptation renamed to ARRanker, without modifying either source repository.

## Scope

The delivery root is `arranker-adaptation/`. It mirrors files only from `vllm-0.18.0/` and `vllm-ascend-0.18.0/`. `qrranker-monitor/` is explicitly excluded.

## Naming Contract

Rename filesystem paths, Python modules, public APIs, route names, classes, functions, metadata keys, request IDs, model architecture names, documentation strings, examples, and tests consistently:

- `QRRanker` to `ARRanker`
- `QRRerank` to `ARRerank`
- `qr_rerank` to `ar_rerank`
- `qr-rerank` to `ar-rerank`
- `Qwen3QRForRerank` to `Qwen3ARForRerank`
- `Qwen3QR` to `Qwen3AR`
- `QRModelSpec` to `ARModelSpec`
- `qr_end_layer` to `ar_end_layer`
- `qr_layer_head_map` to `ar_layer_head_map`
- internal `qr_` identifiers to corresponding `ar_` identifiers.

The resulting checkpoint contract requires `architectures: ["Qwen3ARForRerank"]`, `ar_end_layer`, and `ar_layer_head_map` in the model `config.json`.

## Delivery Structure

The delivery preserves each file's relative path below its source repository root. Renamed modules use `ar_rerank.py` and `qwen3_ar*.py` paths. Production code, tests, and the online example are all included so they can be copied to the test machine and independently verified.

## Behavior and Performance

Only identifiers and strings change. Prompt construction, paged-K scoring math, captured-Q data flow, tensor operations, cache layout, scheduling assumptions, error conditions, and response shape remain unchanged. The online endpoint becomes `/v1/ar-rerank`; the offline entrypoint becomes `LLM.ar_rerank()`.

## Validation

Verify the delivery with: (1) a source-tree hash before/after comparison, (2) absence of legacy QRRanker-specific identifiers in all copied files, (3) Python syntax compilation, (4) import/contract unit tests from the renamed test tree, and (5) normalized source comparison proving every production change is an approved identifier substitution.
