"""
LLM客户端模块
封装DeepSeek API调用
"""
import json
import time
from typing import Dict, Any, Optional, List
import requests


class LLMClient:
    """DeepSeek LLM客户端"""
    
    def __init__(self, api_key: str, model: str = "deepseek-chat", base_url: str = "https://api.deepseek.com"):
        self.api_key = api_key
        self.model = model
        self.base_url = base_url.rstrip('/')
        self.endpoint = f"{self.base_url}/v1/chat/completions"
        
    def call(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.3,
        max_tokens: int = 4000,
        response_format: Optional[Dict[str, str]] = None,
        retry_times: int = 3,
        retry_delay: float = 2.0
    ) -> str:
        """
        调用LLM API
        
        Args:
            prompt: 用户提示词
            system_prompt: 系统提示词
            temperature: 温度参数
            max_tokens: 最大token数
            response_format: 响应格式，例如 {"type": "json_object"}
            retry_times: 重试次数
            retry_delay: 重试延迟（秒）
            
        Returns:
            LLM响应文本
        """
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens
        }
        
        if response_format:
            payload["response_format"] = response_format
        
        last_error = None
        for attempt in range(retry_times):
            try:
                response = requests.post(
                    self.endpoint,
                    headers=headers,
                    json=payload,
                    timeout=120
                )
                
                if response.status_code == 200:
                    result = response.json()
                    return result['choices'][0]['message']['content']
                else:
                    last_error = f"API返回错误: {response.status_code} - {response.text}"
                    if attempt < retry_times - 1:
                        time.sleep(retry_delay)
                        continue
                    
            except requests.exceptions.Timeout:
                last_error = "请求超时"
                if attempt < retry_times - 1:
                    time.sleep(retry_delay)
                    continue
                    
            except Exception as e:
                last_error = f"请求异常: {str(e)}"
                if attempt < retry_times - 1:
                    time.sleep(retry_delay)
                    continue
        
        raise Exception(f"LLM调用失败（已重试{retry_times}次）: {last_error}")
    
    def call_json(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.3,
        max_tokens: int = 4000,
        retry_times: int = 3
    ) -> Dict[str, Any]:
        """
        调用LLM API并返回JSON格式结果
        
        Args:
            prompt: 用户提示词
            system_prompt: 系统提示词
            temperature: 温度参数
            max_tokens: 最大token数
            retry_times: 重试次数
            
        Returns:
            解析后的JSON对象
        """
        # 在prompt中明确要求JSON格式
        json_prompt = f"{prompt}\n\n请以JSON格式返回结果。"
        
        response_text = self.call(
            prompt=json_prompt,
            system_prompt=system_prompt,
            temperature=temperature,
            max_tokens=max_tokens,
            retry_times=retry_times
        )
        
        # 尝试解析JSON
        try:
            # 尝试直接解析
            return json.loads(response_text)
        except json.JSONDecodeError:
            # 如果失败，尝试提取JSON代码块
            if "```json" in response_text:
                start = response_text.find("```json") + 7
                end = response_text.find("```", start)
                json_str = response_text[start:end].strip()
                return json.loads(json_str)
            elif "```" in response_text:
                start = response_text.find("```") + 3
                end = response_text.find("```", start)
                json_str = response_text[start:end].strip()
                return json.loads(json_str)
            else:
                raise ValueError(f"无法解析JSON响应: {response_text}")
