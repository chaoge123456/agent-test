# 自动化文档树组织系统

基于LLM的文档结构解析系统，将扫描版或数字文档（PDF、图片）自动解析为层次化的文档树结构。

## 系统架构

### 核心模块

1. **models.py** - 数据结构定义
   - `ElementType`: 元素类型枚举
   - `BBox`: 边界框坐标
   - `LayoutBox`: 页面布局元素
   - `PageLayout`: 页面布局数据
   - `TreeNode`: 文档树节点
   - `DocumentTree`: 完整文档树结构

2. **llm_client.py** - LLM客户端
   - 封装DeepSeek API调用
   - 支持JSON格式响应
   - 自动重试机制

3. **page_tree_builder.py** - 页面级树构建
   - 将单页layout boxes构建为局部树
   - LLM驱动的结构识别
   - 规则方法作为后备方案

4. **document_start_detector.py** - 正文起始识别
   - 规则+LLM混合策略
   - 识别封面、摘要、目录、正文

5. **cross_page_merger.py** - 跨页元素合并
   - 增量合并策略（窗口大小=3页）
   - LLM判断跨页连续性
   - 重建树结构

6. **pipeline.py** - 主流程编排
   - 整合所有组件
   - 端到端处理流程

## 技术特点

### 1. 页面内层级构建

**LLM提示词设计**：
- 明确标题层级规则（title_level数字越小级别越高）
- 定义元素归属关系（内容归属到最近上级标题）
- 处理特殊组合（表格标题+表格、图片标题+图片）
- 标记跨页候选（cross_page_hint）

**输入格式**：
```
元素列表（按阅读顺序）：
[0] paragraph_title, level=1: "2024年山东省卫生健康事业发展统计公报"
[1] text: "2024年是实现"十四五"规划目标任务的关键一年..."
[2] paragraph_title, level=2: "一、卫生资源"
[3] text: "（一）医疗卫生机构总数。2024年，全省各级各类医疗卫..."
```

**输出格式**：
```json
{
  "node_id": "page_0_root",
  "type": "document",
  "box_ids": [],
  "children": [
    {
      "node_id": "title_0",
      "type": "title",
      "level": 1,
      "box_ids": [0],
      "children": [...]
    }
  ]
}
```

### 2. 正文起始识别

**规则方法**：
- 检测章节标记（"一、"、"第一章"等）
- 识别文档结构元素（doc_title、abstract、content）
- 判断实质性内容开始位置

**LLM方法**：
- 分析前N页内容摘要
- 理解文档结构语义
- 返回正文起始页索引

### 3. 跨页整合策略

**识别候选**：
- 相邻页面节点
- 类型匹配（相同类型或相关组合）
- 位置连续性

**LLM判断**：
- 段落跨页：检查句子完整性
- 表格跨页：检查表格连续性
- 标题跨页：通常不合并

**合并执行**：
- 文本拼接
- 页面范围扩展
- 子节点合并
- 树结构重建

### 4. 上下文窗口管理

**增量合并**：
- 窗口大小：3页
- 逐步合并相邻窗口
- 避免一次性加载所有页面

**信息压缩**：
- 限制文本长度（200字符）
- 只保留关键字段
- 提取结构骨架

### 5. 多阶段LLM提示词

**阶段1 - 页面树构建**：
```
系统角色：文档结构分析专家
任务：组织页面元素为层次化树结构
输入：元素列表（label、text、title_level、coordinate）
输出：JSON树结构
```

**阶段2 - 正文起始检测**：
```
系统角色：文档结构分析专家
任务：判断正文从哪一页开始
输入：前N页内容摘要
输出：{"start_page": 页码索引}
```

**阶段3 - 跨页合并判断**：
```
系统角色：文档结构分析专家
任务：判断哪些跨页元素应该合并
输入：跨页候选对列表
输出：{"merge_pairs": [应合并的pair_id列表]}
```

## 使用方法

### 安装依赖

```bash
pip install -r requirements.txt
```

### 配置API

编辑 `pipeline.py` 中的配置：

```python
API_KEY = "your-api-key"
MODEL = "deepseek-chat"
BASE_URL = "https://api.deepseek.com"
```

### 准备数据

将页面JSON文件放入 `data/` 目录，命名格式：
- `page-0.json`
- `page-1.json`
- `page-2.json`
- ...

### 运行处理

```bash
python pipeline.py
```

### 输出结果

结果保存在 `output/document_tree.json`：

```json
{
  "document": {
    "node_id": "doc_root",
    "type": "document",
    "text": "",
    "page_range": [0, 10],
    "children": [
      {
        "node_id": "title_1",
        "type": "title",
        "level": 1,
        "text": "第一章 引言",
        "page_range": [0, 0],
        "bbox": {...},
        "children": [...]
      }
    ]
  },
  "metadata": {
    "title": "文档标题",
    "total_pages": 11,
    "source_file": "..."
  }
}
```

## 数据结构说明

### 输入格式（每页JSON）

```json
{
  "boxes": [
    {
      "cls_id": 0,
      "label": "paragraph_title",
      "coordinate": [x1, y1, x2, y2],
      "box_name": "...",
      "page_index": 0,
      "box_id": 0,
      "recognize": "文本内容",
      "title_level": 1
    }
  ],
  "page_index": 0
}
```

### 输出格式（文档树）

```json
{
  "document": {
    "node_id": "唯一标识",
    "type": "节点类型",
    "text": "文本内容",
    "page_range": [起始页, 结束页],
    "level": "标题级别（可选）",
    "bbox": "边界框（可选）",
    "children": [子节点列表],
    "metadata": {
      "box_ids": [原始box_id列表],
      "cross_page_hint": false
    }
  },
  "metadata": {
    "title": "文档标题",
    "total_pages": 总页数
  }
}
```

## 元素类型映射

| label | ElementType |
|-------|-------------|
| paragraph_title | TITLE |
| doc_title | TITLE |
| text | TEXT |
| table | TABLE |
| table_title | TABLE_TITLE |
| image | IMAGE |
| figure_title | FIGURE_TITLE |
| chart | CHART |
| chart_title | CHART_TITLE |
| abstract | ABSTRACT |
| reference | REFERENCE |
| formula | FORMULA |
| ... | ... |

## 优化建议

1. **成本控制**：
   - 调整温度参数（temperature=0.2）降低随机性
   - 限制max_tokens避免过长响应
   - 使用规则方法作为后备

2. **准确性提升**：
   - 利用bbox坐标辅助判断层级
   - 结合title_level和文本内容
   - 多轮验证跨页合并决策

3. **性能优化**：
   - 增量合并减少上下文长度
   - 并行处理独立页面
   - 缓存LLM响应

## 测试结果

使用提供的测试数据（page-1.json），成功构建文档树：

- ✅ 正确识别文档标题（1级）
- ✅ 正确识别章节标题（2级）
- ✅ 正确归属段落到对应标题
- ✅ 保留bbox坐标信息
- ✅ 输出符合预期格式

## 许可证

MIT License
