"""
页面级文档树构建模块
负责将单个页面的layout boxes构建为局部树结构
"""
from typing import List, Dict, Any, Optional
from models import PageLayout, TreeNode, ElementType, LayoutBox
from llm_client import LLMClient


class PageTreeBuilder:
    """页面树构建器"""
    
    def __init__(self, llm_client: LLMClient):
        self.llm_client = llm_client
        
    def build_page_tree(self, page_layout: PageLayout) -> TreeNode:
        """
        构建单个页面的文档树
        
        Args:
            page_layout: 页面布局数据
            
        Returns:
            页面根节点
        """
        if not page_layout.boxes:
            # 空页面
            return TreeNode(
                node_id=f"page_{page_layout.page_index}",
                type=ElementType.DOCUMENT,
                text="",
                page_range=[page_layout.page_index, page_layout.page_index]
            )
        
        # 准备输入数据
        boxes_data = self._prepare_boxes_data(page_layout.boxes)
        
        # 调用LLM构建树结构
        tree_structure = self._call_llm_for_tree(boxes_data, page_layout.page_index)
        
        # 将LLM返回的结构转换为TreeNode
        root = self._convert_to_tree_node(tree_structure, page_layout)
        
        return root
    
    def _prepare_boxes_data(self, boxes: List[LayoutBox]) -> List[Dict[str, Any]]:
        """准备boxes数据用于LLM输入"""
        boxes_data = []
        for box in boxes:
            box_info = {
                'box_id': str(box.box_id),  # 转换为字符串
                'label': box.label,
                'text': box.recognize[:200] if box.recognize else "",  # 限制文本长度
                'title_level': box.title_level,
                'coordinate': box.coordinate,
                'page_index': box.page_index
            }
            boxes_data.append(box_info)
        return boxes_data
        """准备boxes数据用于LLM输入"""
        boxes_data = []
        for box in boxes:
            box_info = {
                'box_id': box.box_id,
                'label': box.label,
                'text': box.recognize[:200] if box.recognize else "",  # 限制文本长度
                'title_level': box.title_level,
                'coordinate': box.coordinate,
                'page_index': box.page_index
            }
            boxes_data.append(box_info)
        return boxes_data
    
    def _call_llm_for_tree(self, boxes_data: List[Dict[str, Any]], page_index: int) -> Dict[str, Any]:
        """
        调用LLM构建页面树结构
        """
        system_prompt = """你是一个文档结构分析专家。你的任务是将页面中的元素（boxes）组织成层次化的树结构。

规则：
1. 标题（paragraph_title, doc_title）应该成为父节点，包含其后的内容，直到遇到同级或更高级标题
2. title_level数字越小，标题级别越高（1级 > 2级 > 3级）
3. 文本（text）、图片（image）、表格（table）等内容元素应该归属到最近的上级标题下
4. 如果没有标题，内容元素直接作为页面的子节点
5. 表格标题（table_title）应该和其后的表格（table）组合在一起
6. 图片标题（figure_title, chart_title）应该和其后的图片（image, chart）组合在一起
7. 页眉（header）、页脚（footer）、脚注（footnote）通常不参与主体结构
8. 按照box_id的顺序处理元素（box_id表示阅读顺序）

输出格式：
返回JSON格式的树结构，每个节点包含：
- node_id: 节点唯一标识
- type: 节点类型（title/paragraph/table/image等）
- level: 标题级别（仅标题节点）
- box_ids: 该节点包含的box_id列表
- children: 子节点列表（递归结构）
- cross_page_hint: 如果该元素可能跨页，标记为true"""

        user_prompt = f"""请分析第{page_index}页的以下元素，构建层次化树结构：

元素列表（按阅读顺序）：
{self._format_boxes_for_prompt(boxes_data)}

请返回JSON格式的树结构。"""

        try:
            result = self.llm_client.call_json(
                prompt=user_prompt,
                system_prompt=system_prompt,
                temperature=0.2,
                max_tokens=3000
            )
            return result
        except Exception as e:
            # LLM调用失败，使用规则方法构建
            print(f"LLM调用失败，使用规则方法: {e}")
            return self._build_tree_by_rules(boxes_data, page_index)
    
    def _format_boxes_for_prompt(self, boxes_data: List[Dict[str, Any]]) -> str:
        """格式化boxes数据用于prompt"""
        lines = []
        for box in boxes_data:
            text_preview = box['text'][:50] + "..." if len(box['text']) > 50 else box['text']
            level_info = f", level={box['title_level']}" if box['title_level'] else ""
            lines.append(
                f"[{box['box_id']}] {box['label']}{level_info}: \"{text_preview}\""
            )
        return "\n".join(lines)
    
    def _build_tree_by_rules(self, boxes_data: List[Dict[str, Any]], page_index: int) -> Dict[str, Any]:
        """
        使用规则方法构建树结构（LLM失败时的后备方案）
        """
        root = {
            'node_id': f'page_{page_index}_root',
            'type': 'document',
            'box_ids': [],
            'children': []
        }
        
        # 按box_id排序
        sorted_boxes = sorted(boxes_data, key=lambda x: x['box_id'])
        
        # 标题栈，用于跟踪当前层级
        title_stack = [root]
        
        for box in sorted_boxes:
            label = box['label']
            
            # 跳过页眉页脚
            if label in ['header', 'footer', 'header_image', 'footer_image']:
                continue
            
            # 处理标题
            if label in ['paragraph_title', 'doc_title']:
                title_level = box.get('title_level', 1)
                
                # 弹出栈中级别大于等于当前标题的节点
                while len(title_stack) > 1:
                    parent = title_stack[-1]
                    if parent.get('level', 0) >= title_level:
                        title_stack.pop()
                    else:
                        break
                
                # 创建标题节点
                title_node = {
                    'node_id': f'page_{page_index}_box_{box["box_id"]}',
                    'type': 'title',
                    'level': title_level,
                    'box_ids': [box['box_id']],
                    'children': []
                }
                
                # 添加到父节点
                title_stack[-1]['children'].append(title_node)
                title_stack.append(title_node)
                
            # 处理内容元素
            else:
                content_node = {
                    'node_id': f'page_{page_index}_box_{box["box_id"]}',
                    'type': self._map_label_to_type(label),
                    'box_ids': [box['box_id']],
                    'children': []
                }
                
                # 添加到当前标题下
                title_stack[-1]['children'].append(content_node)
        
        return root
    
    def _map_label_to_type(self, label: str) -> str:
        """映射label到节点类型"""
        type_map = {
            'text': 'paragraph',
            'table': 'table',
            'table_title': 'table_title',
            'image': 'image',
            'figure_title': 'figure_title',
            'chart': 'chart',
            'chart_title': 'chart_title',
            'formula': 'formula',
            'reference': 'reference',
            'abstract': 'abstract',
            'content': 'content',
            'footnote': 'footnote',
            'number': 'number',
            'seal': 'seal',
            'aside_text': 'aside_text',
            'algorithm': 'algorithm'
        }
        return type_map.get(label, 'paragraph')
    
    def _convert_to_tree_node(self, tree_structure: Dict[str, Any], page_layout: PageLayout) -> TreeNode:
        """
        将LLM返回的树结构转换为TreeNode对象
        """
        # 创建box_id到box的映射
        box_map = {box.box_id: box for box in page_layout.boxes}
        
        def convert_node(node_data: Dict[str, Any]) -> TreeNode:
            box_ids = node_data.get('box_ids', [])
            
            # 获取文本内容
            text_parts = []
            bbox = None
            for box_id_str in box_ids:
                # box_id可能是字符串或整数，统一转换
                try:
                    box_id = int(box_id_str) if isinstance(box_id_str, str) else box_id_str
                except (ValueError, TypeError):
                    continue
                    
                if box_id in box_map:
                    box = box_map[box_id]
                    if box.recognize:
                        text_parts.append(box.recognize)
                    if bbox is None:
                        bbox = box.bbox
            
            text = " ".join(text_parts) if text_parts else ""
            
            # 创建节点
            node_type_str = node_data.get('type', 'paragraph')
            try:
                node_type = ElementType(node_type_str)
            except ValueError:
                node_type = ElementType.TEXT
            
            node = TreeNode(
                node_id=node_data.get('node_id', f'node_{id(node_data)}'),
                type=node_type,
                text=text,
                page_range=[page_layout.page_index, page_layout.page_index],
                level=node_data.get('level'),
                bbox=bbox,
                metadata={
                    'box_ids': box_ids,
                    'cross_page_hint': node_data.get('cross_page_hint', False)
                }
            )
            
            # 递归处理子节点
            for child_data in node_data.get('children', []):
                child_node = convert_node(child_data)
                node.add_child(child_node)
            
            return node
        
        return convert_node(tree_structure)
