"""
跨页元素合并模块
处理跨页的标题、段落、表格等元素的合并
"""
from typing import List, Dict, Any, Optional, Tuple
from models import TreeNode, ElementType, PageLayout
from llm_client import LLMClient


class CrossPageMerger:
    """跨页元素合并器"""
    
    def __init__(self, llm_client: LLMClient):
        self.llm_client = llm_client
    
    def merge_trees(self, page_trees: List[TreeNode], page_layouts: List[PageLayout]) -> TreeNode:
        """
        合并多个页面树为一个完整的文档树
        
        Args:
            page_trees: 页面树列表
            page_layouts: 页面布局列表（用于获取原始数据）
            
        Returns:
            合并后的文档树根节点
        """
        if not page_trees:
            return TreeNode(
                node_id="doc_root",
                type=ElementType.DOCUMENT,
                text="",
                page_range=[0, 0]
            )
        
        if len(page_trees) == 1:
            # 只有一页，直接返回
            root = page_trees[0]
            root.node_id = "doc_root"
            root.type = ElementType.DOCUMENT
            return root
        
        # 增量合并策略：每次合并相邻的几页
        merge_window = 3  # 每次合并3页
        
        merged_trees = page_trees.copy()
        
        while len(merged_trees) > 1:
            new_merged = []
            i = 0
            
            while i < len(merged_trees):
                # 取当前窗口的树
                window_trees = merged_trees[i:i+merge_window]
                
                if len(window_trees) == 1:
                    new_merged.append(window_trees[0])
                else:
                    # 合并窗口内的树
                    merged = self._merge_tree_window(window_trees, page_layouts)
                    new_merged.append(merged)
                
                i += merge_window
            
            merged_trees = new_merged
        
        # 最终结果
        root = merged_trees[0]
        root.node_id = "doc_root"
        root.type = ElementType.DOCUMENT
        
        return root
    
    def _merge_tree_window(self, trees: List[TreeNode], page_layouts: List[PageLayout]) -> TreeNode:
        """
        合并一个窗口内的树
        
        策略：
        1. 识别跨页元素（标题、段落、表格）
        2. 合并跨页元素
        3. 调整树结构
        """
        if len(trees) == 1:
            return trees[0]
        
        # 创建合并后的根节点
        first_page = trees[0].page_range[0]
        last_page = trees[-1].page_range[1]
        
        merged_root = TreeNode(
            node_id=f"merged_{first_page}_{last_page}",
            type=ElementType.DOCUMENT,
            text="",
            page_range=[first_page, last_page]
        )
        
        # 收集所有节点（扁平化）
        all_nodes = []
        for tree in trees:
            all_nodes.extend(self._flatten_tree(tree))
        
        # 识别跨页候选
        cross_page_pairs = self._identify_cross_page_candidates(all_nodes)
        
        # 如果有跨页候选，使用LLM判断是否合并
        if cross_page_pairs:
            merge_decisions = self._llm_decide_merge(cross_page_pairs, page_layouts)
        else:
            merge_decisions = []
        
        # 执行合并
        merged_nodes = self._execute_merge(all_nodes, merge_decisions)
        
        # 重建树结构
        self._rebuild_tree_structure(merged_root, merged_nodes)
        
        return merged_root
    
    def _flatten_tree(self, node: TreeNode, result: Optional[List[TreeNode]] = None) -> List[TreeNode]:
        """扁平化树结构"""
        if result is None:
            result = []
        
        # 跳过根节点
        if node.type != ElementType.DOCUMENT:
            result.append(node)
        
        for child in node.children:
            self._flatten_tree(child, result)
        
        return result
    
    def _identify_cross_page_candidates(self, nodes: List[TreeNode]) -> List[Tuple[TreeNode, TreeNode]]:
        """
        识别可能跨页的元素对
        
        规则：
        1. 相邻页面的节点
        2. 类型相同或相关（如table_title和table）
        3. 第一个节点在页面底部，第二个节点在页面顶部
        """
        candidates = []
        
        for i in range(len(nodes) - 1):
            node1 = nodes[i]
            node2 = nodes[i + 1]
            
            # 检查是否相邻页面
            if node2.page_range[0] - node1.page_range[1] != 1:
                continue
            
            # 检查类型是否匹配
            if self._is_mergeable_type_pair(node1.type, node2.type):
                candidates.append((node1, node2))
        
        return candidates
    
    def _is_mergeable_type_pair(self, type1: ElementType, type2: ElementType) -> bool:
        """判断两个类型是否可以合并"""
        # 相同类型可以合并
        if type1 == type2:
            return True
        
        # 特殊组合
        mergeable_pairs = [
            (ElementType.TABLE_TITLE, ElementType.TABLE),
            (ElementType.FIGURE_TITLE, ElementType.IMAGE),
            (ElementType.CHART_TITLE, ElementType.CHART),
            (ElementType.TITLE, ElementType.PARAGRAPH),
            (ElementType.TITLE, ElementType.TEXT),
        ]
        
        return (type1, type2) in mergeable_pairs
    
    def _llm_decide_merge(
        self, 
        candidates: List[Tuple[TreeNode, TreeNode]], 
        page_layouts: List[PageLayout]
    ) -> List[Tuple[str, str]]:
        """
        使用LLM判断哪些候选对应该合并
        
        Returns:
            应该合并的节点ID对列表
        """
        if not candidates:
            return []
        
        # 准备候选信息
        candidates_info = []
        for i, (node1, node2) in enumerate(candidates):
            candidates_info.append({
                'pair_id': i,
                'node1_id': node1.node_id,
                'node2_id': node2.node_id,
                'node1_type': node1.type.value,
                'node2_type': node2.type.value,
                'node1_text': node1.text[:200],
                'node2_text': node2.text[:200],
                'node1_page': node1.page_range,
                'node2_page': node2.page_range
            })
        
        system_prompt = """你是一个文档结构分析专家。你的任务是判断哪些跨页元素应该合并。

合并规则：
1. 段落跨页：如果第一个段落的最后一句不完整（没有句号、问号等），且第二个段落是其延续，应该合并
2. 表格跨页：如果表格在第一页未结束，在第二页继续，应该合并
3. 标题跨页：标题通常不跨页，除非明确是同一个标题的延续
4. 标题+内容：如果标题在第一页底部，其内容在第二页，不应该合并（保持父子关系即可）

请返回JSON格式：{"merge_pairs": [应该合并的pair_id列表]}"""

        user_prompt = f"""请判断以下跨页候选对中，哪些应该合并：

{self._format_candidates_for_prompt(candidates_info)}

请返回JSON格式的结果。"""

        try:
            result = self.llm_client.call_json(
                prompt=user_prompt,
                system_prompt=system_prompt,
                temperature=0.2,
                max_tokens=1000
            )
            
            merge_pair_ids = result.get('merge_pairs', [])
            
            # 转换为节点ID对
            merge_decisions = []
            for pair_id in merge_pair_ids:
                if 0 <= pair_id < len(candidates):
                    node1, node2 = candidates[pair_id]
                    merge_decisions.append((node1.node_id, node2.node_id))
            
            return merge_decisions
            
        except Exception as e:
            print(f"LLM判断跨页合并失败，使用保守策略: {e}")
            # 保守策略：只合并明显的情况
            return self._conservative_merge_decision(candidates)
    
    def _format_candidates_for_prompt(self, candidates_info: List[Dict[str, Any]]) -> str:
        """格式化候选信息用于prompt"""
        lines = []
        for info in candidates_info:
            lines.append(f"\n候选对 {info['pair_id']}:")
            lines.append(f"  节点1 (第{info['node1_page']}页): {info['node1_type']}")
            lines.append(f"    文本: \"{info['node1_text']}\"")
            lines.append(f"  节点2 (第{info['node2_page']}页): {info['node2_type']}")
            lines.append(f"    文本: \"{info['node2_text']}\"")
        return "\n".join(lines)
    
    def _conservative_merge_decision(self, candidates: List[Tuple[TreeNode, TreeNode]]) -> List[Tuple[str, str]]:
        """
        保守的合并决策（LLM失败时使用）
        只合并明显的情况
        """
        merge_decisions = []
        
        for node1, node2 in candidates:
            # 只合并相同类型的表格和段落
            if node1.type == node2.type:
                if node1.type in [ElementType.TABLE, ElementType.PARAGRAPH, ElementType.TEXT]:
                    # 检查文本连续性
                    if node1.text and node2.text:
                        # 如果第一个节点的文本不以句号结尾，可能跨页
                        if not node1.text.rstrip().endswith(('。', '.', '！', '!', '？', '?')):
                            merge_decisions.append((node1.node_id, node2.node_id))
        
        return merge_decisions
    
    def _execute_merge(self, nodes: List[TreeNode], merge_decisions: List[Tuple[str, str]]) -> List[TreeNode]:
        """
        执行合并操作
        """
        # 创建节点ID到节点的映射
        node_map = {node.node_id: node for node in nodes}
        
        # 创建合并映射（node_id -> merged_node_id）
        merge_map = {}
        for node1_id, node2_id in merge_decisions:
            merge_map[node2_id] = node1_id
        
        # 执行合并
        merged_nodes = []
        merged_ids = set()
        
        for node in nodes:
            if node.node_id in merged_ids:
                continue
            
            # 检查是否需要合并
            if node.node_id in merge_map:
                # 这个节点应该被合并到另一个节点
                merged_ids.add(node.node_id)
                continue
            
            # 检查是否有其他节点应该合并到这个节点
            nodes_to_merge = [node]
            for other_id, target_id in merge_map.items():
                if target_id == node.node_id and other_id in node_map:
                    nodes_to_merge.append(node_map[other_id])
                    merged_ids.add(other_id)
            
            if len(nodes_to_merge) > 1:
                # 合并节点
                merged_node = self._merge_nodes(nodes_to_merge)
                merged_nodes.append(merged_node)
            else:
                merged_nodes.append(node)
        
        return merged_nodes
    
    def _merge_nodes(self, nodes: List[TreeNode]) -> TreeNode:
        """合并多个节点为一个节点"""
        if len(nodes) == 1:
            return nodes[0]
        
        # 使用第一个节点作为基础
        base_node = nodes[0]
        
        # 合并文本
        merged_text = " ".join(node.text for node in nodes if node.text)
        
        # 合并页面范围
        min_page = min(node.page_range[0] for node in nodes)
        max_page = max(node.page_range[1] for node in nodes)
        
        # 合并子节点
        merged_children = []
        for node in nodes:
            merged_children.extend(node.children)
        
        # 创建合并后的节点
        merged_node = TreeNode(
            node_id=base_node.node_id,
            type=base_node.type,
            text=merged_text,
            page_range=[min_page, max_page],
            level=base_node.level,
            bbox=base_node.bbox,
            children=merged_children,
            metadata={**base_node.metadata, 'merged': True}
        )
        
        return merged_node
    
    def _rebuild_tree_structure(self, root: TreeNode, nodes: List[TreeNode]):
        """
        重建树结构
        
        策略：
        1. 标题节点作为父节点
        2. 内容节点归属到最近的上级标题
        3. 如果没有标题，内容节点直接作为根节点的子节点
        """
        # 按页面和位置排序
        sorted_nodes = sorted(nodes, key=lambda n: (n.page_range[0], n.node_id))
        
        # 标题栈
        title_stack = [root]
        
        for node in sorted_nodes:
            if node.type == ElementType.TITLE:
                level = node.level or 1
                
                # 弹出栈中级别大于等于当前标题的节点
                while len(title_stack) > 1:
                    parent = title_stack[-1]
                    parent_level = parent.level or 0
                    if parent_level >= level:
                        title_stack.pop()
                    else:
                        break
                
                # 添加到父节点
                title_stack[-1].add_child(node)
                title_stack.append(node)
            else:
                # 内容节点添加到当前标题下
                title_stack[-1].add_child(node)
