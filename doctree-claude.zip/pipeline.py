"""
主流程编排模块
整合所有组件，实现完整的文档树构建流程
"""
import json
import os
from typing import List, Optional
from pathlib import Path

from models import PageLayout, DocumentTree, TreeNode, ElementType
from llm_client import LLMClient
from page_tree_builder import PageTreeBuilder
from document_start_detector import DocumentStartDetector
from cross_page_merger import CrossPageMerger


class DocumentTreePipeline:
    """文档树构建流程"""
    
    def __init__(
        self,
        api_key: str,
        model: str = "deepseek-chat",
        base_url: str = "https://api.deepseek.com"
    ):
        """
        初始化流程
        
        Args:
            api_key: DeepSeek API密钥
            model: 模型名称
            base_url: API基础URL
        """
        self.llm_client = LLMClient(api_key=api_key, model=model, base_url=base_url)
        self.page_tree_builder = PageTreeBuilder(self.llm_client)
        self.document_start_detector = DocumentStartDetector(self.llm_client)
        self.cross_page_merger = CrossPageMerger(self.llm_client)
    
    def process_document(
        self,
        page_json_files: List[str],
        output_path: Optional[str] = None,
        detect_start: bool = True
    ) -> DocumentTree:
        """
        处理完整文档
        
        Args:
            page_json_files: 页面JSON文件路径列表（按页面顺序）
            output_path: 输出文件路径（可选）
            detect_start: 是否检测正文起始页
            
        Returns:
            文档树对象
        """
        print(f"开始处理文档，共{len(page_json_files)}页")
        
        # 1. 加载所有页面布局
        print("步骤1: 加载页面布局数据...")
        page_layouts = self._load_page_layouts(page_json_files)
        
        if not page_layouts:
            raise ValueError("没有有效的页面数据")
        
        # 2. 检测正文起始页
        start_page = 0
        if detect_start and len(page_layouts) > 1:
            print("步骤2: 检测正文起始页...")
            start_page = self.document_start_detector.detect_start_page(page_layouts)
            print(f"  正文从第{start_page}页开始")
        else:
            print("步骤2: 跳过正文起始检测")
        
        # 3. 构建每页的局部树
        print("步骤3: 构建页面级文档树...")
        page_trees = []
        for i, page_layout in enumerate(page_layouts):
            print(f"  处理第{i}页...")
            page_tree = self.page_tree_builder.build_page_tree(page_layout)
            page_trees.append(page_tree)
        
        # 4. 合并跨页元素
        print("步骤4: 合并跨页元素...")
        merged_root = self.cross_page_merger.merge_trees(page_trees, page_layouts)
        
        # 5. 提取文档元数据
        print("步骤5: 提取文档元数据...")
        metadata = self._extract_metadata(page_layouts, merged_root)
        
        # 6. 创建文档树
        document_tree = DocumentTree(root=merged_root, metadata=metadata)
        
        # 7. 保存结果
        if output_path:
            print(f"步骤6: 保存结果到 {output_path}...")
            self._save_document_tree(document_tree, output_path)
        
        print("处理完成！")
        return document_tree
    
    def _load_page_layouts(self, page_json_files: List[str]) -> List[PageLayout]:
        """加载页面布局数据"""
        page_layouts = []
        
        for file_path in page_json_files:
            if not os.path.exists(file_path):
                print(f"警告: 文件不存在 {file_path}")
                continue
            
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    page_layout = PageLayout.from_json(data)
                    page_layouts.append(page_layout)
            except Exception as e:
                print(f"警告: 加载文件失败 {file_path}: {e}")
                continue
        
        return page_layouts
    
    def _extract_metadata(self, page_layouts: List[PageLayout], root: TreeNode) -> dict:
        """提取文档元数据"""
        metadata = {
            'total_pages': len(page_layouts)
        }
        
        # 尝试提取文档标题
        title = self._find_document_title(root)
        if title:
            metadata['title'] = title
        
        # 提取第一页的输入路径
        if page_layouts and page_layouts[0].input_path:
            metadata['source_file'] = page_layouts[0].input_path
        
        return metadata
    
    def _find_document_title(self, root: TreeNode) -> Optional[str]:
        """查找文档标题"""
        # 在根节点的直接子节点中查找
        for child in root.children:
            if child.type == ElementType.TITLE and child.level == 1:
                return child.text
        
        # 如果没找到，返回根节点的文本
        if root.text:
            return root.text[:100]  # 限制长度
        
        return None
    
    def _save_document_tree(self, document_tree: DocumentTree, output_path: str):
        """保存文档树到文件"""
        output_data = document_tree.to_dict()
        
        # 确保输出目录存在
        output_dir = os.path.dirname(output_path)
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(output_data, f, ensure_ascii=False, indent=2)


def main():
    """主函数示例"""
    # 配置
    API_KEY = "sk-71345ea7232d4739b41c16dabd51d0b8"
    MODEL = "deepseek-chat"
    BASE_URL = "https://api.deepseek.com"
    
    # 数据路径
    DATA_DIR = "data"
    OUTPUT_PATH = "output/document_tree.json"
    
    # 查找所有页面JSON文件
    page_files = []
    data_path = Path(DATA_DIR)
    
    if data_path.exists():
        # 查找所有page-*.json文件并排序
        json_files = sorted(data_path.glob("page-*.json"))
        page_files = [str(f) for f in json_files]
    
    if not page_files:
        print(f"错误: 在 {DATA_DIR} 目录下没有找到页面JSON文件")
        print("请确保数据文件命名格式为: page-0.json, page-1.json, ...")
        return
    
    print(f"找到 {len(page_files)} 个页面文件")
    
    # 创建流程
    pipeline = DocumentTreePipeline(
        api_key=API_KEY,
        model=MODEL,
        base_url=BASE_URL
    )
    
    # 处理文档
    try:
        document_tree = pipeline.process_document(
            page_json_files=page_files,
            output_path=OUTPUT_PATH,
            detect_start=True
        )
        
        print("\n" + "="*50)
        print("文档树构建成功！")
        print(f"输出文件: {OUTPUT_PATH}")
        print(f"文档标题: {document_tree.metadata.get('title', '未知')}")
        print(f"总页数: {document_tree.metadata.get('total_pages', 0)}")
        print("="*50)
        
    except Exception as e:
        print(f"\n错误: 处理失败 - {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
