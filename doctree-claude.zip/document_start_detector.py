"""
正文起始识别模块
识别文档正文从哪一页开始
"""
from typing import List, Optional
from models import PageLayout
from llm_client import LLMClient


class DocumentStartDetector:
    """正文起始检测器"""
    
    def __init__(self, llm_client: LLMClient):
        self.llm_client = llm_client
    
    def detect_start_page(self, page_layouts: List[PageLayout], max_check_pages: int = 5) -> int:
        """
        检测正文起始页
        
        Args:
            page_layouts: 页面布局列表
            max_check_pages: 最多检查前几页
            
        Returns:
            正文起始页索引
        """
        if not page_layouts:
            return 0
        
        # 首先使用规则方法快速判断
        rule_based_start = self._detect_by_rules(page_layouts, max_check_pages)
        
        # 如果规则方法有明确结果，直接返回
        if rule_based_start is not None:
            return rule_based_start
        
        # 否则使用LLM分析
        return self._detect_by_llm(page_layouts, max_check_pages)
    
    def _detect_by_rules(self, page_layouts: List[PageLayout], max_check_pages: int) -> Optional[int]:
        """
        基于规则的正文起始检测
        
        规则：
        1. 如果第一页包含doc_title，且后续页面有paragraph_title，则从第一页开始
        2. 如果前几页只有abstract、content（目录）等，正文从这些页之后开始
        3. 如果检测到"一、"、"第一章"等明确的章节标记，从该页开始
        """
        check_pages = min(max_check_pages, len(page_layouts))
        
        for i in range(check_pages):
            page = page_layouts[i]
            
            # 检查是否有明确的章节标记
            for box in page.boxes:
                if box.label in ['paragraph_title', 'doc_title']:
                    text = box.recognize.strip()
                    
                    # 检测章节标记
                    chapter_markers = [
                        '一、', '第一章', '第1章', '1.', '1 ',
                        '第一节', '第1节', '引言', '概述', '前言'
                    ]
                    
                    for marker in chapter_markers:
                        if text.startswith(marker) or marker in text[:10]:
                            return i
            
            # 检查页面内容类型
            labels = [box.label for box in page.boxes]
            
            # 如果包含doc_title，通常是封面或标题页
            if 'doc_title' in labels:
                # 如果同时有paragraph_title，可能正文已开始
                if 'paragraph_title' in labels:
                    return i
                # 否则继续检查下一页
                continue
            
            # 如果只有abstract或content（目录），继续检查
            if all(label in ['abstract', 'content', 'header', 'footer', 'header_image', 'footer_image'] 
                   for label in labels if label):
                continue
            
            # 如果有paragraph_title和text，可能是正文
            if 'paragraph_title' in labels and 'text' in labels:
                return i
        
        # 规则无法判断，返回None让LLM处理
        return None
    
    def _detect_by_llm(self, page_layouts: List[PageLayout], max_check_pages: int) -> int:
        """
        使用LLM检测正文起始页
        """
        check_pages = min(max_check_pages, len(page_layouts))
        
        # 准备前几页的摘要信息
        pages_summary = []
        for i in range(check_pages):
            page = page_layouts[i]
            page_info = {
                'page_index': i,
                'elements': []
            }
            
            for box in page.boxes[:10]:  # 每页最多取10个元素
                text_preview = box.recognize[:100] if box.recognize else ""
                page_info['elements'].append({
                    'label': box.label,
                    'text': text_preview,
                    'title_level': box.title_level
                })
            
            pages_summary.append(page_info)
        
        system_prompt = """你是一个文档结构分析专家。你的任务是判断文档正文从哪一页开始。

常见的文档结构：
1. 封面页：通常包含doc_title（文档标题）
2. 摘要页：包含abstract（摘要）
3. 目录页：包含content（目录）
4. 正文页：包含paragraph_title（章节标题）和text（正文内容）

判断规则：
- 正文通常从第一个包含章节标题（如"一、"、"第一章"等）的页面开始
- 如果没有明确的章节标记，从第一个包含paragraph_title和实质性text内容的页面开始
- 封面、摘要、目录不算正文

请返回JSON格式：{"start_page": 页码索引}"""

        user_prompt = f"""请分析以下页面，判断正文从哪一页开始：

{self._format_pages_for_prompt(pages_summary)}

请返回JSON格式的结果。"""

        try:
            result = self.llm_client.call_json(
                prompt=user_prompt,
                system_prompt=system_prompt,
                temperature=0.1,
                max_tokens=500
            )
            
            start_page = result.get('start_page', 0)
            # 确保返回值在有效范围内
            return max(0, min(start_page, len(page_layouts) - 1))
            
        except Exception as e:
            print(f"LLM检测正文起始失败，默认从第0页开始: {e}")
            return 0
    
    def _format_pages_for_prompt(self, pages_summary: List[dict]) -> str:
        """格式化页面摘要用于prompt"""
        lines = []
        for page_info in pages_summary:
            lines.append(f"\n第{page_info['page_index']}页：")
            for elem in page_info['elements']:
                text_preview = elem['text'][:50] + "..." if len(elem['text']) > 50 else elem['text']
                level_info = f" (level={elem['title_level']})" if elem['title_level'] else ""
                lines.append(f"  - {elem['label']}{level_info}: \"{text_preview}\"")
        return "\n".join(lines)
