"""
数据结构定义模块
定义文档树构建所需的核心数据结构
"""
from typing import List, Dict, Optional, Any
from dataclasses import dataclass, field
from enum import Enum


class ElementType(Enum):
    """元素类型枚举"""
    DOCUMENT = "document"
    TITLE = "title"
    PARAGRAPH = "paragraph"
    TEXT = "text"
    TABLE = "table"
    TABLE_TITLE = "table_title"
    IMAGE = "image"
    FIGURE_TITLE = "figure_title"
    CHART = "chart"
    CHART_TITLE = "chart_title"
    ABSTRACT = "abstract"
    CONTENT = "content"
    REFERENCE = "reference"
    FORMULA = "formula"
    ALGORITHM = "algorithm"
    FOOTNOTE = "footnote"
    HEADER = "header"
    FOOTER = "footer"
    NUMBER = "number"
    SEAL = "seal"
    ASIDE_TEXT = "aside_text"


# 标签到类型的映射
LABEL_TO_TYPE_MAP = {
    'paragraph_title': ElementType.TITLE,
    'doc_title': ElementType.TITLE,
    'image': ElementType.IMAGE,
    'text': ElementType.TEXT,
    'number': ElementType.NUMBER,
    'abstract': ElementType.ABSTRACT,
    'content': ElementType.CONTENT,
    'figure_title': ElementType.FIGURE_TITLE,
    'formula': ElementType.FORMULA,
    'table': ElementType.TABLE,
    'table_title': ElementType.TABLE_TITLE,
    'reference': ElementType.REFERENCE,
    'footnote': ElementType.FOOTNOTE,
    'header': ElementType.HEADER,
    'footer': ElementType.FOOTER,
    'algorithm': ElementType.ALGORITHM,
    'seal': ElementType.SEAL,
    'chart_title': ElementType.CHART_TITLE,
    'chart': ElementType.CHART,
    'formula_number': ElementType.NUMBER,
    'header_image': ElementType.IMAGE,
    'footer_image': ElementType.IMAGE,
    'aside_text': ElementType.ASIDE_TEXT,
}


@dataclass
class BBox:
    """边界框坐标"""
    x1: float
    y1: float
    x2: float
    y2: float
    
    @property
    def width(self) -> float:
        return self.x2 - self.x1
    
    @property
    def height(self) -> float:
        return self.y2 - self.y1
    
    @property
    def center_x(self) -> float:
        return (self.x1 + self.x2) / 2
    
    @property
    def center_y(self) -> float:
        return (self.y1 + self.y2) / 2
    
    def to_dict(self) -> Dict[str, float]:
        return {
            'x1': self.x1,
            'y1': self.y1,
            'x2': self.x2,
            'y2': self.y2
        }


@dataclass
class LayoutBox:
    """页面布局元素"""
    cls_id: int
    label: str
    coordinate: List[float]
    box_name: str
    page_index: int
    box_id: int
    recognize: str
    title_level: Optional[int] = None
    score: Optional[float] = None
    
    @property
    def bbox(self) -> BBox:
        """获取边界框对象"""
        return BBox(
            x1=self.coordinate[0],
            y1=self.coordinate[1],
            x2=self.coordinate[2],
            y2=self.coordinate[3]
        )
    
    @property
    def element_type(self) -> ElementType:
        """获取元素类型"""
        return LABEL_TO_TYPE_MAP.get(self.label, ElementType.TEXT)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'cls_id': self.cls_id,
            'label': self.label,
            'coordinate': self.coordinate,
            'box_name': self.box_name,
            'page_index': self.page_index,
            'box_id': self.box_id,
            'recognize': self.recognize,
            'title_level': self.title_level,
            'score': self.score
        }


@dataclass
class PageLayout:
    """页面布局数据"""
    page_index: int
    boxes: List[LayoutBox]
    input_path: Optional[str] = None
    
    @classmethod
    def from_json(cls, data: Dict[str, Any]) -> 'PageLayout':
        """从JSON数据创建PageLayout对象"""
        boxes = [
            LayoutBox(
                cls_id=box['cls_id'],
                label=box['label'],
                coordinate=box['coordinate'],
                box_name=box['box_name'],
                page_index=box['page_index'],
                box_id=box['box_id'],
                recognize=box.get('recognize', ''),
                title_level=box.get('title_level'),
                score=box.get('score')
            )
            for box in data['boxes']
        ]
        return cls(
            page_index=data['page_index'],
            boxes=boxes,
            input_path=data.get('input_path')
        )


@dataclass
class TreeNode:
    """文档树节点"""
    node_id: str
    type: ElementType
    text: str
    page_range: List[int]
    level: Optional[int] = None
    bbox: Optional[BBox] = None
    children: List['TreeNode'] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def add_child(self, child: 'TreeNode'):
        """添加子节点"""
        self.children.append(child)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        result = {
            'node_id': self.node_id,
            'type': self.type.value,
            'text': self.text,
            'page_range': self.page_range,
        }
        
        if self.level is not None:
            result['level'] = self.level
        
        if self.bbox is not None:
            result['bbox'] = self.bbox.to_dict()
        
        if self.children:
            result['children'] = [child.to_dict() for child in self.children]
        
        if self.metadata:
            result['metadata'] = self.metadata
        
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TreeNode':
        """从字典创建TreeNode对象"""
        bbox = None
        if 'bbox' in data:
            bbox_data = data['bbox']
            bbox = BBox(
                x1=bbox_data['x1'],
                y1=bbox_data['y1'],
                x2=bbox_data['x2'],
                y2=bbox_data['y2']
            )
        
        children = [cls.from_dict(child) for child in data.get('children', [])]
        
        return cls(
            node_id=data['node_id'],
            type=ElementType(data['type']),
            text=data['text'],
            page_range=data['page_range'],
            level=data.get('level'),
            bbox=bbox,
            children=children,
            metadata=data.get('metadata', {})
        )


@dataclass
class DocumentTree:
    """完整的文档树结构"""
    root: TreeNode
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为输出格式"""
        return {
            'document': self.root.to_dict(),
            'metadata': self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'DocumentTree':
        """从字典创建DocumentTree对象"""
        root = TreeNode.from_dict(data['document'])
        metadata = data.get('metadata', {})
        return cls(root=root, metadata=metadata)
