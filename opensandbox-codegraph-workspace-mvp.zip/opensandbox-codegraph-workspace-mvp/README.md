# OpenSandbox Workspace MVP 交付包

本目录保存本次修改或新增的完整文件，并保持它们相对于项目根目录的路径。将其中的 `OpenSandbox/` 合并到测试平台上的同版本 OpenSandbox 源码树；合并前请先做备份或以 Git patch/三方合并处理，避免覆盖测试平台已有修改。

本包不含 CodeGraph 源码。目标镜像已经包含 CodeGraph CLI 时，无需重新安装 CodeGraph；容器内必须能执行 `codegraph --version`。

## 文件清单

- Server：workspace OverlayFS 管理器、路由、schema、配置、终止清理 hook、配置示例与测试。
- MCP：`workspace_sandbox_create` 和 `codegraph_explore`。
- API：`specs/sandbox-lifecycle.yml` 的新 workspace endpoint 契约。

## Linux 测试平台前提

1. OpenSandbox Server 和 Docker daemon 位于同一个 Linux 宿主机/挂载命名空间。
2. 宿主机支持 OverlayFS，运行 Server 的身份有执行 `mount -t overlay`、`umount` 的权限。生产环境建议将这部分替换为受限的宿主机 workspace-agent。
3. 用户代码目录和 workspace 根都在 Docker daemon 可见的 Linux 文件系统上。
4. workspace 的 `upper/` 和 `work/` 位于同一文件系统。
5. sandbox 镜像 `opensandbox/code-interpreter:v1.1.0` 中存在 `codegraph`、`git` 与 `execd`。

## Server 配置

在测试用 sandbox 配置中加入并按实际路径修改：

```toml
[storage]
allowed_host_paths = ["/srv/agent-workspaces"]

[workspace]
enabled = true
root = "/srv/agent-workspaces"
allowed_repository_roots = ["/srv/user-code"]
retain_artifacts = true
```

`repositoryPath` 必须位于 `allowed_repository_roots` 内，且必须是 Git 仓库。它作为 OverlayFS lowerdir 使用；Agent 真正写入的是 `/workspace/repo` 对应的 merged 视图。

## uv 本地安装与调试

建议从源码树运行，而不是先发布/安装 wheel。这样 `uv sync` 会把当前源码作为 editable 项目使用。

```bash
cd OpenSandbox/server
uv sync --all-groups
export SANDBOX_CONFIG_PATH=/absolute/path/to/workspace-test.toml
uv run opensandbox-server
```

另开终端运行 MCP：

```bash
cd OpenSandbox/sdks/mcp/sandbox/python
uv sync --all-groups
export OPEN_SANDBOX_API_KEY=<server-api-key>
uv run opensandbox-mcp --domain 127.0.0.1:8080 --protocol http
```

因此，测试平台需要安装/同步 **OpenSandbox Server** 和 **OpenSandbox MCP** 的 Python 依赖；不需要为本改动单独安装 CodeGraph 包，因为它在被创建的 sandbox 镜像中运行。

若需要从外部 Python 程序调 MCP，可让 Agent/MCP client 调用：

```text
workspace_sandbox_create(
  repository_path="/srv/user-code/my-repo",
  image="opensandbox/code-interpreter:v1.1.0",
  entrypoint=["tail", "-f", "/dev/null"],
  resource={"cpu": "1", "memory": "2Gi"}
)

codegraph_explore(sandbox_id, "认证流程从入口到错误响应")
```

随后继续复用 `file_*`、`command_run` 与 `sandbox_kill`。

## 验证命令

```bash
cd OpenSandbox/server
uv run pytest tests/test_workspace_routes.py tests/test_workspace_service.py -q
uv run ruff check opensandbox_server/config.py opensandbox_server/api/schema.py \
  opensandbox_server/api/workspace.py opensandbox_server/services/workspace.py

cd ../sdks/mcp/sandbox/python
uv run ruff check src/opensandbox_mcp/server.py
uv run pyright src/opensandbox_mcp/server.py
```

完成静态检查后，在 Linux Docker 主机进行一次真实验证：对同一 Git 仓库创建两个 workspace sandbox，分别修改同一文件，确认各自只看到自己的变更、原仓库不变，并确认 `codegraph_explore` 能看到修改后的符号。

## 当前 MVP 限制

- workspace 映射在当前进程内存中；Server 重启后的 mount 泄漏恢复尚未实现。
- TTL 自动回收尚未接入 runtime 的异步终止事件；通过 MCP/HTTP 调用 `sandbox_kill` 会触发当前实现的清理 hook。
- CodeGraph 初始化由 MCP 的 `workspace_sandbox_create` 完成；直接调用 HTTP workspace API 后，需要在 sandbox 内执行 `codegraph init -i /workspace/repo`。
- API spec 已更新，但各语言生成 SDK 尚未生成 workspace client；MCP 当前以 HTTP 调用该 endpoint。
