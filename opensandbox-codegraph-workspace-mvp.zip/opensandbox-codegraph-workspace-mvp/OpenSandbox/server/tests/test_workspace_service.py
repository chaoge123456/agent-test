# Copyright 2026 Alibaba Group Holding Ltd.

import asyncio
from datetime import datetime, timezone
from pathlib import Path

from opensandbox_server.api.schema import (
    CreateSandboxResponse,
    CreateWorkspaceSandboxRequest,
    SandboxStatus,
)
from opensandbox_server.config import WorkspaceConfig
from opensandbox_server.services.workspace import OverlayWorkspaceManager


def test_workspace_manager_builds_the_only_workspace_volume(tmp_path: Path, monkeypatch) -> None:
    base = tmp_path / "base"
    base.mkdir()
    config = WorkspaceConfig(
        enabled=True,
        root=str(tmp_path / "workspaces"),
        allowed_repository_roots=[str(tmp_path)],
    )
    manager = OverlayWorkspaceManager(config)

    def fake_overlay(base_path, upper_path, work_path, merged_path) -> None:
        del base_path
        upper_path.mkdir(parents=True)
        work_path.mkdir()
        merged_path.mkdir()

    monkeypatch.setattr(manager, "_create_overlay", fake_overlay)
    monkeypatch.setattr(manager, "_resolve_base_revision", lambda *_: "a" * 40)

    class StubSandboxService:
        request = None

        async def create_sandbox(self, request):
            self.request = request
            return CreateSandboxResponse(
                id="sbx_1",
                status=SandboxStatus(state="Pending"),
                createdAt=datetime.now(timezone.utc),
            )

    service = StubSandboxService()
    request = CreateWorkspaceSandboxRequest.model_validate(
        {
            "repositoryPath": str(base),
            "sandbox": {
                "image": {"uri": "example/image"},
                "entrypoint": ["sleep", "infinity"],
                "resourceLimits": {"cpu": "1", "memory": "1Gi"},
            },
        }
    )
    result = asyncio.run(manager.create(request, service))

    assert result.sandbox.id == "sbx_1"
    assert service.request.metadata["opensandbox.io/workspace-id"] == result.workspace_id
    assert len(service.request.volumes) == 1
    assert service.request.volumes[0].mount_path == "/workspace/repo"
    assert Path(service.request.volumes[0].host.path).name == "merged"
