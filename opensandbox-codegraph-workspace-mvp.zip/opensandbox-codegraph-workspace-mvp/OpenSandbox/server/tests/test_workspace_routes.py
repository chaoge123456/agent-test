# Copyright 2026 Alibaba Group Holding Ltd.

from datetime import datetime, timedelta, timezone

from fastapi.testclient import TestClient

from opensandbox_server.api import workspace
from opensandbox_server.api.schema import (
    CreateSandboxResponse,
    CreateWorkspaceSandboxResponse,
    SandboxStatus,
)


def test_create_workspace_sandbox_delegates_to_managed_service(
    client: TestClient,
    auth_headers: dict,
    sample_sandbox_request: dict,
    monkeypatch,
) -> None:
    calls = []
    now = datetime.now(timezone.utc)

    class StubManager:
        async def create(self, request, sandbox_service):
            calls.append((request, sandbox_service))
            return CreateWorkspaceSandboxResponse(
                workspaceId="ws_001",
                baseRevision="a" * 40,
                sandbox=CreateSandboxResponse(
                    id="sbx_001",
                    status=SandboxStatus(state="Pending"),
                    createdAt=now,
                    expiresAt=now + timedelta(hours=1),
                ),
            )

    monkeypatch.setattr(workspace, "get_workspace_manager", lambda: StubManager())
    response = client.post(
        "/v1/workspaces/sandboxes",
        headers=auth_headers,
        json={
            "repositoryPath": "/srv/user-code/repo_123",
            "baseRevision": "a" * 40,
            "sandbox": sample_sandbox_request,
        },
    )

    assert response.status_code == 202
    assert response.json()["workspaceId"] == "ws_001"
    assert response.json()["sandbox"]["id"] == "sbx_001"
    assert calls[0][0].repository_path == "/srv/user-code/repo_123"


def test_create_workspace_sandbox_rejects_caller_supplied_volume(
    client: TestClient,
    auth_headers: dict,
    sample_sandbox_request: dict,
) -> None:
    sample_sandbox_request["volumes"] = [
        {
            "name": "escape",
            "host": {"path": "/tmp"},
            "mountPath": "/workspace/repo",
        }
    ]
    response = client.post(
        "/v1/workspaces/sandboxes",
        headers=auth_headers,
        json={"repositoryPath": "/srv/user-code/repo_123", "sandbox": sample_sandbox_request},
    )

    assert response.status_code == 422
    assert "server-managed" in response.text
