# Copyright 2026 Alibaba Group Holding Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.

"""Server-managed OverlayFS workspaces for coding sandboxes.

The public API carries a user-selected repository path, which is canonicalized
and restricted to configured roots. OverlayFS mount parameters remain in this
module so a caller can never turn a sandbox request into an arbitrary host bind
mount.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from uuid import uuid4

from fastapi import HTTPException, status

from opensandbox_server.api.schema import (
    CreateSandboxRequest,
    CreateWorkspaceSandboxRequest,
    CreateWorkspaceSandboxResponse,
    Host,
    Volume,
)
from opensandbox_server.config import WorkspaceConfig

logger = logging.getLogger(__name__)

WORKSPACE_METADATA_KEY = "opensandbox.io/workspace-id"
WORKSPACE_MOUNT_PATH = "/workspace/repo"


@dataclass(frozen=True)
class WorkspaceRecord:
    workspace_id: str
    sandbox_id: str
    base_revision: str
    root: Path
    merged_path: Path


class OverlayWorkspaceManager:
    """Create and clean up local OverlayFS workspace sessions.

    This manager intentionally supports Docker on Linux only. A Kubernetes
    implementation requires node-local scheduling and is not a safe fallback.
    """

    def __init__(self, config: WorkspaceConfig) -> None:
        self._config = config
        self._records: dict[str, WorkspaceRecord] = {}
        self._lock = asyncio.Lock()

    async def create(
        self,
        request: CreateWorkspaceSandboxRequest,
        sandbox_service,
    ) -> CreateWorkspaceSandboxResponse:
        base_path = self._repository_path(request.repository_path)
        base_revision = await asyncio.to_thread(
            self._resolve_base_revision, base_path, request.base_revision
        )
        workspace_id = f"ws_{uuid4().hex}"
        workspace_root = Path(self._config.root).resolve() / workspace_id
        self._ensure_workspace_path(workspace_root)
        upper_path = workspace_root / "upper"
        work_path = workspace_root / "work"
        merged_path = workspace_root / "merged"

        await asyncio.to_thread(self._create_overlay, base_path, upper_path, work_path, merged_path)
        try:
            sandbox_request = self._build_sandbox_request(
                request.sandbox, merged_path, workspace_id
            )
            sandbox = await sandbox_service.create_sandbox(sandbox_request)
        except Exception:
            await asyncio.to_thread(self._cleanup_paths, workspace_root, merged_path)
            raise

        record = WorkspaceRecord(
            workspace_id=workspace_id,
            sandbox_id=sandbox.id,
            base_revision=base_revision,
            root=workspace_root,
            merged_path=merged_path,
        )
        async with self._lock:
            self._records[sandbox.id] = record
        await asyncio.to_thread(self._write_metadata, record, request.repository_path)
        return CreateWorkspaceSandboxResponse(
            workspaceId=workspace_id,
            sandbox=sandbox,
            baseRevision=base_revision,
        )

    async def cleanup_for_sandbox(self, sandbox_id: str) -> None:
        async with self._lock:
            record = self._records.pop(sandbox_id, None)
        if record is None:
            return
        await asyncio.to_thread(self._archive_and_cleanup, record)

    def _repository_path(self, repository_path: str) -> Path:
        if not self._config.enabled:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail={
                    "code": "WORKSPACE_DISABLED",
                    "message": "Managed workspaces are disabled on this server.",
                },
            )
        try:
            resolved = Path(repository_path).resolve(strict=True)
        except OSError as exc:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={"code": "WORKSPACE_REPOSITORY_NOT_FOUND", "message": "Repository path does not exist."},
            ) from exc
        allowed_roots = [Path(item).resolve() for item in self._config.allowed_repository_roots]
        if any(resolved == root or root in resolved.parents for root in allowed_roots):
            return resolved
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "WORKSPACE_REPOSITORY_FORBIDDEN",
                "message": "Repository path is outside workspace.allowed_repository_roots.",
            },
        )

    def _ensure_workspace_path(self, workspace_root: Path) -> None:
        root = Path(self._config.root).resolve()
        if workspace_root.parent != root or workspace_root.exists():
            raise RuntimeError("invalid workspace root allocation")

    @staticmethod
    def _resolve_base_revision(base_path: Path, requested_revision: str | None) -> str:
        result = subprocess.run(
            ["git", "-C", str(base_path), "rev-parse", "HEAD"],
            check=False,
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "code": "WORKSPACE_BASE_NOT_GIT",
                    "message": "Configured workspace baseline must be a readable Git repository.",
                },
            )
        revision = result.stdout.strip()
        if requested_revision and requested_revision != revision:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail={
                    "code": "WORKSPACE_BASE_REVISION_MISMATCH",
                    "message": "The requested revision is not the configured frozen baseline.",
                },
            )
        return revision

    def _create_overlay(
        self,
        base_path: Path,
        upper_path: Path,
        work_path: Path,
        merged_path: Path,
    ) -> None:
        if os.name != "posix" or not Path("/proc/filesystems").exists():
            raise HTTPException(
                status_code=status.HTTP_501_NOT_IMPLEMENTED,
                detail={
                    "code": "WORKSPACE_OVERLAY_UNSUPPORTED",
                    "message": "Managed OverlayFS workspaces require a Linux host.",
                },
            )
        upper_path.mkdir(parents=True)
        work_path.mkdir()
        merged_path.mkdir()
        options = f"lowerdir={base_path},upperdir={upper_path},workdir={work_path}"
        try:
            subprocess.run(
                ["mount", "-t", "overlay", "overlay", "-o", options, str(merged_path)],
                check=True,
                capture_output=True,
                text=True,
                timeout=15,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            self._cleanup_paths(upper_path.parent, merged_path)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail={
                    "code": "WORKSPACE_OVERLAY_MOUNT_FAILED",
                    "message": f"Could not create the isolated workspace: {exc}",
                },
            ) from exc

    @staticmethod
    def _build_sandbox_request(
        request: CreateSandboxRequest,
        merged_path: Path,
        workspace_id: str,
    ) -> CreateSandboxRequest:
        metadata = dict(request.metadata or {})
        metadata[WORKSPACE_METADATA_KEY] = workspace_id
        return request.model_copy(
            update={
                "metadata": metadata,
                "volumes": [
                    Volume(
                        name="workspace",
                        host=Host(path=str(merged_path)),
                        mountPath=WORKSPACE_MOUNT_PATH,
                    )
                ],
            }
        )

    def _write_metadata(self, record: WorkspaceRecord, repository_path: str) -> None:
        payload = {
            "workspace_id": record.workspace_id,
            "sandbox_id": record.sandbox_id,
            "repository_path": repository_path,
            "base_revision": record.base_revision,
        }
        (record.root / "metadata.json").write_text(json.dumps(payload), encoding="utf-8")

    def _archive_and_cleanup(self, record: WorkspaceRecord) -> None:
        artifacts = record.root / "artifacts"
        artifacts.mkdir(exist_ok=True)
        if self._config.retain_artifacts and record.merged_path.is_mount():
            self._run_git_artifact(record.merged_path, ["status", "--short"], artifacts / "git-status.txt")
            self._run_git_artifact(record.merged_path, ["diff", "--binary"], artifacts / "git-diff.patch")
        self._cleanup_paths(record.root, record.merged_path, keep_artifacts=self._config.retain_artifacts)

    @staticmethod
    def _run_git_artifact(merged_path: Path, args: list[str], destination: Path) -> None:
        result = subprocess.run(
            ["git", "-C", str(merged_path), *args],
            check=False,
            capture_output=True,
            text=True,
            timeout=30,
        )
        destination.write_text(result.stdout + result.stderr, encoding="utf-8")

    @staticmethod
    def _cleanup_paths(workspace_root: Path, merged_path: Path, keep_artifacts: bool = False) -> None:
        if merged_path.is_mount():
            subprocess.run(["umount", str(merged_path)], check=False, capture_output=True, timeout=15)
        if keep_artifacts:
            for child in (workspace_root / "upper", workspace_root / "work", workspace_root / "merged"):
                if child.exists():
                    shutil.rmtree(child)
            metadata = workspace_root / "metadata.json"
            if metadata.exists():
                metadata.unlink()
            return
        if workspace_root.exists():
            shutil.rmtree(workspace_root)


_manager: OverlayWorkspaceManager | None = None


def get_workspace_manager(config: WorkspaceConfig | None = None) -> OverlayWorkspaceManager:
    """Return the process-local manager; tests may pass an explicit configuration."""
    global _manager
    if config is not None:
        return OverlayWorkspaceManager(config)
    if _manager is None:
        from opensandbox_server.config import get_config

        _manager = OverlayWorkspaceManager(get_config().workspace)
    return _manager
