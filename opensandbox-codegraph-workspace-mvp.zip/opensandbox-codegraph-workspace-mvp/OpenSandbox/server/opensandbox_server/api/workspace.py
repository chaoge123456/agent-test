# Copyright 2026 Alibaba Group Holding Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.

"""Routes for server-managed coding workspaces."""

from fastapi import APIRouter, Header, status

from opensandbox_server.api import lifecycle
from opensandbox_server.api.schema import (
    CreateWorkspaceSandboxRequest,
    CreateWorkspaceSandboxResponse,
    ErrorResponse,
)
from opensandbox_server.services.workspace import get_workspace_manager

router = APIRouter(tags=["Workspaces"])


@router.post(
    "/workspaces/sandboxes",
    response_model=CreateWorkspaceSandboxResponse,
    response_model_exclude_none=True,
    status_code=status.HTTP_202_ACCEPTED,
    responses={
        400: {"model": ErrorResponse, "description": "The request was invalid."},
        404: {"model": ErrorResponse, "description": "Repository was not authorized."},
        409: {"model": ErrorResponse, "description": "Baseline revision conflict."},
        503: {"model": ErrorResponse, "description": "Managed workspaces are disabled."},
    },
)
async def create_workspace_sandbox(
    request: CreateWorkspaceSandboxRequest,
    x_request_id: str | None = Header(None, alias="X-Request-ID"),
) -> CreateWorkspaceSandboxResponse:
    """Create a sandbox with a server-built OverlayFS repository view."""
    del x_request_id  # Request IDs are handled by the shared middleware.
    return await get_workspace_manager().create(request, lifecycle.sandbox_service)
