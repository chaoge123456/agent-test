# -*- coding: utf-8 -*-
"""
页级视觉多向量表 (page_token)
存储页面的多向量表示，类似于ColPali、ColQwen
支持MaxSim算法计算页面级最终得分
"""
from typing import Dict, List, Any, Optional, Tuple
from collections import defaultdict
from base.base_table import BaseTable
import config
from utils.snowflake import generate_id


class PageTokenTable(BaseTable):
    """
    页级视觉多向量表
    
    存储页面的多向量表示，将单个页面编码为多个向量
    - vec_id: 主键（雪花算法生成）
    - token_vector: 该页面某个patch的token向量
    - patch_id: 标识同一个页面中不同的向量
    - doc_id: 关联文档ID（业务联合键）
    - page_id: 文档第几页（业务联合键）
    
    支持MaxSim聚合查询：查询结果按doc_id+page_id分组，
    取每个patch与query向量相似度的最大值作为页面得分
    """
    
    def __init__(self, kb_name: str, **kwargs):
        """
        初始化页级视觉多向量表
        
        Args:
            kb_name: 知识库名称，用于生成Collection名称
        """
        collection_name = config.COLLECTION_TEMPLATE_PAGE_TOKEN.format(kb_name=kb_name)
        
        super().__init__(
            collection_name=collection_name,
            schema_fields=config.PAGE_TOKEN_SCHEMA,
            description=f"页级视觉多向量表 - {kb_name}",
            **kwargs
        )
        
        self._kb_name = kb_name
    
    def get_kb_name(self) -> str:
        """获取知识库名称"""
        return self._kb_name
    
    # =========================================================================
    # 业务方法 - 数据插入
    # =========================================================================
    
    def add_page_tokens(
        self,
        doc_id: int,
        page_id: int,
        token_vectors: List[List[float]],
        metadata: Optional[Dict[str, Any]] = None
    ) -> List[int]:
        """
        添加页面的多向量表示
        
        将一个页面的多个token向量拆分为多条记录存储
        
        Args:
            doc_id: 文档ID
            page_id: 页码
            token_vectors: 页面编码后的多向量列表
            metadata: 其他相关信息
            
        Returns:
            生成的vec_id列表
        """
        if not token_vectors:
            return []
        
        # 限制每页最大patch数
        max_patches = config.MAX_PATCHES_PER_PAGE
        token_vectors = token_vectors[:max_patches]
        
        data = []
        vec_ids = []
        
        for patch_id, token_vector in enumerate(token_vectors):
            vec_id = generate_id()
            vec_ids.append(vec_id)
            
            data.append({
                "vec_id": vec_id,
                "token_vector": token_vector,
                "patch_id": patch_id,
                "doc_id": doc_id,
                "page_id": page_id,
                "metadata": metadata or {}
            })
        
        self.insert(data)
        return vec_ids
    
    def add_page_tokens_batch(
        self,
        pages_data: List[Dict[str, Any]]
    ) -> Tuple[List[int], int]:
        """
        批量添加多页面的多向量表示
        
        Args:
            pages_data: 页面数据列表，每项包含:
                - doc_id: 文档ID
                - page_id: 页码
                - token_vectors: token向量列表
                - metadata: 元数据(可选)
                
        Returns:
            (生成的vec_id列表, 总插入数量)
        """
        data = []
        vec_ids = []
        
        max_patches = config.MAX_PATCHES_PER_PAGE
        
        for page in pages_data:
            doc_id = page["doc_id"]
            page_id = page["page_id"]
            token_vectors = page["token_vectors"][:max_patches]
            metadata = page.get("metadata", {})
            
            for patch_id, token_vector in enumerate(token_vectors):
                vec_id = generate_id()
                vec_ids.append(vec_id)
                
                data.append({
                    "vec_id": vec_id,
                    "token_vector": token_vector,
                    "patch_id": patch_id,
                    "doc_id": doc_id,
                    "page_id": page_id,
                    "metadata": metadata
                })
        
        return self.insert(data)
    
    # =========================================================================
    # 业务方法 - MaxSim查询
    # =========================================================================
    
    def search_with_maxsim(
        self,
        query_vectors: List[List[float]],
        doc_ids: Optional[List[int]] = None,
        limit: int = 10,
        min_patches: int = 1,
        output_fields: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """
        MaxSim聚合查询
        
        1. 向量搜索获取候选patch
        2. 按doc_id+page_id分组
        3. 计算每组内patch与query向量相似度的最大值
        4. 按得分排序返回
        
        Args:
            query_vectors: 查询向量列表（支持多向量查询）
            doc_ids: 可选的文档ID过滤列表
            limit: 返回的页面数量
            min_patches: 最少patch数量要求（用于验证多向量完整性）
            output_fields: 输出字段列表
            
        Returns:
            聚合后的页面列表，每项包含:
                - doc_id: 文档ID
                - page_id: 页码
                - score: MaxSim聚合得分
                - patch_count: 该页面的patch总数
                - matched_patches: 匹配的patch数量
        """
        if output_fields is None:
            output_fields = ["vec_id", "doc_id", "page_id", "patch_id", "token_vector"]
        
        # 构建过滤表达式
        filter_expr = None
        if doc_ids:
            doc_ids_str = str(doc_ids).replace(" ", "")
            filter_expr = f"doc_id in {doc_ids_str}"
        
        # 第一步：向量搜索获取候选patch
        all_results = self.search(
            vectors=query_vectors,
            vector_field="token_vector",
            filter_expr=filter_expr,
            output_fields=output_fields,
            limit=limit * config.MAX_PATCHES_PER_PAGE,  # 扩大搜索范围
            search_params={
                "metric_type": config.INDEX_METRIC_TYPE,
                "params": {"nprobe": config.INDEX_NPROBE}
            }
        )
        
        # 合并多向量查询结果
        if len(query_vectors) > 1:
            # 多向量查询：合并所有查询向量的结果
            merged_hits = self._merge_query_results(all_results)
        else:
            merged_hits = all_results[0] if all_results else []
        
        # 第二步：按doc_id+page_id分组，计算MaxSim
        page_scores = self._calculate_maxsim(merged_hits)
        
        # 第三步：验证patch完整性并排序
        final_results = self._filter_and_rank(
            page_scores, 
            limit=limit,
            min_patches=min_patches
        )
        
        return final_results
    
    def _merge_query_results(
        self, 
        query_results: List[List[Dict[str, Any]]]
    ) -> List[Dict[str, Any]]:
        """
        合并多向量查询结果
        
        对于多向量查询，每个query_vector都会返回一个结果列表
        需要合并这些结果，保留每个patch的最高得分
        
        Args:
            query_results: 多向量查询结果
            
        Returns:
            合并后的命中结果列表
        """
        # 使用dict去重，key为(vec_id)，保留最高得分
        merged = {}
        
        for query_hits in query_results:
            for hit in query_hits:
                vec_id = hit.get("vec_id")
                distance = hit.get("_distance", 0.0)
                
                if vec_id not in merged or distance > merged[vec_id].get("_distance", 0.0):
                    merged[vec_id] = hit
        
        return list(merged.values())
    
    def _calculate_maxsim(
        self,
        hits: List[Dict[str, Any]]
    ) -> Dict[Tuple[int, int], Dict[str, Any]]:
        """
        计算MaxSim聚合得分
        
        对于每个页面，计算所有匹配patch与query向量相似度的最大值
        
        Args:
            hits: patch级别的搜索结果
            
        Returns:
            以(doc_id, page_id)为key的字典，包含聚合后的页面信息
        """
        page_data = defaultdict(lambda: {
            "max_score": float("-inf"),
            "patch_count": 0,
            "matched_patches": 0,
            "doc_id": None,
            "page_id": None
        })
        
        # 收集每个页面的patch信息
        for hit in hits:
            doc_id = hit.get("doc_id")
            page_id = hit.get("page_id")
            patch_id = hit.get("patch_id")
            score = hit.get("_distance", 0.0)
            
            if doc_id is None or page_id is None:
                continue
            
            key = (doc_id, page_id)
            
            # 更新最大得分
            if score > page_data[key]["max_score"]:
                page_data[key]["max_score"] = score
                page_data[key]["doc_id"] = doc_id
                page_data[key]["page_id"] = page_id
            
            # 记录匹配的patch数
            page_data[key]["matched_patches"] += 1
        
        return page_data
    
    def _filter_and_rank(
        self,
        page_scores: Dict[Tuple[int, int], Dict[str, Any]],
        limit: int,
        min_patches: int = 1
    ) -> List[Dict[str, Any]]:
        """
        过滤并排序结果
        
        验证多向量完整性，按得分排序
        
        Args:
            page_scores: 页面得分字典
            limit: 返回数量限制
            min_patches: 最少patch数量要求
            
        Returns:
            排序后的页面列表
        """
        # 先获取每个页面的总patch数
        results = []
        
        for (doc_id, page_id), data in page_scores.items():
            # 获取该页面的总patch数
            patch_count = self._get_patch_count(doc_id, page_id)
            
            # 验证完整性
            if patch_count < min_patches:
                continue
            
            results.append({
                "doc_id": doc_id,
                "page_id": page_id,
                "score": data["max_score"],
                "patch_count": patch_count,
                "matched_patches": data["matched_patches"],
                "completeness": data["matched_patches"] / patch_count if patch_count > 0 else 0
            })
        
        # 按得分降序排序
        results.sort(key=lambda x: x["score"], reverse=True)
        
        return results[:limit]
    
    def _get_patch_count(self, doc_id: int, page_id: int) -> int:
        """
        获取指定页面的patch总数
        
        Args:
            doc_id: 文档ID
            page_id: 页码
            
        Returns:
            patch数量
        """
        results = self.query(
            filter_expr=f"doc_id == {doc_id} and page_id == {page_id}",
            output_fields=["count(*)"],
            limit=1
        )
        
        return results[0].get("count(*)", 0) if results else 0
    
    # =========================================================================
    # 业务方法 - 数据查询和删除
    # =========================================================================
    
    def get_page_tokens(
        self,
        doc_id: int,
        page_id: int
    ) -> List[Dict[str, Any]]:
        """
        获取指定页面的所有token向量
        
        Args:
            doc_id: 文档ID
            page_id: 页码
            
        Returns:
            token向量列表
        """
        return self.query(
            filter_expr=f"doc_id == {doc_id} and page_id == {page_id}",
            output_fields=["vec_id", "token_vector", "patch_id", "metadata"],
            limit=config.MAX_PATCHES_PER_PAGE
        )
    
    def delete_page_tokens(self, doc_id: int, page_id: int) -> int:
        """
        删除指定页面的所有token向量
        
        Args:
            doc_id: 文档ID
            page_id: 页码
            
        Returns:
            删除的记录数
        """
        return self.delete(f"doc_id == {doc_id} and page_id == {page_id}")
    
    def delete_tokens_by_doc(self, doc_id: int) -> int:
        """
        删除文档的所有token向量
        
        Args:
            doc_id: 文档ID
            
        Returns:
            删除的记录数
        """
        return self.delete(f"doc_id == {doc_id}")
    
    def verify_page_integrity(
        self,
        doc_id: int,
        page_id: int,
        expected_patches: int
    ) -> Dict[str, Any]:
        """
        验证页面多向量完整性
        
        Args:
            doc_id: 文档ID
            page_id: 页码
            expected_patches: 期望的patch数量
            
        Returns:
            完整性验证结果
        """
        actual_patches = self._get_patch_count(doc_id, page_id)
        
        return {
            "doc_id": doc_id,
            "page_id": page_id,
            "expected_patches": expected_patches,
            "actual_patches": actual_patches,
            "is_complete": actual_patches >= expected_patches,
            "missing_patches": max(0, expected_patches - actual_patches)
        }


# 便捷函数
def get_page_token_table(kb_name: str) -> PageTokenTable:
    """
    获取页级视觉多向量表实例
    
    Args:
        kb_name: 知识库名称
        
    Returns:
        PageTokenTable实例
    """
    return PageTokenTable(kb_name=kb_name)