# -*- coding: utf-8 -*-
"""
页级摘要向量表 (page_abs)
存储页面的VLM摘要信息和多模态embedding向量
"""
from typing import Dict, List, Any, Optional
from base.base_table import BaseTable
import config
from utils.snowflake import generate_id


class PageAbsTable(BaseTable):
    """
    页级摘要向量表
    
    存储每个页面的VLM摘要信息和多模态embedding向量
    """
    
    def __init__(self, kb_name: str, **kwargs):
        """
        初始化页级摘要表
        
        Args:
            kb_name: 知识库名称，用于生成Collection名称
        """
        collection_name = config.COLLECTION_TEMPLATE_PAGE_ABS.format(kb_name=kb_name)
        
        super().__init__(
            collection_name=collection_name,
            schema_fields=config.PAGE_ABS_SCHEMA,
            description=f"页级摘要向量表 - {kb_name}",
            **kwargs
        )
        
        self._kb_name = kb_name
    
    def get_kb_name(self) -> str:
        """获取知识库名称"""
        return self._kb_name
    
    # =========================================================================
    # 业务方法
    # =========================================================================
    
    def add_page_abstract(
        self,
        doc_id: int,
        page_id: int,
        abstract: str,
        vector: List[float],
        page_path: str,
        keyword: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> int:
        """
        添加页面摘要
        
        Args:
            doc_id: 所属文档ID
            page_id: 文档第几页
            abstract: VLM生成的页面描述
            vector: 多模态embedding向量
            page_path: 页面存储路径
            keyword: 关键词列表
            metadata: 页面元素信息
            
        Returns:
            页面记录ID
        """
        row_id = generate_id()
        
        data = [{
            "row_id": row_id,
            "doc_id": doc_id,
            "abstract": abstract,
            "page_id": page_id,
            "vector": vector,
            "page_path": page_path,
            "keyword": keyword or [],
            "metadata": metadata or {}
        }]
        
        self.insert(data)
        return row_id
    
    def add_page_abstracts(
        self,
        page_data_list: List[Dict[str, Any]]
    ) -> Tuple[List[int], int]:
        """
        批量添加页面摘要
        
        Args:
            page_data_list: 页面数据列表，每项包含:
                - doc_id: 文档ID
                - page_id: 页码
                - abstract: 摘要
                - vector: 向量
                - page_path: 页面路径
                - keyword: 关键词(可选)
                - metadata: 元数据(可选)
                
        Returns:
            (生成的ID列表, 总插入数量)
        """
        data = []
        for item in page_data_list:
            data.append({
                "row_id": generate_id(),
                "doc_id": item["doc_id"],
                "page_id": item["page_id"],
                "abstract": item["abstract"],
                "vector": item["vector"],
                "page_path": item["page_path"],
                "keyword": item.get("keyword", []),
                "metadata": item.get("metadata", {})
            })
        
        return self.insert(data)
    
    def get_page_abstract(
        self,
        doc_id: int,
        page_id: int
    ) -> Optional[Dict[str, Any]]:
        """
        获取指定页的摘要
        
        Args:
            doc_id: 文档ID
            page_id: 页码
            
        Returns:
            页面摘要信息
        """
        results = self.query(
            filter_expr=f"doc_id == {doc_id} and page_id == {page_id}",
            output_fields=list(config.PAGE_ABS_SCHEMA.keys())
        )
        
        return results[0] if results else None
    
    def list_page_abstracts(
        self,
        doc_id: Optional[int] = None,
        page_ids: Optional[List[int]] = None,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """
        列出页面摘要
        
        Args:
            doc_id: 文档ID过滤
            page_ids: 页码列表过滤
            limit: 返回数量限制
            
        Returns:
            页面摘要列表
        """
        filter_exprs = []
        
        if doc_id is not None:
            filter_exprs.append(f"doc_id == {doc_id}")
        
        if page_ids:
            page_ids_str = str(page_ids).replace(" ", "")
            filter_exprs.append(f"page_id in {page_ids_str}")
        
        filter_expr = " and ".join(filter_exprs) if filter_exprs else "row_id >= 0"
        
        return self.query(
            filter_expr=filter_expr,
            output_fields=["row_id", "doc_id", "page_id", "abstract", 
                          "page_path", "keyword", "metadata"],
            limit=limit
        )
    
    def search_pages(
        self,
        query_vector: List[float],
        doc_id: Optional[int] = None,
        limit: int = 10
    ) -> List[Dict[str, Any]]:
        """
        向量搜索页面
        
        Args:
            query_vector: 查询向量
            doc_id: 文档ID过滤
            limit: 返回数量限制
            
        Returns:
            匹配的页面列表
        """
        filter_expr = f"doc_id == {doc_id}" if doc_id else None
        
        results = self.search(
            vectors=[query_vector],
            vector_field="vector",
            filter_expr=filter_expr,
            output_fields=["row_id", "doc_id", "page_id", "abstract", 
                          "page_path", "keyword", "metadata"],
            limit=limit
        )
        
        return results[0] if results else []
    
    def delete_pages_by_doc(self, doc_id: int) -> int:
        """
        删除文档的所有页面摘要
        
        Args:
            doc_id: 文档ID
            
        Returns:
            删除的页面数量
        """
        return self.delete(f"doc_id == {doc_id}")
    
    def delete_page(
        self,
        doc_id: int,
        page_id: int
    ) -> bool:
        """
        删除指定页面
        
        Args:
            doc_id: 文档ID
            page_id: 页码
            
        Returns:
            是否成功
        """
        count = self.delete(f"doc_id == {doc_id} and page_id == {page_id}")
        return count > 0
    
    def get_page_count(self, doc_id: int) -> int:
        """
        获取文档的页面数量
        
        Args:
            doc_id: 文档ID
            
        Returns:
            页面数量
        """
        return self.count(f"doc_id == {doc_id}")


# 便捷函数
def get_page_abs_table(kb_name: str) -> PageAbsTable:
    """
    获取页级摘要表实例
    
    Args:
        kb_name: 知识库名称
        
    Returns:
        PageAbsTable实例
    """
    return PageAbsTable(kb_name=kb_name)