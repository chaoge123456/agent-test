# -*- coding: utf-8 -*-
"""
文档元数据表 (document)
用于存储知识库内的文档信息
"""
from typing import Dict, List, Any, Optional
from base.base_table import BaseTable
import config
from utils.snowflake import generate_id


class DocumentTable(BaseTable):
    """
    文档元数据向量表
    
    存储知识库内的文档元信息，包括文档名称、标签、摘要、向量等
    """
    
    def __init__(self, kb_name: str, **kwargs):
        """
        初始化文档元数据表
        
        Args:
            kb_name: 知识库名称，用于生成Collection名称
        """
        # 根据模板生成Collection名称
        collection_name = config.COLLECTION_TEMPLATE_DOCUMENT.format(kb_name=kb_name)
        
        super().__init__(
            collection_name=collection_name,
            schema_fields=config.DOCUMENT_SCHEMA,
            description=f"文档元数据表 - {kb_name}",
            **kwargs
        )
        
        self._kb_name = kb_name
    
    def get_kb_name(self) -> str:
        """获取知识库名称"""
        return self._kb_name
    
    # =========================================================================
    # 业务方法
    # =========================================================================
    
    def add_document(
        self,
        doc_name: str,
        kb_id: int,
        tags: List[str],
        organize: List[str],
        metadata: Dict[str, Any],
        keywords: Optional[List[str]] = None,
        abstract: Optional[str] = None,
        vector: Optional[List[float]] = None,
        relation: Optional[Dict[str, Any]] = None
    ) -> int:
        """
        添加文档
        
        Args:
            doc_name: 文档名称
            kb_id: 所属知识库ID
            tags: 标签列表
            organize: 组织方式（tree、page、chunk）
            metadata: 元数据（存储路径、入库时间、文档类型等）
            keywords: 关键词列表
            abstract: 文档摘要
            abstract: 摘要向量
            vector: 文档关联信息
            
        Returns:
            文档ID
        """
        doc_id = generate_id()
        
        data = [{
            "doc_id": doc_id,
            "kb_id": kb_id,
            "doc_name": doc_name,
            "tags": tags,
            "keywords": keywords or [],
            "abstract": abstract or "",
            "vector": vector or [0.0] * config.VECTOR_DIM_TEXT,
            "organize": organize,
            "metadata": metadata,
            "relation": relation or {}
        }]
        
        self.insert(data)
        return doc_id
    
    def get_document(
        self,
        doc_id: Optional[int] = None,
        doc_name: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """
        获取文档信息
        
        Args:
            doc_id: 文档ID
            doc_name: 文档名称
            
        Returns:
            文档信息字典，不存在则返回None
        """
        if doc_id is not None:
            results = self.query(
                filter_expr=f"doc_id == {doc_id}",
                output_fields=list(config.DOCUMENT_SCHEMA.keys())
            )
        elif doc_name is not None:
            results = self.query(
                filter_expr=f'doc_name == "{doc_name}"',
                output_fields=list(config.DOCUMENT_SCHEMA.keys())
            )
        else:
            return None
        
        return results[0] if results else None
    
    def list_documents(
        self,
        kb_id: Optional[int] = None,
        tags: Optional[List[str]] = None,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """
        列出文档
        
        Args:
            kb_id: 知识库ID过滤
            tags: 标签过滤
            limit: 返回数量限制
            
        Returns:
            文档列表
        """
        filter_exprs = []
        
        if kb_id is not None:
            filter_exprs.append(f"kb_id == {kb_id}")
        
        if tags:
            for tag in tags:
                filter_exprs.append(f'tags contains "{tag}"')
        
        filter_expr = " and ".join(filter_exprs) if filter_exprs else "doc_id >= 0"
        
        return self.query(
            filter_expr=filter_expr,
            output_fields=["doc_id", "doc_name", "kb_id", "tags", "keywords", 
                          "abstract", "organize", "metadata"],
            limit=limit
        )
    
    def search_documents(
        self,
        query_vector: List[float],
        kb_id: Optional[int] = None,
        limit: int = 10
    ) -> List[Dict[str, Any]]:
        """
        向量搜索文档
        
        Args:
            query_vector: 查询向量
            kb_id: 知识库ID过滤
            limit: 返回数量限制
            
        Returns:
            匹配的文档列表
        """
        filter_expr = f"kb_id == {kb_id}" if kb_id else None
        
        results = self.search(
            vectors=[query_vector],
            vector_field="vector",
            filter_expr=filter_expr,
            output_fields=["doc_id", "doc_name", "kb_id", "tags", "keywords", 
                          "abstract", "metadata"],
            limit=limit
        )
        
        return results[0] if results else []
    
    def update_document(
        self,
        doc_id: int,
        doc_name: Optional[str] = None,
        tags: Optional[List[str]] = None,
        keywords: Optional[List[str]] = None,
        abstract: Optional[str] = None,
        vector: Optional[List[float]] = None,
        organize: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        relation: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        更新文档信息
        
        Args:
            doc_id: 文档ID
            doc_name: 文档名称
            tags: 标签列表
            keywords: 关键词列表
            abstract: 文档摘要
            vector: 摘要向量
            organize: 组织方式
            metadata: 元数据
            relation: 关联信息
            
        Returns:
            是否成功
        """
        existing = self.get_document(doc_id=doc_id)
        if not existing:
            return False
        
        update_data = [{"doc_id": doc_id}]
        
        if doc_name is not None:
            update_data[0]["doc_name"] = doc_name
        if tags is not None:
            update_data[0]["tags"] = tags
        if keywords is not None:
            update_data[0]["keywords"] = keywords
        if abstract is not None:
            update_data[0]["abstract"] = abstract
        if vector is not None:
            update_data[0]["vector"] = vector
        if organize is not None:
            update_data[0]["organize"] = organize
        if metadata is not None:
            update_data[0]["metadata"] = metadata
        if relation is not None:
            update_data[0]["relation"] = relation
        
        self.upsert(update_data)
        return True
    
    def delete_document(self, doc_id: int) -> bool:
        """
        删除文档
        
        Args:
            doc_id: 文档ID
            
        Returns:
            是否成功
        """
        count = self.delete(f"doc_id == {doc_id}")
        return count > 0
    
    def delete_documents_by_kb(self, kb_id: int) -> int:
        """
        删除知识库下的所有文档
        
        Args:
            kb_id: 知识库ID
            
        Returns:
            删除的文档数量
        """
        return self.delete(f"kb_id == {kb_id}")


# 便捷函数
def get_document_table(kb_name: str) -> DocumentTable:
    """
    获取文档元数据表实例
    
    Args:
        kb_name: 知识库名称
        
    Returns:
        DocumentTable实例
    """
    return DocumentTable(kb_name=kb_name)