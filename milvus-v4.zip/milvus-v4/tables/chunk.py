# -*- coding: utf-8 -*-
"""
文档切片向量表 (chunk)
存储文档文本内容的信息，通过OCR模型提取后经过chunk切分存储
"""
from typing import Dict, List, Any, Optional, Tuple
from base.base_table import BaseTable
import config
from utils.snowflake import generate_id


class ChunkTable(BaseTable):
    """
    文档切片向量表
    
    存储文档文本内容的信息：
    - type: 块类型（text、table、image caption等）
    - content: 块文本内容
    - vector: embedding向量
    - 支持pre、next链式引用
    """
    
    def __init__(self, kb_name: str, **kwargs):
        """
        初始化文档切片表
        
        Args:
            kb_name: 知识库名称，用于生成Collection名称
        """
        collection_name = config.COLLECTION_TEMPLATE_CHUNK.format(kb_name=kb_name)
        
        super().__init__(
            collection_name=collection_name,
            schema_fields=config.CHUNK_SCHEMA,
            description=f"文档切片向量表 - {kb_name}",
            **kwargs
        )
        
        self._kb_name = kb_name
    
    def get_kb_name(self) -> str:
        """获取知识库名称"""
        return self._kb_name
    
    # =========================================================================
    # 业务方法 - 数据插入
    # =========================================================================
    
    def add_chunk(
        self,
        doc_id: int,
        type: str,
        content: str,
        vector: List[float],
        page_id: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
        keyword: Optional[List[str]] = None
    ) -> int:
        """
        添加文档切片
        
        Args:
            doc_id: 所属文档ID
            type: 块类型（text、table、image caption等）
            content: 块文本内容
            vector: embedding向量
            page_id: 文档第几页
            metadata: 引用、pre、next等信息
            keyword: 关键词列表
            
        Returns:
            chunk_id
        """
        chunk_id = generate_id()
        
        data = [{
            "chunk_id": chunk_id,
            "doc_id": doc_id,
            "page_id": page_id,
            "type": type,
            "content": content,
            "vector": vector,
            "metadata": metadata or {},
            "keyword": keyword or []
        }]
        
        self.insert(data)
        return chunk_id
    
    def add_chunks(
        self,
        chunks_data: List[Dict[str, Any]]
    ) -> Tuple[List[int], int]:
        """
        批量添加文档切片
        
        Args:
            chunks_data: 切片数据列表，每项包含:
                - doc_id: 文档ID
                - page_id: 页码(可选)
                - type: 类型
                - content: 内容
                - vector: 向量
                - metadata: 元数据(可选)
                - keyword: 关键词(可选)
                
        Returns:
            (生成的chunk_id列表, 总插入数量)
        """
        data = []
        
        for item in chunks_data:
            data.append({
                "chunk_id": generate_id(),
                "doc_id": item["doc_id"],
                "page_id": item.get("page_id"),
                "type": item["type"],
                "content": item["content"],
                "vector": item["vector"],
                "metadata": item.get("metadata", {}),
                "keyword": item.get("keyword", [])
            })
        
        return self.insert(data)
    
    def add_chunks_with_chain(
        self,
        chunks_data: List[Dict[str, Any]]
    ) -> Tuple[List[int], int]:
        """
        批量添加切片并建立pre/next链式关系
        
        Args:
            chunks_data: 切片数据列表（需按顺序排列）
            
        Returns:
            (生成的chunk_id列表, 总插入数量)
        """
        chunk_ids = []
        processed_data = []
        
        for i, item in enumerate(chunks_data):
            chunk_id = generate_id()
            chunk_ids.append(chunk_id)
            
            # 构建pre/next元数据
            metadata = item.get("metadata", {})
            
            # 设置pre引用
            if i > 0:
                metadata["pre"] = chunk_ids[i - 1]
            
            # 设置next引用
            if i < len(chunks_data) - 1:
                metadata["next"] = chunk_ids[i + 1]
            
            processed_data.append({
                "chunk_id": chunk_id,
                "doc_id": item["doc_id"],
                "page_id": item.get("page_id"),
                "type": item["type"],
                "content": item["content"],
                "vector": item["vector"],
                "metadata": metadata,
                "keyword": item.get("keyword", [])
            })
        
        return self.insert(processed_data)
    
    # =========================================================================
    # 业务方法 - 查询
    # =========================================================================
    
    def get_chunk(
        self,
        chunk_id: int
    ) -> Optional[Dict[str, Any]]:
        """
        获取切片信息
        
        Args:
            chunk_id: 切片ID
            
        Returns:
            切片信息
        """
        results = self.query(
            filter_expr=f"chunk_id == {chunk_id}",
            output_fields=list(config.CHUNK_SCHEMA.keys())
        )
        
        return results[0] if results else None
    
    def get_chunks_by_doc(
        self,
        doc_id: int,
        chunk_type: Optional[str] = None,
        page_id: Optional[int] = None,
        limit: int = 1000
    ) -> List[Dict[str, Any]]:
        """
        获取文档的所有切片
        
        Args:
            doc_id: 文档ID
            chunk_type: 可选的类型过滤
            page_id: 可选的页码过滤
            limit: 返回数量限制
            
        Returns:
            切片列表
        """
        filter_exprs = [f"doc_id == {doc_id}"]
        
        if chunk_type:
            filter_exprs.append(f'type == "{chunk_type}"')
        
        if page_id is not None:
            filter_exprs.append(f"page_id == {page_id}")
        
        filter_expr = " and ".join(filter_exprs)
        
        return self.query(
            filter_expr=filter_expr,
            output_fields=["chunk_id", "doc_id", "page_id", "type", 
                          "content", "metadata", "keyword"],
            limit=limit
        )
    
    def search_chunks(
        self,
        query_vector: List[float],
        doc_id: Optional[int] = None,
        chunk_type: Optional[str] = None,
        keywords: Optional[List[str]] = None,
        limit: int = 10
    ) -> List[Dict[str, Any]]:
        """
        向量搜索切片
        
        Args:
            query_vector: 查询向量
            doc_id: 文档ID过滤
            chunk_type: 类型过滤
            keywords: 关键词过滤
            limit: 返回数量限制
            
        Returns:
            匹配的切片列表
        """
        filter_exprs = []
        
        if doc_id is not None:
            filter_exprs.append(f"doc_id == {doc_id}")
        
        if chunk_type:
            filter_exprs.append(f'type == "{chunk_type}"')
        
        if keywords:
            for kw in keywords:
                filter_exprs.append(f'keyword contains "{kw}"')
        
        filter_expr = " and ".join(filter_exprs) if filter_exprs else None
        
        results = self.search(
            vectors=[query_vector],
            vector_field="vector",
            filter_expr=filter_expr,
            output_fields=["chunk_id", "doc_id", "page_id", "type", 
                          "content", "metadata", "keyword"],
            limit=limit
        )
        
        return results[0] if results else []
    
    def search_chunks_with_context(
        self,
        query_vector: List[float],
        doc_id: Optional[int] = None,
        chunk_type: Optional[str] = None,
        limit: int = 10,
        context_window: int = 2
    ) -> List[Dict[str, Any]]:
        """
        搜索切片并返回上下文（包含pre/next内容）
        
        Args:
            query_vector: 查询向量
            doc_id: 文档ID过滤
            chunk_type: 类型过滤
            limit: 返回数量限制
            context_window: 上下文窗口大小
            
        Returns:
            包含上下文的切片列表
        """
        # 先搜索基础结果
        chunks = self.search_chunks(
            query_vector=query_vector,
            doc_id=doc_id,
            chunk_type=chunk_type,
            limit=limit
        )
        
        # 补充上下文
        result_chunks = []
        seen_ids = set()
        
        for chunk in chunks:
            result_chunks.append(chunk)
            seen_ids.add(chunk["chunk_id"])
            
            # 获取pre上下文
            metadata = chunk.get("metadata", {})
            pre_id = metadata.get("pre")
            
            if pre_id and pre_id not in seen_ids and len(result_chunks) < limit * context_window:
                pre_chunk = self.get_chunk(pre_id)
                if pre_chunk:
                    result_chunks.append(pre_chunk)
                    seen_ids.add(pre_id)
            
            # 获取next上下文
            next_id = metadata.get("next")
            
            if next_id and next_id not in seen_ids and len(result_chunks) < limit * context_window:
                next_chunk = self.get_chunk(next_id)
                if next_chunk:
                    result_chunks.append(next_chunk)
                    seen_ids.add(next_id)
        
        # 按原始顺序排序
        result_chunks.sort(key=lambda x: chunks.index(x) if x in chunks else 0)
        
        return result_chunks
    
    # =========================================================================
    # 业务方法 - 数据删除
    # =========================================================================
    
    def delete_chunk(self, chunk_id: int) -> bool:
        """
        删除切片
        
        Args:
            chunk_id: 切片ID
            
        Returns:
            是否成功
        """
        count = self.delete(f"chunk_id == {chunk_id}")
        return count > 0
    
    def delete_chunks_by_doc(self, doc_id: int) -> int:
        """
        删除文档的所有切片
        
        Args:
            doc_id: 文档ID
            
        Returns:
            删除的切片数量
        """
        return self.delete(f"doc_id == {doc_id}")
    
    def delete_chunks_by_page(self, doc_id: int, page_id: int) -> int:
        """
        删除指定页的所有切片
        
        Args:
            doc_id: 文档ID
            page_id: 页码
            
        Returns:
            删除的切片数量
        """
        return self.delete(f"doc_id == {doc_id} and page_id == {page_id}")
    
    # =========================================================================
    # 业务方法 - 统计
    # =========================================================================
    
    def get_chunk_count(
        self,
        doc_id: Optional[int] = None,
        chunk_type: Optional[str] = None
    ) -> int:
        """
        统计切片数量
        
        Args:
            doc_id: 文档ID过滤
            chunk_type: 类型过滤
            
        Returns:
            切片数量
        """
        filter_exprs = []
        
        if doc_id is not None:
            filter_exprs.append(f"doc_id == {doc_id}")
        
        if chunk_type:
            filter_exprs.append(f'type == "{chunk_type}"')
        
        filter_expr = " and ".join(filter_exprs) if filter_exprs else "chunk_id >= 0"
        
        return self.count(filter_expr)


# 便捷函数
def get_chunk_table(kb_name: str) -> ChunkTable:
    """
    获取文档切片表实例
    
    Args:
        kb_name: 知识库名称
        
    Returns:
        ChunkTable实例
    """
    return ChunkTable(kb_name=kb_name)