# -*- coding: utf-8 -*-
"""
向量表模块
"""
from tables.knowledge import KnowledgeTable, get_knowledge_table
from tables.document import DocumentTable, get_document_table
from tables.page_abs import PageAbsTable, get_page_abs_table
from tables.page_token import PageTokenTable, get_page_token_table
from tables.chunk import ChunkTable, get_chunk_table
from utils.cascade import CascadeDeleteManager, get_cascade_delete_manager

__all__ = [
    # 知识库表
    "KnowledgeTable",
    "get_knowledge_table",
    # 文档元数据表
    "DocumentTable",
    "get_document_table",
    # 页级摘要向量表
    "PageAbsTable",
    "get_page_abs_table",
    # 页级视觉多向量表
    "PageTokenTable",
    "get_page_token_table",
    # 文档切片向量表
    "ChunkTable",
    "get_chunk_table",
    # 级联删除
    "CascadeDeleteManager",
    "get_cascade_delete_manager",
]
"""
向量表模块
"""
from tables.knowledge import KnowledgeTable, get_knowledge_table
from tables.document import DocumentTable, get_document_table
from tables.page_abs import PageAbsTable, get_page_abs_table
from tables.page_token import PageTokenTable, get_page_token_table
from tables.chunk import ChunkTable, get_chunk_table
from utils.cascade import CascadeDeleteManager, get_cascade_delete_manager

__all__ = [
    # 知识库表
    "KnowledgeTable",
    "get_knowledge_table",
    # 文档元数据表
    "DocumentTable",
    "get_document_table",
    # 页级摘要向量表
    "PageAbsTable",
    "get_page_abs_table",
    # 页级视觉多向量表
    "PageTokenTable",
    "get_page_token_table",
    # 文档切片向量表
    "ChunkTable",
    "get_chunk_table",
    # 级联删除
    "CascadeDeleteManager",
    "get_cascade_delete_manager",
]