# -*- coding: utf-8 -*-
"""
知识库表 (knowledge)
用于存储知识库信息，支持语义路由
"""
from typing import Dict, List, Any, Optional
from base.base_table import BaseTable
import config
from utils.snowflake import generate_id


class KnowledgeTable(BaseTable):
    """
    知识库向量表
    
    存储不同知识库的信息，用户query进来后首先判断可能存在于哪个知识库
    """
    
    # Collection名称（全局唯一）
    COLLECTION_NAME = config.COLLECTION_TEMPLATE_KNOWLEDGE
    
    def __init__(self, **kwargs):
        """
        初始化知识库表
        """
        super().__init__(
            collection_name=self.COLLECTION_NAME,
            schema_fields=config.KNOWLEDGE_SCHEMA,
            description="知识库表，存储知识库元信息和语义向量",
            **kwargs
        )
    
    def get_kb_name(self) -> str:
        """获取知识库名称（全局表，无知识库概念）"""
        return "global"
    
    # =========================================================================
    # 业务方法
    # =========================================================================
    
    def create_knowledge_base(
        self,
        kb_name: str,
        description: str,
        tags: List[str],
        vector: List[float],
        metadata: Optional[Dict[str, Any]] = None
    ) -> int:
        """
        创建知识库
        
        Args:
            kb_name: 知识库名称
            description: 知识库描述
            tags: 知识库标签
            vector: 知识库描述向量（用于语义路由）
            metadata: 扩展元数据
            
        Returns:
            知识库ID
        """
        kb_id = generate_id()
        
        data = [{
            "kb_id": kb_id,
            "kb_name": kb_name,
            "description": description,
            "tags": tags,
            "vector": vector,
            "metadata": metadata or {}
        }]
        
        self.insert(data)
        return kb_id
    
    def get_knowledge_base(
        self,
        kb_id: Optional[int] = None,
        kb_name: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """
        获取知识库信息
        
        Args:
            kb_id: 知识库ID
            kb_name: 知识库名称
            
        Returns:
            知识库信息字典，不存在则返回None
        """
        if kb_id is not None:
            results = self.query(
                filter_expr=f"kb_id == {kb_id}",
                output_fields=["kb_id", "kb_name", "description", "tags", "metadata"]
            )
        elif kb_name is not None:
            results = self.query(
                filter_expr=f'kb_name == "{kb_name}"',
                output_fields=["kb_id", "kb_name", "description", "tags", "metadata"]
            )
        else:
            return None
        
        return results[0] if results else None
    
    def list_knowledge_bases(self) -> List[Dict[str, Any]]:
        """
        列出所有知识库
        
        Returns:
            知识库列表
        """
        return self.query(
            filter_expr="kb_id >= 0",
            output_fields=["kb_id", "kb_name", "description", "tags", "metadata"]
        )
    
    def update_knowledge_base(
        self,
        kb_id: int,
        kb_name: Optional[str] = None,
        description: Optional[str] = None,
        tags: Optional[List[str]] = None,
        vector: Optional[List[float]] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        更新知识库信息
        
        Args:
            kb_id: 知识库ID
            kb_name: 知识库名称
            description: 知识库描述
            tags: 知识库标签
            vector: 知识库描述向量
            metadata: 扩展元数据
            
        Returns:
            是否成功
        """
        # 先查询现有数据
        existing = self.get_knowledge_base(kb_id=kb_id)
        if not existing:
            return False
        
        # 构建更新数据
        update_data = [{"kb_id": kb_id}]
        
        if kb_name is not None:
            update_data[0]["kb_name"] = kb_name
        if description is not None:
            update_data[0]["description"] = description
        if tags is not None:
            update_data[0]["tags"] = tags
        if vector is not None:
            update_data[0]["vector"] = vector
        if metadata is not None:
            update_data[0]["metadata"] = metadata
        
        # upsert
        self.upsert(update_data)
        return True
    
    def delete_knowledge_base(self, kb_id: int) -> bool:
        """
        删除知识库（级联删除其他表的数据由应用层处理）
        
        Args:
            kb_id: 知识库ID
            
        Returns:
            是否成功
        """
        count = self.delete(f"kb_id == {kb_id}")
        return count > 0
    
    def semantic_route(
        self,
        query_vector: List[float],
        top_k: int = 3
    ) -> List[Dict[str, Any]]:
        """
        语义路由：根据query向量找到最匹配的知识库
        
        Args:
            query_vector: 查询向量
            top_k: 返回前k个最匹配的知识库
            
        Returns:
            匹配的知识库列表（按相似度排序）
        """
        results = self.search(
            vectors=[query_vector],
            vector_field="vector",
            output_fields=["kb_id", "kb_name", "description", "tags", "metadata"],
            limit=top_k
        )
        
        return results[0] if results else []
    
    def search_by_keyword(
        self,
        keyword: str,
        tags: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """
        按关键词搜索知识库
        
        Args:
            keyword: 搜索关键词
            tags: 可选的标签过滤
            
        Returns:
            匹配的知识库列表
        """
        # 简单实现：基于描述和名称的模糊匹配
        # 实际生产中可以使用全文索引
        filter_expr = f'kb_name like "%{keyword}%" or description like "%{keyword}%"'
        
        if tags:
            tag_filter = " or ".join([f'tags contains "{tag}"' for tag in tags])
            filter_expr = f"({filter_expr}) and ({tag_filter})"
        
        return self.query(
            filter_expr=filter_expr,
            output_fields=["kb_id", "kb_name", "description", "tags", "metadata"]
        )


# 便捷函数
def get_knowledge_table() -> KnowledgeTable:
    """获取知识库表实例"""
    return KnowledgeTable()