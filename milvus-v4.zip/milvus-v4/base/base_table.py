# -*- coding: utf-8 -*-
"""
Milvus向量数据库基类
封装所有向量表的通用功能，包括连接管理、CRUD操作、索引管理等
"""
from abc import ABC, abstractmethod
from typing import (
    Dict, List, Any, Optional, Tuple, Union, Callable
)
from pymilvus import (
    connections, Collection, FieldSchema, CollectionSchema,
    DataType, utility, exceptions
)
import config


class BaseTable(ABC):
    """
    Milvus向量表基类
    
    提供通用的数据库操作接口，子类只需定义schema和特定业务逻辑
    """
    
    # 批量操作默认大小
    DEFAULT_BATCH_SIZE = config.BATCH_SIZE_INSERT
    
    def __init__(
        self,
        collection_name: str,
        schema_fields: Dict[str, Dict[str, Any]],
        description: str = "",
        **kwargs
    ):
        """
        初始化向量表
        
        Args:
            collection_name: Collection名称
            schema_fields: 字段定义字典
            description: Collection描述
            **kwargs: 其他配置参数
        """
        self.collection_name = collection_name
        self.schema_fields = schema_fields
        self.description = description
        self._collection: Optional[Collection] = None
        self._milvus_kwargs = kwargs
        
        # 初始化Milvus连接
        self._ensure_connection()
    
    # =========================================================================
    # 连接管理
    # =========================================================================
    
    def _ensure_connection(self) -> None:
        """确保Milvus连接已建立"""
        alias = "default"
        if not connections.has_connection(alias):
            connections.connect(
                alias=alias,
                host=config.MILVUS_HOST,
                port=config.MILVUS_PORT,
                user=config.MILVUS_USER,
                password=config.MILVUS_PASSWORD,
                db_name=config.MILVUS_DB_NAME,
                timeout=config.TIMEOUT_SECONDS
            )
    
    @property
    def collection(self) -> Collection:
        """获取Collection对象，延迟加载"""
        if self._collection is None:
            self._collection = Collection(self.collection_name)
        return self._collection
    
    def reload_collection(self) -> Collection:
        """重新加载Collection"""
        self._collection = Collection(self.collection_name)
        return self._collection
    
    # =========================================================================
    # Schema构建
    # =========================================================================
    
    def _build_schema(self) -> CollectionSchema:
        """
        构建Collection Schema
        
        Returns:
            CollectionSchema对象
        """
        fields = []
        
        for field_name, field_config in self.schema_fields.items():
            dtype = self._parse_dtype(field_config["type"])
            is_primary = field_config.get("is_primary", False)
            max_length = field_config.get("max_length", None)
            element_type = field_config.get("element_type", None)
            
            if element_type:
                # Array类型
                field = FieldSchema(
                    name=field_name,
                    dtype=dtype,
                    is_primary=is_primary,
                    element_type=self._parse_dtype(element_type),
                    max_capacity=max_length,
                    description=field_config.get("description", "")
                )
            elif max_length:
                # VarChar类型
                field = FieldSchema(
                    name=field_name,
                    dtype=dtype,
                    is_primary=is_primary,
                    max_length=max_length,
                    description=field_config.get("description", "")
                )
            else:
                # 其他类型
                field = FieldSchema(
                    name=field_name,
                    dtype=dtype,
                    is_primary=is_primary,
                    description=field_config.get("description", "")
                )
            
            fields.append(field)
        
        return CollectionSchema(
            fields=fields,
            description=self.description,
            enable_dynamic_field=False
        )
    
    def _parse_dtype(self, type_str: str) -> DataType:
        """
        解析数据类型字符串
        
        Args:
            type_str: 类型字符串
            
        Returns:
            DataType枚举值
        """
        dtype_map = {
            "Int64": DataType.INT64,
            "Int32": DataType.INT32,
            "Int16": DataType.INT16,
            "Int8": DataType.INT8,
            "Float": DataType.FLOAT,
            "Double": DataType.DOUBLE,
            "Bool": DataType.BOOL,
            "VarChar": DataType.VARCHAR,
            "Array": DataType.ARRAY,
            "FloatVector": DataType.FLOAT_VECTOR,
            "BinaryVector": DataType.BINARY_VECTOR,
            "JSON": DataType.JSON,
        }
        
        if type_str not in dtype_map:
            raise ValueError(f"Unknown data type: {type_str}")
        
        return dtype_map[type_str]
    
    # =========================================================================
    # Collection管理
    # =========================================================================
    
    def create_collection(
        self,
        index_params: Optional[Dict[str, Any]] = None,
        force_recreate: bool = False
    ) -> bool:
        """
        创建Collection并建立索引
        
        Args:
            index_params: 索引参数字典
            force_recreate: 是否强制重建
            
        Returns:
            是否成功
        """
        # 检查是否已存在
        if utility.has_collection(self.collection_name):
            if force_recreate:
                utility.drop_collection(self.collection_name)
            else:
                return False  # 已存在，不重复创建
        
        # 创建Schema
        schema = self._build_schema()
        
        # 创建Collection
        self._collection = Collection(
            name=self.collection_name,
            schema=schema,
            **self._milvus_kwargs
        )
        
        # 创建索引
        if index_params is None:
            index_params = config.DEFAULT_INDEX_PARAMS
            
        self.create_index(index_params)
        
        return True
    
    def create_index(
        self,
        index_params: Dict[str, Any],
        field_name: str = "vector"
    ) -> bool:
        """
        为向量字段创建索引
        
        Args:
            index_params: 索引参数字典
            field_name: 字段名
            
        Returns:
            是否成功
        """
        try:
            self.collection.create_index(
                field_name=field_name,
                index_params=index_params
            )
            return True
        except exceptions.MilvusException as e:
            print(f"创建索引失败: {e}")
            return False
    
    def create_inverted_index(
        self,
        field_names: Optional[List[str]] = None
    ) -> bool:
        """
        为标量字段创建倒排索引（支持高效过滤查询）
        
        Args:
            field_names: 需要创建倒排索引的字段名列表
            
        Returns:
            是否成功
        """
        if field_names is None:
            # 自动识别所有非向量字段
            field_names = [
                name for name, cfg in self.schema_fields.items()
                if cfg["type"] != "FloatVector" and cfg["type"] != "BinaryVector"
            ]
        
        try:
            for field_name in field_names:
                # 检查字段是否存在
                if field_name not in self.schema_fields:
                    continue
                    
                index_params = {
                    "index_type": "STL_SORT"
                }
                self.collection.create_index(
                    field_name=field_name,
                    index_params=index_params
                )
            return True
        except exceptions.MilvusException as e:
            print(f"创建倒排索引失败: {e}")
            return False
    
    def drop_collection(self) -> bool:
        """
        删除Collection
        
        Returns:
            是否成功
        """
        try:
            if utility.has_collection(self.collection_name):
                utility.drop_collection(self.collection_name)
                self._collection = None
            return True
        except exceptions.MilvusException as e:
            print(f"删除Collection失败: {e}")
            return False
    
    def exists(self) -> bool:
        """检查Collection是否存在"""
        return utility.has_collection(self.collection_name)
    
    # =========================================================================
    # 数据操作 - 插入
    # =========================================================================
    
    def insert(
        self,
        data: List[Dict[str, Any]],
        batch_size: Optional[int] = None
    ) -> Tuple[List[int], int]:
        """
        插入数据
        
        Args:
            data: 数据列表，每条数据为字典
            batch_size: 批次大小
            
        Returns:
            (成功插入的ID列表, 总插入数量)
        """
        if not data:
            return [], 0
        
        if batch_size is None:
            batch_size = self.DEFAULT_BATCH_SIZE
        
        inserted_ids = []
        total_count = 0
        
        # 分批插入
        for i in range(0, len(data), batch_size):
            batch = data[i:i + batch_size]
            
            # 转换为Milvus格式
            milvus_data = self._prepare_insert_data(batch)
            
            # 插入
            result = self.collection.insert(milvus_data)
            inserted_ids.extend(result.primary_keys)
            total_count += len(batch)
        
        # 刷新以确保数据可见
        self.collection.flush()
        
        return inserted_ids, total_count
    
    def _prepare_insert_data(self, data: List[Dict[str, Any]]) -> List[Any]:
        """
        将数据转换为Milvus插入格式
        
        Args:
            data: 数据列表
            
        Returns:
            按字段顺序排列的数据列表
        """
        # 按schema字段顺序整理数据
        result = []
        for field_name in self.schema_fields.keys():
            field_data = [item.get(field_name) for item in data]
            result.append(field_data)
        return result
    
    # =========================================================================
    # 数据操作 - 查询
    # =========================================================================
    
    def query(
        self,
        filter_expr: str,
        output_fields: Optional[List[str]] = None,
        limit: int = 100,
        offset: int = 0
    ) -> List[Dict[str, Any]]:
        """
        标量查询
        
        Args:
            filter_expr: 过滤表达式
            output_fields: 输出字段列表
            limit: 返回数量限制
            offset: 偏移量
            
        Returns:
            查询结果列表
        """
        if output_fields is None:
            # 默认返回所有字段
            output_fields = list(self.schema_fields.keys())
        
        results = self.collection.query(
            filter=filter_expr,
            output_fields=output_fields,
            limit=limit,
            offset=offset
        )
        
        return results
    
    def search(
        self,
        vectors: List[List[float]],
        vector_field: str = "vector",
        filter_expr: Optional[str] = None,
        output_fields: Optional[List[str]] = None,
        limit: int = 100,
        search_params: Optional[Dict[str, Any]] = None,
        anns_field: Optional[str] = None
    ) -> List[List[Dict[str, Any]]]:
        """
        向量相似度搜索
        
        Args:
            vectors: 查询向量列表
            vector_field: 向量字段名
            filter_expr: 过滤表达式
            output_fields: 输出字段列表
            limit: 每条查询返回的结果数
            search_params: 搜索参数
            anns_field: 向量字段名（别名）
            
        Returns:
            搜索结果列表，外层按查询向量索引，内层按距离排序
        """
        if search_params is None:
            search_params = config.DEFAULT_SEARCH_PARAMS
            
        if output_fields is None:
            output_fields = list(self.schema_fields.keys())
        
        # 确保向量字段在输出中
        if vector_field not in output_fields:
            output_fields.append(vector_field)
        
        results = self.collection.search(
            data=vectors,
            anns_field=anns_field or vector_field,
            param=search_params,
            filter=filter_expr,
            output_fields=output_fields,
            limit=limit
        )
        
        # 转换为字典格式
        formatted_results = []
        for hits in results:
            hits_list = []
            for hit in hits:
                hit_dict = {field: hit.entity.get(field) for field in output_fields}
                hit_dict["_distance"] = hit.distance
                hits_list.append(hit_dict)
            formatted_results.append(hits_list)
        
        return formatted_results
    
    # =========================================================================
    # 数据操作 - 删除
    # =========================================================================
    
    def delete(
        self,
        filter_expr: str
    ) -> int:
        """
        删除数据
        
        Args:
            filter_expr: 过滤表达式
            
        Returns:
            删除的记录数
        """
        # 先查询获取要删除的数据
        results = self.query(filter_expr=filter_expr, limit=10000)
        delete_count = len(results)
        
        if delete_count > 0:
            self.collection.delete(filter_expr)
            self.collection.flush()
        
        return delete_count
    
    def delete_by_ids(
        self,
        ids: List[int],
        pk_field: str = "id"
    ) -> int:
        """
        根据主键删除数据
        
        Args:
            ids: 主键列表
            pk_field: 主键字段名
            
        Returns:
            删除的记录数
        """
        filter_expr = f"{pk_field} in {ids}"
        return self.delete(filter_expr)
    
    # =========================================================================
    # 数据操作 - 更新（Milvus不支持直接更新，需删除后重新插入）
    # =========================================================================
    
    def upsert(
        self,
        data: List[Dict[str, Any]]
    ) -> Tuple[List[int], int]:
        """
        插入或更新数据（如果主键已存在则更新）
        
        Args:
            data: 数据列表
            
        Returns:
            (成功的主键列表, 总数量)
        """
        # Milvus的upsert实际上是先删后插
        # 这里简化处理，直接调用insert
        # 实际使用时可能需要先查询是否存在，再决定是insert还是delete+insert
        
        if not data:
            return [], 0
        
        # 收集主键
        pk_field = self._get_primary_key_field()
        pks = [item[pk_field] for item in data if pk_field in item]
        
        # 删除已存在的记录
        if pks:
            self.delete(f"{pk_field} in {pks}")
        
        # 插入新数据
        return self.insert(data)
    
    def _get_primary_key_field(self) -> str:
        """获取主键字段名"""
        for name, cfg in self.schema_fields.items():
            if cfg.get("is_primary", False):
                return name
        return "id"
    
    # =========================================================================
    # 统计和工具方法
    # =========================================================================
    
    def count(self, filter_expr: str = "") -> int:
        """
        统计数量
        
        Args:
            filter_expr: 过滤表达式，空字符串表示统计全部
            
        Returns:
            数量
        """
        return self.collection.query(
            filter=filter_expr if filter_expr else "pk >= 0",
            output_fields=["count(*)"],
            limit=1
        )[0].get("count(*)", 0) if self.collection.num_entities > 0 else 0
    
    def get_entity_count(self) -> int:
        """获取Collection中的实体总数"""
        return self.collection.num_entities
    
    def flush(self) -> bool:
        """刷新数据到磁盘"""
        try:
            self.collection.flush()
            return True
        except exceptions.MilvusException as e:
            print(f"刷新数据失败: {e}")
            return False
    
    def get_collection_stats(self) -> Dict[str, Any]:
        """获取Collection统计信息"""
        stats = {
            "name": self.collection_name,
            "entity_count": self.collection.num_entities,
            "fields": list(self.schema_fields.keys()),
        }
        
        # 获取索引信息
        try:
            indexes = self.collection.indexes
            stats["indexes"] = [
                {
                    "field": idx.field_name,
                    "type": idx.params.get("index_type", "unknown")
                }
                for idx in indexes
            ]
        except:
            stats["indexes"] = []
        
        return stats
    
    # =========================================================================
    # 抽象方法（子类实现）
    # =========================================================================
    
    @abstractmethod
    def get_kb_name(self) -> str:
        """获取知识库名称（子类必须实现）"""
        pass