# -*- coding: utf-8 -*-
"""
Milvus RAG 系统配置文件
所有可变参数必须从此处配置，支持环境变量覆盖
"""
import os
from typing import Dict, Any

# =============================================================================
# Milvus 连接配置
# =============================================================================
MILVUS_HOST = os.getenv("MILVUS_HOST", "localhost")
MILVUS_PORT = int(os.getenv("MILVUS_PORT", "19530"))
MILVUS_USER = os.getenv("MILVUS_USER", "")
MILVUS_PASSWORD = os.getenv("MILVUS_PASSWORD", "")
MILVUS_DB_NAME = os.getenv("MILVUS_DB_NAME", "rag_system")

# =============================================================================
# 向量维度配置（根据实际使用的embedding模型调整）
# =============================================================================
VECTOR_DIM_TEXT = int(os.getenv("VECTOR_DIM_TEXT", "1024"))      # 文本embedding维度
VECTOR_DIM_MULTIMODAL = int(os.getenv("VECTOR_DIM_MULTIMODAL", "1024"))  # 多模态embedding维度

# =============================================================================
# 索引配置
# =============================================================================
INDEX_TYPE_VECTOR = os.getenv("INDEX_TYPE_VECTOR", "IVF_FLAT")
INDEX_METRIC_TYPE = os.getenv("INDEX_METRIC_TYPE", "IP")  # IP: 内积, L2: 欧氏距离, COSINE: 余弦
INDEX_NLIST = int(os.getenv("INDEX_NLIST", "1024"))  # IVF聚类中心数
INDEX_NPROBE = int(os.getenv("INDEX_NPROBE", "16"))   # 查询时探针数

# 标量字段倒排索引配置
ENABLE_INVERTED_INDEX = True

# =============================================================================
# 批次大小配置
# =============================================================================
BATCH_SIZE_INSERT = int(os.getenv("BATCH_SIZE_INSERT", "100"))    # 插入批次大小
BATCH_SIZE_QUERY = int(os.getenv("BATCH_SIZE_QUERY", "100"))      # 查询批次大小

# =============================================================================
# 超时配置
# =============================================================================
TIMEOUT_SECONDS = int(os.getenv("TIMEOUT_SECONDS", "30"))

# =============================================================================
# Collection命名模板
# =============================================================================
COLLECTION_TEMPLATE_KNOWLEDGE = "knowledge"
COLLECTION_TEMPLATE_DOCUMENT = "{kb_name}_documents"
COLLECTION_TEMPLATE_PAGE_ABS = "{kb_name}_page_abs"
COLLECTION_TEMPLATE_PAGE_TOKEN = "{kb_name}_page_token"
COLLECTION_TEMPLATE_CHUNK = "{kb_name}_chunk"

# =============================================================================
# 页面多向量配置
# =============================================================================
MAX_PATCHES_PER_PAGE = int(os.getenv("MAX_PATCHES_PER_PAGE", "64"))  # 单页最大patch数

# =============================================================================
# 知识库字段定义
# =============================================================================
KNOWLEDGE_SCHEMA = {
    "kb_id": {"type": "Int64", "is_primary": True, "description": "知识库唯一ID"},
    "kb_name": {"type": "VarChar", "max_length": 512, "is_primary": False, "description": "知识库名称"},
    "description": {"type": "VarChar", "max_length": 10000, "description": "知识库描述"},
    "tags": {"type": "Array", "element_type": "VarChar", "max_length": 128, "description": "知识库标签"},
    "vector": {"type": "FloatVector", "dim": VECTOR_DIM_TEXT, "description": "知识库描述向量"},
    "metadata": {"type": "JSON", "description": "知识库元数据"},
}

# =============================================================================
# 文档元数据表字段定义
# =============================================================================
DOCUMENT_SCHEMA = {
    "doc_id": {"type": "Int64", "is_primary": True, "description": "文档唯一ID"},
    "kb_id": {"type": "Int64", "is_primary": False, "description": "所属知识库ID"},
    "doc_name": {"type": "VarChar", "max_length": 512, "description": "文件名"},
    "tags": {"type": "Array", "element_type": "VarChar", "max_length": 128, "description": "标签"},
    "keywords": {"type": "Array", "element_type": "VarChar", "max_length": 256, "description": "关键词"},
    "abstract": {"type": "VarChar", "max_length": 10000, "description": "文档摘要"},
    "vector": {"type": "FloatVector", "dim": VECTOR_DIM_TEXT, "description": "摘要embedding向量"},
    "organize": {"type": "Array", "element_type": "VarChar", "max_length": 64, "description": "组织方式"},
    "metadata": {"type": "JSON", "description": "存储路径、入库时间等元数据"},
    "relation": {"type": "JSON", "description": "文档间关联信息"},
}

# =============================================================================
# 页级摘要向量表字段定义
# =============================================================================
PAGE_ABS_SCHEMA = {
    "row_id": {"type": "Int64", "is_primary": True, "description": "页面唯一ID"},
    "doc_id": {"type": "Int64", "is_primary": False, "description": "所属文档ID"},
    "abstract": {"type": "VarChar", "max_length": 10000, "description": "VLM生成的页面描述"},
    "page_id": {"type": "Int64", "is_primary": False, "description": "文档第几页"},
    "vector": {"type": "FloatVector", "dim": VECTOR_DIM_MULTIMODAL, "description": "多模态embedding向量"},
    "page_path": {"type": "VarChar", "max_length": 512, "description": "页面存储路径"},
    "keyword": {"type": "Array", "element_type": "VarChar", "max_length": 256, "description": "关键词"},
    "metadata": {"type": "JSON", "description": "页面元素信息"},
}

# =============================================================================
# 页级视觉多向量表字段定义
# =============================================================================
PAGE_TOKEN_SCHEMA = {
    "vec_id": {"type": "Int64", "is_primary": True, "description": "主键"},
    "token_vector": {"type": "FloatVector", "dim": VECTOR_DIM_MULTIMODAL, "description": "patch token向量"},
    "patch_id": {"type": "Int16", "is_primary": False, "description": "第几个patch"},
    "doc_id": {"type": "Int64", "is_primary": False, "description": "关联文档ID"},
    "page_id": {"type": "Int64", "is_primary": False, "description": "文档第几页"},
    "metadata": {"type": "JSON", "description": "其他相关信息"},
}

# =============================================================================
# 文档切片向量表字段定义
# =============================================================================
CHUNK_SCHEMA = {
    "chunk_id": {"type": "Int64", "is_primary": True, "description": "文本块唯一ID"},
    "doc_id": {"type": "Int64", "is_primary": False, "description": "所属文档ID"},
    "page_id": {"type": "Int64", "is_primary": False, "description": "文档第几页"},
    "type": {"type": "VarChar", "max_length": 32, "description": "类型：text、table、image caption"},
    "content": {"type": "VarChar", "max_length": 65536, "description": "块文本内容"},
    "vector": {"type": "FloatVector", "dim": VECTOR_DIM_TEXT, "description": "embedding向量"},
    "metadata": {"type": "JSON", "description": "引用、pre、next"},
    "keyword": {"type": "Array", "element_type": "VarChar", "max_length": 256, "description": "关键词"},
}

# =============================================================================
# 默认索引参数（可覆盖）
# =============================================================================
DEFAULT_INDEX_PARAMS: Dict[str, Any] = {
    "metric_type": INDEX_METRIC_TYPE,
    "index_type": INDEX_TYPE_VECTOR,
    "params": {"nlist": INDEX_NLIST, "nprobe": INDEX_NPROBE}
}

DEFAULT_SEARCH_PARAMS: Dict[str, Any] = {
    "metric_type": INDEX_METRIC_TYPE,
    "params": {"nprobe": INDEX_NPROBE}
}

# =============================================================================
# Snowflake ID 配置
# =============================================================================
SNOWFLAKE_EPOCH = int(os.getenv("SNOWFLAKE_EPOCH", "1704067200000"))  # 2024-01-01 00:00:00 UTC
SNOWFLAKE_WORKER_ID = int(os.getenv("SNOWFLAKE_WORKER_ID", "1"))
SNOWFLAKE_DATACENTER_ID = int(os.getenv("SNOWFLAKE_DATACENTER_ID", "1"))
SNOWFLAKE_SEQUENCE_BITS = int(os.getenv("SNOWFLAKE_SEQUENCE_BITS", "12"))
SNOWFLAKE_WORKER_BITS = int(os.getenv("SNOWFLAKE_WORKER_BITS", "5"))
SNOWFLAKE_DATACENTER_BITS = int(os.getenv("SNOWFLAKE_DATACENTER_BITS", "5"))

# =============================================================================
# 查询配置
# =============================================================================
DEFAULT_TOP_K = int(os.getenv("DEFAULT_TOP_K", "100"))
MAX_TOP_K = int(os.getenv("MAX_TOP_K", "10000"))

# =============================================================================
# 多向量查询配置 (MaxSIM)
# =============================================================================
MAXSIM_GROUP_FIELDS = ["doc_id", "page_id"]
ENABLE_PATCH_VALIDATION = os.getenv("ENABLE_PATCH_VALIDATION", "true").lower() == "true"

# =============================================================================
# 功能开关
# =============================================================================
ENABLE_CASCADING_DELETE = os.getenv("ENABLE_CASCADING_DELETE", "true").lower() == "true"
ENABLE_SOFT_DELETE = os.getenv("ENABLE_SOFT_DELETE", "false").lower() == "true"