# -*- coding: utf-8 -*-
"""
级联删除管理器
实现文档删除时同步清理关联的page_abs、page_token、chunk数据
"""
from typing import List, Dict, Any, Optional
from tables.document import get_document_table
from tables.page_abs import get_page_abs_table
from tables.page_token import get_page_token_table
from tables.chunk import get_chunk_table


class CascadeDeleteManager:
    """
    级联删除管理器
    
    删除文档时自动清理关联的所有数据：
    - document表中的文档元数据
    - page_abs表中的页级摘要
    - page_token表中的页级视觉多向量
    - chunk表中的文档切片
    """
    
    def __init__(self, kb_name: str):
        """
        初始化级联删除管理器
        
        Args:
            kb_name: 知识库名称
        """
        self.kb_name = kb_name
        
        # 初始化各表实例
        self.document_table = get_document_table(kb_name)
        self.page_abs_table = get_page_abs_table(kb_name)
        self.page_token_table = get_page_token_table(kb_name)
        self.chunk_table = get_chunk_table(kb_name)
    
    def delete_document(
        self,
        doc_id: int,
        delete_chunks: bool = True,
        delete_pages: bool = True,
        delete_tokens: bool = True
    ) -> Dict[str, Any]:
        """
        级联删除文档及其关联数据
        
        Args:
            doc_id: 文档ID
            delete_chunks: 是否删除chunk数据
            delete_pages: 是否删除page_abs数据
            delete_tokens: 是否删除page_token数据
            
        Returns:
            删除结果统计
        """
        result = {
            "doc_id": doc_id,
            "document_deleted": False,
            "chunks_deleted": 0,
            "pages_deleted": 0,
            "tokens_deleted": 0,
            "errors": []
        }
        
        try:
            # 1. 删除chunk数据
            if delete_chunks:
                try:
                    chunks_deleted = self.chunk_table.delete_chunks_by_doc(doc_id)
                    result["chunks_deleted"] = chunks_deleted
                except Exception as e:
                    result["errors"].append(f"chunk: {str(e)}")
            
            # 2. 删除page_abs数据
            if delete_pages:
                try:
                    pages_deleted = self.page_abs_table.delete_pages_by_doc(doc_id)
                    result["pages_deleted"] = pages_deleted
                except Exception as e:
                    result["errors"].append(f"page_abs: {str(e)}")
            
            # 3. 删除page_token数据
            if delete_tokens:
                try:
                    tokens_deleted = self.page_token_table.delete_tokens_by_doc(doc_id)
                    result["tokens_deleted"] = tokens_deleted
                except Exception as e:
                    result["errors"].append(f"page_token: {str(e)}")
            
            # 4. 最后删除文档元数据
            try:
                result["document_deleted"] = self.document_table.delete_document(doc_id)
            except Exception as e:
                result["errors"].append(f"document: {str(e)}")
            
        except Exception as e:
            result["errors"].append(f"critical: {str(e)}")
        
        return result
    
    def delete_documents(
        self,
        doc_ids: List[int],
        **kwargs
    ) -> List[Dict[str, Any]]:
        """
        批量级联删除文档
        
        Args:
            doc_ids: 文档ID列表
            **kwargs: delete_document的参数
            
        Returns:
            每条文档的删除结果列表
        """
        results = []
        
        for doc_id in doc_ids:
            result = self.delete_document(doc_id, **kwargs)
            results.append(result)
        
        return results
    
    def delete_knowledge_base(
        self,
        kb_id: int,
        document_table: Any  # KnowledgeTable
    ) -> Dict[str, Any]:
        """
        级联删除知识库及其所有关联数据
        
        Args:
            kb_id: 知识库ID
            document_table: 知识库表实例
            
        Returns:
            删除结果统计
        """
        result = {
            "kb_id": kb_id,
            "documents_deleted": 0,
            "cascade_results": []
        }
        
        try:
            # 1. 获取该知识库下的所有文档
            documents = self.document_table.list_documents(kb_id=kb_id)
            doc_ids = [doc["doc_id"] for doc in documents]
            
            # 2. 级联删除每个文档
            for doc_id in doc_ids:
                cascade_result = self.delete_document(doc_id)
                result["cascade_results"].append(cascade_result)
            
            result["documents_deleted"] = len(doc_ids)
            
            # 3. 删除知识库元信息
            document_table.delete_knowledge_base(kb_id)
            
        except Exception as e:
            result["error"] = str(e)
        
        return result
    
    def get_document_stats(self, doc_id: int) -> Dict[str, int]:
        """
        获取文档关联数据的统计信息
        
        Args:
            doc_id: 文档ID
            
        Returns:
            统计信息字典
        """
        return {
            "chunks": self.chunk_table.get_chunk_count(doc_id=doc_id),
            "pages": self.page_abs_table.get_page_count(doc_id),
            "tokens": self.page_token_table.count(f"doc_id == {doc_id}"),
        }


def get_cascade_delete_manager(kb_name: str) -> CascadeDeleteManager:
    """
    获取级联删除管理器实例
    
    Args:
        kb_name: 知识库名称
        
    Returns:
        CascadeDeleteManager实例
    """
    return CascadeDeleteManager(kb_name=kb_name)