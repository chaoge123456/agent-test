# -*- coding: utf-8 -*-
"""
雪花算法ID生成器
用于生成分布式环境下全局唯一的Int64类型主键
"""
import time
import threading
from typing import Optional


class SnowflakeGenerator:
    """
    雪花算法实现
    
    结构: 1位符号位 + 41位时间戳 + 5位数据中心ID + 5位机器ID + 12位序列号
    - 符号位: 始终为0
    - 时间戳: 41位，可支持约69年
    - 数据中心ID: 5位，支持32个数据中心
    - 机器ID: 5位，支持32个机器
    - 序列号: 12位，每毫秒最多4096个ID
    
    使用方式:
        generator = SnowflakeGenerator()
        unique_id = generator.generate()
    """
    
    # 起始时间戳 (2024-01-01 00:00:00 UTC)
    EPOCH = 1704067200000
    
    # 位移常量
    TIMESTAMP_SHIFT = 22  # 时间戳左移22位
    DATACENTER_SHIFT = 17  # 数据中心左移17位
    MACHINE_SHIFT = 12    # 机器ID左移12位
    
    # 掩码
    SEQUENCE_MASK = (1 << 12) - 1  # 12位序列号掩码
    
    def __init__(
        self,
        datacenter_id: int = 0,
        machine_id: int = 0,
        epoch: Optional[int] = None
    ):
        """
        初始化雪花算法生成器
        
        Args:
            datacenter_id: 数据中心ID (0-31)
            machine_id: 机器ID (0-31)
            epoch: 起始时间戳（毫秒），默认为配置的时间
        """
        if datacenter_id < 0 or datacenter_id > 31:
            raise ValueError("datacenter_id must be between 0 and 31")
        if machine_id < 0 or machine_id > 31:
            raise ValueError("machine_id must be between 0 and 31")
            
        self.datacenter_id = datacenter_id
        self.machine_id = machine_id
        self.epoch = epoch or self.EPOCH
        
        # 序列号和上次时间戳
        self._sequence = 0
        self._last_timestamp = 0
        
        # 线程锁
        self._lock = threading.Lock()
    
    def generate(self) -> int:
        """
        生成唯一的64位ID
        
        Returns:
            生成的唯一ID (Int64)
        """
        with self._lock:
            timestamp = self._current_timestamp()
            
            # 如果当前时间小于上次时间戳，说明时钟回拨
            if timestamp < self._last_timestamp:
                raise RuntimeError(
                    f"Clock moved backwards. Refusing to generate ID for "
                    f"{self._last_timestamp - timestamp} milliseconds"
                )
            
            # 如果是同一毫秒内，增加序列号
            if timestamp == self._last_timestamp:
                self._sequence = (self._sequence + 1) & self.SEQUENCE_MASK
                # 如果序列号溢出，等待下一毫秒
                if self._sequence == 0:
                    timestamp = self._wait_next_millis(self._last_timestamp)
            else:
                # 不同毫秒，重置序列号
                self._sequence = 0
            
            self._last_timestamp = timestamp
            
            # 组装ID
            # 时间戳部分
            id_value = ((timestamp - self.epoch) << self.TIMESTAMP_SHIFT)
            # 数据中心部分
            id_value |= (self.datacenter_id << self.DATACENTER_SHIFT)
            # 机器ID部分
            id_value |= (self.machine_id << self.MACHINE_SHIFT)
            # 序列号部分
            id_value |= self._sequence
            
            return id_value
    
    def _current_timestamp(self) -> int:
        """获取当前时间戳（毫秒）"""
        return int(time.time() * 1000)
    
    def _wait_next_millis(self, last_timestamp: int) -> int:
        """
        等待下一毫秒
        
        Args:
            last_timestamp: 上次时间戳
            
        Returns:
            新的时间戳
        """
        timestamp = self._current_timestamp()
        while timestamp <= last_timestamp:
            timestamp = self._current_timestamp()
        return timestamp
    
    @property
    def last_timestamp(self) -> int:
        """获取上次生成ID时的时间戳"""
        return self._last_timestamp


# 全局单例实例
_default_generator: Optional[SnowflakeGenerator] = None
_generator_lock = threading.Lock()


def get_generator(
    datacenter_id: int = 0,
    machine_id: int = 0,
    force_new: bool = False
) -> SnowflakeGenerator:
    """
    获取雪花算法生成器单例
    
    Args:
        datacenter_id: 数据中心ID
        machine_id: 机器ID
        force_new: 是否强制创建新实例
        
    Returns:
        雪花算法生成器实例
    """
    global _default_generator
    
    with _generator_lock:
        if _default_generator is None or force_new:
            _default_generator = SnowflakeGenerator(
                datacenter_id=datacenter_id,
                machine_id=machine_id
            )
        return _default_generator


def generate_id() -> int:
    """
    快捷函数：生成唯一ID
    
    Returns:
        唯一的Int64类型ID
    """
    return get_generator().generate()


def generate_ids(count: int) -> list[int]:
    """
    批量生成唯一ID
    
    Args:
        count: 需要生成的ID数量
        
    Returns:
        ID列表
    """
    return [generate_id() for _ in range(count)]


# 示例用法
if __name__ == "__main__":
    # 测试
    generator = SnowflakeGenerator(datacenter_id=1, machine_id=1)
    
    print("测试雪花算法ID生成:")
    for i in range(5):
        print(f"  ID {i+1}: {generator.generate()}")
    
    print(f"\n当前时间戳: {int(time.time() * 1000)}")
    print(f"起始时间戳: {SnowflakeGenerator.EPOCH}")