# Milvus RAG System

基于 [Milvus](https://milvus.io/) 向量数据库的 RAG（检索增强生成）系统实现，支持知识库管理、文档多模态向量存储和语义路由。

## 项目概述

这是一个生产级的 RAG 系统，提供了完整的向量数据库操作接口，支持：
- 多知识库管理（支持语义路由）
- 文档元数据存储
- 页级摘要向量（多模态embedding）
- 页级视觉多向量（类 ColPali/ColQwen2 架构）
- 文档切片向量（文本chunk）
- 级联删除（保证数据一致性）
- 雪花算法ID生成（分布式唯一ID）

## 系统架构

```
milvus-v4/
├── config.py              # 全局配置
├── base/
│   └── base_table.py      # 向量表基类
├── tables/
│   ├── knowledge.py       # 知识库表
│   ├── document.py        # 文档元数据表
│   ├── page_abs.py        # 页级摘要向量表
│   ├── page_token.py      # 页级视觉多向量表
│   └── chunk.py           # 文档切片向量表
├── utils/
│   ├── snowflake.py       # 雪花算法ID生成器
│   └── cascade.py         # 级联删除管理器
└── tests/                 # 单元测试
```

## 模块说明

### config.py - 配置模块

所有系统配置均在此文件中，支持环境变量覆盖：

| 配置项 | 说明 | 默认值 |
|--------|------|--------|
| MILVUS_HOST | Milvus服务地址 | localhost |
| MILVUS_PORT | Milvus服务端口 | 19530 |
| VECTOR_DIM_TEXT | 文本embedding维度 | 1024 |
| VECTOR_DIM_MULTIMODAL | 多模态embedding维度 | 1024 |
| INDEX_TYPE_VECTOR | 向量索引类型 | IVF_FLAT |
| INDEX_METRIC_TYPE | 距离度量类型 | IP |
| BATCH_SIZE_INSERT | 插入批次大小 | 100 |
| MAX_PATCHES_PER_PAGE | 单页最大patch数 | 64 |

### base/base_table.py - 向量表基类

封装所有向量表的通用功能：
- 连接管理（自动重连）
- Schema构建
- Collection管理（创建、删除、索引）
- 数据操作（插入、查询、搜索、删除）
- 统计和工具方法

### tables/ 模块

#### KnowledgeTable - 知识库表

存储知识库元信息，支持语义路由：
- `create_knowledge_base()` - 创建知识库
- `get_knowledge_base()` - 获取知识库
- `list_knowledge_bases()` - 列出所有知识库
- `semantic_route()` - 语义路由（向量检索）
- `search_by_keyword()` - 关键词搜索

#### DocumentTable - 文档元数据表

存储知识库内的文档信息：
- `add_document()` - 添加文档
- `get_document()` - 获取文档
- `list_documents()` - 列出文档
- `search_documents()` - 向量搜索文档
- `update_document()` - 更新文档

#### PageAbsTable - 页级摘要向量表

存储页面的VLM摘要和多模态embedding向量：
- `add_page_abstract()` - 添加页面摘要
- `add_page_abstracts()` - 批量添加
- `get_page_abstract()` - 获取页面摘要
- `search_pages()` - 向量搜索页面

#### PageTokenTable - 页级视觉多向量表

类似 ColPali/ColQwen2 架构，存储页面的多向量表示：
- `add_page_tokens()` - 添加页面多向量
- `add_page_tokens_batch()` - 批量添加
- `search_with_maxsim()` - MaxSim聚合查询
- `verify_page_integrity()` - 验证页面完整性

#### ChunkTable - 文档切片向量表

存储文档文本内容：
- `add_chunk()` - 添加切片
- `add_chunks()` - 批量添加
- `add_chunks_with_chain()` - 带链式关系添加
- `search_chunks()` - 向量搜索
- `search_chunks_with_context()` - 带上下文搜索

### utils/ 模块

#### snowflake.py - 雪花算法

分布式唯一ID生成器：
- 64位ID结构：1位符号 + 41位时间戳 + 5位数据中心 + 5位机器 + 12位序列号
- 线程安全
- 支持单例模式和自定义配置

#### cascade.py - 级联删除

保证删除文档时关联数据的一致性：
- 自动清理 page_abs、page_token、chunk 数据
- 支持批量删除
- 提供统计信息

## 快速开始

### 1. 安装依赖

```bash
pip install pymilvus
```

### 2. 配置环境变量（可选）

```bash
export MILVUS_HOST=localhost
export MILVUS_PORT=19530
export MILVUS_USER=your_user
export MILVUS_PASSWORD=your_password
export MILVUS_DB_NAME=rag_system
```

### 3. 基本使用示例

```python
import milvus_v4 as milvus

# 创建知识库
knowledge_table = milvus.tables.KnowledgeTable()
kb_id = knowledge_table.create_knowledge_base(
    kb_name="my_knowledge_base",
    description="这是一个测试知识库",
    tags=["AI", "RAG"],
    vector=[0.1] * 1024  # 知识库描述的embedding向量
)

# 添加文档
doc_table = milvus.tables.DocumentTable(kb_name="my_knowledge_base")
doc_id = doc_table.add_document(
    doc_name="document.pdf",
    kb_id=kb_id,
    tags=["技术文档"],
    organize=["tree"],
    metadata={"path": "/path/to/document.pdf", "type": "pdf"}
)

# 添加文档切片
chunk_table = milvus.tables.ChunkTable(kb_name="my_knowledge_base")
chunk_id = chunk_table.add_chunk(
    doc_id=doc_id,
    type="text",
    content="这是文档的内容",
    vector=[0.2] * 1024,  # 文本的embedding向量
    page_id=1
)

# 向量搜索
results = chunk_table.search_chunks(
    query_vector=[0.3] * 1024,
    limit=10
)

# 删除文档（级联删除关联数据）
from utils.cascade import get_cascade_delete_manager
cascade = get_cascade_delete_manager(kb_name="my_knowledge_base")
result = cascade.delete_document(doc_id=doc_id)
```

## 测试

```bash
# 运行所有测试
pytest tests/ -v

# 运行特定模块测试
pytest tests/test_snowflake.py -v

# 运行特定测试
pytest tests/test_snowflake.py::TestSnowflakeGenerator::test_generate_id_unique -v
```

## 许可证

MIT License