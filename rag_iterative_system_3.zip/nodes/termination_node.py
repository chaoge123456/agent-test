# -*- coding: utf-8 -*-
"""
迭代条件判断、循环终止决策节点
- 多条件组合判定机制
- 可通过配置文件灵活调整阈值与规则
- 满足任一条件即刻终止迭代
- 迭代式检索开关（enable_iterative_retrieval）
- 管道式检索下钻由路由和检索节点负责，本节点只做终止判定
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List

from rag_iterative_system.config.system_settings import get_settings
from rag_iterative_system.evaluation.metrics import compute_coverage_score
from rag_iterative_system.state.graph_state import GraphState
from rag_iterative_system.utils.logging import get_iteration_logger

logger = logging.getLogger(__name__)


def _check_max_iterations(
    iteration: int,
    max_iterations: int,
) -> tuple:
    """条件1: 迭代轮次达到系统设定最大上限"""
    if iteration >= max_iterations:
        return True, f"已达最大迭代轮次上限({max_iterations}轮)"
    return False, ""


def _check_low_information_gain(
    current_gain: float,
    previous_gains: List[float],
    min_gain: float,
    consecutive_threshold: int,
    current_no_gain: int,
) -> tuple:
    """条件2: 信息增益低于阈值，且连续多轮无有效新增信息"""
    if current_gain < min_gain:
        new_no_gain = current_no_gain + 1
        if new_no_gain >= consecutive_threshold:
            return True, (
                f"连续{new_no_gain}轮信息增益低于阈值"
                f"(增益={current_gain:.4f}, 阈值={min_gain})"
            )
        return False, ""
    return False, ""


def _check_coverage_complete(
    query: str,
    documents: list,
    coverage_threshold: float = 0.9,
) -> tuple:
    """条件3: 检索文档内容已完整覆盖用户查询核心诉求"""
    if not documents:
        return False, ""
    coverage = compute_coverage_score(query, documents)
    if coverage >= coverage_threshold:
        return True, f"查询覆盖度已达{coverage:.1%}，信息充分"
    return False, ""


def _check_no_new_docs(
    filtered_count: int,
    history_count: int,
    max_total: int,
) -> tuple:
    """条件4: 本轮无新增有效文档 或 历史文档已达上限"""
    if filtered_count == 0 and history_count > 0:
        return True, "本轮检索无新增有效文档"
    if history_count >= max_total:
        return True, f"历史文档数已达上限({max_total})"
    return False, ""


def termination_node(state: GraphState) -> dict:
    """
    迭代终止判定节点

    多条件组合判定（满足任一即终止）:
    1. 迭代轮次达到最大上限
    2. 连续多轮信息增益低于阈值
    3. 检索文档已完整覆盖查询诉求
    4. 本轮无新增有效文档 或 历史文档达上限

    如果 enable_iterative_retrieval=False（默认），
    则首轮检索后直接终止（除非首轮无结果）。

    Args:
        state: 当前图状态

    Returns:
        状态更新字典，包含是否继续迭代与终止原因
    """
    settings = get_settings()
    iter_logger = get_iteration_logger()

    iteration = state.get("iteration_count", 1)
    information_gain = state.get("information_gain", 0.0)
    previous_gains = state.get("previous_gain_scores", [])
    doc_history = state.get("document_history", [])
    filtered_docs = state.get("filtered_documents", [])
    original_query = state.get("original_query", "")
    no_gain_rounds = state.get("no_gain_rounds", 0)

    should_terminate = False
    termination_reason = ""

    # ---- 迭代开关检查 ----
    if not settings.enable_iterative_retrieval:
        # 非迭代模式：首轮后直接终止
        if iteration >= 1:
            should_terminate = True
            if doc_history:
                termination_reason = "迭代式检索未启用，单轮检索完成"
            else:
                termination_reason = "迭代式检索未启用，首轮无结果"

    # ---- 逐一检查终止条件 ----
    if not should_terminate:
        # 条件1: 最大迭代轮次
        terminated, reason = _check_max_iterations(
            iteration, settings.max_iterations
        )
        if terminated:
            should_terminate = True
            termination_reason = reason

    if not should_terminate:
        # 条件2: 连续低信息增益
        terminated, reason = _check_low_information_gain(
            information_gain,
            previous_gains,
            settings.min_information_gain,
            settings.consecutive_no_gain_rounds,
            no_gain_rounds,
        )
        if terminated:
            should_terminate = True
            termination_reason = reason

    if not should_terminate:
        # 条件3: 覆盖度充分
        terminated, reason = _check_coverage_complete(
            original_query, doc_history
        )
        if terminated:
            should_terminate = True
            termination_reason = reason

    if not should_terminate:
        # 条件4: 无新增文档或达上限
        terminated, reason = _check_no_new_docs(
            len(filtered_docs),
            len(doc_history),
            settings.max_total_documents,
        )
        if terminated:
            should_terminate = True
            termination_reason = reason

    # 更新连续无增益轮次计数
    if information_gain < settings.min_information_gain:
        no_gain_rounds += 1
    else:
        no_gain_rounds = 0

    should_continue = not should_terminate

    iter_logger.log_termination(termination_reason, should_continue)

    logger.info(
        "终止判定 [Iter-%d]: 继续=%s, 增益=%.4f, 历史文档=%d, 原因=%s",
        iteration,
        should_continue,
        information_gain,
        len(doc_history),
        termination_reason or "继续迭代",
    )

    return {
        "should_continue": should_continue,
        "termination_reason": termination_reason,
        "no_gain_rounds": no_gain_rounds,
    }
