# -*- coding: utf-8 -*-
"""
上下文聚合、最终答案生成节点
- 迭代终止后聚合全流程优质文档
- 优先使用高置信度累加器结果
- 结合原始问题生成完整连贯答案
- 支持引用溯源、结构化输出
"""

from __future__ import annotations

import logging
from typing import List

from rag_iterative_system.config.llm_config import get_llm
from rag_iterative_system.config.system_settings import get_settings
from rag_iterative_system.state.graph_state import (
    ConfidenceAccumulator,
    GraphState,
    RetrievalResult,
)
from rag_iterative_system.utils.error_handler import (
    retry_with_backoff,
    LLMCallError,
    truncate_context,
)
from rag_iterative_system.utils.logging import get_iteration_logger

logger = logging.getLogger(__name__)

ANSWER_SYSTEM_PROMPT = (
    "你是一个专业的知识问答助手。请基于提供的检索上下文，"
    "为用户的问题生成准确、完整、可溯源的答案。\n\n"
    "答案生成要求：\n"
    "1. 准确性：严格基于提供的上下文信息作答，不编造、不推测\n"
    "2. 完整性：充分整合多个来源的信息，全面回答问题\n"
    "3. 可溯源：在答案中标注信息来源（用[来源:知识库ID]标注）\n"
    "4. 结构化：对复杂问题分点作答，逻辑清晰\n"
    "5. 简洁性：避免冗余，直接回答核心问题\n"
    "6. 诚实性：如果上下文信息不足以完全回答问题，明确说明\n"
)


@retry_with_backoff(max_retries=2, exceptions=(LLMCallError,))
def _call_answer_llm(prompt: str, system_prompt: str) -> str:
    """调用LLM生成答案"""
    llm = get_llm()
    return llm.call(prompt, system_prompt)


def _build_context_text(documents: list) -> str:
    """构建格式化的检索上下文文本"""
    if not documents:
        return "（无可用检索上下文）"

    context_parts: List[str] = []
    for i, doc in enumerate(documents, 1):
        if isinstance(doc, RetrievalResult):
            # 层次化信息
            hierarchy = f"doc={doc.doc_id}"
            if doc.page_id:
                hierarchy += f", page={doc.page_id}"
            if doc.chunk_id:
                hierarchy += f", chunk={doc.chunk_id}"

            context_parts.append(
                f"[文档{i}] [来源:{doc.source}] [相关度:{doc.score:.3f}] [{hierarchy}]\n{doc.content}"
            )
        elif hasattr(doc, "content") and hasattr(doc, "source"):
            source_label = doc.source
            score = getattr(doc, "score", 0.0)
            context_parts.append(
                f"[文档{i}] [来源:{source_label}] [相关度:{score:.3f}]\n{doc.content}"
            )
        elif isinstance(doc, dict):
            context_parts.append(
                f"[文档{i}] [来源:{doc.get('source', '?')}]\n{doc.get('content', '')}"
            )

    return "\n\n---\n\n".join(context_parts)


def answer_node(state: GraphState) -> dict:
    """
    答案生成节点

    迭代终止后：
    1. 优先使用高置信度累加器结果
    2. 补充document_history中的其他结果
    3. 构建上下文并生成最终答案

    Args:
        state: 当前图状态

    Returns:
        状态更新字典，包含最终答案
    """
    settings = get_settings()
    iter_logger = get_iteration_logger()

    original_query = state.get("original_query", "")
    doc_history = state.get("document_history", [])
    termination_reason = state.get("termination_reason", "")

    # 优先使用高置信度累加器结果
    accumulator = state.get("confidence_accumulator")
    if accumulator and hasattr(accumulator, "results") and accumulator.results:
        # 累加器中的高置信度结果
        high_conf_docs = accumulator.get_all()
        # 补充历史中不在累加器的文档
        high_conf_ids = {
            (d.doc_id, d.page_id, d.chunk_id)
            for d in high_conf_docs
            if isinstance(d, RetrievalResult)
        }
        supplementary = []
        for doc in doc_history:
            if isinstance(doc, RetrievalResult):
                if (doc.doc_id, doc.page_id, doc.chunk_id) not in high_conf_ids:
                    supplementary.append(doc)
            else:
                supplementary.append(doc)

        # 高置信度文档在前，补充文档在后
        context_docs = high_conf_docs + supplementary
        logger.info(
            "答案生成: 高置信度=%d, 补充=%d",
            len(high_conf_docs), len(supplementary),
        )
    else:
        context_docs = doc_history

    # 构建检索上下文
    context_text = _build_context_text(context_docs)
    context_text = truncate_context(context_text, settings.max_context_length)

    # 构建用户提示词
    user_prompt = (
        f"用户问题：{original_query}\n\n"
        f"检索上下文：\n{context_text}\n\n"
        f"请基于上述检索上下文，回答用户的问题。"
    )

    try:
        final_answer = _call_answer_llm(user_prompt, ANSWER_SYSTEM_PROMPT)
    except Exception as e:
        logger.error("答案生成失败: %s", str(e)[:200])
        final_answer = (
            f"抱歉，答案生成过程中出现异常。"
            f"已检索到{len(doc_history)}个相关文档，但无法生成最终答案。"
            f"错误信息: {str(e)[:100]}"
        )

    # 更新最后一轮迭代日志
    iteration_logs = state.get("iteration_logs", [])
    if iteration_logs:
        last_log = iteration_logs[-1]
        if hasattr(last_log, "termination_reason"):
            last_log.termination_reason = termination_reason

    iter_logger.log_answer(len(final_answer))

    logger.info(
        "答案生成完成: 长度=%d, 引用文档=%d, 终止原因=%s",
        len(final_answer),
        len(doc_history),
        termination_reason or "N/A",
    )

    return {
        "final_answer": final_answer,
        "should_continue": False,
    }
