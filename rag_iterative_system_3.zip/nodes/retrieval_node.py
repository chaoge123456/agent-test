# -*- coding: utf-8 -*-
"""
多路并行检索执行节点
- 对接多数据源、多索引引擎
- 支持管道式顺序检索（doc→page→chunk，前一步输出传递给后一步）
- 不同知识库的管道并行执行
- 聚合多源原始文档结果
"""

from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List

from rag_iterative_system.config.knowledge_bases import (
    RetrievalGranularity,
    get_registry,
)
from rag_iterative_system.config.system_settings import get_settings
from rag_iterative_system.state.graph_state import (
    GraphState,
    RetrievalPipeline,
    RetrievalResult,
    RetrievalToolCall,
)
from rag_iterative_system.utils.error_handler import safe_execute
from rag_iterative_system.utils.logging import get_iteration_logger

logger = logging.getLogger(__name__)


def _execute_pipeline_step(
    kb_id: str,
    step: RetrievalToolCall,
    extra_ids: Dict[str, Any],
) -> List[RetrievalResult]:
    """
    执行管道中的单个检索步骤

    Args:
        kb_id: 知识库ID
        step: 检索工具调用指令
        extra_ids: 从前一步结果中提取的doc_id/page_id列表

    Returns:
        检索结果列表
    """
    registry = get_registry()

    try:
        tool = registry.get_tool(kb_id, step.tool_name)
    except KeyError:
        logger.warning("检索工具 %s/%s 未注册，跳过", kb_id, step.tool_name)
        return []

    # 合并参数：step.params + extra_ids
    call_params = dict(step.params)
    call_params.update(extra_ids)

    # 调用检索函数
    try:
        result = safe_execute(
            tool.func,
            default=[],
            log_error=True,
            **call_params,
        )
    except Exception as e:
        logger.error(
            "检索工具 %s 调用失败: %s",
            step.tool_name, str(e)[:200],
        )
        return []

    if not result or not isinstance(result, list):
        return []

    # 将结果统一为 RetrievalResult
    retrieval_results: List[RetrievalResult] = []
    for item in result:
        if isinstance(item, RetrievalResult):
            if not item.source:
                item.source = kb_id
            retrieval_results.append(item)
        elif isinstance(item, dict):
            rr = RetrievalResult.from_dict(item, source=kb_id)
            retrieval_results.append(rr)
        else:
            # 兼容旧的Document对象
            if hasattr(item, "content"):
                rr = RetrievalResult(
                    content=item.content,
                    source=getattr(item, "source", kb_id) or kb_id,
                    score=getattr(item, "score", 0.0),
                    metadata=getattr(item, "metadata", {}),
                    doc_id=getattr(item, "doc_id", ""),
                )
                retrieval_results.append(rr)

    # 按分数排序并截断
    top_k = call_params.get("top_k", 5)
    retrieval_results.sort(key=lambda r: r.score, reverse=True)
    return retrieval_results[:top_k]


def _execute_pipeline(
    pipeline: RetrievalPipeline,
) -> List[RetrievalResult]:
    """
    执行单条检索管道（同一知识库内，doc→page→chunk顺序执行）

    前一步的输出(doc_id/page_id)自动传递给后一步

    Args:
        pipeline: 检索管道

    Returns:
        管道所有步骤的检索结果汇总
    """
    all_results: List[RetrievalResult] = []
    # 管道间传递的ID
    forwarded_ids: Dict[str, Any] = {}

    for i, step in enumerate(pipeline.steps):
        # 将前一步的结果ID注入到当前步骤的参数中
        if i > 0:
            if step.granularity == RetrievalGranularity.PAGE:
                # page级需要doc_id_list
                doc_ids = list({r.doc_id for r in all_results if r.doc_id})
                if doc_ids:
                    forwarded_ids["doc_id_list"] = doc_ids
            elif step.granularity == RetrievalGranularity.CHUNK:
                # chunk级可以需要doc_id_list和/或page_id_list
                doc_ids = list({r.doc_id for r in all_results if r.doc_id})
                page_ids = list({
                    (r.doc_id, r.page_id)
                    for r in all_results
                    if r.doc_id and r.page_id
                })
                if doc_ids:
                    forwarded_ids["doc_id_list"] = doc_ids
                if page_ids:
                    forwarded_ids["page_id_list"] = page_ids

        step_results = _execute_pipeline_step(
            kb_id=pipeline.kb_id,
            step=step,
            extra_ids=forwarded_ids,
        )

        all_results.extend(step_results)

        # 如果某一步没有结果，后续步骤可能无法继续
        if not step_results and i < len(pipeline.steps) - 1:
            logger.info(
                "管道步骤 %s 无结果，后续步骤可能受影响 (KB=%s)",
                step.tool_name, pipeline.kb_id,
            )

    logger.debug(
        "管道执行完成 (KB=%s, 步骤=%d): 总结果=%d",
        pipeline.kb_id, len(pipeline.steps), len(all_results),
    )

    return all_results


def _execute_pipelines_parallel(
    pipelines: List[RetrievalPipeline],
) -> List[RetrievalResult]:
    """并行执行多条管道（不同知识库）"""
    all_documents: List[RetrievalResult] = []

    with ThreadPoolExecutor(max_workers=min(len(pipelines), 8)) as executor:
        futures = {}
        for pipeline in pipelines:
            future = executor.submit(_execute_pipeline, pipeline)
            futures[future] = pipeline.kb_id

        for future in as_completed(futures):
            kb_id = futures[future]
            try:
                docs = future.result()
                all_documents.extend(docs)
                logger.debug("知识库 %s 管道检索完成: %d 结果", kb_id, len(docs))
            except Exception as e:
                logger.error("知识库 %s 管道检索异常: %s", kb_id, str(e)[:200])

    return all_documents


def _execute_pipelines_sequential(
    pipelines: List[RetrievalPipeline],
) -> List[RetrievalResult]:
    """串行执行多条管道（降级模式）"""
    all_documents: List[RetrievalResult] = []

    for pipeline in pipelines:
        docs = _execute_pipeline(pipeline)
        all_documents.extend(docs)

    return all_documents


def retrieval_node(state: GraphState) -> dict:
    """
    多路检索执行节点

    根据路由决策的管道列表执行检索：
    - 不同知识库的管道并行执行
    - 同一管道内按 doc→page→chunk 顺序执行
    - 前一步输出自动传递给后一步

    Args:
        state: 当前图状态

    Returns:
        状态更新字典，包含原始检索结果
    """
    settings = get_settings()
    iter_logger = get_iteration_logger()

    routing_decision = state.get("routing_decision")
    if routing_decision is None:
        logger.warning("路由决策为空，跳过检索")
        return {"raw_documents": []}

    # 获取管道列表
    pipelines = routing_decision.pipelines if hasattr(routing_decision, "pipelines") else []
    if not pipelines:
        logger.warning("检索管道为空，跳过检索")
        return {"raw_documents": []}

    # 并行执行管道（默认），失败时降级为串行
    try:
        raw_documents = _execute_pipelines_parallel(pipelines)
    except Exception as e:
        logger.error("并行检索失败，降级为串行: %s", str(e)[:200])
        raw_documents = _execute_pipelines_sequential(pipelines)

    # 限制单轮最大文档数
    if len(raw_documents) > settings.max_retrieved_docs_per_round:
        raw_documents.sort(key=lambda d: d.score, reverse=True)
        raw_documents = raw_documents[:settings.max_retrieved_docs_per_round]

    # 统计各源文档数
    by_source: Dict[str, int] = {}
    for doc in raw_documents:
        by_source[doc.source] = by_source.get(doc.source, 0) + 1

    iter_logger.log_retrieval(len(raw_documents), by_source)

    return {"raw_documents": raw_documents}
