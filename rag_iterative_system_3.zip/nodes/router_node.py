# -*- coding: utf-8 -*-
"""
智能检索路由决策节点
- 依托大模型语义决策，无硬编码规则
- 结合查询意图与知识库+工具能力选择目标知识库
- 输出管道式检索决策（RetrievalPipeline: 函数列表 + 第一个函数输入参数）
- 路由决策不仅要决定函数列表，还要为第一个函数指定完整的输入参数
- 默认知识库fallback机制
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List

from rag_iterative_system.config.knowledge_bases import (
    RetrievalGranularity,
    get_registry,
)
from rag_iterative_system.config.llm_config import get_llm
from rag_iterative_system.config.system_settings import get_settings
from rag_iterative_system.state.graph_state import (
    GraphState,
    RetrievalPipeline,
    RetrievalToolCall,
    RoutingDecision,
)
from rag_iterative_system.utils.error_handler import retry_with_backoff, RoutingError, LLMCallError
from rag_iterative_system.utils.logging import get_iteration_logger

logger = logging.getLogger(__name__)

# 路由决策系统提示词 - 管道式检索
ROUTING_SYSTEM_PROMPT = """你是一个智能检索路由专家。你需要根据用户查询的意图和语义，决定应该在哪些知识库中检索，并规划检索管道。

可用知识库及其检索工具：
{kb_descriptions}

检索管道规则：
1. 每个知识库可以规划一条检索管道，管道内函数按 doc→page→chunk 粒度顺序执行
2. 前一个函数的输出(doc_id/page_id)会自动传递给后一个函数
3. 你只需要为管道中的第一个函数指定完整输入参数(query, top_k等)
4. 如果查询明确只需要某个粒度，可以只规划单步管道
5. 首次检索建议从document粒度开始（定位文档），逐步下钻到chunk粒度
6. 需要精确答案时可以直接用chunk粒度
7. 一个查询可以路由到多个知识库，每个知识库生成独立管道
8. 不同知识库的管道并行执行

默认知识库: {default_kb}

输出JSON格式：
{{
  "pipelines": [
    {{
      "kb_id": "知识库ID",
      "steps": [
        {{
          "tool_name": "检索工具注册名",
          "granularity": "document|page|chunk",
          "params": {{
            "query": "检索查询",
            "top_k": 5
          }}
        }}
      ],
      "reasoning": "为什么选择这个管道"
    }}
  ],
  "reasoning": "整体路由决策的推理过程说明"
}}"""


def _build_fallback_pipeline(
    queries: List[str],
    state: GraphState,
) -> RoutingDecision:
    """
    降级路由：为所有已启用知识库生成默认管道

    默认管道策略：
    - 有candidate_doc_ids → page级管道
    - 有candidate_page_ids → chunk级管道
    - 否则 → chunk级管道
    """
    registry = get_registry()
    settings = get_settings()
    pipelines: List[RetrievalPipeline] = []

    # 根据已有信息推断粒度
    candidate_doc_ids = state.get("candidate_doc_ids", [])
    candidate_page_ids = state.get("candidate_page_ids", [])

    for kb in registry.list_enabled():
        tools = registry.get_all_tools(kb.kb_id)

        # 确定默认粒度和工具
        if candidate_page_ids:
            granularity = RetrievalGranularity.CHUNK
        elif candidate_doc_ids:
            granularity = RetrievalGranularity.PAGE
        else:
            granularity = RetrievalGranularity.CHUNK

        # 构建管道步骤
        steps: List[RetrievalToolCall] = []
        if tools:
            # 找到目标粒度的工具
            target_tools = [t for t in tools if t.granularity == granularity]
            if not target_tools:
                target_tools = tools  # 退而求其次

            for tool in target_tools[:1]:  # 取第一个匹配的工具
                step_params = {
                    "query": queries[0] if queries else state.get("original_query", ""),
                    "top_k": kb.top_k,
                }
                # 注入候选ID
                if granularity == RetrievalGranularity.PAGE and candidate_doc_ids:
                    step_params["doc_id_list"] = candidate_doc_ids
                elif granularity == RetrievalGranularity.CHUNK:
                    if candidate_doc_ids:
                        step_params["doc_id_list"] = candidate_doc_ids
                    if candidate_page_ids:
                        step_params["page_id_list"] = candidate_page_ids

                steps.append(RetrievalToolCall(
                    tool_name=tool.name,
                    granularity=tool.granularity,
                    params=step_params,
                ))

        pipelines.append(RetrievalPipeline(
            kb_id=kb.kb_id,
            steps=steps,
            reasoning="降级路由：默认管道",
        ))

    return RoutingDecision(pipelines=pipelines, reasoning="路由决策异常降级")


@retry_with_backoff(max_retries=2, exceptions=(RoutingError, LLMCallError))
def _call_routing_llm(prompt: str, system_prompt: str) -> RoutingDecision:
    """调用LLM执行路由决策"""
    llm = get_llm()
    try:
        result = llm.call_json(prompt, system_prompt)
    except (LLMCallError, ValueError) as e:
        raise RoutingError(f"路由LLM调用失败: {e}") from e

    registry = get_registry()

    # 解析管道列表
    pipeline_data = result.get("pipelines", [])
    reasoning = result.get("reasoning", "")

    pipelines: List[RetrievalPipeline] = []
    for pipe_info in pipeline_data:
        kb_id = pipe_info.get("kb_id", "")

        # 校验知识库已注册
        try:
            kb_config = registry.get(kb_id)
        except KeyError:
            logger.warning("路由指向未注册知识库，跳过: %s", kb_id)
            continue

        # 解析管道步骤
        steps: List[RetrievalToolCall] = []
        for step_info in pipe_info.get("steps", []):
            tool_name = step_info.get("tool_name", "")
            granularity_str = step_info.get("granularity", "chunk")
            params = step_info.get("params", {})

            # 校验工具是否已注册
            try:
                tool = registry.get_tool(kb_id, tool_name)
            except KeyError:
                # 如果工具名不匹配，按粒度查找
                granularity = RetrievalGranularity(granularity_str)
                tools_by_g = registry.get_tools_by_granularity(kb_id, granularity)
                if tools_by_g:
                    tool = tools_by_g[0]
                    tool_name = tool.name
                else:
                    logger.warning(
                        "路由指定的工具 %s 未注册且无替代，跳过", tool_name
                    )
                    continue

            steps.append(RetrievalToolCall(
                tool_name=tool_name,
                granularity=RetrievalGranularity(granularity_str),
                params=params,
            ))

        pipelines.append(RetrievalPipeline(
            kb_id=kb_id,
            steps=steps,
            reasoning=pipe_info.get("reasoning", ""),
        ))

    # 如果没有有效管道，使用默认知识库fallback
    if not pipelines:
        default_kb_id = registry.get_default_kb_id()
        if default_kb_id:
            logger.warning("路由决策无有效管道，fallback到默认知识库: %s", default_kb_id)
            # 为默认KB构建单步chunk管道
            tools = registry.get_tools_by_granularity(
                default_kb_id, RetrievalGranularity.CHUNK
            )
            try:
                default_kb_config = registry.get(default_kb_id)
                fallback_top_k = default_kb_config.top_k
            except KeyError:
                fallback_top_k = 5
            steps = []
            if tools:
                steps.append(RetrievalToolCall(
                    tool_name=tools[0].name,
                    granularity=RetrievalGranularity.CHUNK,
                    params={"query": "", "top_k": fallback_top_k},
                ))
            pipelines.append(RetrievalPipeline(
                kb_id=default_kb_id,
                steps=steps,
                reasoning="Fallback到默认知识库",
            ))

    return RoutingDecision(pipelines=pipelines, reasoning=reasoning)


def router_node(state: GraphState) -> dict:
    """
    智能路由决策节点

    根据改写后的查询列表，利用LLM决策目标知识库与检索管道。
    管道内函数按 doc→page→chunk 顺序执行，
    路由决策为第一个函数指定完整输入参数。

    Args:
        state: 当前图状态

    Returns:
        状态更新字典，包含路由决策结果
    """
    settings = get_settings()
    iter_logger = get_iteration_logger()
    registry = get_registry()

    # 获取改写查询
    rewritten_queries = state.get("rewritten_queries", [])
    if rewritten_queries and isinstance(rewritten_queries[-1], list):
        current_queries = rewritten_queries[-1]
    elif isinstance(rewritten_queries, list):
        current_queries = rewritten_queries if rewritten_queries else [state.get("original_query", "")]
    else:
        current_queries = [state.get("original_query", "")]

    original_query = state.get("original_query", "")

    # 构建知识库描述
    kb_descriptions = registry.get_descriptions_for_routing()
    if not kb_descriptions.strip():
        kb_descriptions = "（未注册任何知识库，将使用默认检索）"

    default_kb = registry.get_default_kb_id() or "无"

    system_prompt = ROUTING_SYSTEM_PROMPT.format(
        kb_descriptions=kb_descriptions,
        default_kb=default_kb,
    )

    # 构建迭代上下文（如果有候选ID，告知LLM）
    context_hints = []
    candidate_doc_ids = state.get("candidate_doc_ids", [])
    candidate_page_ids = state.get("candidate_page_ids", [])
    if candidate_doc_ids:
        context_hints.append(f"已定位 {len(candidate_doc_ids)} 篇候选文档，可选择page级检索下钻")
    if candidate_page_ids:
        context_hints.append(f"已定位 {len(candidate_page_ids)} 个候选页面，可选择chunk级检索下钻")

    context_str = "\n".join(context_hints) if context_hints else "无"

    user_prompt = (
        f"原始查询: {original_query}\n"
        f"当前改写查询: {json.dumps(current_queries, ensure_ascii=False)}\n"
        f"已有检索上下文: {context_str}\n\n"
        f"请进行路由决策，规划检索管道。"
    )

    try:
        routing_decision = _call_routing_llm(user_prompt, system_prompt)
    except Exception as e:
        logger.error("路由决策失败，使用降级策略: %s", str(e)[:200])
        routing_decision = _build_fallback_pipeline(current_queries, state)

    # 后处理：如果管道步骤的params.query为空，用当前改写查询填充
    for pipeline in routing_decision.pipelines:
        for step in pipeline.steps:
            if not step.params.get("query"):
                step.params["query"] = current_queries[0] if current_queries else original_query
            # 确保top_k有值
            if "top_k" not in step.params:
                try:
                    kb_config = registry.get(pipeline.kb_id)
                    step.params["top_k"] = kb_config.top_k
                except KeyError:
                    step.params["top_k"] = settings.default_top_k

            # 注入候选ID（如果步骤粒度需要且尚未指定）
            if step.granularity == RetrievalGranularity.PAGE and candidate_doc_ids:
                step.params.setdefault("doc_id_list", candidate_doc_ids)
            elif step.granularity == RetrievalGranularity.CHUNK:
                if candidate_doc_ids:
                    step.params.setdefault("doc_id_list", candidate_doc_ids)
                if candidate_page_ids:
                    step.params.setdefault("page_id_list", candidate_page_ids)

    iter_logger.log_routing(
        routing_decision.targets,
        routing_decision.reasoning,
    )

    return {
        "routing_decision": routing_decision,
    }
