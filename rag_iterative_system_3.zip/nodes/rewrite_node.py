# -*- coding: utf-8 -*-
"""
查询改写与意图拓展核心节点
- 基于LLM优化、拆解、拓展原始查询
- 生成多维度检索问句
- 结合迭代轮次与历史检索失败信息优化策略
- 增加管道/累加器上下文信息
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List

from rag_iterative_system.config.llm_config import get_llm
from rag_iterative_system.config.system_settings import get_settings
from rag_iterative_system.state.graph_state import GraphState
from rag_iterative_system.utils.error_handler import retry_with_backoff, LLMCallError
from rag_iterative_system.utils.logging import get_iteration_logger

logger = logging.getLogger(__name__)

# 系统提示词：查询改写
REWRITE_SYSTEM_PROMPT = """你是一个专业的查询改写专家。你的任务是优化用户的原始查询，使其更适合信息检索。

改写策略：
1. 语义优化：补全隐含信息，消除歧义，使查询更加明确具体
2. 问题拆解：将复杂问题拆分为多个子问题，分别检索
3. 关键词拓展：补充同义词、相关术语、专业术语
4. 视角转换：从不同角度生成查询变体

输出要求：
- 返回JSON格式：{"rewrites": ["改写查询1", "改写查询2", ...]}
- 每条改写查询应聚焦不同的检索角度
- 保留原始查询的核心语义
- 首轮改写侧重全面覆盖，后续轮次侧重补充缺失信息"""

REWRITE_SYSTEM_PROMPT_ITERATIVE = """你是一个专业的查询改写专家。当前处于迭代检索的后续轮次，之前的检索未能完全满足信息需求。

改写策略：
1. 针对性补充：根据历史检索缺失信息，生成针对性查询
2. 换角度检索：从不同视角、不同术语重新描述需求
3. 细化聚焦：针对未覆盖的子问题深入检索
4. 降维简化：简化过于复杂的查询，提高召回率
5. 粒度感知：根据已有信息决定是否需要更粗粒度（文档级定位）或更细粒度（chunk级提取）的查询

历史检索上下文：
{iteration_context}

输出要求：
- 返回JSON格式：{{"rewrites": ["改写查询1", "改写查询2", ...]}}
- 侧重补充之前未检索到的信息
- 避免与已有改写查询重复"""


@retry_with_backoff(max_retries=2, exceptions=(LLMCallError,))
def _call_rewrite_llm(prompt: str, system_prompt: str) -> List[str]:
    """调用LLM执行查询改写"""
    llm = get_llm()
    result = llm.call_json(prompt, system_prompt)
    rewrites = result.get("rewrites", [])
    if not rewrites:
        logger.warning("LLM查询改写返回空列表，使用原始查询")
        return []
    return rewrites


def _build_iteration_context(state: Any) -> str:
    """构建迭代上下文信息供后续轮次改写参考"""
    parts: List[str] = []

    iteration = state.get("iteration_count", 0)
    parts.append(f"当前迭代轮次: {iteration}")

    # 已有改写查询
    existing_queries = state.get("rewritten_queries", [])
    if existing_queries:
        flat_queries = []
        for q_group in existing_queries:
            if isinstance(q_group, list):
                flat_queries.extend(q_group)
            else:
                flat_queries.append(q_group)
        if flat_queries:
            parts.append("已有改写查询: " + "; ".join(str(q)[:50] for q in flat_queries[:10]))

    # 已检索文档摘要
    doc_history = state.get("document_history", [])
    if doc_history:
        parts.append(f"已检索到 {len(doc_history)} 个相关文档")

    # 高置信度累加器信息
    accumulator = state.get("confidence_accumulator")
    if accumulator and hasattr(accumulator, "results") and accumulator.results:
        parts.append(f"高置信度结果: {len(accumulator.results)} 个")

    # 上轮信息增益
    gain = state.get("information_gain", 0.0)
    if gain > 0:
        parts.append(f"上轮信息增益: {gain:.4f}")

    # 候选文档/页面数
    candidate_doc_ids = state.get("candidate_doc_ids", [])
    candidate_page_ids = state.get("candidate_page_ids", [])
    if candidate_doc_ids:
        parts.append(f"已定位 {len(candidate_doc_ids)} 篇候选文档")
    if candidate_page_ids:
        parts.append(f"已定位 {len(candidate_page_ids)} 个候选页面")

    return "\n".join(parts)


def rewrite_node(state: GraphState) -> dict:
    """
    查询改写节点

    根据迭代轮次选择改写策略：
    - 首轮：全面覆盖式改写
    - 后续轮次：针对缺失信息的补充式改写

    Args:
        state: 当前图状态

    Returns:
        状态更新字典
    """
    settings = get_settings()
    iter_logger = get_iteration_logger()
    iteration = state.get("iteration_count", 0)
    iter_logger.set_iteration(iteration + 1)

    original_query = state.get("original_query", "")

    # 首轮 vs 后续轮次使用不同提示词
    if iteration == 0:
        system_prompt = REWRITE_SYSTEM_PROMPT
        user_prompt = f"请改写以下查询，生成{settings.max_rewrite_queries}条不同角度的检索查询：\n\n原始查询: {original_query}"
    else:
        iteration_context = _build_iteration_context(state)
        system_prompt = REWRITE_SYSTEM_PROMPT_ITERATIVE.format(
            iteration_context=iteration_context
        )
        user_prompt = (
            f"请根据迭代上下文，改写以下查询以补充缺失信息：\n\n"
            f"原始查询: {original_query}\n\n"
            f"生成{settings.max_rewrite_queries}条针对性改写查询。"
        )

    try:
        rewrites = _call_rewrite_llm(user_prompt, system_prompt)
    except Exception as e:
        logger.error("查询改写失败，降级使用原始查询: %s", str(e)[:200])
        rewrites = [original_query]

    # 确保原始查询始终在检索列表中
    if original_query not in rewrites:
        rewrites.insert(0, original_query)

    # 限制改写查询数量
    rewrites = rewrites[: settings.max_rewrite_queries + 1]

    iter_logger.log_rewrite(rewrites, original_query)

    return {
        "rewritten_queries": rewrites,
        "iteration_count": iteration + 1,
    }
