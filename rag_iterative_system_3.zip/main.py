# -*- coding: utf-8 -*-
"""
项目入口、示例调用、流程测试
- 展示新的3级检索工具注册模式
- 默认知识库概念
- 迭代式检索开关
"""

from __future__ import annotations

import logging
import sys
from typing import Any, Dict, List

from rag_iterative_system.config.knowledge_bases import (
    KnowledgeBaseRegistry,
    RetrievalGranularity,
    RetrievalMode,
    get_registry,
    register_knowledge_base,
    register_retrieval_tool,
)
from rag_iterative_system.config.llm_config import LLMAdapter
from rag_iterative_system.config.system_settings import SystemSettings, get_settings, set_settings
from rag_iterative_system.graph.rag_graph import compile_rag_graph, run_rag_query
from rag_iterative_system.state.graph_state import RetrievalResult
from rag_iterative_system.utils.logging import setup_logging

logger = logging.getLogger(__name__)


# ============================================================
# 示例：三级检索函数（document/page/chunk）
# ============================================================

def mock_document_retrieval(
    query: str,
    top_k: int = 5,
    score_threshold: float = 0.3,
    **kwargs: Any,
) -> List[Dict[str, Any]]:
    """
    文档级检索函数

    返回格式: doc_id + 文档摘要, page_id/chunk_id为空
    """
    mock_docs = [
        {
            "doc_id": f"doc_{hash(query) % 100}_1",
            "page_id": "",
            "chunk_id": "",
            "content": f"关于'{query}'的文档概述。本文档涵盖核心技术概念、实现方案与最佳实践。",
            "score": 0.85,
            "source": "",
        },
        {
            "doc_id": f"doc_{hash(query) % 100}_2",
            "page_id": "",
            "chunk_id": "",
            "content": f"'{query}'的常见问题与使用指南汇总。",
            "score": 0.72,
            "source": "",
        },
    ]
    return [doc for doc in mock_docs if doc["score"] >= score_threshold][:top_k]


def mock_page_retrieval(
    query: str,
    top_k: int = 5,
    doc_id_list: List[str] | None = None,
    score_threshold: float = 0.3,
    **kwargs: Any,
) -> List[Dict[str, Any]]:
    """
    页面级检索函数

    输入: query, top_k, doc_id_list(可选)
    返回格式: doc_id + page_id + 页面摘要, chunk_id为空
    """
    # 如果有doc_id_list，在该文档范围内检索
    base_docs = doc_id_list or ["doc_default"]
    mock_pages = []
    for i, doc_id in enumerate(base_docs[:3]):
        mock_pages.append({
            "doc_id": doc_id,
            "page_id": f"p{i+1}",
            "chunk_id": "",
            "content": f"文档{doc_id}第{i+1}页: 关于'{query}'的详细说明，涵盖关键实现细节。",
            "score": 0.80 - i * 0.05,
            "source": "",
        })
    return [p for p in mock_pages if p["score"] >= score_threshold][:top_k]


def mock_chunk_retrieval(
    query: str,
    top_k: int = 5,
    doc_id_list: List[str] | None = None,
    page_id_list: List[Any] | None = None,
    score_threshold: float = 0.3,
    **kwargs: Any,
) -> List[Dict[str, Any]]:
    """
    chunk级检索函数

    输入: query, top_k, doc_id_list(可选), page_id_list(可选)
    返回格式: doc_id + page_id + chunk_id + chunk内容
    """
    base_pages = page_id_list or [("doc_default", "p1")]
    mock_chunks = []
    for i, page_info in enumerate(base_pages[:3]):
        if isinstance(page_info, (list, tuple)) and len(page_info) >= 2:
            doc_id, page_id = page_info[0], page_info[1]
        else:
            doc_id = str(page_info)
            page_id = "p1"
        mock_chunks.append({
            "doc_id": doc_id,
            "page_id": page_id,
            "chunk_id": f"c{i+1}",
            "content": f"文档{doc_id}页面{page_id}片段{i+1}: '{query}'的具体技术细节和实现方案。",
            "score": 0.90 - i * 0.08,
            "source": "",
        })
    return [c for c in mock_chunks if c["score"] >= score_threshold][:top_k]


# ============================================================
# 旧版兼容：模拟单函数检索
# ============================================================

def mock_retrieval_func(
    query: str,
    top_k: int = 5,
    score_threshold: float = 0.3,
    retrieval_mode: str = "vector",
    **kwargs: Any,
) -> List[Dict[str, Any]]:
    """旧版模拟检索函数（向后兼容）"""
    mock_docs = [
        {
            "content": f"关于'{query}'的详细说明文档。本知识库包含相关领域的专业技术资料。",
            "score": 0.85,
            "metadata": {"category": "technical", "version": "1.0"},
            "doc_id": f"mock_doc_{hash(query) % 1000}_1",
        },
        {
            "content": f"'{query}'的常见问题解答与使用指南。",
            "score": 0.72,
            "metadata": {"category": "faq", "version": "2.0"},
            "doc_id": f"mock_doc_{hash(query) % 1000}_2",
        },
    ]
    return [doc for doc in mock_docs if doc["score"] >= score_threshold][:top_k]


def demo_setup_new() -> None:
    """演示新版3级工具注册模式"""

    # 1. 配置系统参数（迭代式检索默认关闭）
    settings = SystemSettings(
        max_iterations=3,
        min_information_gain=0.05,
        enable_iterative_retrieval=False,  # 默认关闭
        default_top_k=5,
        llm_model="gpt-4o",
        llm_api_base="https://api.openai.com/v1",
        llm_api_key="sk-your-api-key-here",
        log_level="INFO",
    )
    set_settings(settings)

    # 2. 初始化日志
    setup_logging(level=settings.log_level)

    # 3. 初始化LLM适配器
    LLMAdapter.initialize(
        model_name=settings.llm_model,
        api_base=settings.llm_api_base,
        api_key=settings.llm_api_key,
        temperature=settings.llm_temperature,
        max_tokens=settings.llm_max_tokens,
        timeout=settings.llm_timeout,
    )

    # 4. 注册知识库 + 3级检索工具
    register_knowledge_base(
        kb_id="tech_docs",
        name="技术文档库",
        description="包含系统架构、API文档、技术规范等技术资料",
        domains=["技术", "架构", "API", "开发"],
        retrieval_mode=RetrievalMode.VECTOR,
        top_k=5,
        is_default=True,  # 设为默认知识库
    )

    # 注册document级检索工具
    register_retrieval_tool(
        kb_id="tech_docs",
        tool_name="tech_docs__document",
        granularity=RetrievalGranularity.DOCUMENT,
        func=mock_document_retrieval,
        description="技术文档库的文档级检索，返回文档摘要",
        input_schema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "检索查询"},
                "top_k": {"type": "integer", "description": "返回数量"},
            },
            "required": ["query"],
        },
        output_schema={
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "doc_id": {"type": "string"},
                    "content": {"type": "string", "description": "文档摘要"},
                },
            },
        },
        scenario="需要定位相关文档时使用",
    )

    # 注册page级检索工具
    register_retrieval_tool(
        kb_id="tech_docs",
        tool_name="tech_docs__page",
        granularity=RetrievalGranularity.PAGE,
        func=mock_page_retrieval,
        description="技术文档库的页面级检索，返回页面摘要",
        input_schema={
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "top_k": {"type": "integer"},
                "doc_id_list": {"type": "array", "items": {"type": "string"}, "description": "限定文档范围"},
            },
            "required": ["query"],
        },
        scenario="已定位文档后，需要在文档内定位页面时使用",
    )

    # 注册chunk级检索工具
    register_retrieval_tool(
        kb_id="tech_docs",
        tool_name="tech_docs__chunk",
        granularity=RetrievalGranularity.CHUNK,
        func=mock_chunk_retrieval,
        description="技术文档库的chunk级检索，返回具体内容片段",
        input_schema={
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "top_k": {"type": "integer"},
                "doc_id_list": {"type": "array", "items": {"type": "string"}},
                "page_id_list": {"type": "array", "items": {"type": "array"}, "description": "限定页面范围"},
            },
            "required": ["query"],
        },
        scenario="需要精确答案或具体内容片段时使用",
    )

    # 校验三级工具注册完整性
    registry = get_registry()
    missing = registry.validate_kb_tools("tech_docs")
    if missing:
        logger.warning("知识库 tech_docs 缺少粒度: %s", missing)
    else:
        logger.info("知识库 tech_docs 三级检索工具注册完整")

    # 5. 注册第二个知识库（非默认）
    register_knowledge_base(
        kb_id="faq_kb",
        name="常见问题库",
        description="产品常见问题、使用指南、故障排除等FAQ文档",
        domains=["FAQ", "使用指南", "故障排除", "产品"],
        retrieval_mode=RetrievalMode.HYBRID,
        top_k=3,
    )

    register_retrieval_tool(
        kb_id="faq_kb",
        tool_name="faq_kb__document",
        granularity=RetrievalGranularity.DOCUMENT,
        func=mock_document_retrieval,
        description="FAQ库的文档级检索",
        scenario="需要定位FAQ文档时使用",
    )
    register_retrieval_tool(
        kb_id="faq_kb",
        tool_name="faq_kb__page",
        granularity=RetrievalGranularity.PAGE,
        func=mock_page_retrieval,
        description="FAQ库的页面级检索",
        scenario="已定位FAQ文档后需要定位页面",
    )
    register_retrieval_tool(
        kb_id="faq_kb",
        tool_name="faq_kb__chunk",
        granularity=RetrievalGranularity.CHUNK,
        func=mock_chunk_retrieval,
        description="FAQ库的chunk级检索",
        scenario="需要FAQ的具体答案",
    )

    logger.info("演示环境初始化完成")


def main() -> None:
    """主入口函数"""
    demo_setup_new()

    # 编译图
    compiled_graph = compile_rag_graph()

    # 执行查询
    query = "如何设计一个高可用的分布式系统架构？"
    logger.info("=" * 60)
    logger.info("执行查询: %s", query)
    logger.info("=" * 60)

    result = run_rag_query(query, compiled_graph)

    # 输出结果
    print("\n" + "=" * 60)
    print("查询结果")
    print("=" * 60)
    print(f"\n原始问题: {result.get('original_query', '')}")
    print(f"迭代轮次: {result.get('iteration_count', 0)}")
    print(f"终止原因: {result.get('termination_reason', 'N/A')}")

    # 高置信度结果
    accumulator = result.get("confidence_accumulator")
    if accumulator and hasattr(accumulator, "results"):
        print(f"高置信度结果数: {len(accumulator.results)}")

    print(f"历史文档数: {len(result.get('document_history', []))}")
    print(f"\n最终答案:\n{result.get('final_answer', '无答案')}")

    # 输出迭代日志
    iteration_logs = result.get("iteration_logs", [])
    if iteration_logs:
        print(f"\n迭代过程日志 ({len(iteration_logs)} 轮):")
        for log in iteration_logs:
            if hasattr(log, "iteration"):
                print(
                    f"  轮次{log.iteration}: "
                    f"检索{log.retrieved_count}文档, "
                    f"过滤后{log.filtered_count}, "
                    f"增益={log.information_gain:.4f}"
                )


if __name__ == "__main__":
    main()
