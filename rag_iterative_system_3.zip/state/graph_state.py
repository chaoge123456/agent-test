# -*- coding: utf-8 -*-
"""
LangGraph全局状态结构化定义
- 基于TypedDict的类型约束
- 使用Annotated支持状态累积（operator.add）
- 全流程数据集中管理
- 层次化检索结果结构（RetrievalResult: doc_id/page_id/chunk_id）
- 管道式检索结构（RetrievalPipeline: 函数列表 + 顺序执行 + 前后传递）
- 高置信度结果累加器（ConfidenceAccumulator）
"""

from __future__ import annotations

import operator
from dataclasses import dataclass, field
from enum import Enum
from typing import Annotated, Any, Dict, List, Optional

from typing_extensions import TypedDict

# 从 knowledge_bases 导入统一的 RetrievalGranularity，避免重复定义
from rag_iterative_system.config.knowledge_bases import RetrievalGranularity as _RetrievalGranularity

# 重新导出，供其他模块使用
RetrievalGranularity = _RetrievalGranularity


# ============================================================
# 核心数据结构
# ============================================================

@dataclass
class RetrievalResult:
    """
    统一检索结果结构

    层次化返回格式:
    - 文档级: content=文档摘要, page_id/chunk_id为空
    - 页面级: content=页面摘要, chunk_id为空
    - chunk级: content=chunk内容
    """
    doc_id: str = ""                                        # 文档唯一标识
    page_id: str = ""                                       # 页面标识（文档级为空）
    chunk_id: str = ""                                      # chunk标识（文档/页面级为空）
    content: str = ""                                       # 内容（随粒度变化）
    source: str = ""                                        # 来源知识库ID
    score: float = 0.0                                      # 相似度/reranker分数
    metadata: Dict[str, Any] = field(default_factory=dict)  # 元数据

    @property
    def granularity(self) -> RetrievalGranularity:
        """根据ID字段自动推断粒度"""
        if self.chunk_id:
            return RetrievalGranularity.CHUNK
        if self.page_id:
            return RetrievalGranularity.PAGE
        return RetrievalGranularity.DOCUMENT

    def to_dict(self) -> Dict[str, Any]:
        """序列化为字典"""
        return {
            "doc_id": self.doc_id,
            "page_id": self.page_id,
            "chunk_id": self.chunk_id,
            "content": self.content,
            "source": self.source,
            "score": self.score,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any], source: str = "") -> "RetrievalResult":
        """从字典反序列化"""
        return cls(
            doc_id=str(data.get("doc_id", "")),
            page_id=str(data.get("page_id", "")),
            chunk_id=str(data.get("chunk_id", "")),
            content=data.get("content", ""),
            source=data.get("source", source),
            score=float(data.get("score", 0.0)),
            metadata=data.get("metadata", {}),
        )


@dataclass
class RetrievalToolCall:
    """
    管道中单个检索函数的调用指令

    包含: 工具名称、输入参数、预期粒度
    """
    tool_name: str                                          # 检索函数注册名
    granularity: RetrievalGranularity = RetrievalGranularity.CHUNK
    params: Dict[str, Any] = field(default_factory=dict)    # 该函数的完整输入参数


@dataclass
class RetrievalPipeline:
    """
    检索管道：一个知识库内的有序检索函数列表

    管道内函数按 doc→page→chunk 顺序执行，
    前一个函数的输出(doc_id/page_id)自动传递给后一个函数
    """
    kb_id: str                                              # 所属知识库ID
    steps: List[RetrievalToolCall] = field(default_factory=list)  # 有序检索步骤
    reasoning: str = ""                                     # 路由推理说明

    @property
    def first_step(self) -> Optional[RetrievalToolCall]:
        """获取管道第一个步骤"""
        return self.steps[0] if self.steps else None

    @property
    def is_empty(self) -> bool:
        return len(self.steps) == 0


@dataclass
class RoutingDecision:
    """
    路由决策结果

    变更: targets 现在是 RetrievalPipeline 列表（每个pipeline绑定一个KB）
    每个pipeline内含有序检索函数列表 + 第一个函数的输入参数
    """
    pipelines: List[RetrievalPipeline] = field(default_factory=list)
    reasoning: str = ""

    # 向后兼容：保留 targets 属性访问
    @property
    def targets(self) -> List[Dict[str, Any]]:
        """兼容旧代码的 targets 访问，将 pipelines 序列化"""
        result = []
        for pipeline in self.pipelines:
            target: Dict[str, Any] = {
                "kb_id": pipeline.kb_id,
                "pipeline_steps": [
                    {
                        "tool_name": step.tool_name,
                        "granularity": step.granularity.value,
                        "params": step.params,
                    }
                    for step in pipeline.steps
                ],
            }
            result.append(target)
        return result


@dataclass
class ConfidenceAccumulator:
    """
    高置信度结果累加器

    保存置信度较高的检索结果（保留上下文），
    用于生成答案时利用这些结果。

    筛选策略: reranker得分 + 信息增益双重筛选
    """
    results: List[RetrievalResult] = field(default_factory=list)
    confidence_threshold: float = 0.6                       # reranker得分阈值
    min_novelty: float = 0.1                                # 最小新颖度（信息增益）

    def add_results(
        self,
        new_results: List[RetrievalResult],
        existing_results: Optional[List[RetrievalResult]] = None,
    ) -> List[RetrievalResult]:
        """
        添加高置信度结果

        Args:
            new_results: 本轮检索结果
            existing_results: 已有累积结果（用于信息增益计算）

        Returns:
            本轮新增的高置信度结果列表
        """
        from rag_iterative_system.evaluation.metrics import compute_novelty_for_result

        accepted: List[RetrievalResult] = []
        baseline = existing_results or self.results

        for result in new_results:
            # 条件1: reranker得分高于阈值
            if result.score < self.confidence_threshold:
                continue

            # 条件2: 对已有结果有新增信息量
            if baseline:
                novelty = compute_novelty_for_result(result, baseline)
                if novelty < self.min_novelty:
                    continue

            # 去重：同 doc_id+page_id+chunk_id 不重复添加
            key = (result.doc_id, result.page_id, result.chunk_id)
            if any(
                (r.doc_id, r.page_id, r.chunk_id) == key
                for r in self.results
            ):
                continue

            self.results.append(result)
            accepted.append(result)

        return accepted

    def get_all(self) -> List[RetrievalResult]:
        """获取所有累积的高置信度结果"""
        return list(self.results)

    def clear(self) -> None:
        """清空累加器"""
        self.results.clear()


@dataclass
class IterationLog:
    """单轮迭代日志"""
    iteration: int                                          # 当前轮次
    rewritten_queries: List[str] = field(default_factory=list)
    routing_decision: str = ""                              # 路由决策摘要
    retrieved_count: int = 0                                # 检索文档数
    filtered_count: int = 0                                 # 过滤后文档数
    information_gain: float = 0.0                           # 信息增益分数
    termination_reason: str = ""                            # 终止原因（仅最后一轮）


# ============================================================
# 向后兼容别名
# ============================================================

# Document 保留为 RetrievalResult 的别名，兼容旧代码
Document = RetrievalResult


# ============================================================
# 全局状态定义
# ============================================================

class GraphState(TypedDict, total=False):
    """
    LangGraph全局状态定义

    字段说明:
    - 带 Annotated[..., operator.add] 的字段在每轮迭代中累积追加
    - 不带 Annotated 的字段每轮覆盖更新
    """
    # ---- 原始输入 ----
    original_query: str                                     # 用户原始查询

    # ---- 迭代控制 ----
    iteration_count: int                                    # 当前迭代轮次
    should_continue: bool                                   # 是否继续迭代

    # ---- 查询改写 ----
    rewritten_queries: Annotated[list, operator.add]        # 所有改写查询（累积）

    # ---- 路由决策 ----
    routing_decision: RoutingDecision                       # 当前轮路由决策（含管道列表）

    # ---- 检索结果 ----
    raw_documents: Annotated[list, operator.add]            # 原始检索结果（累积，RetrievalResult列表）
    filtered_documents: List[RetrievalResult]               # 当前轮过滤后结果

    # ---- 历史快照 ----
    document_history: List[RetrievalResult]                 # 全量历史优质结果（去重后）
    previous_gain_scores: Annotated[list, operator.add]     # 历史信息增益分数（累积）

    # ---- 高置信度累加器 ----
    confidence_accumulator: ConfidenceAccumulator            # 高置信度结果累加器

    # ---- 漏斗下钻候选ID ----
    candidate_doc_ids: List[str]                             # 候选文档ID列表（供page级检索）
    candidate_page_ids: List[Any]                            # 候选页面ID列表（供chunk级检索）

    # ---- 评估指标 ----
    information_gain: float                                 # 当前轮信息增益

    # ---- 终止判定 ----
    termination_reason: str                                 # 终止原因描述
    no_gain_rounds: int                                     # 连续无增益轮次计数

    # ---- 最终输出 ----
    final_answer: str                                       # 最终生成答案

    # ---- 运行日志 ----
    iteration_logs: Annotated[list, operator.add]           # 全流程迭代日志（累积）


def create_initial_state(query: str) -> dict:
    """
    创建初始状态

    Args:
        query: 用户原始查询

    Returns:
        初始化的状态字典
    """
    return {
        "original_query": query,
        "iteration_count": 0,
        "should_continue": True,
        "rewritten_queries": [],
        "routing_decision": RoutingDecision(),
        "raw_documents": [],
        "filtered_documents": [],
        "document_history": [],
        "previous_gain_scores": [],
        "confidence_accumulator": ConfidenceAccumulator(),
        "candidate_doc_ids": [],
        "candidate_page_ids": [],
        "information_gain": 0.0,
        "termination_reason": "",
        "no_gain_rounds": 0,
        "final_answer": "",
        "iteration_logs": [],
    }
