# -*- coding: utf-8 -*-
"""
查询改写与意图拓展核心节点
- 基于LLM优化、拆解、拓展原始查询
- 生成多维度检索问句
- 结合迭代轮次与历史检索失败信息优化策略
- 增加管道/累加器上下文信息
- 【需求1】条件性查询拆解：根据已有信息和历史查询判断是否需要拆解
- 【需求2】结合高置信度检索结果辅助查询改写方向
- 【需求3】读取终止节点的继续迭代原因，指导改写方向
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any, Dict, List

from rag_iterative_system.config.llm_config import get_llm
from rag_iterative_system.config.system_settings import get_settings
from rag_iterative_system.state.graph_state import (
    GraphState,
    RetrievalNodeInfo,
    RetrievalResult,
)
from rag_iterative_system.utils.error_handler import retry_with_backoff, LLMCallError
from rag_iterative_system.utils.logging import get_iteration_logger

logger = logging.getLogger(__name__)

# ============================================================
# Prompt: 判断是否需要拆解查询（需求1）
# ============================================================

DECOMPOSITION_JUDGMENT_PROMPT = """你是一个查询分析专家。你需要判断当前查询是否需要拆解为多个子查询。

判断原则：
1. 如果查询是一个简单、单一维度的问题，不需要拆解，直接进行语义优化即可
2. 如果查询明显包含多个独立子问题、需要跨领域检索、或涉及多个不同维度，则需要拆解
3. 如果已有检索结果已经部分覆盖了查询诉求，且剩余未覆盖部分是单一维度的，不需要拆解
4. 如果之前的检索已经覆盖了查询的某些方面，只需要针对未覆盖的特定方面深入检索，不需要拆解

已有检索上下文：
{retrieval_context}

输出JSON格式：
{{"need_decomposition": true/false, "reason": "判断原因说明"}}"""


# ============================================================
# Prompt: 首轮改写（条件性拆解，不再强制拆解）
# ============================================================

REWRITE_SYSTEM_PROMPT = """你是一个专业的查询改写专家。你的任务是优化用户的原始查询，使其更适合信息检索。

改写策略（根据判断结果选择）：

**如果不需要拆解（need_decomposition=false）：**
1. 语义优化：补全隐含信息，消除歧义，使查询更加明确具体
2. 关键词拓展：补充同义词、相关术语、专业术语
3. 视角转换：从不同角度生成查询变体
4. 输出1-2条优化后的查询即可，保持聚焦

**如果需要拆解（need_decomposition=true）：**
1. 问题拆解：将复杂问题拆分为多个子问题，分别检索
2. 每条子查询聚焦一个独立维度
3. 关键词拓展：为每个子查询补充专业术语
4. 输出多条改写查询，覆盖不同检索角度

输出要求：
- 返回JSON格式：{{"rewrites": ["改写查询1", "改写查询2", ...]}}
- 保留原始查询的核心语义
- 不需要拆解时，1-2条高质量改写即可
- 需要拆解时，每条改写查询应聚焦不同的检索维度"""


# ============================================================
# Prompt: 后续轮次改写（结合高置信度检索结果 + 继续迭代原因）
# ============================================================

REWRITE_SYSTEM_PROMPT_ITERATIVE = """你是一个专业的查询改写专家。当前处于迭代检索的后续轮次，之前的检索未能完全满足信息需求。

改写策略：
1. 针对性补充：根据历史检索缺失信息，生成针对性查询
2. 换角度检索：从不同视角、不同术语重新描述需求
3. 细化聚焦：针对未覆盖的子问题深入检索
4. 降维简化：简化过于复杂的查询，提高召回率
5. 粒度感知：根据已有信息决定是否需要更粗粒度（文档级定位）或更细粒度（chunk级提取）的查询

**【重要】已检索到的高置信度结果摘要（请参考这些信息指导改写方向）：**
{high_confidence_context}

**【重要】继续迭代原因（请针对以下未覆盖方面重点改写）：**
{continue_reason}

历史检索上下文：
{iteration_context}

输出要求：
- 返回JSON格式：{{"rewrites": ["改写查询1", "改写查询2", ...]}}
- 侧重补充之前未检索到的信息
- 避免与已有改写查询重复
- 参考高置信度结果中的信息，优化查询的精确性和方向性
- 重点针对「继续迭代原因」中指出的不足进行改写"""


# ============================================================
# Prompt: 判断是否需要拆解查询（后续轮次）
# ============================================================

DECOMPOSITION_JUDGMENT_ITERATIVE_PROMPT = """你是一个查询分析专家。当前处于迭代检索的后续轮次，你需要判断本轮是否需要将查询拆解为多个子查询。

判断原则：
1. 如果剩余未覆盖的信息是单一维度的，不需要拆解，只需要针对性优化即可
2. 如果剩余未覆盖的信息涉及多个独立方面，则需要拆解
3. 如果已有检索结果已覆盖大部分查询诉求，只需微调查询方向，不需要拆解

已有检索上下文：
{retrieval_context}

继续迭代原因（说明还有哪些信息未覆盖）：
{continue_reason}

输出JSON格式：
{{"need_decomposition": true/false, "reason": "判断原因说明"}}"""


@retry_with_backoff(max_retries=2, exceptions=(LLMCallError,))
def _call_rewrite_llm(prompt: str, system_prompt: str) -> List[str]:
    """调用LLM执行查询改写"""
    llm = get_llm()
    result = llm.call_json(prompt, system_prompt)
    rewrites = result.get("rewrites", [])
    if not rewrites:
        logger.warning("LLM查询改写返回空列表，使用原始查询")
        return []
    return rewrites


@retry_with_backoff(max_retries=2, exceptions=(LLMCallError,))
def _call_decomposition_judgment(prompt: str, system_prompt: str) -> Dict[str, Any]:
    """调用LLM判断是否需要拆解查询"""
    llm = get_llm()
    result = llm.call_json(prompt, system_prompt)
    need = result.get("need_decomposition", True)
    reason = result.get("reason", "")
    return {"need_decomposition": bool(need), "reason": str(reason)}


def _build_retrieval_context(state: Any) -> str:
    """构建已有检索上下文，供判断是否需要拆解使用"""
    parts: List[str] = []

    # 已有改写查询
    existing_queries = state.get("rewritten_queries", [])
    if existing_queries:
        flat_queries = []
        for q_group in existing_queries:
            if isinstance(q_group, list):
                flat_queries.extend(q_group)
            else:
                flat_queries.append(q_group)
        if flat_queries:
            parts.append("已有改写查询: " + "; ".join(str(q)[:50] for q in flat_queries[:10]))

    # 已检索文档数量
    doc_history = state.get("document_history", [])
    if doc_history:
        parts.append(f"已检索到 {len(doc_history)} 个相关文档")

    # 高置信度结果摘要
    accumulator = state.get("confidence_accumulator")
    if accumulator and hasattr(accumulator, "results") and accumulator.results:
        parts.append(f"高置信度结果: {len(accumulator.results)} 个")

    # 上轮信息增益
    gain = state.get("information_gain", 0.0)
    if gain > 0:
        parts.append(f"上轮信息增益: {gain:.4f}")

    # 候选文档/页面数
    candidate_doc_ids = state.get("candidate_doc_ids", [])
    candidate_page_ids = state.get("candidate_page_ids", [])
    if candidate_doc_ids:
        parts.append(f"已定位 {len(candidate_doc_ids)} 篇候选文档")
    if candidate_page_ids:
        parts.append(f"已定位 {len(candidate_page_ids)} 个候选页面")

    return "\n".join(parts) if parts else "暂无检索结果"


def _build_iteration_context(state: Any) -> str:
    """构建迭代上下文信息供后续轮次改写参考"""
    parts: List[str] = []

    iteration = state.get("iteration_count", 0)
    parts.append(f"当前迭代轮次: {iteration}")

    # 已有改写查询
    existing_queries = state.get("rewritten_queries", [])
    if existing_queries:
        flat_queries = []
        for q_group in existing_queries:
            if isinstance(q_group, list):
                flat_queries.extend(q_group)
            else:
                flat_queries.append(q_group)
        if flat_queries:
            parts.append("已有改写查询: " + "; ".join(str(q)[:50] for q in flat_queries[:10]))

    # 已检索文档摘要
    doc_history = state.get("document_history", [])
    if doc_history:
        parts.append(f"已检索到 {len(doc_history)} 个相关文档")

    # 高置信度累加器信息
    accumulator = state.get("confidence_accumulator")
    if accumulator and hasattr(accumulator, "results") and accumulator.results:
        parts.append(f"高置信度结果: {len(accumulator.results)} 个")

    # 上轮信息增益
    gain = state.get("information_gain", 0.0)
    if gain > 0:
        parts.append(f"上轮信息增益: {gain:.4f}")

    # 候选文档/页面数
    candidate_doc_ids = state.get("candidate_doc_ids", [])
    candidate_page_ids = state.get("candidate_page_ids", [])
    if candidate_doc_ids:
        parts.append(f"已定位 {len(candidate_doc_ids)} 篇候选文档")
    if candidate_page_ids:
        parts.append(f"已定位 {len(candidate_page_ids)} 个候选页面")

    return "\n".join(parts)


def _build_high_confidence_context(
    state: Any, max_items: int = 5, max_content_len: int = 200,
) -> str:
    """
    【需求2】构建高置信度检索结果上下文

    将高置信度结果的摘要/内容片段提供给LLM，
    辅助查询改写的方向性决策。
    """
    accumulator = state.get("confidence_accumulator")
    if not accumulator or not hasattr(accumulator, "results") or not accumulator.results:
        return "暂无高置信度结果"

    parts: List[str] = []
    for i, result in enumerate(accumulator.results[:max_items]):
        if not isinstance(result, RetrievalResult):
            continue
        # 层次化标识
        hierarchy = f"doc={result.doc_id}" if result.doc_id else ""
        if result.page_id:
            hierarchy += f", page={result.page_id}" if hierarchy else f"page={result.page_id}"
        if result.chunk_id:
            hierarchy += f", chunk={result.chunk_id}" if hierarchy else f"chunk={result.chunk_id}"

        # 截断内容
        content_preview = result.content[:max_content_len]
        if len(result.content) > max_content_len:
            content_preview += "..."

        line = f"[{i+1}] [分数:{result.score:.3f}]"
        if hierarchy:
            line += f" [{hierarchy}]"
        line += f"\n内容摘要: {content_preview}"
        parts.append(line)

    return "\n".join(parts) if parts else "暂无高置信度结果"


def _judge_decomposition(
    state: Any, original_query: str, iteration: int,
) -> Dict[str, Any]:
    """
    【需求1】判断当前查询是否需要拆解

    基于已有检索信息和历史查询，利用LLM判断
    是否需要将查询拆解为多个子查询。

    Returns:
        {"need_decomposition": bool, "reason": str}
    """
    retrieval_context = _build_retrieval_context(state)

    if iteration == 0:
        prompt = DECOMPOSITION_JUDGMENT_PROMPT.format(
            retrieval_context=(
                retrieval_context
                if retrieval_context != "暂无检索结果"
                else "首轮检索，暂无历史信息"
            ),
        )
        user_prompt = (
            f"请判断以下查询是否需要拆解为多个子查询：\n\n"
            f"原始查询: {original_query}"
        )
    else:
        continue_reason = state.get("continue_iteration_reason", "")
        prompt = DECOMPOSITION_JUDGMENT_ITERATIVE_PROMPT.format(
            retrieval_context=retrieval_context,
            continue_reason=(
                continue_reason if continue_reason else "未提供具体原因"
            ),
        )
        user_prompt = (
            f"请判断本轮是否需要将查询拆解为多个子查询：\n\n"
            f"原始查询: {original_query}"
        )

    try:
        result = _call_decomposition_judgment(user_prompt, prompt)
        return result
    except Exception as e:
        logger.warning("查询拆解判断失败，降级为不拆解: %s", str(e)[:200])
        return {"need_decomposition": False, "reason": f"判断失败降级: {str(e)[:100]}"}


def rewrite_node(state: GraphState) -> dict:
    """
    查询改写节点

    根据迭代轮次选择改写策略：
    - 首轮：全面覆盖式改写（条件性拆解）
    - 后续轮次：针对缺失信息的补充式改写（结合高置信度结果）

    【需求1】先判断是否需要拆解查询，再根据判断结果选择改写策略
    【需求2】后续轮次改写时，注入高置信度检索结果作为上下文
    【需求3】后续轮次改写时，读取终止节点的继续迭代原因

    Args:
        state: 当前图状态

    Returns:
        状态更新字典
    """
    settings = get_settings()
    iter_logger = get_iteration_logger()
    iteration = state.get("iteration_count", 0)
    iter_logger.set_iteration(iteration + 1)

    original_query = state.get("original_query", "")
    start_time = time.time()

    # ---- 【需求1】判断是否需要拆解查询 ----
    decomposition_result = _judge_decomposition(state, original_query, iteration)
    need_decomposition = decomposition_result.get("need_decomposition", True)
    decomposition_reason = decomposition_result.get("reason", "")

    logger.info(
        "查询拆解判断 [Iter-%d]: need_decomposition=%s, reason=%s",
        iteration + 1,
        need_decomposition,
        decomposition_reason[:200],
    )

    # ---- 构建改写数量限制（不需要拆解时减少数量） ----
    if need_decomposition:
        max_queries = settings.max_rewrite_queries
    else:
        max_queries = min(2, settings.max_rewrite_queries)

    # 首轮 vs 后续轮次使用不同提示词
    if iteration == 0:
        system_prompt = REWRITE_SYSTEM_PROMPT
        # 在system_prompt中追加拆解判断提示
        decomposition_hint = (
            f"\n\n本次判断结果: 需要{'拆解' if need_decomposition else '优化（不拆解）'}，"
            f"原因: {decomposition_reason}\n请据此选择改写策略。"
        )
        system_prompt = system_prompt + decomposition_hint
        user_prompt = (
            f"请改写以下查询，生成{max_queries}条检索查询：\n\n"
            f"原始查询: {original_query}"
        )
    else:
        # ---- 【需求2】构建高置信度结果上下文 ----
        high_conf_context = _build_high_confidence_context(state)

        # ---- 【需求3】读取继续迭代原因 ----
        continue_reason = state.get("continue_iteration_reason", "")
        if not continue_reason:
            continue_reason = "未提供具体原因，请根据历史检索上下文判断缺失信息"

        iteration_context = _build_iteration_context(state)
        system_prompt = REWRITE_SYSTEM_PROMPT_ITERATIVE.format(
            high_confidence_context=high_conf_context,
            continue_reason=continue_reason,
            iteration_context=iteration_context,
        )

        # 在prompt中也体现拆解判断结果
        if not need_decomposition:
            user_prompt = (
                f"请根据迭代上下文，优化以下查询以补充缺失信息"
                f"（无需拆解，保持聚焦）：\n\n"
                f"原始查询: {original_query}\n\n"
                f"生成{max_queries}条针对性改写查询。"
            )
        else:
            user_prompt = (
                f"请根据迭代上下文，改写以下查询以补充缺失信息"
                f"（可拆解为子问题）：\n\n"
                f"原始查询: {original_query}\n\n"
                f"生成{max_queries}条针对性改写查询。"
            )

    try:
        rewrites = _call_rewrite_llm(user_prompt, system_prompt)
    except Exception as e:
        logger.error("查询改写失败，降级使用原始查询: %s", str(e)[:200])
        rewrites = [original_query]

    # 确保原始查询始终在检索列表中
    if original_query not in rewrites:
        rewrites.insert(0, original_query)

    # 限制改写查询数量
    rewrites = rewrites[: max_queries + 1]

    iter_logger.log_rewrite(rewrites, original_query)

    end_time = time.time()
    duration_ms = (end_time - start_time) * 1000

    # 构建检索节点追踪信息（需求4）
    node_info = RetrievalNodeInfo(
        iteration=iteration + 1,
        node_name="rewrite",
        status="completed",
        start_time=start_time,
        end_time=end_time,
        duration_ms=duration_ms,
        input_summary={
            "original_query": original_query[:100],
            "iteration": iteration,
            "need_decomposition": need_decomposition,
            "decomposition_reason": decomposition_reason[:200],
        },
        output_summary={
            "rewrites": [q[:50] for q in rewrites],
            "rewrite_count": len(rewrites),
        },
    )

    return {
        "rewritten_queries": rewrites,
        "iteration_count": iteration + 1,
        "need_decomposition": need_decomposition,
        "retrieval_node_infos": [node_info],
    }
