﻿# 迭代式 RAG 查询系统技术文档

> 基于 LangGraph 框架的模块化、可迭代、高可扩展智能检索增强生成系统

---

## 目录

- [1. 项目概述](#1-项目概述)
- [2. 系统架构](#2-系统架构)
- [3. 目录结构](#3-目录结构)
- [4. 快速开始](#4-快速开始)
- [5. 核心模块详解](#5-核心模块详解)
- [6. 评估算法](#6-评估算法)
- [7. 配置参数手册](#7-配置参数手册)
- [8. 容错与降级机制](#8-容错与降级机制)
- [9. 可观测性](#9-可观测性)
- [10. 扩展指南](#10-扩展指南)

---

## 1. 项目概述

传统单次检索 RAG 存在信息覆盖不全、无法补充缺失上下文的问题。本系统以大模型为核心驱动，构建「查询优化 - 智能路由 - 多路检索 - 结果评估 - 迭代决策」全自动闭环流程：

| 特性 | 说明 |
|---|---|
| **迭代式闭环** | 多轮循环检索，每轮结合历史信息优化策略，直至信息充分或达到终止条件 |
| **全模块解耦** | 核心能力独立封装为 LangGraph 节点，可单独迭代、替换、扩展 |
| **LLM 驱动决策** | 查询改写与路由均由大模型语义决策，无硬编码规则 |
| **多知识库混合检索** | 并行检索多个数据源，支持向量/关键词/混合三种模式 |
| **量化评估与自适应终止** | 信息增益评分 + 4 条件组合判定，自动决定迭代终止时机 |
| **统一 LLM 调用** | 全局单例，严格遵循 `llm.call(prompt, system_prompt)` 调用规范 |

---

## 2. 系统架构

### 2.1 核心业务流程

```
用户查询
   |
   v
+---------------+
|  查询改写      |  <-- LLM 驱动: 语义优化 / 问题拆解 / 关键词拓展
+-------+-------+
        |
        v
+---------------+
|  智能路由      |  <-- LLM 驱动: 选择知识库 / 检索模式 / 参数
+-------+-------+
        |
        v
+---------------+
|  多路并行检索  |  <-- ThreadPoolExecutor 并行检索多知识库
+-------+-------+
        |
        v
+---------------+
|  评估与过滤    |  <-- 去重 / 低质过滤 / 信息增益 / 覆盖度
+-------+-------+
        |
        v
+---------------+
|  终止判定      |  <-- 4 条件: 轮次 / 增益 / 覆盖 / 无新文档
+-------+-------+
        |
        +-- 继续迭代 --> 回流至 [查询改写]
        |
        +-- 终止迭代 --> 答案生成 --> END
```

### 2.2 LangGraph 工作流图

系统通过 LangGraph `StateGraph` 编排，关键设计：

```python
# 节点串联
rewrite --> router --> retrieval --> evaluator --> termination

# 条件边: 循环闭环
termination --+-- should_continue=True  --> rewrite  (继续迭代)
              +-- should_continue=False --> answer   (生成答案)

# 终止
answer --> END
```

**状态累积机制**: 使用 `Annotated[list, operator.add]` 标注的字段在每轮迭代中自动追加而非覆盖:

| 字段 | 累积行为 | 说明 |
|---|---|---|
| `rewritten_queries` | 追加 | 保留所有轮次的改写查询 |
| `raw_documents` | 追加 | 保留所有轮次的原始检索文档 |
| `previous_gain_scores` | 追加 | 保留所有轮次的增益分数 |
| `iteration_logs` | 追加 | 保留全流程迭代日志 |

### 2.3 模块依赖关系

```
graph/rag_graph.py              <-- 编排层(依赖所有 nodes)
    |-- nodes/rewrite_node.py       <-- config/llm_config, config/system_settings
    |-- nodes/router_node.py        <-- config/llm_config, config/knowledge_bases
    |-- nodes/retrieval_node.py     <-- config/knowledge_bases
    |-- nodes/evaluator_node.py     <-- evaluation/metrics, evaluation/filters
    |-- nodes/termination_node.py   <-- evaluation/metrics
    +-- nodes/answer_node.py        <-- config/llm_config

state/graph_state.py            <-- 被所有 nodes 和 graph 引用
utils/                          <-- 被所有模块引用 (logging, error_handler)
config/                         <-- 被所有 nodes 引用
```

---

## 3. 目录结构

```
rag_iterative_system/
|-- config/
|   |-- __init__.py
|   |-- llm_config.py          # LLM 统一适配器 (单例, call/call_json)
|   |-- knowledge_bases.py     # 知识库注册中心 (元数据/检索函数/领域描述)
|   +-- system_settings.py     # 全局配置 (环境变量覆盖, 迭代/检索/重试参数)
|-- state/
|   |-- __init__.py
|   +-- graph_state.py         # LangGraph 状态定义 (TypedDict + Annotated 累积字段)
|-- nodes/
|   |-- __init__.py
|   |-- rewrite_node.py        # 查询改写 (首轮全覆盖 vs 后续轮补充策略)
|   |-- router_node.py         # 智能路由 (LLM 语义决策, 降级兜底)
|   |-- retrieval_node.py      # 多路并行检索 (ThreadPoolExecutor, 串行降级)
|   |-- evaluator_node.py      # 评估过滤 (去重/低质过滤/增益计算/覆盖度)
|   |-- termination_node.py    # 终止判定 (4 条件组合判定)
|   +-- answer_node.py         # 答案生成 (溯源标注, 截断保护, 异常降级)
|-- evaluation/
|   |-- __init__.py
|   |-- metrics.py             # 量化算法 (Jaccard/余弦相似度/信息增益/新颖度/覆盖度)
|   +-- filters.py             # 过滤流水线 (精确去重->近似去重->历史去重->长度裁剪)
|-- utils/
|   |-- __init__.py
|   |-- logging.py             # 迭代感知日志器 (自动附加轮次前缀)
|   +-- error_handler.py       # 异常体系 (重试退避/安全执行/截断/状态校验)
|-- graph/
|   |-- __init__.py
|   +-- rag_graph.py           # LangGraph 流程编排 (条件边/循环闭环)
|-- __init__.py
|-- main.py                    # 入口 + 演示 (模拟检索函数, 完整调用流程)
+-- requirements.txt           # 依赖: langgraph, langchain-core, langchain-openai
```

---

## 4. 快速开始

### 4.1 环境准备

```bash
# 安装依赖
pip install -r rag_iterative_system/requirements.txt

# 设置环境变量 (可选, 也可在代码中配置)
export RAG_LLM_API_KEY="sk-your-api-key"
export RAG_LLM_API_BASE="https://api.openai.com/v1"
export RAG_LLM_MODEL="gpt-4o"
```

### 4.2 最小运行示例

```python
from rag_iterative_system.config.llm_config import LLMAdapter
from rag_iterative_system.config.system_settings import SystemSettings, set_settings
from rag_iterative_system.config.knowledge_bases import register_knowledge_base, RetrievalMode
from rag_iterative_system.graph.rag_graph import compile_rag_graph, run_rag_query
from rag_iterative_system.utils.logging import setup_logging

# 1. 配置
settings = SystemSettings(
    max_iterations=3,
    llm_api_key="sk-your-api-key",
    llm_api_base="https://api.openai.com/v1",
)
set_settings(settings)
setup_logging(settings.log_level)

# 2. 初始化 LLM
LLMAdapter.initialize(
    model_name=settings.llm_model,
    api_base=settings.llm_api_base,
    api_key=settings.llm_api_key,
)

# 3. 注册知识库 (需要提供真实的检索函数)
def my_retrieval_func(query, top_k=5, score_threshold=0.3, retrieval_mode="vector", **kwargs):
    # 返回格式: [{"content": "...", "score": 0.85, "doc_id": "...", "metadata": {}}]
    return your_vector_db.search(query, top_k=top_k)

register_knowledge_base(
    kb_id="my_kb",
    name="My Knowledge Base",
    description="Technical documents for XXX domain",
    domains=["tech", "dev"],
    retrieval_func=my_retrieval_func,
)

# 4. 执行查询
compiled_graph = compile_rag_graph()
result = run_rag_query("How to implement distributed transactions?", compiled_graph)

# 5. 获取结果
print(result["final_answer"])
print(f"Iterations: {result['iteration_count']}")
print(f"Stop reason: {result['termination_reason']}")
```

### 4.3 自定义知识库接入

检索函数的接口约定:

```python
def retrieval_func(
    query: str,                   # 检索查询
    top_k: int = 5,              # 返回文档数量
    score_threshold: float = 0.3, # 最低相似度阈值
    retrieval_mode: str = "vector",  # vector / keyword / hybrid
    **kwargs,                    # 扩展参数
) -> List[Dict[str, Any]]:
    """
    返回文档列表, 每个文档为字典格式:
    {
        "content": str,      # 文档文本内容 (必填)
        "score": float,      # 相似度分数 0~1 (必填)
        "doc_id": str,       # 文档唯一标识 (可选, 用于去重)
        "metadata": dict,    # 元数据 (可选)
    }
    """
    ...
```

支持的后端:
- **向量数据库**: Milvus / Pinecone / Weaviate / Chroma
- **全文检索**: Elasticsearch / OpenSearch
- **混合检索**: 自定义混合策略

---

## 5. 核心模块详解

### 5.1 全局状态 (graph_state)

全局状态是 LangGraph 图的数据中枢, 所有节点通过读写状态进行通信:

```python
class GraphState(TypedDict, total=False):
    # 原始输入
    original_query: str

    # 迭代控制 (每轮覆盖)
    iteration_count: int
    should_continue: bool

    # 累积字段 (Annotated + operator.add, 每轮追加)
    rewritten_queries: Annotated[list, operator.add]
    raw_documents: Annotated[list, operator.add]
    previous_gain_scores: Annotated[list, operator.add]
    iteration_logs: Annotated[list, operator.add]

    # 覆盖字段 (每轮取最新值)
    routing_decision: RoutingDecision
    filtered_documents: List[Document]
    document_history: List[Document]
    information_gain: float
    termination_reason: str
    no_gain_rounds: int
    final_answer: str
```

**关键数据结构**:

| 结构 | 字段 | 用途 |
|---|---|---|
| `Document` | content, source, score, metadata, doc_id | 检索文档标准化表示 |
| `RoutingDecision` | targets, reasoning | 路由决策结果 (目标知识库列表 + 推理说明) |
| `IterationLog` | iteration, queries, counts, gain, reason | 单轮迭代运行日志 |

### 5.2 LLM 适配器 (llm_config)

全局单例模式, 统一 LLM 调用接口:

```python
# 初始化 (项目启动时调用一次)
LLMAdapter.initialize(model_name="gpt-4o", api_key="sk-xxx")

# 获取实例
llm = get_llm()

# 文本调用
response = llm.call(prompt="...", system_prompt="...")

# JSON 调用 (自动解析返回的 JSON, 兼容 markdown 代码块包裹)
result = llm.call_json(prompt="...", system_prompt="...")
# result 为 dict
```

**JSON 解析容错**:
- 自动剥离 markdown 代码块包裹
- 尝试提取第一个 `{ ... }` 块
- 全部失败时抛出 `ValueError`

### 5.3 查询改写节点 (rewrite_node)

根据迭代轮次选择不同策略:

| 轮次 | 策略 | 侧重点 |
|---|---|---|
| 首轮 (`iteration=0`) | 全面覆盖式改写 | 语义优化、问题拆解、关键词拓展、视角转换 |
| 后续轮次 | 补充式改写 | 针对缺失信息、换角度检索、细化聚焦、降维简化 |

后续轮次改写时, 自动注入迭代上下文:
- 当前迭代轮次
- 已有改写查询列表
- 已检索文档数量
- 上轮信息增益分数

**输出格式**: LLM 返回 `{"rewrites": ["查询1", "查询2", ...]}`, 通过 `call_json` 解析。

**降级策略**: LLM 调用失败时, 降级使用原始查询。

### 5.4 智能路由节点 (router_node)

LLM 语义决策, 输入查询 + 知识库列表, 输出路由目标:

```python
# 输入
{
    "query": "...",
    "rewritten_queries": ["..."],
    "kb_descriptions": "- ID: tech_docs | Domain: tech | ..."
}

# 输出
{
    "targets": [
        {
            "kb_id": "tech_docs",
            "queries": ["query1", "query2"],
            "retrieval_mode": "vector",
            "top_k": 5,
            "score_threshold": 0.5
        }
    ],
    "reasoning": "This query is about tech architecture..."
}
```

**降级策略**: 路由失败或返回无效目标时, 降级路由到所有已启用知识库。

### 5.5 多路检索节点 (retrieval_node)

- **默认模式**: `ThreadPoolExecutor` 并行检索 (最大 8 线程)
- **降级模式**: 并行失败时自动切换串行检索
- **文档数量限制**: 单轮检索文档数不超过 `max_retrieved_docs_per_round`

### 5.6 评估过滤节点 (evaluator_node)

每轮执行完整过滤流水线 + 信息增益计算:

1. **过滤流水线**: 低质过滤 -> 精确去重 -> 近似去重 -> 历史去重 -> 长度裁剪
2. **信息增益**: 计算过滤后新文档 vs 历史文档的平均新颖度
3. **历史文档合并**: 将本轮新增文档合并到 `document_history` (去重)
4. **覆盖度计算**: 评估查询关键词在文档集合中的覆盖率

### 5.7 终止判定节点 (termination_node)

4 条件组合判定, 满足任一即终止:

| 条件 | 判定逻辑 | 示例 |
|---|---|---|
| 1. 最大迭代轮次 | `iteration_count >= max_iterations` | 达到 3 轮上限 |
| 2. 连续低增益 | `no_gain_rounds >= consecutive_threshold` | 连续 2 轮增益 < 0.05 |
| 3. 覆盖度充分 | `coverage_score >= 0.9` | 查询关键词 90%+ 已覆盖 |
| 4. 无新增文档 | `filtered_count == 0` 或 `history >= max_total` | 本轮无新文档 / 历史已达 50 上限 |

### 5.8 答案生成节点 (answer_node)

迭代终止后:
1. 聚合 `document_history` 全流程优质文档
2. 构建格式化上下文 (含来源标注: `[来源:kb_id] [相关度:score]`)
3. 截断超长上下文 (`truncate_context`)
4. LLM 生成最终答案 (含引用溯源标注)

**降级策略**: 生成失败时返回异常提示信息。

### 5.9 流程引擎 (rag_graph)

LangGraph 编排核心:

```python
graph = StateGraph(GraphState)

# 添加节点
graph.add_node("rewrite", rewrite_node)
graph.add_node("router", router_node)
graph.add_node("retrieval", retrieval_node)
graph.add_node("evaluator", evaluator_node)
graph.add_node("termination", termination_node)
graph.add_node("answer", answer_node)

# 顺序边
graph.add_edge("rewrite", "router")
graph.add_edge("router", "retrieval")
graph.add_edge("retrieval", "evaluator")
graph.add_edge("evaluator", "termination")

# 条件边 (循环闭环)
graph.add_conditional_edges("termination", _should_continue, {
    "continue": "rewrite",   # 继续迭代
    "generate": "answer",    # 生成答案
})

graph.add_edge("answer", END)
```

便捷调用:

```python
# 编译并执行
compiled = compile_rag_graph()
result = run_rag_query("your query", compiled)

# 或一步到位
result = run_rag_query("your query")
```

---

## 6. 评估算法

### 6.1 相似度计算

| 算法 | 函数 | 复杂度 | 适用场景 |
|---|---|---|---|
| Jaccard 相似度 | `jaccard_similarity(a, b)` | O(n) | 快速粗筛, 无序集合比较 |
| 余弦相似度 | `cosine_similarity_text(a, b)` | O(n) | 精确文本相似度, 词频加权 |

**分词策略**: 中英文混合分词 - 英文按空格拆分, 中文逐字符拆分。

### 6.2 信息增益

```
信息增益 = 所有新文档的平均新颖度

新颖度(新文档, 历史文档) = 1 - max(余弦相似度(新文档, 历史文档_i))
```

- 新颖度范围 [0, 1]: 1 表示完全新颖 (与所有历史文档不相似), 0 表示与某个历史文档完全重复
- 信息增益 = 0: 本轮无新增信息
- 信息增益 = 1: 本轮所有文档都是全新信息

### 6.3 文档覆盖度

```
覆盖度 = 查询关键词在文档集合中的出现率

覆盖度 = |查询词元 & 文档词元| / |查询词元|
```

- 范围 [0, 1]: 1 表示查询所有关键词都在文档中出现
- 用于判断是否已检索到足够信息

### 6.4 过滤流水线

执行顺序: **低质过滤 -> 精确去重 -> 近似去重 -> 历史去重 -> 长度裁剪**

| 步骤 | 函数 | 方法 | 参数 |
|---|---|---|---|
| 1. 低质过滤 | `filter_low_quality` | 移除过短/低分文档 | `min_length=20`, `min_score=0.3` |
| 2. 精确去重 | `deduplicate_exact` | MD5 哈希比对 | - |
| 3. 近似去重 | `deduplicate_near` | 余弦相似度 > 阈值则去重 | `threshold=0.95` |
| 4. 历史去重 | `deduplicate_against_history` | 新文档 vs 历史文档相似度 | `threshold=0.95` |
| 5. 长度裁剪 | `truncate_documents` | 按分数降序, 总长度超限时裁剪 | `max_context_length=8000` |

---

## 7. 配置参数手册

### 7.1 系统配置 (SystemSettings)

#### 迭代控制

| 参数 | 默认值 | 说明 |
|---|---|---|
| `max_iterations` | 3 | 最大迭代轮次 |
| `min_information_gain` | 0.05 | 最小信息增益阈值 (低于此值视为无新信息) |
| `consecutive_no_gain_rounds` | 2 | 连续无增益轮次阈值 (触发终止) |

#### 检索参数

| 参数 | 默认值 | 说明 |
|---|---|---|
| `default_top_k` | 5 | 默认检索文档数量 |
| `max_retrieved_docs_per_round` | 20 | 单轮最大检索文档数 |
| `score_threshold` | 0.3 | 最低相似度分数阈值 |

#### 上下文控制

| 参数 | 默认值 | 说明 |
|---|---|---|
| `max_context_length` | 8000 | 最大上下文字符长度 |
| `max_total_documents` | 50 | 全流程累计最大文档数 |

#### 查询改写

| 参数 | 默认值 | 说明 |
|---|---|---|
| `max_rewrite_queries` | 3 | 每轮最大改写查询数 |

#### 去重与过滤

| 参数 | 默认值 | 说明 |
|---|---|---|
| `dedup_similarity_threshold` | 0.95 | 去重相似度阈值 |
| `min_doc_length` | 20 | 最短有效文档字符数 |

#### LLM 调用

| 参数 | 默认值 | 说明 |
|---|---|---|
| `llm_model` | gpt-4o | 模型名称 |
| `llm_api_base` | https://api.openai.com/v1 | API 基础地址 |
| `llm_api_key` | sk-placeholder | API 密钥 |
| `llm_temperature` | 0.0 | 温度参数 |
| `llm_max_tokens` | 4096 | 最大 token 数 |
| `llm_timeout` | 60 | 超时时间 (秒) |

#### 重试与容错

| 参数 | 默认值 | 说明 |
|---|---|---|
| `max_retries` | 3 | 最大重试次数 |
| `retry_delay` | 1.0 | 重试间隔 (秒) |
| `enable_fallback` | True | 是否启用降级兜底 |

#### 日志

| 参数 | 默认值 | 说明 |
|---|---|---|
| `log_level` | INFO | 日志级别 |
| `enable_iteration_logging` | True | 是否记录迭代详细日志 |

### 7.2 环境变量覆盖

所有参数均支持环境变量覆盖, 命名规则 `RAG_大写字段名`:

```bash
export RAG_MAX_ITERATIONS=5
export RAG_MIN_INFORMATION_GAIN=0.08
export RAG_LLM_API_KEY="sk-your-key"
export RAG_LLM_MODEL="gpt-4o-mini"
export RAG_SCORE_THRESHOLD=0.4
```

优先级: **环境变量 > 代码设定 > 默认值**

### 7.3 知识库配置

```python
register_knowledge_base(
    kb_id="unique_id",              # 唯一标识
    name="Display Name",            # 显示名称
    description="KB description",   # 能力描述 (供路由决策)
    domains=["domain1", "domain2"], # 覆盖领域标签
    retrieval_mode=RetrievalMode.VECTOR,  # vector / keyword / hybrid
    top_k=5,                        # 默认检索数量
    score_threshold=0.5,            # 默认最低分数
    retrieval_func=your_func,       # 检索函数 (必须)
)
```

---

## 8. 容错与降级机制

系统在每个关键环节均设有降级策略, 确保单点故障不阻断整个流程:

| 模块 | 故障场景 | 降级策略 |
|---|---|---|
| **查询改写** | LLM 调用失败 | 降级使用原始查询 |
| **智能路由** | LLM 调用失败 / 返回无效目标 | 降级路由到所有已启用知识库 |
| **多路检索** | 并行检索异常 | 自动切换串行检索 |
| **单知识库检索** | 检索函数抛异常 | `safe_execute` 捕获, 返回空列表, 其他知识库不受影响 |
| **答案生成** | LLM 调用失败 | 返回异常提示信息 (包含已检索文档数) |
| **JSON 解析** | LLM 返回非标准 JSON | 自动剥离代码块, 提取 `{...}` 块 |

**重试机制**: 通过 `@retry_with_backoff` 装饰器实现指数退避重试:
- 默认最多重试 3 次
- 延迟: 1s -> 2s -> 4s (指数增长, 上限 30s)
- 支持指定 `fallback` 降级返回值

**异常体系**:

```
RAGSystemError               # 基础异常
  +-- LLMCallError           # LLM 调用异常
  +-- RetrievalError         # 检索异常
  +-- RoutingError           # 路由异常
  +-- EvaluationError        # 评估异常
  +-- ContextOverflowError   # 上下文超限异常
```

**保护机制**:
- 空结果保护: 检索无结果时不崩溃, 继续流程
- 上下文长度限制: `truncate_context` 防止上下文爆炸
- 文档数量管控: `max_total_documents` 防止历史文档无限增长
- 状态完整性校验: `validate_state_integrity` 检查异常状态

---

## 9. 可观测性

### 迭代感知日志器 (IterationLogger)

自动在每条日志前附加迭代轮次前缀:

```
[Iter-1] 查询改写完成: original='如何设计...' -> 3 条改写查询
[Iter-1] 路由决策: 目标知识库=['tech_docs'], 推理=该查询涉及技术架构...
[Iter-1] 检索完成: 总文档数=5, 各源={'tech_docs': 5}
[Iter-1] 评估完成: 原始=5, 过滤后=3, 信息增益=0.7200
[Iter-1] 终止判定: 继续迭代, 原因=
[Iter-2] 查询改写完成: original='如何设计...' -> 3 条改写查询
[Iter-2] 终止判定: 终止迭代, 原因=查询覆盖度已达92.0%, 信息充分
[Iter-2] 答案生成完成: 长度=1250字符
```

### 结构化迭代日志

每轮迭代自动记录 `IterationLog`, 存储在状态 `iteration_logs` 字段:

```python
@dataclass
class IterationLog:
    iteration: int          # 当前轮次
    rewritten_queries: List[str]  # 改写查询
    routing_decision: str  # 路由决策摘要
    retrieved_count: int   # 检索文档数
    filtered_count: int    # 过滤后文档数
    information_gain: float # 信息增益分数
    termination_reason: str # 终止原因 (仅最后一轮)
```

### 运行结果查看

```python
result = run_rag_query("your query")

# 核心输出
result["final_answer"]         # 最终答案
result["iteration_count"]      # 总迭代轮次
result["termination_reason"]   # 终止原因
result["document_history"]     # 全流程优质文档列表

# 迭代过程追溯
for log in result["iteration_logs"]:
    print(f"Round {log.iteration}: "
          f"retrieved={log.retrieved_count}, "
          f"filtered={log.filtered_count}, "
          f"gain={log.information_gain:.4f}")
```

---

## 10. 扩展指南

### 10.1 接入新知识库

```python
from rag_iterative_system.config.knowledge_bases import register_knowledge_base, RetrievalMode

# 1. 定义检索函数
def milvus_retrieval(query, top_k=5, score_threshold=0.3, retrieval_mode="vector", **kwargs):
    results = milvus_collection.search(query, limit=top_k)
    return [
        {
            "content": hit.entity.text,
            "score": hit.distance,
            "doc_id": hit.id,
            "metadata": {"source": "milvus"},
        }
        for hit in results
        if hit.distance >= score_threshold
    ]

# 2. 注册知识库
register_knowledge_base(
    kb_id="milvus_docs",
    name="Milvus Document Store",
    description="Vector-indexed technical documents stored in Milvus",
    domains=["vector-db", "embedding", "search"],
    retrieval_mode=RetrievalMode.VECTOR,
    top_k=5,
    retrieval_func=milvus_retrieval,
)
```

无需修改任何主流程代码, 路由模块会自动识别新知识库。

### 10.2 替换相似度算法

当前默认使用基于词频的余弦相似度。替换为向量嵌入相似度:

```python
from rag_iterative_system.evaluation.metrics import compute_information_gain, compute_novelty

# 自定义相似度函数 (使用 sentence-transformers)
from sentence_transformers import SentenceTransformer, util

model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')

def embedding_similarity(text_a: str, text_b: str) -> float:
    emb_a = model.encode(text_a)
    emb_b = model.encode(text_b)
    return float(util.cos_sim(emb_a, emb_b))

# 使用自定义相似度函数
gain = compute_information_gain(new_docs, history_docs, similarity_func=embedding_similarity)
novelty = compute_novelty(doc, existing_docs, similarity_func=embedding_similarity)
```

### 10.3 新增终止条件

在 `termination_node.py` 中添加自定义条件:

```python
def _check_custom_condition(some_param: str) -> tuple:
    """自定义终止条件"""
    if some_condition_met:
        return True, "Custom condition triggered"
    return False, ""

# 在 termination_node 函数中, 按顺序添加检查:
if not should_terminate:
    terminated, reason = _check_custom_condition(state.get("some_field"))
    if terminated:
        should_terminate = True
        termination_reason = reason
```

### 10.4 自定义节点

遵循 LangGraph 节点规范, 函数签名: `def node_name(state: GraphState) -> dict`

```python
# example: 新增"查询分类"节点
def classify_node(state: GraphState) -> dict:
    query = state.get("original_query", "")
    # ... 分类逻辑 ...
    return {"query_category": "technical"}

# 在 rag_graph.py 中注册
graph.add_node("classify", classify_node)
graph.add_edge("rewrite", "classify")    # rewrite -> classify -> router
graph.add_edge("classify", "router")
# 删掉原来的: graph.add_edge("rewrite", "router")
```

---

## 依赖版本

| 包 | 版本 | 用途 |
|---|---|---|
| langgraph | >=0.2.0 | LangGraph 图编排框架 |
| langchain-core | >=0.3.0 | LangChain 核心抽象 (消息/模型接口) |
| langchain-openai | >=0.2.0 | OpenAI 模型适配 |
| typing_extensions | >=4.0.0 | TypedDict 等类型扩展 |
