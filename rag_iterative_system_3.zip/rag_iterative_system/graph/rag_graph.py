# -*- coding: utf-8 -*-
"""
LangGraph工作流搭建、节点编排、条件边配置、图编译
- 定义标准化节点执行顺序
- 循环回流逻辑
- 条件分支管理
- 引擎层与业务逻辑解耦
"""

from __future__ import annotations

import logging
from typing import Any, Literal

from langgraph.graph import END, StateGraph

from rag_iterative_system.nodes.answer_node import answer_node
from rag_iterative_system.nodes.evaluator_node import evaluator_node
from rag_iterative_system.nodes.retrieval_node import retrieval_node
from rag_iterative_system.nodes.rewrite_node import rewrite_node
from rag_iterative_system.nodes.router_node import router_node
from rag_iterative_system.nodes.termination_node import termination_node
from rag_iterative_system.state.graph_state import GraphState, create_initial_state

logger = logging.getLogger(__name__)


def _should_continue(state: GraphState) -> Literal["continue", "generate"]:
    """
    条件边判断函数：决定是继续迭代还是生成答案

    Args:
        state: 当前图状态

    Returns:
        "continue" -> 回流到查询改写节点继续迭代
        "generate" -> 进入答案生成节点
    """
    should_continue = state.get("should_continue", False)

    if should_continue:
        logger.info("决策: 继续迭代 (should_continue=True)")
        return "continue"
    else:
        logger.info("决策: 生成答案 (should_continue=False)")
        return "generate"


def build_rag_graph() -> StateGraph:
    """
    构建迭代式RAG工作流图

    流程:
    1. rewrite -> router -> retrieval -> evaluator -> termination
    2. termination -> [继续迭代] -> rewrite (循环)
    3. termination -> [终止迭代] -> answer -> END

    Returns:
        编译后的LangGraph状态图
    """
    # 创建状态图
    graph = StateGraph(GraphState)

    # 添加节点
    graph.add_node("rewrite", rewrite_node)
    graph.add_node("router", router_node)
    graph.add_node("retrieval", retrieval_node)
    graph.add_node("evaluator", evaluator_node)
    graph.add_node("termination", termination_node)
    graph.add_node("answer", answer_node)

    # 设置入口节点
    graph.set_entry_point("rewrite")

    # 定义顺序边
    graph.add_edge("rewrite", "router")
    graph.add_edge("router", "retrieval")
    graph.add_edge("retrieval", "evaluator")
    graph.add_edge("evaluator", "termination")

    # 定义条件边：终止判定后的分支
    graph.add_conditional_edges(
        "termination",
        _should_continue,
        {
            "continue": "rewrite",     # 继续迭代 -> 回流到查询改写
            "generate": "answer",      # 终止迭代 -> 生成答案
        },
    )

    # 答案生成后结束
    graph.add_edge("answer", END)

    logger.info("迭代式RAG工作流图构建完成")

    return graph


def compile_rag_graph() -> Any:
    """
    构建并编译RAG工作流图

    Returns:
        编译后的可执行图
    """
    graph = build_rag_graph()
    compiled = graph.compile()
    logger.info("RAG工作流图编译完成")
    return compiled


def run_rag_query(
    query: str,
    compiled_graph: Any = None,
) -> dict:
    """
    执行迭代式RAG查询

    Args:
        query: 用户查询
        compiled_graph: 预编译的图（可选，为空则自动编译）

    Returns:
        最终状态字典，包含 final_answer 等字段
    """
    if compiled_graph is None:
        compiled_graph = compile_rag_graph()

    initial_state = create_initial_state(query)

    logger.info("开始执行迭代式RAG查询: %s", query[:100])

    result = compiled_graph.invoke(initial_state)

    logger.info(
        "迭代式RAG查询完成: 迭代轮次=%d, 最终答案长度=%d",
        result.get("iteration_count", 0),
        len(result.get("final_answer", "")),
    )

    return result
