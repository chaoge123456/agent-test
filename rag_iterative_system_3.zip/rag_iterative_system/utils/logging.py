# -*- coding: utf-8 -*-
"""
迭代全链路日志记录
- 结构化日志埋点
- 迭代轮次追踪
- 关键指标记录
"""

from __future__ import annotations

import logging
import sys
from typing import Optional


def setup_logging(
    level: str = "INFO",
    format_string: Optional[str] = None,
) -> None:
    """
    配置全局日志

    Args:
        level: 日志级别
        format_string: 自定义格式字符串
    """
    fmt = format_string or (
        "[%(asctime)s] %(levelname)-8s %(name)-20s | %(message)s"
    )
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format=fmt,
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=[logging.StreamHandler(sys.stdout)],
    )


class IterationLogger:
    """
    迭代感知日志器

    自动附加当前迭代轮次信息到每条日志
    """

    def __init__(self, name: str = "rag_iterative") -> None:
        self._logger = logging.getLogger(name)
        self._iteration: int = 0

    def set_iteration(self, iteration: int) -> None:
        """设置当前迭代轮次"""
        self._iteration = iteration

    def info(self, msg: str, *args: object) -> None:
        self._logger.info("[Iter-%d] %s", self._iteration, msg, *args)

    def warning(self, msg: str, *args: object) -> None:
        self._logger.warning("[Iter-%d] %s", self._iteration, msg, *args)

    def error(self, msg: str, *args: object) -> None:
        self._logger.error("[Iter-%d] %s", self._iteration, msg, *args)

    def debug(self, msg: str, *args: object) -> None:
        self._logger.debug("[Iter-%d] %s", self._iteration, msg, *args)

    def log_rewrite(
        self, queries: list, original: str
    ) -> None:
        """记录查询改写"""
        self._logger.info(
            "[Iter-%d] 查询改写完成: original='%s' -> %d 条改写查询: %s",
            self._iteration,
            original[:50],
            len(queries),
            [q[:30] for q in queries],
        )

    def log_routing(
        self, targets: list, reasoning: str
    ) -> None:
        """记录路由决策"""
        kb_ids = [t.get("kb_id", "?") for t in targets]
        self._logger.info(
            "[Iter-%d] 路由决策: 目标知识库=%s, 推理=%s",
            self._iteration,
            kb_ids,
            reasoning[:100],
        )

    def log_retrieval(
        self, total_docs: int, by_source: dict
    ) -> None:
        """记录检索结果"""
        self._logger.info(
            "[Iter-%d] 检索完成: 总文档数=%d, 各源=%s",
            self._iteration,
            total_docs,
            by_source,
        )

    def log_evaluation(
        self, raw_count: int, filtered_count: int, gain: float
    ) -> None:
        """记录评估结果"""
        self._logger.info(
            "[Iter-%d] 评估完成: 原始=%d, 过滤后=%d, 信息增益=%.4f",
            self._iteration,
            raw_count,
            filtered_count,
            gain,
        )

    def log_termination(
        self, reason: str, should_continue: bool
    ) -> None:
        """记录终止决策"""
        action = "继续迭代" if should_continue else "终止迭代"
        self._logger.info(
            "[Iter-%d] 终止判定: %s, 原因=%s",
            self._iteration,
            action,
            reason,
        )

    def log_answer(self, answer_length: int) -> None:
        """记录答案生成"""
        self._logger.info(
            "[Iter-%d] 答案生成完成: 长度=%d字符",
            self._iteration,
            answer_length,
        )


# 全局迭代日志器
_iteration_logger: IterationLogger | None = None


def get_iteration_logger() -> IterationLogger:
    """获取全局迭代日志器"""
    global _iteration_logger
    if _iteration_logger is None:
        _iteration_logger = IterationLogger()
    return _iteration_logger
