# -*- coding: utf-8 -*-
"""
检索过程可视化工具（需求4）

功能：
1. 收集和保存每个检索节点的信息
2. 生成可交互的HTML报告，可视化查看每个节点的检索状态和信息
3. 支持迭代流程的时间线视图
4. 支持节点详情展开/折叠
5. 支持导出为独立HTML文件，可在浏览器中查看

使用方式：
    from rag_iterative_system.utils.visualizer import RetrievalVisualizer
    viz = RetrievalVisualizer()
    viz.save_report(result, output_path="retrieval_report.html")
    html = viz.generate_html_report(result)
"""

from __future__ import annotations

import html as html_module
import json
import logging
import os
from datetime import datetime
from typing import Any, Dict, List, Optional

from rag_iterative_system.state.graph_state import (
    ConfidenceAccumulator,
    IterationLog,
    RetrievalNodeInfo,
    RetrievalResult,
)

logger = logging.getLogger(__name__)


def _esc(text: str) -> str:
    """HTML转义"""
    return html_module.escape(str(text))


class RetrievalVisualizer:
    """检索过程可视化器：解析RAG检索流程状态，生成交互式HTML报告。"""

    def __init__(self) -> None:
        self._reports_dir = "retrieval_reports"

    def save_report(
        self,
        result: dict,
        output_path: Optional[str] = None,
        open_browser: bool = False,
    ) -> str:
        """保存检索过程分析报告到HTML文件。"""
        report_html = self.generate_html_report(result)
        if output_path is None:
            os.makedirs(self._reports_dir, exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            query_short = result.get("original_query", "query")[:20]
            safe_query = "".join(
                c if c.isalnum() or c in "_-" else "_" for c in query_short
            )
            output_path = os.path.join(
                self._reports_dir, f"report_{safe_query}_{timestamp}.html"
            )
        output_dir = os.path.dirname(output_path)
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as fh:
            fh.write(report_html)
        logger.info("检索过程分析报告已保存: %s", output_path)
        if open_browser:
            import webbrowser
            webbrowser.open(f"file://{os.path.abspath(output_path)}")
        return output_path

    def generate_html_report(self, result: dict) -> str:
        """生成HTML报告字符串。"""
        original_query = result.get("original_query", "")
        iteration_count = result.get("iteration_count", 0)
        termination_reason = result.get("termination_reason", "")
        final_answer = result.get("final_answer", "")
        iteration_logs = result.get("iteration_logs", [])
        node_infos = result.get("retrieval_node_infos", [])
        doc_history = result.get("document_history", [])
        llm_judgment = result.get("llm_coverage_judgment", "")
        continue_reason = result.get("continue_iteration_reason", "")
        accumulator = result.get("confidence_accumulator")
        high_conf_count = 0
        if accumulator and hasattr(accumulator, "results"):
            high_conf_count = len(accumulator.results)
        iterations_data = self._group_by_iteration(iteration_logs, node_infos, result)
        iterations_json = json.dumps(iterations_data, ensure_ascii=False, default=str)
        nodes_json = json.dumps(
            [n.to_dict() if hasattr(n, "to_dict") else str(n) for n in node_infos],
            ensure_ascii=False, default=str,
        )
        generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        report = _build_html(
            query=_esc(original_query),
            iteration_count=iteration_count,
            termination_reason=_esc(termination_reason or "N/A"),
            doc_count=len(doc_history),
            high_conf_count=high_conf_count,
            final_answer=_esc(final_answer or "无"),
            llm_judgment=_esc(llm_judgment or "无"),
            continue_reason=_esc(continue_reason or "无"),
            iterations_json=iterations_json,
            nodes_json=nodes_json,
            generated_at=generated_at,
        )
        return report

    def _group_by_iteration(
        self, logs: List[Any], node_infos: List[Any], result: dict,
    ) -> List[Dict[str, Any]]:
        """按迭代轮次分组数据"""
        iterations: Dict[int, Dict[str, Any]] = {}
        for log in logs:
            if not hasattr(log, "iteration"):
                continue
            it = log.iteration
            if it not in iterations:
                iterations[it] = {"iteration": it, "nodes": []}
            iterations[it]["rewritten_queries"] = getattr(log, "rewritten_queries", [])
            iterations[it]["retrieved_count"] = getattr(log, "retrieved_count", 0)
            iterations[it]["filtered_count"] = getattr(log, "filtered_count", 0)
            iterations[it]["information_gain"] = getattr(log, "information_gain", 0.0)
            iterations[it]["termination_reason"] = getattr(log, "termination_reason", "")
            iterations[it]["need_decomposition"] = getattr(log, "need_decomposition", True)
            iterations[it]["decomposition_reason"] = getattr(log, "decomposition_reason", "")
            iterations[it]["llm_coverage_judgment"] = getattr(log, "llm_coverage_judgment", "")
            iterations[it]["continue_iteration_reason"] = getattr(log, "continue_iteration_reason", "")
        for info in node_infos:
            if not hasattr(info, "iteration"):
                continue
            it = info.iteration
            if it not in iterations:
                iterations[it] = {"iteration": it, "nodes": []}
            node_data = info.to_dict() if hasattr(info, "to_dict") else {"node_name": str(info)}
            iterations[it]["nodes"].append(node_data)
        return sorted(iterations.values(), key=lambda x: x.get("iteration", 0))


def _build_html(**kw) -> str:
    """构建HTML报告（简化版框架，后续优化样式和交互）"""
    import json as _json

    q = kw
    # 将迭代数据和节点数据嵌入JS
    it_json = q.get("iterations_json", "[]")
    nd_json = q.get("nodes_json", "[]")

    # 构建迭代时间线HTML（服务端渲染）
    timeline_html = ""
    try:
        iterations = _json.loads(it_json)
        for it in iterations:
            is_term = bool(it.get("termination_reason", ""))
            badge = "终止" if is_term else "继续迭代"
            badge_cls = "badge-terminate" if is_term else "badge-continue"
            timeline_html += f'''<div class="iteration-card">
<div class="iteration-header"><h2>第 {it['iteration']} 轮 <span class="iteration-badge {badge_cls}">{badge}</span></h2></div>
<div class="collapse-content open">'''
            # 改写查询
            queries = it.get("rewritten_queries", [])
            if queries:
                tags = " ".join(f'<span class="query-tag">{_esc(qi)}</span>' for qi in queries)
                timeline_html += f'<div style="margin-bottom:12px;"><strong>改写查询:</strong> {tags}</div>'
            # 是否拆解
            need_decomp = it.get("need_decomposition")
            if need_decomp is not None:
                decomp_label = "是" if need_decomp else "否"
                decomp_reason = it.get("decomposition_reason", "")
                reason_str = f' <span style="color:#888;">({_esc(decomp_reason)})</span>' if decomp_reason else ""
                timeline_html += f'<div style="margin-bottom:8px;font-size:13px;"><strong>是否拆解:</strong> {decomp_label}{reason_str}</div>'
            # 指标
            timeline_html += f'''<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:8px;margin-bottom:12px;">
<div style="background:#f8f9fa;padding:8px;border-radius:6px;text-align:center;"><div style="font-size:16px;font-weight:700;">{it.get("retrieved_count",0)}</div><div style="font-size:12px;color:#666;">检索文档</div></div>
<div style="background:#f8f9fa;padding:8px;border-radius:6px;text-align:center;"><div style="font-size:16px;font-weight:700;">{it.get("filtered_count",0)}</div><div style="font-size:12px;color:#666;">过滤后</div></div>
<div style="background:#f8f9fa;padding:8px;border-radius:6px;text-align:center;"><div style="font-size:16px;font-weight:700;">{it.get("information_gain",0):.4f}</div><div style="font-size:12px;color:#666;">信息增益</div></div>
</div>'''
            # 信息增益进度条
            gain = it.get("information_gain", 0)
            gain_pct = min(gain * 100, 100)
            gain_cls = "bar-green" if gain > 0.3 else ("bar-blue" if gain > 0.1 else "bar-orange")
            timeline_html += f'<div class="metric-bar"><div class="label">信息增益: {gain:.4f}</div><div class="bar"><div class="fill {gain_cls}" style="width:{gain_pct:.1f}%"></div></div></div>'
            # 节点卡片
            nodes = it.get("nodes", [])
            if nodes:
                timeline_html += '<div class="node-grid">'
                for node in nodes:
                    status = node.get("status", "pending")
                    timeline_html += f'''<div class="node-card">
<div class="node-name">{_esc(node.get("node_name","unknown"))} <span class="node-status status-{status}">{status}</span></div>
<div class="node-duration">耗时: {node.get("duration_ms",0):.1f}ms</div>
<details><summary style="cursor:pointer;font-size:12px;color:#666;">详情</summary><pre style="background:#f8f9fa;padding:8px;border-radius:4px;font-size:11px;white-space:pre-wrap;word-break:break-all;">{_esc(_json.dumps(node, ensure_ascii=False, indent=2))}</pre></details>
</div>'''
                timeline_html += '</div>'
            # 终止原因/LLM判定/继续迭代原因
            if it.get("termination_reason"):
                timeline_html += f'<div style="margin-top:12px;padding:10px;background:#d4edda;border-radius:6px;font-size:13px;"><strong>终止原因:</strong> {_esc(it["termination_reason"])}</div>'
            if it.get("llm_coverage_judgment"):
                timeline_html += f'<div style="margin-top:8px;padding:10px;background:#cce5ff;border-radius:6px;font-size:13px;"><strong>LLM判定:</strong> {_esc(it["llm_coverage_judgment"])}</div>'
            if it.get("continue_iteration_reason"):
                timeline_html += f'<div style="margin-top:8px;padding:10px;background:#fff3cd;border-radius:6px;font-size:13px;"><strong>继续迭代原因:</strong> {_esc(it["continue_iteration_reason"])}</div>'
            timeline_html += '</div></div>'
    except Exception:
        timeline_html = '<p style="color:#999;">迭代数据解析失败</p>'

    # 构建节点详情HTML
    nodes_html = ""
    try:
        nodes = _json.loads(nd_json)
        if nodes:
            nodes_html += '<div class="node-grid">'
            for node in nodes:
                status = node.get("status", "pending")
                nodes_html += f'''<div class="node-card">
<div class="node-name">[Iter-{node.get("iteration",0)}] {_esc(node.get("node_name","unknown"))} <span class="node-status status-{status}">{status}</span></div>
<div class="node-duration">耗时: {node.get("duration_ms",0):.1f}ms</div>
<details><summary style="cursor:pointer;font-size:12px;color:#666;">详情</summary><pre style="background:#f8f9fa;padding:8px;border-radius:4px;font-size:11px;white-space:pre-wrap;word-break:break-all;">{_esc(_json.dumps(node, ensure_ascii=False, indent=2))}</pre></details>
</div>'''
            nodes_html += '</div>'
        else:
            nodes_html = '<p style="color:#999;">暂无节点数据</p>'
    except Exception:
        nodes_html = '<p style="color:#999;">节点数据解析失败</p>'

    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>检索过程分析报告</title>
<style>
* {{ margin:0; padding:0; box-sizing:border-box; }}
body {{ font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif; background:#f5f7fa; color:#333; line-height:1.6; }}
.container {{ max-width:1200px; margin:0 auto; padding:20px; }}
.header {{ background:linear-gradient(135deg,#667eea 0%,#764ba2 100%); color:#fff; padding:30px; border-radius:12px; margin-bottom:24px; }}
.header h1 {{ font-size:24px; margin-bottom:16px; }}
.header .query {{ background:rgba(255,255,255,0.15); padding:12px 16px; border-radius:8px; font-size:16px; margin-bottom:16px; word-break:break-all; }}
.stats {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:12px; }}
.stat-card {{ background:rgba(255,255,255,0.15); padding:12px 16px; border-radius:8px; text-align:center; }}
.stat-card .value {{ font-size:24px; font-weight:700; }}
.stat-card .label {{ font-size:12px; opacity:0.85; }}
.timeline {{ position:relative; padding-left:30px; }}
.timeline::before {{ content:''; position:absolute; left:14px; top:0; bottom:0; width:2px; background:#ddd; }}
.iteration-card {{ background:#fff; border-radius:12px; padding:20px; margin-bottom:20px; box-shadow:0 2px 8px rgba(0,0,0,0.08); position:relative; }}
.iteration-card::before {{ content:''; position:absolute; left:-22px; top:24px; width:12px; height:12px; border-radius:50%; background:#667eea; border:2px solid #fff; }}
.iteration-header h2 {{ font-size:18px; color:#444; }}
.iteration-badge {{ display:inline-block; padding:4px 12px; border-radius:12px; font-size:12px; font-weight:600; }}
.badge-continue {{ background:#fff3cd; color:#856404; }}
.badge-terminate {{ background:#d4edda; color:#155724; }}
.node-grid {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(280px,1fr)); gap:12px; margin-top:12px; }}
.node-card {{ border:1px solid #e8ecf1; border-radius:8px; padding:14px; }}
.node-name {{ font-weight:600; font-size:14px; margin-bottom:6px; }}
.node-duration {{ font-size:12px; color:#888; }}
.node-status {{ display:inline-block; padding:2px 8px; border-radius:4px; font-size:11px; font-weight:500; }}
.status-completed {{ background:#d4edda; color:#155724; }}
.status-running {{ background:#cce5ff; color:#004085; }}
.status-failed {{ background:#f8d7da; color:#721c24; }}
.status-pending {{ background:#e2e3e5; color:#383d41; }}
.metric-bar {{ margin:6px 0; }}
.metric-bar .label {{ font-size:12px; color:#666; margin-bottom:3px; }}
.metric-bar .bar {{ height:6px; background:#e8ecf1; border-radius:3px; overflow:hidden; }}
.metric-bar .fill {{ height:100%; border-radius:3px; }}
.bar-green {{ background:linear-gradient(90deg,#28a745,#71d875); }}
.bar-blue {{ background:linear-gradient(90deg,#007bff,#6dc0ff); }}
.bar-orange {{ background:linear-gradient(90deg,#fd7e14,#ffc107); }}
.detail-section {{ background:#fff; border-radius:12px; padding:20px; margin-bottom:20px; box-shadow:0 2px 8px rgba(0,0,0,0.08); }}
.detail-section h3 {{ font-size:16px; margin-bottom:12px; padding-bottom:8px; border-bottom:2px solid #f0f0f0; }}
.detail-section .content {{ font-size:14px; line-height:1.8; white-space:pre-wrap; word-break:break-all; }}
.tab-container {{ margin-bottom:20px; }}
.tab-buttons {{ display:flex; gap:8px; margin-bottom:16px; flex-wrap:wrap; }}
.tab-btn {{ padding:8px 16px; border:1px solid #ddd; border-radius:8px; background:#fff; cursor:pointer; font-size:14px; }}
.tab-btn.active {{ background:#667eea; color:#fff; border-color:#667eea; }}
.tab-content {{ display:none; }}
.tab-content.active {{ display:block; }}
.footer {{ text-align:center; padding:20px; color:#999; font-size:12px; }}
.query-tag {{ display:inline-block; background:#e8f0fe; color:#1a73e8; padding:4px 10px; border-radius:4px; font-size:12px; margin:2px 4px; }}
.collapse-content {{ overflow:hidden; }}
.collapse-content.open {{ }}
</style>
</head>
<body>
<div class="container">
<div class="header">
    <h1>检索过程分析报告</h1>
    <div class="query">{q['query']}</div>
    <div class="stats">
        <div class="stat-card"><div class="value">{q['iteration_count']}</div><div class="label">迭代轮次</div></div>
        <div class="stat-card"><div class="value">{q['doc_count']}</div><div class="label">检索文档数</div></div>
        <div class="stat-card"><div class="value">{q['high_conf_count']}</div><div class="label">高置信度结果</div></div>
        <div class="stat-card"><div class="value" style="font-size:14px;">{q['termination_reason']}</div><div class="label">终止原因</div></div>
    </div>
</div>
<div class="tab-container">
    <div class="tab-buttons">
        <button class="tab-btn active" onclick="switchTab('timeline',this)">迭代时间线</button>
        <button class="tab-btn" onclick="switchTab('nodes',this)">节点详情</button>
        <button class="tab-btn" onclick="switchTab('judgment',this)">LLM判定</button>
        <button class="tab-btn" onclick="switchTab('answer',this)">最终答案</button>
    </div>
    <div id="tab-timeline" class="tab-content active"><div class="timeline">{timeline_html}</div></div>
    <div id="tab-nodes" class="tab-content"><div class="detail-section"><h3>各节点执行详情</h3>{nodes_html}</div></div>
    <div id="tab-judgment" class="tab-content">
        <div class="detail-section"><h3>LLM覆盖度判定</h3><div class="content">{q['llm_judgment']}</div></div>
        <div class="detail-section"><h3>继续迭代原因</h3><div class="content">{q['continue_reason']}</div></div>
    </div>
    <div id="tab-answer" class="tab-content"><div class="detail-section"><h3>最终答案</h3><div class="content">{q['final_answer']}</div></div></div>
</div>
<div class="footer">生成时间: {q['generated_at']} | RAG Iterative Retrieval System</div>
</div>
<script>
function switchTab(name, btn) {{
    document.querySelectorAll('.tab-content').forEach(function(el) {{ el.classList.remove('active'); }});
    document.querySelectorAll('.tab-btn').forEach(function(el) {{ el.classList.remove('active'); }});
    document.getElementById('tab-' + name).classList.add('active');
    btn.classList.add('active');
}}
</script>
</body>
</html>"""
