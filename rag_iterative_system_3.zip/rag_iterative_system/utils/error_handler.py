# -*- coding: utf-8 -*-
"""
全局异常处理与重试机制
- 检索异常捕获
- 自动重试与退避
- 服务降级兜底
- 空结果保护
"""

from __future__ import annotations

import functools
import logging
import time
from typing import Any, Callable, TypeVar, Optional

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


class RAGSystemError(Exception):
    """RAG系统基础异常"""
    pass


class LLMCallError(RAGSystemError):
    """LLM调用异常"""
    pass


class RetrievalError(RAGSystemError):
    """检索异常"""
    pass


class RoutingError(RAGSystemError):
    """路由异常"""
    pass


class EvaluationError(RAGSystemError):
    """评估异常"""
    pass


class ContextOverflowError(RAGSystemError):
    """上下文超限异常"""
    pass


def retry_with_backoff(
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 30.0,
    exceptions: tuple = (Exception,),
    fallback: Optional[Any] = None,
) -> Callable:
    """
    自动重试装饰器（指数退避）

    Args:
        max_retries: 最大重试次数
        base_delay: 基础延迟（秒）
        max_delay: 最大延迟（秒）
        exceptions: 需要重试的异常类型
        fallback: 全部重试失败后的降级返回值
    """

    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            last_error: Optional[Exception] = None
            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    last_error = e
                    if attempt < max_retries:
                        delay = min(base_delay * (2 ** attempt), max_delay)
                        logger.warning(
                            "%s 第%d次失败，%.1f秒后重试: %s",
                            func.__name__,
                            attempt + 1,
                            delay,
                            str(e)[:200],
                        )
                        time.sleep(delay)
                    else:
                        logger.error(
                            "%s 重试%d次后仍失败: %s",
                            func.__name__,
                            max_retries,
                            str(e)[:200],
                        )

            if fallback is not None:
                logger.warning(
                    "%s 全部重试失败，返回降级值", func.__name__
                )
                return fallback

            raise last_error  # type: ignore[misc]

        return wrapper  # type: ignore[return-value]

    return decorator


def safe_execute(
    func: Callable,
    *args: Any,
    default: Any = None,
    log_error: bool = True,
    **kwargs: Any,
) -> Any:
    """
    安全执行函数，异常时返回默认值

    Args:
        func: 要执行的函数
        default: 异常时返回的默认值
        log_error: 是否记录错误日志
    """
    try:
        return func(*args, **kwargs)
    except Exception as e:
        if log_error:
            logger.error(
                "safe_execute %s 失败: %s",
                getattr(func, "__name__", "unknown"),
                str(e)[:200],
            )
        return default


def truncate_context(text: str, max_length: int = 8000) -> str:
    """
    截断过长的上下文文本，防止溢出

    Args:
        text: 原始文本
        max_length: 最大字符长度

    Returns:
        截断后的文本（附加省略标记）
    """
    if len(text) <= max_length:
        return text
    truncated = text[:max_length]
    return truncated + "\n\n[...内容过长已截断，原文共%d字符...]" % len(text)


def validate_state_integrity(state: dict) -> list:
    """
    校验状态完整性，防止异常状态传播

    Args:
        state: 当前图状态

    Returns:
        校验发现的问题列表（空列表表示无问题）
    """
    issues: list = []
    if not state.get("original_query", "").strip():
        issues.append("原始查询为空")
    if state.get("iteration_count", 0) < 0:
        issues.append("迭代轮次为负数")
    if state.get("no_gain_rounds", 0) < 0:
        issues.append("无增益轮次为负数")

    doc_history = state.get("document_history", [])
    if len(doc_history) > 50:
        issues.append(f"历史文档数超限: {len(doc_history)}")

    return issues
