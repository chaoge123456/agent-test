# -*- coding: utf-8 -*-
"""
文档去重、低质内容过滤、重复内容剔除规则
- 精确去重（内容哈希 / 层次化ID）
- 近似去重（相似度阈值）
- 低质文档过滤
- 上下文长度裁剪
- 支持RetrievalResult结构
"""

from __future__ import annotations

import logging
from typing import List, Set

from rag_iterative_system.config.system_settings import get_settings
from rag_iterative_system.evaluation.metrics import (
    cosine_similarity_text,
    doc_content_hash,
    result_dedup_key,
)
from rag_iterative_system.state.graph_state import Document, RetrievalResult

logger = logging.getLogger(__name__)


def deduplicate_exact(documents: List[Document]) -> List[Document]:
    """
    精确去重：基于内容哈希移除完全相同的文档

    Args:
        documents: 待去重文档列表

    Returns:
        去重后的文档列表
    """
    seen_hashes: Set[str] = set()
    unique_docs: List[Document] = []

    for doc in documents:
        # 优先使用层次化ID去重
        if isinstance(doc, RetrievalResult):
            key = result_dedup_key(doc)
        else:
            key = doc_content_hash(doc)

        if key not in seen_hashes:
            seen_hashes.add(key)
            unique_docs.append(doc)

    removed = len(documents) - len(unique_docs)
    if removed > 0:
        logger.debug("精确去重: 移除%d个重复文档", removed)

    return unique_docs


def deduplicate_near(
    documents: List[Document],
    threshold: float = 0.95,
) -> List[Document]:
    """
    近似去重：基于文本相似度移除高度相似的文档

    保留每组相似文档中评分最高的那个

    Args:
        documents: 待去重文档列表
        threshold: 相似度阈值，高于此值视为近似重复

    Returns:
        去重后的文档列表
    """
    if len(documents) <= 1:
        return documents

    sorted_docs = sorted(documents, key=lambda d: d.score, reverse=True)
    kept: List[Document] = []

    for doc in sorted_docs:
        is_duplicate = False
        for kept_doc in kept:
            sim = cosine_similarity_text(doc.content, kept_doc.content)
            if sim >= threshold:
                is_duplicate = True
                break
        if not is_duplicate:
            kept.append(doc)

    removed = len(documents) - len(kept)
    if removed > 0:
        logger.debug("近似去重: 移除%d个近似重复文档（阈值=%.2f）", removed, threshold)

    return kept


def deduplicate_against_history(
    new_docs: List[Document],
    history_docs: List[Document],
    threshold: float = 0.95,
) -> List[Document]:
    """
    对比历史文档去重：移除与已有历史文档高度重复的新文档

    优先按层次化ID精确匹配，再用文本相似度

    Args:
        new_docs: 新检索到的文档
        history_docs: 已有历史优质文档
        threshold: 相似度阈值

    Returns:
        去重后的新文档列表
    """
    if not history_docs:
        return new_docs

    # 收集历史文档的层次化ID集合
    history_id_keys: Set[str] = set()
    for doc in history_docs:
        if isinstance(doc, RetrievalResult):
            key = result_dedup_key(doc)
            history_id_keys.add(key)

    kept: List[Document] = []
    for doc in new_docs:
        # 优先精确ID匹配
        if isinstance(doc, RetrievalResult):
            key = result_dedup_key(doc)
            if key in history_id_keys:
                continue

        # 文本相似度匹配
        is_duplicate = False
        for hist_doc in history_docs:
            sim = cosine_similarity_text(doc.content, hist_doc.content)
            if sim >= threshold:
                is_duplicate = True
                break
        if not is_duplicate:
            kept.append(doc)

    removed = len(new_docs) - len(kept)
    if removed > 0:
        logger.debug("历史去重: 移除%d个与历史重复文档", removed)

    return kept


def filter_low_quality(
    documents: List[Document],
    min_length: int = 20,
    min_score: float = 0.3,
) -> List[Document]:
    """
    低质文档过滤

    过滤条件:
    1. 文档内容过短（低于最小长度）
    2. 相似度分数过低（低于最低阈值）

    Args:
        documents: 待过滤文档列表
        min_length: 最短有效文档字符数
        min_score: 最低相似度分数

    Returns:
        过滤后的文档列表
    """
    filtered: List[Document] = []
    for doc in documents:
        if len(doc.content.strip()) < min_length:
            logger.debug("过滤低质文档: 内容过短 (%d字符)", len(doc.content.strip()))
            continue
        if doc.score < min_score:
            logger.debug("过滤低质文档: 分数过低 (%.3f)", doc.score)
            continue
        filtered.append(doc)

    removed = len(documents) - len(filtered)
    if removed > 0:
        logger.debug("低质过滤: 移除%d个低质文档", removed)

    return filtered


def truncate_documents(
    documents: List[Document],
    max_context_length: int = 8000,
) -> List[Document]:
    """
    文档集合长度裁剪

    当文档总长度超过限制时，按优先级（相似度分数）裁剪

    Args:
        documents: 待裁剪文档列表
        max_context_length: 最大上下文字符长度

    Returns:
        裁剪后的文档列表
    """
    settings = get_settings()

    sorted_docs = sorted(documents, key=lambda d: d.score, reverse=True)

    total_length = 0
    kept: List[Document] = []

    for doc in sorted_docs:
        doc_length = len(doc.content)
        if total_length + doc_length <= max_context_length:
            kept.append(doc)
            total_length += doc_length
        else:
            remaining = max_context_length - total_length
            if remaining >= settings.min_doc_length:
                truncated_doc = RetrievalResult(
                    doc_id=doc.doc_id if isinstance(doc, RetrievalResult) else "",
                    page_id=doc.page_id if isinstance(doc, RetrievalResult) else "",
                    chunk_id=doc.chunk_id if isinstance(doc, RetrievalResult) else "",
                    content=doc.content[:remaining] + "\n[...内容已截断...]",
                    source=doc.source,
                    score=doc.score,
                    metadata=doc.metadata if isinstance(doc, RetrievalResult) else getattr(doc, "metadata", {}),
                )
                kept.append(truncated_doc)
                total_length += remaining
            break

    if len(kept) < len(documents):
        logger.debug(
            "上下文裁剪: %d/%d文档保留, 总长度=%d",
            len(kept),
            len(documents),
            total_length,
        )

    return kept


def full_filter_pipeline(
    documents: List[Document],
    history_docs: List[Document] | None = None,
) -> List[Document]:
    """
    完整过滤流水线

    执行顺序: 低质过滤 -> 精确去重 -> 近似去重 -> 历史去重 -> 长度裁剪

    Args:
        documents: 原始检索文档
        history_docs: 已有历史优质文档

    Returns:
        过滤后的优质文档列表
    """
    settings = get_settings()
    history = history_docs or []

    # 1. 低质过滤
    result = filter_low_quality(
        documents,
        min_length=settings.min_doc_length,
        min_score=settings.score_threshold,
    )

    # 2. 精确去重
    result = deduplicate_exact(result)

    # 3. 近似去重
    result = deduplicate_near(
        result,
        threshold=settings.dedup_similarity_threshold,
    )

    # 4. 历史去重
    if history:
        result = deduplicate_against_history(
            result,
            history,
            threshold=settings.dedup_similarity_threshold,
        )

    # 5. 长度裁剪
    result = truncate_documents(
        result,
        max_context_length=settings.max_context_length,
    )

    logger.info(
        "过滤流水线完成: 输入=%d, 输出=%d",
        len(documents),
        len(result),
    )

    return result
