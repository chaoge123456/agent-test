# -*- coding: utf-8 -*-
"""
多知识库元数据、能力描述、检索配置管理
- 知识库注册与元数据管理
- 检索工具注册（函数式 + JSON Schema）
- 默认知识库概念
- 每个KB必须注册doc/page/chunk三级检索函数
- 支持动态注册新知识库
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class RetrievalMode(str, Enum):
    """检索模式枚举"""
    VECTOR = "vector"           # 向量语义检索
    KEYWORD = "keyword"         # 关键词检索
    HYBRID = "hybrid"           # 混合检索


class RetrievalGranularity(str, Enum):
    """检索粒度枚举"""
    DOCUMENT = "document"       # 文档级
    PAGE = "page"               # 页面级
    CHUNK = "chunk"             # chunk级


# ============================================================
# 检索工具定义
# ============================================================

@dataclass
class RetrievalToolSchema:
    """
    检索工具的JSON Schema描述

    类似OpenAI Function Calling方式，
    每个检索函数附带JSON Schema描述输入输出格式
    """
    # 输入参数JSON Schema
    input_schema: Dict[str, Any] = field(default_factory=dict)
    # 输出格式JSON Schema
    output_schema: Dict[str, Any] = field(default_factory=dict)
    # 适用场景描述
    scenario: str = ""


@dataclass
class RetrievalTool:
    """
    检索工具：一个知识库中某个粒度的检索函数

    每个工具绑定:
    - 函数本体（Callable）
    - 粒度标记（document/page/chunk）
    - JSON Schema描述（输入输出格式）
    - 适用场景标注
    """
    name: str                                               # 工具注册名（如 "tech_docs__document"）
    granularity: RetrievalGranularity                       # 检索粒度
    func: Callable                                          # 检索函数本体
    description: str = ""                                   # 工具能力描述
    schema: RetrievalToolSchema = field(default_factory=RetrievalToolSchema)

    @property
    def tool_id(self) -> str:
        """工具唯一标识"""
        return self.name


# ============================================================
# 知识库配置
# ============================================================

@dataclass
class KnowledgeBaseConfig:
    """单个知识库配置"""
    kb_id: str                              # 知识库唯一标识
    name: str                               # 知识库显示名称
    description: str                        # 知识库能力描述（供路由模块决策）
    domains: List[str] = field(default_factory=list)  # 覆盖领域标签
    retrieval_mode: RetrievalMode = RetrievalMode.VECTOR
    top_k: int = 5                          # 默认检索文档数量
    score_threshold: float = 0.5            # 最低相似度阈值
    enabled: bool = True                    # 是否启用
    is_default: bool = False                # 是否为默认知识库
    extra: Dict[str, Any] = field(default_factory=dict)  # 扩展参数


# ============================================================
# 知识库注册中心
# ============================================================

class KnowledgeBaseRegistry:
    """
    知识库注册中心

    职责:
    - 管理知识库元数据
    - 管理检索工具（每个KB多个工具，按粒度区分）
    - 默认知识库管理
    - 为路由模块提供决策上下文（含工具Schema）
    - 校验每个KB必须注册doc/page/chunk三级检索函数
    """

    def __init__(self) -> None:
        self._registries: Dict[str, KnowledgeBaseConfig] = {}
        # kb_id -> {tool_name: RetrievalTool}
        self._tools: Dict[str, Dict[str, RetrievalTool]] = {}
        self._default_kb_id: Optional[str] = None

    def register(
        self,
        config: KnowledgeBaseConfig,
        retrieval_func: Optional[Callable] = None,
    ) -> None:
        """注册知识库"""
        self._registries[config.kb_id] = config

        # 默认知识库逻辑：只注册一个KB时自动成为默认；多个时需显式指定
        if config.is_default:
            self._default_kb_id = config.kb_id
        elif len(self._registries) == 1 and self._default_kb_id is None:
            self._default_kb_id = config.kb_id

        # 向后兼容：如果传入单个retrieval_func，注册为chunk级工具
        if retrieval_func is not None:
            tool_name = f"{config.kb_id}__chunk"
            self._tools.setdefault(config.kb_id, {})
            self._tools[config.kb_id][tool_name] = RetrievalTool(
                name=tool_name,
                granularity=RetrievalGranularity.CHUNK,
                func=retrieval_func,
                description=f"知识库 {config.name} 的chunk级检索",
            )

        logger.info(
            "注册知识库: %s (%s), 默认=%s",
            config.kb_id, config.name, config.is_default,
        )

    def register_tool(
        self,
        kb_id: str,
        tool: RetrievalTool,
    ) -> None:
        """
        为知识库注册检索工具

        Args:
            kb_id: 知识库ID
            tool: 检索工具实例
        """
        if kb_id not in self._registries:
            raise KeyError(f"知识库未注册: {kb_id}，请先注册知识库")

        self._tools.setdefault(kb_id, {})
        self._tools[kb_id][tool.name] = tool
        logger.info(
            "注册检索工具: %s (KB=%s, 粒度=%s)",
            tool.name, kb_id, tool.granularity.value,
        )

    def validate_kb_tools(self, kb_id: str) -> List[str]:
        """
        校验知识库是否注册了doc/page/chunk三级检索函数

        Returns:
            缺失粒度列表（空列表表示校验通过）
        """
        if kb_id not in self._tools:
            return ["document", "page", "chunk"]

        kb_tools = self._tools[kb_id]
        registered_granularities = {t.granularity.value for t in kb_tools.values()}
        required = {"document", "page", "chunk"}
        missing = required - registered_granularities
        return sorted(missing)

    def get(self, kb_id: str) -> KnowledgeBaseConfig:
        """获取知识库配置"""
        if kb_id not in self._registries:
            raise KeyError(f"知识库未注册: {kb_id}")
        return self._registries[kb_id]

    def get_default_kb_id(self) -> Optional[str]:
        """获取默认知识库ID"""
        if self._default_kb_id and self._default_kb_id in self._registries:
            return self._default_kb_id
        enabled = [c for c in self._registries.values() if c.enabled]
        if len(enabled) == 1:
            return enabled[0].kb_id
        return None

    def set_default_kb(self, kb_id: str) -> None:
        """显式设置默认知识库"""
        if kb_id not in self._registries:
            raise KeyError(f"知识库未注册: {kb_id}")
        for config in self._registries.values():
            config.is_default = False
        self._registries[kb_id].is_default = True
        self._default_kb_id = kb_id
        logger.info("设置默认知识库: %s", kb_id)

    def get_retrieval_func(self, kb_id: str) -> Callable:
        """
        获取知识库检索函数（向后兼容）

        优先返回chunk级工具函数，否则返回任意可用工具函数
        """
        if kb_id in self._tools and self._tools[kb_id]:
            tools = self._tools[kb_id]
            for tool in tools.values():
                if tool.granularity == RetrievalGranularity.CHUNK:
                    return tool.func
            return next(iter(tools.values())).func
        raise KeyError(f"知识库检索函数未注册: {kb_id}")

    def get_tool(self, kb_id: str, tool_name: str) -> RetrievalTool:
        """获取指定检索工具"""
        if kb_id not in self._tools or tool_name not in self._tools[kb_id]:
            raise KeyError(f"检索工具未注册: {kb_id}/{tool_name}")
        return self._tools[kb_id][tool_name]

    def get_tools_by_granularity(
        self, kb_id: str, granularity: RetrievalGranularity
    ) -> List[RetrievalTool]:
        """获取知识库中指定粒度的所有检索工具"""
        if kb_id not in self._tools:
            return []
        return [
            t for t in self._tools[kb_id].values()
            if t.granularity == granularity
        ]

    def get_all_tools(self, kb_id: str) -> List[RetrievalTool]:
        """获取知识库的所有检索工具"""
        if kb_id not in self._tools:
            return []
        return list(self._tools[kb_id].values())

    def list_enabled(self) -> List[KnowledgeBaseConfig]:
        """列出所有已启用的知识库"""
        return [c for c in self._registries.values() if c.enabled]

    def list_all(self) -> List[KnowledgeBaseConfig]:
        """列出所有知识库"""
        return list(self._registries.values())

    def get_descriptions_for_routing(self) -> str:
        """生成供路由LLM决策使用的知识库+工具描述文本"""
        lines: List[str] = []
        for kb in self.list_enabled():
            domains = ", ".join(kb.domains) if kb.domains else "通用"
            default_mark = " [默认]" if kb.is_default else ""
            lines.append(
                f"- ID: {kb.kb_id} | 名称: {kb.name}{default_mark} | "
                f"领域: {domains} | 描述: {kb.description} | "
                f"检索模式: {kb.retrieval_mode.value} | 默认TopK: {kb.top_k}"
            )
            # 列出该KB的所有检索工具
            tools = self.get_all_tools(kb.kb_id)
            for tool in tools:
                scenario = f" | 场景: {tool.schema.scenario}" if tool.schema.scenario else ""
                lines.append(
                    f"  工具: {tool.name} | 粒度: {tool.granularity.value} | "
                    f"描述: {tool.description}{scenario}"
                )
                if tool.schema.input_schema:
                    lines.append(f"    输入Schema: {tool.schema.input_schema}")

        return "\n".join(lines)

    def unregister(self, kb_id: str) -> None:
        """移除知识库"""
        self._registries.pop(kb_id, None)
        self._tools.pop(kb_id, None)
        if self._default_kb_id == kb_id:
            self._default_kb_id = None
        logger.info("移除知识库: %s", kb_id)


# ============================================================
# 向后兼容别名
# ============================================================

@dataclass
class RoutingTarget:
    """路由决策结果 - 单个知识库的检索指令（向后兼容）"""
    kb_id: str
    queries: List[str]                      # 该知识库使用的检索查询列表
    retrieval_mode: RetrievalMode
    top_k: int
    score_threshold: float
    extra: Dict[str, Any] = field(default_factory=dict)


# 全局注册中心单例
_registry = KnowledgeBaseRegistry()


def get_registry() -> KnowledgeBaseRegistry:
    """获取全局知识库注册中心"""
    return _registry


def register_knowledge_base(
    kb_id: str,
    name: str,
    description: str,
    domains: Optional[List[str]] = None,
    retrieval_mode: RetrievalMode = RetrievalMode.VECTOR,
    top_k: int = 5,
    score_threshold: float = 0.5,
    retrieval_func: Optional[Callable] = None,
    is_default: bool = False,
    **extra: Any,
) -> None:
    """便捷函数：注册知识库"""
    config = KnowledgeBaseConfig(
        kb_id=kb_id,
        name=name,
        description=description,
        domains=domains or [],
        retrieval_mode=retrieval_mode,
        top_k=top_k,
        score_threshold=score_threshold,
        is_default=is_default,
        extra=extra,
    )
    _registry.register(config, retrieval_func)


def register_retrieval_tool(
    kb_id: str,
    tool_name: str,
    granularity: RetrievalGranularity,
    func: Callable,
    description: str = "",
    input_schema: Optional[Dict[str, Any]] = None,
    output_schema: Optional[Dict[str, Any]] = None,
    scenario: str = "",
) -> None:
    """
    便捷函数：为知识库注册检索工具

    Args:
        kb_id: 知识库ID
        tool_name: 工具名称
        granularity: 检索粒度
        func: 检索函数
        description: 工具描述
        input_schema: 输入JSON Schema
        output_schema: 输出JSON Schema
        scenario: 适用场景
    """
    tool = RetrievalTool(
        name=tool_name,
        granularity=granularity,
        func=func,
        description=description,
        schema=RetrievalToolSchema(
            input_schema=input_schema or {},
            output_schema=output_schema or {},
            scenario=scenario,
        ),
    )
    _registry.register_tool(kb_id, tool)
