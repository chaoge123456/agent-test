# -*- coding: utf-8 -*-
"""
大模型连接配置与统一调用封装
- 全局单例管理LLM实例
- 统一调用规范: llm.call(prompt, system_prompt)
- 隔离模型接口差异，预留扩展接口
"""

from __future__ import annotations

import json
import logging
from typing import Any, Optional

from langchain_openai import ChatOpenAI
from pydantic import SecretStr

from rag_iterative_system.utils.error_handler import LLMCallError

logger = logging.getLogger(__name__)


class LLMAdapter:
    """
    大模型统一适配器

    设计原则:
    - 全局单例，通过 get_llm() 获取
    - 统一调用签名 call(prompt, system_prompt)
    - 支持模型热切换、接口扩容
    """

    _instance: Optional[LLMAdapter] = None

    def __init__(
        self,
        model_name: str = "gpt-4o",
        api_base: str = "https://api.openai.com/v1",
        api_key: str = "sk-placeholder",
        temperature: float = 0.0,
        max_tokens: int = 4096,
        timeout: int = 60,
        **kwargs: Any,
    ) -> None:
        self._llm = ChatOpenAI(
            model=model_name,
            base_url=api_base,
            api_key=SecretStr(api_key),
            temperature=temperature,
            max_completion_tokens=max_tokens,
            timeout=timeout,
            **kwargs,
        )
        logger.info(
            "LLMAdapter initialized: model=%s, api_base=%s",
            model_name,
            api_base,
        )

    @classmethod
    def initialize(
        cls,
        model_name: str = "gpt-4o",
        api_base: str = "https://api.openai.com/v1",
        api_key: str = "sk-placeholder",
        temperature: float = 0.0,
        max_tokens: int = 4096,
        timeout: int = 60,
        **kwargs: Any,
    ) -> LLMAdapter:
        """初始化全局单例"""
        cls._instance = cls(
            model_name=model_name,
            api_base=api_base,
            api_key=api_key,
            temperature=temperature,
            max_tokens=max_tokens,
            timeout=timeout,
            **kwargs,
        )
        return cls._instance

    @classmethod
    def get_instance(cls) -> LLMAdapter:
        """获取全局单例，未初始化时抛出异常"""
        if cls._instance is None:
            raise RuntimeError(
                "LLMAdapter 未初始化，请先调用 LLMAdapter.initialize()"
            )
        return cls._instance

    def call(self, prompt: str, system_prompt: str = "") -> str:
        """
        统一LLM调用接口

        Args:
            prompt: 用户提示词
            system_prompt: 系统提示词（可选）

        Returns:
            模型生成的文本内容
        """
        from langchain_core.messages import HumanMessage, SystemMessage

        messages: list = []
        if system_prompt:
            messages.append(SystemMessage(content=system_prompt))
        messages.append(HumanMessage(content=prompt))

        try:
            response = self._llm.invoke(messages)
            content = response.content
            # content can be str or list (multi-modal); normalize to str
            if isinstance(content, list):
                content = "\n".join(
                    part if isinstance(part, str) else str(part)
                    for part in content
                )
            logger.debug(
                "LLM call success: prompt_len=%d, response_len=%d",
                len(prompt),
                len(content),
            )
            return content
        except Exception as e:
            logger.error("LLM call failed: %s", e)
            raise LLMCallError(str(e)) from e

    def call_json(self, prompt: str, system_prompt: str = "") -> dict:
        """
        调用LLM并解析JSON格式返回

        Args:
            prompt: 用户提示词
            system_prompt: 系统提示词

        Returns:
            解析后的字典

        Raises:
            ValueError: 返回内容无法解析为JSON
        """
        raw = self.call(prompt, system_prompt)
        # 尝试提取JSON块（兼容markdown代码块包裹）
        text = raw.strip()
        if text.startswith("```"):
            lines = text.split("\n")
            # 去掉首尾的```行
            lines = [l for l in lines if not l.strip().startswith("```")]
            text = "\n".join(lines)
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            logger.warning("LLM返回非标准JSON，尝试修复: %s", text[:200])
            # 尝试提取第一个 { ... } 块
            start = text.find("{")
            end = text.rfind("}") + 1
            if start != -1 and end > start:
                try:
                    return json.loads(text[start:end])
                except json.JSONDecodeError:
                    pass
            raise LLMCallError(f"无法解析LLM返回的JSON: {text[:200]}") from None

    @classmethod
    def reset(cls) -> None:
        """重置单例（主要用于测试）"""
        cls._instance = None


# ============================================================
# Mock LLM 适配器（测试用，无需真实 API Key）
# ============================================================


class MockLLMAdapter:
    """
    Mock LLM 适配器，用于测试模式

    根据系统提示词/用户提示词内容自动返回符合预期格式的响应，
    使整个 RAG 流程可以在无真实 API Key 时完整运行。
    """

    def __init__(self) -> None:
        self._query = ""

    def call(self, prompt: str, system_prompt: str = "") -> str:
        """返回通用文本响应"""
        return (
            f"这是一个关于「{prompt[:60]}...」的模拟回答。\n\n"
            "基于检索到的文档，以下是相关解答：\n"
            "1. 建议使用微服务架构实现分布式系统的高可用性\n"
            "2. 引入服务注册与发现机制（如Consul/Etcd）\n"
            "3. 采用多副本部署 + 负载均衡策略\n"
            "4. 实现断路器（Circuit Breaker）防止级联故障\n"
            "5. 使用异步消息队列解耦服务间通信\n\n"
            "[来源:tech_docs] [相关度:0.850]\n"
            "[来源:faq_kb] [相关度:0.720]\n"
        )

    def call_json(self, prompt: str, system_prompt: str = "") -> dict:
        """根据提示词内容返回符合预期格式的 JSON"""
        combined = (system_prompt + " " + prompt).lower()

        # 提取查询内容
        import re
        query_match = re.search(r"原始查询[:：]\s*(.+?)(?:\n|$)", prompt)
        if query_match:
            self._query = query_match.group(1).strip()

        # 路由决策: 有 pipelines + kb_id
        if "pipelines" in combined and "kb_id" in combined:
            return self._mock_routing(prompt)
        # 覆盖度判定: 有 is_covered
        if "is_covered" in combined and "覆盖" in combined:
            return self._mock_coverage_judgment(prompt)
        # 查询改写: 有 rewrites（必须在 need_decomposition 之前检查，因为改写 prompt 也含 need_decomposition）
        if "rewrites" in combined:
            return self._mock_rewrite(prompt)
        # 拆解判定: 有 need_decomposition
        if "need_decomposition" in combined:
            return self._mock_decomposition_judgment()
        # 兜底
        return {"rewrites": [self._query[:80] if self._query else prompt[:80]]}

    def _mock_rewrite(self, prompt: str) -> dict:
        return {
            "rewrites": [
                "分布式系统高可用架构设计方法",
                "分布式系统故障容错与恢复策略",
                "微服务高可用最佳实践",
            ]
        }

    def _mock_decomposition_judgment(self) -> dict:
        return {"need_decomposition": False, "reason": "查询为单一维度问题，无需拆解"}

    def _mock_routing(self, prompt: str) -> dict:
        return {
            "pipelines": [
                {
                    "kb_id": "tech_docs",
                    "steps": [
                        {
                            "tool_name": "tech_docs__document",
                            "granularity": "document",
                            "params": {"query": "分布式系统高可用架构设计方法", "top_k": 5},
                        },
                        {
                            "tool_name": "tech_docs__page",
                            "granularity": "page",
                            "params": {"query": "分布式系统高可用架构设计方法", "top_k": 5},
                        },
                        {
                            "tool_name": "tech_docs__chunk",
                            "granularity": "chunk",
                            "params": {"query": "分布式系统高可用架构设计方法", "top_k": 5},
                        },
                    ],
                    "reasoning": "技术文档库覆盖系统架构领域",
                },
                {
                    "kb_id": "faq_kb",
                    "steps": [
                        {
                            "tool_name": "faq_kb__chunk",
                            "granularity": "chunk",
                            "params": {"query": "高可用架构常见问题", "top_k": 3},
                        }
                    ],
                    "reasoning": "FAQ库可能包含常见问题",
                },
            ],
            "reasoning": "分布式架构查询需要技术文档+FAQ双源检索",
        }

    def _mock_coverage_judgment(self, prompt: str) -> dict:
        return {
            "is_covered": False,
            "coverage_analysis": "已检索到系统架构和容错策略相关内容，但缺少具体实现示例和性能指标",
            "uncovered_aspects": "缺少具体代码实现示例、性能基准数据、运维监控方案",
            "confidence": 0.45,
        }

    @classmethod
    def initialize(cls, **kwargs) -> "MockLLMAdapter":
        return cls()

    @classmethod
    def get_instance(cls) -> "MockLLMAdapter":
        return cls()

    @classmethod
    def reset(cls) -> None:
        pass


# ============================================================
# 便捷访问函数
# ============================================================

# 全局 mock 标记
_use_mock_llm: bool = False


def set_mock_mode(enabled: bool = True) -> None:
    """启用/禁用 Mock LLM 模式"""
    global _use_mock_llm
    _use_mock_llm = enabled


def is_mock_mode() -> bool:
    """检查是否处于 Mock 模式"""
    return _use_mock_llm


def get_llm():
    """
    获取全局LLM适配器实例

    自动根据 mock 模式返回 MockLLMAdapter 或真实的 LLMAdapter
    """
    if _use_mock_llm:
        return MockLLMAdapter.get_instance()
    return LLMAdapter.get_instance()
