# 层次化检索系统重构

## TL;DR

> **Quick Summary**: 重构迭代式RAG检索系统，引入层次化多粒度检索（文档级/页面级/chunk级）、检索函数JSON Schema注册机制、管道式路由决策与执行、可配置迭代开关、高置信度结果累加器。
> 
> **Deliverables**:
> - 统一检索结果格式 RetrievalResult（doc_id/page_id/chunk_id/content/source/score）
> - 检索函数注册体系 RetrievalTool + RetrievalToolRegistry（函数式注册 + JSON Schema）
> - 知识库强制三级注册（doc/page/chunk）+ 默认知识库机制
> - 管道式检索执行引擎（doc→page→chunk 自动传递）
> - 增强路由决策（生成检索函数列表 + 首函数输入）
> - 迭代式检索开关（enable_iterative_retrieval）
> - 高置信度结果累加器 ConfidenceAccumulator（得分阈值+信息增益双重筛选）
> - 全链路适配（所有节点、graph、main.py、README、测试）
> 
> **Estimated Effort**: Large
> **Parallel Execution**: YES - 5 waves
> **Critical Path**: Task 1 → Task 5 → Task 8 → Task 13 → Task 16

---

## Context

### Original Request
用户要求修改项目代码，实现8项需求：默认知识库+多KB注册、层次化检索结构、检索函数tools注册、管道式路由决策、路由给出首函数输入、迭代开关、迭代增强、高置信度累加器。

### Interview Summary
**Key Discussions**:
- 检索函数注册形式: 函数式注册 + JSON Schema（类OpenAI Function Calling）
- 跨知识库管道: 不允许，同一管道内同一KB
- 管道参数传递: 路由决策指定首函数输入，后续步骤自动从结果提取doc_id/page_id
- 置信度判定: reranker得分阈值 + 信息增益双重筛选
- 默认知识库: 只注册一个时自动默认；多个时显式指定；fallback到默认
- 检索函数粒度: 每个KB强制注册doc/page/chunk三级
- 测试策略: 实现后补充

**Research Findings**:
- 当前Document数据结构不含page_id/chunk_id，需全面替换为RetrievalResult
- 当前KnowledgeBaseRegistry每KB一个retrieval_func，需改为每KB三个tool
- 当前路由输出RoutingDecision.targets不含管道概念，需重构为pipelines
- 当前无迭代开关，需在SystemSettings和rag_graph中添加
- 当前document_history无置信度筛选，需替换为ConfidenceAccumulator

### Metis Review
**Identified Gaps** (addressed):
- 迭代开关需同时影响graph结构和节点内部逻辑：已规划在SystemSettings和rag_graph中同步处理
- 默认知识库fallback需防止无KB时死循环：已规划空KB校验
- ConfidenceAccumulator需考虑跨迭代累积：已规划为全局累积+去重
- 检索函数返回值需校验格式合规：已规划在Pipeline引擎中加入结果校验

---

## Work Objectives

### Core Objective
将现有的"每KB一个统一检索函数"架构重构为"层次化多粒度检索函数注册 + 管道式路由决策执行"架构，同时添加迭代开关和高置信度结果累加器。

### Concrete Deliverables
- `config/retrieval_tools.py` — RetrievalTool + RetrievalToolRegistry
- `retrieval/` 目录 — `retrieval_pipeline.py` + `confidence_accumulator.py`
- `config/knowledge_bases.py` — 重构：3-tool注册 + 默认KB
- `config/system_settings.py` — 新增 enable_iterative_retrieval, confidence_score_threshold
- `state/graph_state.py` — 重构：RetrievalResult, PipelineDecision, 新状态字段
- `nodes/router_node.py` — 重构：pipeline决策 + 首函数输入
- `nodes/retrieval_node.py` — 重构：管道式执行
- `nodes/evaluator_node.py` — 重构：适配RetrievalResult + 置信度累加
- `nodes/termination_node.py` — 重构：尊重迭代开关
- `nodes/answer_node.py` — 重构：使用ConfidenceAccumulator
- `graph/rag_graph.py` — 重构：条件迭代循环
- `main.py` — 适配新注册API
- `tests/` — 单元测试

### Definition of Done
- [ ] 所有检索函数返回统一的 RetrievalResult 格式
- [ ] 每个KB必须注册doc/page/chunk三级检索函数，否则报错
- [ ] 路由决策输出包含pipeline列表和首函数输入参数
- [ ] 检索管道按doc→page→chunk顺序执行，自动传递doc_id/page_id
- [ ] enable_iterative_retrieval=False时只执行一轮
- [ ] ConfidenceAccumulator通过得分阈值+信息增益筛选高置信度结果
- [ ] main.py可正常演示完整流程

### Must Have
- 统一RetrievalResult返回格式（doc_id/page_id/chunk_id/content/source/score）
- 每个KB强制三级检索函数注册
- 默认知识库机制（自动+可指定）
- 管道式检索执行（doc→page→chunk自动传递）
- 路由决策生成pipeline列表并指定首函数输入
- 迭代式检索开关
- 高置信度结果累加器（得分+增益双重筛选）

### Must NOT Have (Guardrails)
- 不允许跨知识库的检索管道
- 不修改评估算法（metrics.py）的内部实现
- 不修改日志系统（logging.py）的内部实现
- 不修改错误处理体系（error_handler.py）的异常类定义
- 不引入新的外部依赖（除已有langgraph/langchain外）
- 不改变LangGraph框架的使用方式
- 不添加过度抽象（如工厂模式、策略模式等AI slop）

---

## Verification Strategy (MANDATORY)

> **ZERO HUMAN INTERVENTION** - ALL verification is agent-executed. No exceptions.

### Test Decision
- **Infrastructure exists**: YES (当前无test目录，需新建)
- **Automated tests**: Tests-after
- **Framework**: pytest
- **测试文件**: tests/ 目录

### QA Policy
Every task MUST include agent-executed QA scenarios.
Evidence saved to `.sisyphus/evidence/task-{N}-{scenario-slug}.{ext}`.

- **Library/Module**: Use Bash (python -c) - Import, call functions, compare output
- **API/Backend**: Use Bash (python -m pytest) - Run test suite, assert pass

---

## Execution Strategy

### Parallel Execution Waves

```
Wave 1 (Start Immediately - foundation + data structures):
├── Task 1: 核心数据结构 (RetrievalResult, RetrievalTool, PipelineStep, RetrievalPipeline) [quick]
├── Task 2: SystemSettings更新 (enable_iterative_retrieval, confidence配置) [quick]
└── Task 3: RetrievalToolRegistry检索函数注册中心 [quick]

Wave 2 (After Wave 1 - core infrastructure, MAX PARALLEL):
├── Task 4: 重构knowledge_bases.py (3-tool注册 + 默认KB) (depends: 1, 3) [unspecified-high]
├── Task 5: 重构graph_state.py (RetrievalResult + pipeline字段 + confidence) (depends: 1) [unspecified-high]
├── Task 6: 检索管道执行引擎 (depends: 1, 3) [deep]
└── Task 7: 高置信度结果累加器 (depends: 1, 2) [unspecified-high]

Wave 3 (After Wave 2 - node refactoring, MAX PARALLEL):
├── Task 8: 重构router_node.py (pipeline决策 + 首函数输入) (depends: 3, 5) [deep]
├── Task 9: 重构retrieval_node.py (管道式执行) (depends: 5, 6) [unspecified-high]
├── Task 10: 重构evaluator_node.py (适配新结构 + 置信度累加) (depends: 5, 7) [unspecified-high]
├── Task 11: 重构termination_node.py (尊重迭代开关) (depends: 2, 5) [quick]
└── Task 12: 重构answer_node.py (使用ConfidenceAccumulator) (depends: 5, 7) [quick]

Wave 4 (After Wave 3 - integration):
├── Task 13: 重构rag_graph.py (条件迭代循环) (depends: 2, 8-12) [unspecified-high]
├── Task 14: 重构main.py + mock三级检索函数 (depends: 4, 13) [unspecified-high]
└── Task 15: 更新README.md (depends: all) [writing]

Wave 5 (After Wave 4 - testing):
└── Task 16: 单元测试 (depends: all) [deep]

Wave FINAL (After ALL tasks — 4 parallel reviews, then user okay):
├── Task F1: Plan compliance audit (oracle)
├── Task F2: Code quality review (unspecified-high)
├── Task F3: Real manual QA (unspecified-high)
└── Task F4: Scope fidelity check (deep)
-> Present results -> Get explicit user okay

Critical Path: Task 1 → Task 5 → Task 8 → Task 13 → Task 14 → Task 16 → F1-F4
Parallel Speedup: ~60% faster than sequential
Max Concurrent: 5 (Wave 3)
```

### Dependency Matrix

| Task | Depends On | Blocks | Wave |
|------|-----------|--------|------|
| 1 | - | 3,4,5,6,7 | 1 |
| 2 | - | 7,11,13 | 1 |
| 3 | 1 | 4,6,8 | 1 |
| 4 | 1,3 | 14 | 2 |
| 5 | 1 | 8,9,10,11,12 | 2 |
| 6 | 1,3 | 9 | 2 |
| 7 | 1,2 | 10,12 | 2 |
| 8 | 3,5 | 13 | 3 |
| 9 | 5,6 | 13 | 3 |
| 10 | 5,7 | 13 | 3 |
| 11 | 2,5 | 13 | 3 |
| 12 | 5,7 | 13 | 3 |
| 13 | 2,8,9,10,11,12 | 14 | 4 |
| 14 | 4,13 | 16 | 4 |
| 15 | all | - | 4 |
| 16 | all | F1-F4 | 5 |

### Agent Dispatch Summary

- **Wave 1**: **3** - T1→`quick`, T2→`quick`, T3→`quick`
- **Wave 2**: **4** - T4→`unspecified-high`, T5→`unspecified-high`, T6→`deep`, T7→`unspecified-high`
- **Wave 3**: **5** - T8→`deep`, T9→`unspecified-high`, T10→`unspecified-high`, T11→`quick`, T12→`quick`
- **Wave 4**: **3** - T13→`unspecified-high`, T14→`unspecified-high`, T15→`writing`
- **Wave 5**: **1** - T16→`deep`
- **FINAL**: **4** - F1→`oracle`, F2→`unspecified-high`, F3→`unspecified-high`, F4→`deep`

---

## TODOs

- [ ] 1. 核心数据结构定义 (RetrievalResult, RetrievalTool, PipelineStep, RetrievalPipeline)

  **What to do**:
  - 创建 `config/retrieval_tools.py`，定义以下数据类:
    - `RetrievalGranularity(str, Enum)`: DOCUMENT="document", PAGE="page", CHUNK="chunk"
    - `RetrievalResult`: dataclass(doc_id:str, page_id:Optional[str], chunk_id:Optional[str], content:str, source:str, score:float) — 这是统一的检索返回格式
    - `RetrievalTool`: dataclass(tool_id:str, kb_id:str, granularity:RetrievalGranularity, func:Callable, description:str, scenario:str, input_schema:dict, output_schema:dict) — 输入输出格式用JSON Schema描述
    - `PipelineStep`: dataclass(tool_id:str, kb_id:str, granularity:RetrievalGranularity, params:dict) — 管道中的单步，params包含该步的输入参数
    - `RetrievalPipeline`: dataclass(steps:List[PipelineStep], reasoning:str) — 完整管道，steps按doc→page→chunk顺序
  - `RetrievalTool.input_schema` 示例:
    - 文档级: `{"type":"object","properties":{"query":{"type":"string"},"top_k":{"type":"integer","default":5}},"required":["query"]}`
    - 页面级: `{"type":"object","properties":{"query":{"type":"string"},"top_k":{"type":"integer","default":5},"doc_id_list":{"type":"array","items":{"type":"string"}}},"required":["query"]}`
    - chunk级: `{"type":"object","properties":{"query":{"type":"string"},"top_k":{"type":"integer","default":5},"doc_id_list":{"type":"array","items":{"type":"string"}},"page_id_list":{"type":"array","items":{"type":"string"}}},"required":["query"]}`
  - `RetrievalTool.output_schema` 统一: `{"type":"array","items":{"type":"object","properties":{"doc_id":{"type":"string"},"page_id":{"type":"string"},"chunk_id":{"type":"string"},"content":{"type":"string"},"source":{"type":"string"},"score":{"type":"number"}}}}`
  - 注意: 此文件只定义数据结构，不包含注册逻辑(注册在Task 3)

  **Must NOT do**:
  - 不要在此文件实现注册中心
  - 不要引入新的外部依赖
  - 不要过度抽象（不要用抽象基类、Protocol等）

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: 纯数据结构定义，逻辑简单
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 1 (with Tasks 2, 3)
  - **Blocks**: Tasks 3, 4, 5, 6, 7
  - **Blocked By**: None (can start immediately)

  **References**:
  **Pattern References**:
  - `config/knowledge_bases.py:19-37` — 当前RetrievalMode枚举和KnowledgeBaseConfig数据类风格，新数据类保持一致
  - `state/graph_state.py:18-25` — 当前Document数据类，RetrievalResult将替代它

  **API/Type References**:
  - `config/knowledge_bases.py:19-23` — RetrievalMode枚举模式，RetrievalGranularity类似

  **WHY Each Reference Matters**:
  - knowledge_bases.py的风格需保持一致（dataclass + Enum + field默认值）
  - Document的字段设计决定了哪些需要保留、哪些需要新增

  **Acceptance Criteria**:
  - [ ] `config/retrieval_tools.py` 文件存在
  - [ ] `python -c "from rag_iterative_system.config.retrieval_tools import RetrievalResult, RetrievalTool, PipelineStep, RetrievalPipeline, RetrievalGranularity"` 无报错
  - [ ] RetrievalResult包含doc_id, page_id, chunk_id, content, source, score字段
  - [ ] RetrievalTool包含tool_id, kb_id, granularity, func, description, scenario, input_schema, output_schema字段
  - [ ] PipelineStep包含tool_id, kb_id, granularity, params字段
  - [ ] RetrievalPipeline包含steps, reasoning字段

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: 数据结构实例化与属性访问
    Tool: Bash (python -c)
    Preconditions: config/retrieval_tools.py 已创建
    Steps:
      1. python -c "from rag_iterative_system.config.retrieval_tools import RetrievalResult, RetrievalGranularity; r = RetrievalResult(doc_id='d1', page_id=None, chunk_id=None, content='摘要', source='kb1', score=0.9); assert r.doc_id == 'd1'; assert r.page_id is None; assert r.granularity is None or True; print('PASS')"
      2. python -c "from rag_iterative_system.config.retrieval_tools import RetrievalTool, RetrievalGranularity; t = RetrievalTool(tool_id='kb1_doc', kb_id='kb1', granularity=RetrievalGranularity.DOCUMENT, func=lambda x:x, description='test', scenario='文档定位', input_schema={}, output_schema={}); assert t.tool_id == 'kb1_doc'; print('PASS')"
    Expected Result: 两个PASS输出
    Failure Indicators: ImportError, AttributeError, AssertionError
    Evidence: .sisyphus/evidence/task-1-dataclass-instantiation.txt

  Scenario: 粒度枚举值完整性
    Tool: Bash (python -c)
    Preconditions: None
    Steps:
      1. python -c "from rag_iterative_system.config.retrieval_tools import RetrievalGranularity; vals = [g.value for g in RetrievalGranularity]; assert 'document' in vals; assert 'page' in vals; assert 'chunk' in vals; print('PASS')"
    Expected Result: PASS
    Failure Indicators: 缺少粒度值
    Evidence: .sisyphus/evidence/task-1-granularity-enum.txt
  ```

  **Commit**: YES (groups with Tasks 2, 3)
  - Message: `refactor(data): add hierarchical retrieval data structures and tool registry`
  - Files: `config/retrieval_tools.py`

- [ ] 2. SystemSettings更新 (enable_iterative_retrieval, confidence配置)

  **What to do**:
  - 修改 `config/system_settings.py`:
    - 在SystemSettings中新增字段:
      - `enable_iterative_retrieval: bool = False` — 迭代式检索开关，默认不开启
      - `confidence_score_threshold: float = 0.7` — 高置信度分数阈值
      - `confidence_gain_threshold: float = 0.1` — 高置信度信息增益阈值
    - 在 `load_settings()` 中添加环境变量覆盖:
      - `RAG_ENABLE_ITERATIVE_RETRIEVAL` (default: "false")
      - `RAG_CONFIDENCE_SCORE_THRESHOLD` (default: "0.7")
      - `RAG_CONFIDENCE_GAIN_THRESHOLD` (default: "0.1")

  **Must NOT do**:
  - 不要修改已有的参数默认值
  - 不要删除已有参数

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: 仅添加3个配置字段
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 1 (with Tasks 1, 3)
  - **Blocks**: Tasks 7, 11, 13
  - **Blocked By**: None (can start immediately)

  **References**:
  **Pattern References**:
  - `config/system_settings.py:16-61` — 当前SystemSettings结构，新增字段需保持风格一致
  - `config/system_settings.py:63-96` — load_settings()函数，环境变量覆盖模式

  **WHY Each Reference Matters**:
  - 需要严格按照现有命名风格和_env()模式添加新字段

  **Acceptance Criteria**:
  - [ ] SystemSettings包含enable_iterative_retrieval字段，默认False
  - [ ] SystemSettings包含confidence_score_threshold字段，默认0.7
  - [ ] SystemSettings包含confidence_gain_threshold字段，默认0.1
  - [ ] 环境变量RAG_ENABLE_ITERATIVE_RETRIEVAL可覆盖

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: 新配置字段默认值验证
    Tool: Bash (python -c)
    Preconditions: system_settings.py已修改
    Steps:
      1. python -c "from rag_iterative_system.config.system_settings import SystemSettings; s = SystemSettings(); assert s.enable_iterative_retrieval == False; assert s.confidence_score_threshold == 0.7; assert s.confidence_gain_threshold == 0.1; print('PASS')"
    Expected Result: PASS
    Failure Indicators: AttributeError, AssertionError
    Evidence: .sisyphus/evidence/task-2-settings-defaults.txt

  Scenario: 环境变量覆盖验证
    Tool: Bash (python)
    Preconditions: None
    Steps:
      1. 设置环境变量RAG_ENABLE_ITERATIVE_RETRIEVAL=true后调用load_settings()
      2. 验证enable_iterative_retrieval==True
    Expected Result: 环境变量优先级高于默认值
    Failure Indicators: 值仍为False
    Evidence: .sisyphus/evidence/task-2-settings-env-override.txt
  ```

  **Commit**: YES (groups with Tasks 1, 3)
  - Message: `refactor(data): add hierarchical retrieval data structures and tool registry`
  - Files: `config/system_settings.py`

- [ ] 3. RetrievalToolRegistry检索函数注册中心

  **What to do**:
  - 在 `config/retrieval_tools.py` 中（Task 1创建的文件）追加:
    - `RetrievalToolRegistry` 类:
      - `__init__()`: 初始化 `_tools: Dict[str, RetrievalTool]`
      - `register(tool: RetrievalTool) -> None`: 注册tool，以tool_id为key
      - `get(tool_id: str) -> RetrievalTool`: 获取tool
      - `get_tools_by_kb(kb_id: str) -> List[RetrievalTool]`: 获取某KB的所有tool
      - `get_tools_by_granularity(kb_id: str, granularity: RetrievalGranularity) -> List[RetrievalTool]`: 获取某KB某粒度的tool
      - `get_tool_for_pipeline_step(kb_id: str, granularity: RetrievalGranularity) -> RetrievalTool`: 获取某KB某粒度的唯一tool（强制三级注册保证唯一）
      - `list_all() -> List[RetrievalTool]`: 列出所有tool
      - `get_tool_descriptions_for_routing() -> str`: 生成供路由LLM决策使用的tool描述文本（含tool_id, kb_id, granularity, scenario, input_schema概要）
    - 全局单例 `_tool_registry = RetrievalToolRegistry()`
    - 便捷函数 `get_tool_registry() -> RetrievalToolRegistry`
    - 便捷注册函数 `register_retrieval_tool(tool_id, kb_id, granularity, func, description, scenario, input_schema, output_schema) -> None`
  - 注意: Task 1在config/retrieval_tools.py中创建数据结构，Task 3在同一个文件中追加注册中心逻辑

  **Must NOT do**:
  - 不要在此文件中实现检索执行逻辑
  - 不要引入新的外部依赖

  **Recommended Agent Profile**:
  - **Category**: `quick`
    - Reason: 注册中心模式简单，与现有KnowledgeBaseRegistry一致
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 1 (with Tasks 1, 2)
  - **Blocks**: Tasks 4, 6, 8
  - **Blocked By**: Task 1 (需要数据结构定义)

  **References**:
  **Pattern References**:
  - `config/knowledge_bases.py:55-117` — 当前KnowledgeBaseRegistry实现，新Registry保持一致模式
  - `config/knowledge_bases.py:100-110` — get_descriptions_for_routing()模式，新Registry需类似方法

  **WHY Each Reference Matters**:
  - 注册中心的API设计需与现有KnowledgeBaseRegistry风格一致
  - 路由描述生成方法需参考现有实现

  **Acceptance Criteria**:
  - [ ] RetrievalToolRegistry包含register/get/get_tools_by_kb/get_tools_by_granularity/get_tool_for_pipeline_step方法
  - [ ] get_tool_descriptions_for_routing()返回包含tool_id/kb_id/granularity/scenario/input_schema概要的文本
  - [ ] register_retrieval_tool()便捷函数可用
  - [ ] `python -c "from rag_iterative_system.config.retrieval_tools import get_tool_registry"` 无报错

  **QA Scenarios (MANDATORY):**

  ```
  Scenario: 注册和查询检索工具
    Tool: Bash (python -c)
    Preconditions: Task 1完成
    Steps:
      1. 注册3个tool(doc/page/chunk)到同一kb_id
      2. get_tools_by_kb(kb_id)返回3个tool
      3. get_tool_for_pipeline_step(kb_id, RetrievalGranularity.DOCUMENT)返回文档级tool
    Expected Result: 注册成功，查询返回正确结果
    Failure Indicators: KeyError, 数量不匹配
    Evidence: .sisyphus/evidence/task-3-tool-registry.txt

  Scenario: 路由描述生成
    Tool: Bash (python)
    Preconditions: 已注册tools
    Steps:
      1. 调用get_tool_descriptions_for_routing()
      2. 验证返回文本包含tool_id, granularity, scenario信息
    Expected Result: 格式化的描述文本
    Failure Indicators: 空字符串或缺少关键字段
    Evidence: .sisyphus/evidence/task-3-routing-descriptions.txt
  ```

  **Commit**: YES (groups with Tasks 1, 2)
  - Message: `refactor(data): add hierarchical retrieval data structures and tool registry`
  - Files: `config/retrieval_tools.py`

- [ ] 4. 重构knowledge_bases.py (3-tool注册 + 默认KB)

  **What to do**:
  - 修改 `config/knowledge_bases.py`:
    - 修改 `KnowledgeBaseConfig`: 移除 `retrieval_mode` 字段（粒度信息由tool管理），新增 `is_default: bool = False`
    - 修改 `KnowledgeBaseRegistry`:
      - `__init__()`: 新增 `_default_kb_id: Optional[str] = None`
      - `register()`: 不再接收 retrieval_func 参数；注册后检查是否只有一个KB（自动设为默认）；如果是is_default=True，设置_default_kb_id
      - `get_default() -> KnowledgeBaseConfig`: 获取默认KB（无默认时返回第一个enabled的）
      - `set_default(kb_id: str)`: 显式设置默认KB
      - 移除 `get_retrieval_func()` 和 `_retrieval_funcs`（检索函数由RetrievalToolRegistry管理）
      - `get_descriptions_for_routing()`: 更新格式，标注默认KB
    - 修改 `RoutingTarget`: 移除 retrieval_mode, 新增 `pipeline_steps: List[Dict]` (描述管道步骤)
    - 修改 `register_knowledge_base()` 便捷函数: 移除 retrieval_func/retrieval_mode 参数，新增 is_default 参数
    - 新增 `register_knowledge_base_with_tools()` 便捷函数: 接收kb配置 + 3个检索函数(doc_func, page_func, chunk_func)，同时注册KB到KBRegistry和3个tool到ToolRegistry
    - 在 `register_knowledge_base_with_tools()` 中强制校验: 3个函数都不为None，否则抛出ValueError
  - 在文件顶部新增: `from rag_iterative_system.config.retrieval_tools import (RetrievalTool, RetrievalGranularity, get_tool_registry, register_retrieval_tool)`

  **Must NOT do**:
  - 不要保留旧的 retrieval_func 注册接口（完全迁移到tool体系）
  - 不要在KB层实现检索执行逻辑

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 2 (with Tasks 5, 6, 7)
  - **Blocks**: Task 14
  - **Blocked By**: Tasks 1, 3

  **References**:
  - `config/knowledge_bases.py:55-117` — 当前KnowledgeBaseRegistry完整实现，需重构
  - `config/knowledge_bases.py:128-150` — 当前register_knowledge_base()便捷函数，需重写
  - `config/retrieval_tools.py` — Task 1&3创建的RetrievalTool/RetrievalGranularity/register_retrieval_tool

  **Acceptance Criteria**:
  - [ ] KnowledgeBaseRegistry.register()不再接收retrieval_func
  - [ ] get_default()返回默认KB
  - [ ] register_knowledge_base_with_tools()同时注册KB和3个tool
  - [ ] 只注册1个KB时自动成为默认
  - [ ] 缺少任一检索函数时ValueError

  **QA Scenarios:**
  ```
  Scenario: 三级注册 + 默认KB自动设置
    Tool: Bash (python -c)
    Steps:
      1. 注册一个KB及3个检索函数
      2. get_registry().get_default() 返回该KB
      3. get_tool_registry().get_tools_by_kb(kb_id) 返回3个tool
    Expected Result: 默认KB自动设置，3个tool注册成功
    Evidence: .sisyphus/evidence/task-4-kb-3tool-register.txt

  Scenario: 缺少检索函数报错
    Tool: Bash (python -c)
    Steps:
      1. 调用register_knowledge_base_with_tools()但page_func=None
      2. 应抛出ValueError
    Expected Result: ValueError异常
    Evidence: .sisyphus/evidence/task-4-missing-func-error.txt
  ```

  **Commit**: YES (groups with Wave 2)
  - Message: `refactor(core): refactor KB registration, graph state, pipeline engine, accumulator`
  - Files: `config/knowledge_bases.py`

- [ ] 5. 重构graph_state.py (RetrievalResult + pipeline字段 + confidence)

  **What to do**:
  - 修改 `state/graph_state.py`:
    - 将 `Document` dataclass 替换为 `RetrievalResult` (从config.retrieval_tools导入)
    - 修改 `RoutingDecision` dataclass:
      - 移除 `targets: List[Dict[str, Any]]`
      - 新增 `pipelines: List[RetrievalPipeline]`
      - 保留 `reasoning: str`
    - 修改 `GraphState` TypedDict:
      - `raw_documents` → `retrieval_results: Annotated[list, operator.add]` — 存储RetrievalResult列表
      - `filtered_documents` → `filtered_results: List[RetrievalResult]`
      - `document_history` → `confidence_results: List[RetrievalResult]` — 高置信度结果
      - 移除 `retrieval_granularity`, `candidate_doc_ids`, `candidate_page_ids`
      - 新增 `current_pipeline: RetrievalPipeline`
      - 新增 `pipeline_results: Annotated[list, operator.add]`
    - 修改 `create_initial_state()`: 更新所有字段名和初始值

  **Must NOT do**:
  - 不要同时保留Document和RetrievalResult两套体系（完全迁移）

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 2 (with Tasks 4, 6, 7)
  - **Blocks**: Tasks 8, 9, 10, 11, 12
  - **Blocked By**: Task 1

  **References**:
  - `state/graph_state.py:18-45` — 当前Document/RoutingDecision/IterationLog
  - `state/graph_state.py:47-93` — 当前GraphState全部字段
  - `config/retrieval_tools.py` — RetrievalResult, RetrievalPipeline

  **Acceptance Criteria**:
  - [ ] Document类已移除或标记deprecated
  - [ ] GraphState使用RetrievalResult替代Document
  - [ ] RoutingDecision使用pipelines替代targets
  - [ ] 新增current_pipeline和pipeline_results字段
  - [ ] 移除retrieval_granularity/candidate_doc_ids/candidate_page_ids

  **QA Scenarios:**
  ```
  Scenario: 新状态结构验证
    Tool: Bash (python -c)
    Steps:
      1. 创建initial_state = create_initial_state("test query")
      2. 验证包含retrieval_results, filtered_results, confidence_results, pipeline_results
      3. 验证不包含candidate_doc_ids, candidate_page_ids, retrieval_granularity
    Expected Result: 新字段存在，旧字段已移除
    Evidence: .sisyphus/evidence/task-5-state-restructure.txt
  ```

  **Commit**: YES (groups with Wave 2)
  - Message: `refactor(core): refactor KB registration, graph state, pipeline engine, accumulator`
  - Files: `state/graph_state.py`

- [ ] 6. 检索管道执行引擎

  **What to do**:
  - 创建 `retrieval/` 目录, `retrieval/__init__.py`
  - 创建 `retrieval/retrieval_pipeline.py`:
    - `RetrievalPipelineEngine` 类:
      - `__init__(self, tool_registry: RetrievalToolRegistry)`: 注入tool注册中心
      - `execute_pipeline(self, pipeline: RetrievalPipeline, initial_params: dict) -> List[RetrievalResult]`:
        - 按 pipeline.steps 顺序执行每个step
        - 执行顺序强制校验: doc→page→chunk，不符合顺序则抛ValueError
        - 执行第一个step时使用 initial_params
        - 执行后续step时: 从前一步结果中自动提取 doc_id_list / page_id_list，注入下一步的params
        - 每步执行: 获取tool → 调用tool.func(**params) → 校验返回格式 → 转换为List[RetrievalResult]
        - 返回最后一步的结果
      - `execute_pipelines_parallel(self, pipelines: List[tuple]) -> List[RetrievalResult]`:
        - ThreadPoolExecutor并行执行多个pipeline（每个pipeline是(pipeline, initial_params)元组）
        - 聚合结果，按score排序

  **Must NOT do**:
  - 不允许跨KB的pipeline
  - 不要在此处实现置信度筛选

  **Recommended Agent Profile**:
  - **Category**: `deep`
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 2 (with Tasks 4, 5, 7)
  - **Blocks**: Task 9
  - **Blocked By**: Tasks 1, 3

  **References**:
  - `nodes/retrieval_node.py:79-110` — 当前并行检索模式（ThreadPoolExecutor）
  - `nodes/retrieval_node.py:24-76` — 当前单源检索逻辑
  - `config/retrieval_tools.py` — RetrievalTool, RetrievalPipeline, PipelineStep, RetrievalResult, RetrievalToolRegistry

  **Acceptance Criteria**:
  - [ ] `retrieval/retrieval_pipeline.py` 文件存在
  - [ ] execute_pipeline() 按doc→page→chunk顺序执行
  - [ ] 自动从前一步结果提取doc_id_list/page_id_list传给下一步
  - [ ] 返回值格式为List[RetrievalResult]
  - [ ] 多pipeline可并行执行

  **QA Scenarios:**
  ```
  Scenario: 管道顺序执行与参数传递
    Tool: Bash (python -c)
    Steps:
      1. 注册3个mock tool(doc/page/chunk)到同一KB
      2. 构建Pipeline: doc→page→chunk并执行
      3. 验证page步包含doc_id_list, chunk步包含doc_id_list和page_id_list
    Expected Result: 管道执行成功，参数正确传递
    Evidence: .sisyphus/evidence/task-6-pipeline-execution.txt

  Scenario: 管道顺序校验
    Tool: Bash (python -c)
    Steps:
      1. 构建Pipeline: chunk→page（违反顺序）
      2. 调用execute_pipeline()应抛ValueError
    Expected Result: ValueError异常
    Evidence: .sisyphus/evidence/task-6-pipeline-order-error.txt
  ```

  **Commit**: YES (groups with Wave 2)
  - Message: `refactor(core): refactor KB registration, graph state, pipeline engine, accumulator`
  - Files: `retrieval/__init__.py`, `retrieval/retrieval_pipeline.py`

- [ ] 7. 高置信度结果累加器

  **What to do**:
  - 创建 `retrieval/confidence_accumulator.py`:
    - `ConfidenceAccumulator` 类:
      - `__init__(self, score_threshold: float = 0.7, gain_threshold: float = 0.1)`:
        - 初始化 `_results: List[RetrievalResult]` 和 `_seen_ids: Set[str]`
      - `add(self, new_results: List[RetrievalResult], history_results: List[RetrievalResult]) -> List[RetrievalResult]`:
        - 双重筛选: score >= score_threshold 且 compute_novelty > gain_threshold
        - 通过筛选的结果按粒度ID去重后加入_results
        - 返回本次新增的高置信度结果
      - `get_results(self) -> List[RetrievalResult]`: 返回所有累积结果
      - `clear(self)`: 清空
      - `__len__(self)`: 返回数量
    - 去重规则: document级按doc_id, page级按doc_id+page_id, chunk级按doc_id+page_id+chunk_id

  **Must NOT do**:
  - 不要修改evaluation/metrics.py
  - 不要在此处实现检索逻辑

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 2 (with Tasks 4, 5, 6)
  - **Blocks**: Tasks 10, 12
  - **Blocked By**: Tasks 1, 2

  **References**:
  - `evaluation/metrics.py:97-127` — compute_novelty()算法
  - `nodes/evaluator_node.py:27-66` — 粒度感知去重逻辑
  - `config/retrieval_tools.py` — RetrievalResult
  - `config/system_settings.py` — confidence_score_threshold, confidence_gain_threshold (Task 2)

  **Acceptance Criteria**:
  - [ ] `retrieval/confidence_accumulator.py` 文件存在
  - [ ] add()方法实现得分+增益双重筛选
  - [ ] 去重按粒度ID进行
  - [ ] get_results()返回所有累积的高置信度结果

  **QA Scenarios:**
  ```
  Scenario: 双重筛选与去重
    Tool: Bash (python -c)
    Steps:
      1. 创建ConfidenceAccumulator(score_threshold=0.7, gain_threshold=0.1)
      2. add()一批结果: 部分score<0.7, 部分score>=0.7
      3. get_results()只返回score>=0.7且新颖度>0.1的
      4. add()重复doc_id的结果，验证去重
    Expected Result: 正确筛选和去重
    Evidence: .sisyphus/evidence/task-7-confidence-accumulator.txt
  ```

  **Commit**: YES (groups with Wave 2)
  - Message: `refactor(core): refactor KB registration, graph state, pipeline engine, accumulator`
  - Files: `retrieval/confidence_accumulator.py`

- [ ] 8. 重构router_node.py (pipeline决策 + 首函数输入)

  **What to do**:
  - 修改 `nodes/router_node.py`:
    - 重写路由系统提示词 `ROUTING_SYSTEM_PROMPT`:
      - 告知LLM可用的检索工具列表(从RetrievalToolRegistry.get_tool_descriptions_for_routing()获取)
      - 告知LLM知识库列表(从KBRegistry.get_descriptions_for_routing()获取，含默认标注)
      - 指示LLM输出pipeline列表: 每个pipeline包含同一KB的tool序列(doc→page→chunk)
      - 指示LLM为每个pipeline的第一个函数指定完整的输入参数(query, top_k, doc_id_list等)
      - 通常最后一个tool应为chunk粒度
      - 输出JSON格式:
        ```json
        {
          "pipelines": [
            {
              "kb_id": "知识库ID",
              "steps": [
                {"tool_id": "kb1_doc", "params": {"query": "...", "top_k": 5}},
                {"tool_id": "kb1_page"},
                {"tool_id": "kb1_chunk"}
              ],
              "reasoning": "..."
            }
          ],
          "reasoning": "总体路由推理"
        }
        ```
    - 修改 `_call_routing_llm()`:
      - 解析返回的pipelines格式
      - 校验每个pipeline: 同一kb_id、步骤顺序doc→page→chunk、tool_id存在
      - 将解析结果转换为 `RoutingDecision(pipelines=[RetrievalPipeline(...)], reasoning=...)`
    - 修改 `router_node()`:
      - 获取可用tool描述(从ToolRegistry)
      - 获取KB描述(从KBRegistry，含默认标注)
      - 调用LLM路由
      - 降级策略: 路由失败时，使用默认KB的完整pipeline(doc→page→chunk)，首函数输入为{query: 原始query, top_k: default_top_k}
    - 返回: `{"routing_decision": routing_decision}`

  **Must NOT do**:
  - 不要允许跨KB的pipeline
  - 不要在路由中执行检索

  **Recommended Agent Profile**:
  - **Category**: `deep`
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: NO (与其他Wave 3任务有共同依赖但独立修改不同文件)
  - **Parallel Group**: Wave 3 (with Tasks 9, 10, 11, 12)
  - **Blocks**: Task 13
  - **Blocked By**: Tasks 3, 5

  **References**:
  - `nodes/router_node.py:24-51` — 当前ROUTING_SYSTEM_PROMPT，需完全重写
  - `nodes/router_node.py:54-93` — 当前_call_routing_llm()，需重构
  - `nodes/router_node.py:96-189` — 当前router_node()，需重构
  - `config/retrieval_tools.py` — RetrievalToolRegistry, RetrievalPipeline, PipelineStep
  - `config/knowledge_bases.py` — KnowledgeBaseRegistry (get_default等)
  - `state/graph_state.py` — RoutingDecision (pipelines字段)

  **Acceptance Criteria**:
  - [ ] ROUTING_SYSTEM_PROMPT包含tool描述和KB描述
  - [ ] LLM输出格式包含pipelines列表和首函数输入参数
  - [ ] _call_routing_llm()校验pipeline顺序和tool_id
  - [ ] 降级策略使用默认KB的完整pipeline
  - [ ] router_node()返回包含RoutingDecision(pipelines=...)

  **QA Scenarios:**
  ```
  Scenario: 路由输出格式校验
    Tool: Bash (python -c)
    Steps:
      1. 注册一个KB和3个tool
      2. 构造模拟state调用router_node()
      3. 验证routing_decision.pipelines非空
      4. 验证每个pipeline.steps[0].params包含query和top_k
    Expected Result: 路由决策包含pipeline和首函数输入
    Evidence: .sisyphus/evidence/task-8-router-pipeline.txt

  Scenario: 降级路由
    Tool: Bash (python -c)
    Steps:
      1. LLM调用失败场景
      2. 验证降级到默认KB的doc→page→chunk pipeline
    Expected Result: 降级pipeline使用默认KB
    Evidence: .sisyphus/evidence/task-8-router-fallback.txt
  ```

  **Commit**: YES (groups with Wave 3)
  - Message: `refactor(nodes): adapt all nodes to hierarchical pipeline architecture`
  - Files: `nodes/router_node.py`

- [ ] 9. 重构retrieval_node.py (管道式执行)

  **What to do**:
  - 修改 `nodes/retrieval_node.py`:
    - 移除 `_retrieve_from_single_source()`, `_execute_parallel_retrieval()`, `_execute_sequential_retrieval()`
    - 使用 `RetrievalPipelineEngine` 替代原有检索逻辑
    - 修改 `retrieval_node()`:
      - 从state获取 `routing_decision` (包含pipelines)
      - 从每个pipeline.steps[0].params获取首函数输入参数
      - 调用 `pipeline_engine.execute_pipelines_parallel([(pipeline, initial_params), ...])`
      - 限制单轮最大结果数(max_retrieved_docs_per_round)
      - 返回 `{"retrieval_results": all_results}` (替代原raw_documents)

  **Must NOT do**:
  - 不要保留旧的并行检索逻辑(完全替换为pipeline引擎)
  - 不要在此处实现置信度筛选

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 3 (with Tasks 8, 10, 11, 12)
  - **Blocks**: Task 13
  - **Blocked By**: Tasks 5, 6

  **References**:
  - `nodes/retrieval_node.py:1-179` — 当前完整文件，需大幅重构
  - `retrieval/retrieval_pipeline.py` — RetrievalPipelineEngine (Task 6)
  - `state/graph_state.py` — 新的retrieval_results字段

  **Acceptance Criteria**:
  - [ ] retrieval_node()使用RetrievalPipelineEngine
  - [ ] 返回 {"retrieval_results": List[RetrievalResult]}
  - [ ] 不再包含旧的_retrieve_from_single_source等方法

  **QA Scenarios:**
  ```
  Scenario: 管道式检索执行
    Tool: Bash (python -c)
    Steps:
      1. 注册KB和3个mock tool
      2. 构造state含routing_decision(pipeline)
      3. 调用retrieval_node()
      4. 验证返回retrieval_results为List[RetrievalResult]
    Expected Result: 管道执行成功，返回RetrievalResult列表
    Evidence: .sisyphus/evidence/task-9-retrieval-pipeline-node.txt
  ```

  **Commit**: YES (groups with Wave 3)
  - Message: `refactor(nodes): adapt all nodes to hierarchical pipeline architecture`
  - Files: `nodes/retrieval_node.py`

- [ ] 10. 重构evaluator_node.py (适配新结构 + 置信度累加)

  **What to do**:
  - 修改 `nodes/evaluator_node.py`:
    - 适配 RetrievalResult 替代 Document
    - 过滤流水线适配: `full_filter_pipeline()` 参数改为 `List[RetrievalResult]`，内部用RetrievalResult的字段(doc_id/page_id等)
    - 移除粒度感知的特殊逻辑(_get_granularity, _get_granularity_id, _dedup_by_granularity, _compute_granularity_gain, _collect_candidate_ids)——这些由pipeline管理
    - 简化evaluator_node():
      - 从state获取retrieval_results(当前轮)
      - 调用full_filter_pipeline()过滤
      - 计算信息增益(使用compute_information_gain，适配RetrievalResult.content)
      - 调用ConfidenceAccumulator.add()将高置信度结果加入累加器
      - 计算覆盖度
      - 返回: filtered_results, confidence_results(累加器结果), information_gain, iteration_logs

  **Must NOT do**:
  - 不要修改evaluation/metrics.py的算法
  - 不要保留candidate_doc_ids/candidate_page_ids逻辑

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 3 (with Tasks 8, 9, 11, 12)
  - **Blocks**: Task 13
  - **Blocked By**: Tasks 5, 7

  **References**:
  - `nodes/evaluator_node.py:1-290` — 当前完整文件，需大幅重构
  - `retrieval/confidence_accumulator.py` — ConfidenceAccumulator (Task 7)
  - `evaluation/filters.py` — full_filter_pipeline()，需适配RetrievalResult
  - `evaluation/metrics.py` — compute_information_gain(), compute_coverage_score()

  **Acceptance Criteria**:
  - [ ] evaluator_node()使用RetrievalResult
  - [ ] 调用ConfidenceAccumulator.add()筛选高置信度结果
  - [ ] 返回confidence_results字段
  - [ ] 移除candidate_doc_ids/candidate_page_ids相关逻辑

  **QA Scenarios:**
  ```
  Scenario: 评估+置信度累加
    Tool: Bash (python -c)
    Steps:
      1. 构造含retrieval_results的state
      2. 调用evaluator_node()
      3. 验证返回filtered_results和confidence_results
      4. confidence_results只包含高置信度结果
    Expected Result: 评估完成，高置信度结果正确筛选
    Evidence: .sisyphus/evidence/task-10-evaluator-confidence.txt
  ```

  **Commit**: YES (groups with Wave 3)
  - Message: `refactor(nodes): adapt all nodes to hierarchical pipeline architecture`
  - Files: `nodes/evaluator_node.py`, `evaluation/filters.py` (适配RetrievalResult)

- [ ] 11. 重构termination_node.py (尊重迭代开关)

  **What to do**:
  - 修改 `nodes/termination_node.py`:
    - 在termination_node()开头检查 `settings.enable_iterative_retrieval`:
      - 如果为False，直接终止(should_continue=False, termination_reason="迭代式检索未启用")
    - 移除粒度下钻逻辑(_check_granularity_drill_down, _GRANULARITY_DRILL_ORDER)——粒度由pipeline管理
    - 保留4个终止条件(最大迭代、低增益、覆盖充分、无新文档)
    - 简化返回: 移除retrieval_granularity(不再需要)
    - 返回: `{"should_continue": bool, "termination_reason": str, "no_gain_rounds": int}`

  **Must NOT do**:
  - 不要保留粒度下钻逻辑(由pipeline自动处理)

  **Recommended Agent Profile**:
  - **Category**: `quick`
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 3 (with Tasks 8, 9, 10, 12)
  - **Blocks**: Task 13
  - **Blocked By**: Tasks 2, 5

  **References**:
  - `nodes/termination_node.py:1-230` — 当前完整文件，需重构
  - `config/system_settings.py` — enable_iterative_retrieval (Task 2)

  **Acceptance Criteria**:
  - [ ] enable_iterative_retrieval=False时直接终止
  - [ ] 移除retrieval_granularity返回值
  - [ ] 保留4个终止条件

  **QA Scenarios:**
  ```
  Scenario: 迭代开关关闭
    Tool: Bash (python -c)
    Steps:
      1. 设置enable_iterative_retrieval=False
      2. 调用termination_node()
      3. 验证should_continue==False
    Expected Result: 直接终止
    Evidence: .sisyphus/evidence/task-11-iter-switch-off.txt
  ```

  **Commit**: YES (groups with Wave 3)
  - Message: `refactor(nodes): adapt all nodes to hierarchical pipeline architecture`
  - Files: `nodes/termination_node.py`

- [ ] 12. 重构answer_node.py (使用ConfidenceAccumulator)

  **What to do**:
  - 修改 `nodes/answer_node.py`:
    - 从state获取 `confidence_results` (高置信度结果)替代 `document_history`
    - `_build_context_text()` 适配RetrievalResult:
      - 格式: `[文档{i}] [来源:{source}] [相关度:{score}] [doc_id:{doc_id}] [page_id:{page_id}] [chunk_id:{chunk_id}]\n{content}`
    - 使用confidence_results构建上下文
    - 其余逻辑(截断、生成、降级)保持不变

  **Must NOT do**:
  - 不要使用document_history(已替换为confidence_results)

  **Recommended Agent Profile**:
  - **Category**: `quick`
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 3 (with Tasks 8, 9, 10, 11)
  - **Blocks**: Task 13
  - **Blocked By**: Tasks 5, 7

  **References**:
  - `nodes/answer_node.py:1-126` — 当前完整文件
  - `state/graph_state.py` — confidence_results字段

  **Acceptance Criteria**:
  - [ ] answer_node()使用confidence_results
  - [ ] _build_context_text()适配RetrievalResult格式
  - [ ] 不再引用document_history

  **QA Scenarios:**
  ```
  Scenario: 使用高置信度结果生成答案
    Tool: Bash (python -c)
    Steps:
      1. 构造含confidence_results的state
      2. 调用answer_node()
      3. 验证使用confidence_results构建上下文
    Expected Result: 答案基于高置信度结果生成
    Evidence: .sisyphus/evidence/task-12-answer-confidence.txt
  ```

  **Commit**: YES (groups with Wave 3)
  - Message: `refactor(nodes): adapt all nodes to hierarchical pipeline architecture`
  - Files: `nodes/answer_node.py`

- [ ] 13. 重构rag_graph.py (条件迭代循环)

  **What to do**:
  - 修改 `graph/rag_graph.py`:
    - 修改 `_should_continue()`: 检查state的should_continue字段，保持原逻辑
    - 修改 `build_rag_graph()`:
      - 根据 `get_settings().enable_iterative_retrieval` 决定是否添加循环边:
        - 如果True: 添加条件边 termination → rewrite (继续迭代) / answer (终止)
        - 如果False: 添加顺序边 termination → answer (无循环)
      - 在enable_iterative_retrieval=False时，流程为: rewrite → router → retrieval → evaluator → termination → answer → END
      - 在enable_iterative_retrieval=True时，流程保持原循环逻辑
    - 修改 `create_initial_state()`: 使用新的字段名(retrieval_results, filtered_results等)
    - 修改 `run_rag_query()`: 保持接口不变，内部适配

  **Must NOT do**:
  - 不要改变run_rag_query()的对外接口签名
  - 不要在graph中硬编码检索逻辑

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: NO (依赖所有Wave 3节点)
  - **Parallel Group**: Wave 4 (with Tasks 14, 15)
  - **Blocks**: Task 14
  - **Blocked By**: Tasks 2, 8, 9, 10, 11, 12

  **References**:
  - `graph/rag_graph.py:1-141` — 当前完整文件
  - `config/system_settings.py` — enable_iterative_retrieval (Task 2)

  **Acceptance Criteria**:
  - [ ] enable_iterative_retrieval=False时无循环边
  - [ ] enable_iterative_retrieval=True时有条件循环边
  - [ ] run_rag_query()接口不变

  **QA Scenarios:**
  ```
  Scenario: 迭代关闭时无循环
    Tool: Bash (python -c)
    Steps:
      1. 设置enable_iterative_retrieval=False
      2. compile_rag_graph()
      3. 验证图中无循环边(termination直接到answer)
    Expected Result: 线性流程
    Evidence: .sisyphus/evidence/task-13-graph-no-loop.txt

  Scenario: 迭代开启时有循环
    Tool: Bash (python -c)
    Steps:
      1. 设置enable_iterative_retrieval=True
      2. compile_rag_graph()
      3. 验证图中有条件循环边
    Expected Result: 循环流程
    Evidence: .sisyphus/evidence/task-13-graph-with-loop.txt
  ```

  **Commit**: YES (groups with Wave 4)
  - Message: `refactor(graph): integrate conditional iteration and update entry point`
  - Files: `graph/rag_graph.py`

- [ ] 14. 重构main.py + mock三级检索函数

  **What to do**:
  - 修改 `main.py`:
    - 导入新模块: `from rag_iterative_system.config.retrieval_tools import RetrievalGranularity, get_tool_registry`
    - 重写 `mock_retrieval_func()` 为3个独立函数:
      - `mock_doc_retrieval(query, top_k=5, **kwargs)` → 返回文档级结果(doc_id有值, page_id/chunk_id为None, content=文档摘要)
      - `mock_page_retrieval(query, top_k=5, doc_id_list=None, **kwargs)` → 返回页面级结果(doc_id+page_id有值, chunk_id为None, content=页面摘要)
      - `mock_chunk_retrieval(query, top_k=5, doc_id_list=None, page_id_list=None, **kwargs)` → 返回chunk级结果(doc_id+page_id+chunk_id有值, content=chunk内容)
    - 每个mock函数返回格式: `[{"doc_id": ..., "page_id": ..., "chunk_id": ..., "content": ..., "source": ..., "score": ...}]`
    - 修改 `demo_setup()`:
      - 使用 `register_knowledge_base_with_tools()` 替代 `register_knowledge_base()`
      - 传入3个检索函数
      - 设置 enable_iterative_retrieval=True (演示迭代)
    - 新增 `demo_setup_no_iteration()`: 同上但enable_iterative_retrieval=False
    - 修改 `main()`: 默认使用迭代模式演示
    - 输出结果中显示confidence_results数量

  **Must NOT do**:
  - 不要使用旧的register_knowledge_base()接口
  - 不要使用旧的mock_retrieval_func()

  **Recommended Agent Profile**:
  - **Category**: `unspecified-high`
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES (与Task 15并行)
  - **Parallel Group**: Wave 4 (with Tasks 13, 15)
  - **Blocks**: Task 16
  - **Blocked By**: Tasks 4, 13

  **References**:
  - `main.py:1-177` — 当前完整文件
  - `config/knowledge_bases.py` — register_knowledge_base_with_tools() (Task 4)

  **Acceptance Criteria**:
  - [ ] 3个mock检索函数(doc/page/chunk)独立定义
  - [ ] 使用register_knowledge_base_with_tools()注册
  - [ ] main.py可运行(不报ImportError)

  **QA Scenarios:**
  ```
  Scenario: main.py可导入
    Tool: Bash (python -c)
    Steps:
      1. python -c "from rag_iterative_system.main import demo_setup, main"
    Expected Result: 无ImportError
    Evidence: .sisyphus/evidence/task-14-main-import.txt
  ```

  **Commit**: YES (groups with Wave 4)
  - Message: `refactor(graph): integrate conditional iteration and update entry point`
  - Files: `main.py`

- [ ] 15. 更新README.md

  **What to do**:
  - 修改 `README.md`:
    - 更新系统架构描述: 层次化检索(文档级/页面级/chunk级)
    - 更新目录结构: 新增 `retrieval/` 目录
    - 更新快速开始: 使用 `register_knowledge_base_with_tools()` 和3个检索函数
    - 更新核心模块详解:
      - 新增"检索函数注册"章节
      - 新增"管道式检索"章节
      - 新增"高置信度累加器"章节
      - 更新路由决策章节(pipeline模式)
    - 更新配置参数手册: 新增enable_iterative_retrieval, confidence_score_threshold, confidence_gain_threshold
    - 更新检索函数接口约定: 新的统一返回格式和3级输入参数
    - 更新扩展指南: 新的注册方式

  **Must NOT do**:
  - 不要删除已有的有价值内容（如评估算法章节、容错机制章节）

  **Recommended Agent Profile**:
  - **Category**: `writing`
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: YES
  - **Parallel Group**: Wave 4 (with Tasks 13, 14)
  - **Blocks**: None
  - **Blocked By**: All implementation tasks (for accurate documentation)

  **References**:
  - `README.md` — 当前完整文档
  - 所有新模块的代码

  **Acceptance Criteria**:
  - [ ] README包含层次化检索描述
  - [ ] README包含新的注册API文档
  - [ ] README包含新配置参数

  **QA Scenarios:**
  ```
  Scenario: README包含关键章节
    Tool: Bash (python -c)
    Steps:
      1. 读取README.md
      2. 验证包含"层次化"、"检索函数注册"、"管道式"、"高置信度"等关键词
    Expected Result: 所有关键章节存在
    Evidence: .sisyphus/evidence/task-15-readme.txt
  ```

  **Commit**: YES (groups with Wave 4)
  - Message: `refactor(graph): integrate conditional iteration and update entry point`
  - Files: `README.md`

- [ ] 16. 单元测试

  **What to do**:
  - 创建 `tests/` 目录和 `tests/__init__.py`
  - 创建 `tests/test_retrieval_tools.py`:
    - 测试RetrievalResult创建和字段
    - 测试RetrievalToolRegistry注册/查询/描述生成
    - 测试PipelineStep和RetrievalPipeline创建
  - 创建 `tests/test_knowledge_bases.py`:
    - 测试register_knowledge_base_with_tools()三级注册
    - 测试默认KB自动设置和显式设置
    - 测试缺少检索函数时报错
  - 创建 `tests/test_pipeline_engine.py`:
    - 测试管道顺序执行(doc→page→chunk)
    - 测试参数自动传递(doc_id_list, page_id_list)
    - 测试管道顺序校验(违反顺序报错)
    - 测试多pipeline并行执行
  - 创建 `tests/test_confidence_accumulator.py`:
    - 测试得分筛选
    - 测试信息增益筛选
    - 测试去重
    - 测试累积和清空
  - 创建 `tests/test_graph_state.py`:
    - 测试create_initial_state()返回正确字段
    - 测试RetrievalResult替代Document
  - 创建 `tests/test_system_settings.py`:
    - 测试enable_iterative_retrieval默认值
    - 测试confidence配置默认值

  **Must NOT do**:
  - 不要写集成测试(只写单元测试)
  - 不需要mock LLM调用

  **Recommended Agent Profile**:
  - **Category**: `deep`
  - **Skills**: []

  **Parallelization**:
  - **Can Run In Parallel**: NO
  - **Parallel Group**: Wave 5
  - **Blocks**: F1-F4
  - **Blocked By**: All implementation tasks

  **References**:
  - 所有新模块和重构模块

  **Acceptance Criteria**:
  - [ ] `tests/` 目录存在且包含5个以上测试文件
  - [ ] `python -m pytest tests/ -v` 全部通过
  - [ ] 覆盖核心数据结构、注册、管道、累加器、状态

  **QA Scenarios:**
  ```
  Scenario: 测试套件运行
    Tool: Bash (python -m pytest)
    Steps:
      1. python -m pytest tests/ -v
    Expected Result: 所有测试通过
    Failure Indicators: 测试失败或导入错误
    Evidence: .sisyphus/evidence/task-16-test-results.txt
  ```

  **Commit**: YES
  - Message: `test: add unit tests for hierarchical retrieval system`
  - Files: `tests/`

---

## Final Verification Wave (MANDATORY — after ALL implementation tasks)

> 4 review agents run in PARALLEL. ALL must APPROVE. Present consolidated results to user and get explicit "okay" before completing.

- [ ] F1. **Plan Compliance Audit** — `oracle`
  Read the plan end-to-end. For each "Must Have": verify implementation exists (read file, import, run command). For each "Must NOT Have": search codebase for forbidden patterns — reject with file:line if found. Check evidence files exist in .sisyphus/evidence/. Compare deliverables against plan.
  Output: `Must Have [N/N] | Must NOT Have [N/N] | Tasks [N/N] | VERDICT: APPROVE/REJECT`

- [ ] F2. **Code Quality Review** — `unspecified-high`
  Run `python -m py_compile` on all modified files + `python -m pytest`. Review all changed files for: `# type: ignore`, empty except, print in prod, commented-out code, unused imports. Check AI slop: excessive comments, over-abstraction, generic names.
  Output: `Compile [PASS/FAIL] | Tests [N pass/N fail] | Files [N clean/N issues] | VERDICT`

- [ ] F3. **Real Manual QA** — `unspecified-high`
  Start from clean state. Execute main.py with mock functions. Verify: 3-level registration, pipeline execution, iterative toggle ON/OFF, confidence accumulator output. Save to `.sisyphus/evidence/final-qa/`.
  Output: `Scenarios [N/N pass] | Integration [N/N] | VERDICT`

- [ ] F4. **Scope Fidelity Check** — `deep`
  For each task: read "What to do", read actual diff. Verify 1:1 — everything in spec was built, nothing beyond spec. Check "Must NOT do" compliance. Flag unaccounted changes.
  Output: `Tasks [N/N compliant] | Unaccounted [CLEAN/N files] | VERDICT`

---

## Commit Strategy

- **Wave 1**: `refactor(data): add hierarchical retrieval data structures and tool registry` - config/retrieval_tools.py, config/system_settings.py
- **Wave 2**: `refactor(core): refactor KB registration, graph state, pipeline engine, accumulator` - config/knowledge_bases.py, state/graph_state.py, retrieval/
- **Wave 3**: `refactor(nodes): adapt all nodes to hierarchical pipeline architecture` - nodes/*.py
- **Wave 4**: `refactor(graph): integrate conditional iteration and update entry point` - graph/rag_graph.py, main.py, README.md
- **Wave 5**: `test: add unit tests for hierarchical retrieval system` - tests/

---

## Success Criteria

### Verification Commands
```bash
python -c "from rag_iterative_system.config.retrieval_tools import RetrievalToolRegistry, RetrievalTool; print('OK')"
python -c "from rag_iterative_system.state.graph_state import RetrievalResult; print('OK')"
python -c "from rag_iterative_system.retrieval.retrieval_pipeline import RetrievalPipelineEngine; print('OK')"
python -c "from rag_iterative_system.retrieval.confidence_accumulator import ConfidenceAccumulator; print('OK')"
python -m pytest tests/ -v
```

### Final Checklist
- [ ] All "Must Have" present
- [ ] All "Must NOT Have" absent
- [ ] All tests pass
- [ ] main.py runs end-to-end with mock functions
- [ ] enable_iterative_retrieval=False produces single-round execution
- [ ] ConfidenceAccumulator filters by score + information gain
