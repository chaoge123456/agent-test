# -*- coding: utf-8 -*-
"""
大模型连接配置与统一调用封装
- 全局单例管理LLM实例
- 统一调用规范: llm.call(prompt, system_prompt)
- 隔离模型接口差异，预留扩展接口
"""

from __future__ import annotations

import json
import logging
from typing import Any, Optional

from langchain_openai import ChatOpenAI
from pydantic import SecretStr

from rag_iterative_system.utils.error_handler import LLMCallError

logger = logging.getLogger(__name__)


class LLMAdapter:
    """
    大模型统一适配器

    设计原则:
    - 全局单例，通过 get_llm() 获取
    - 统一调用签名 call(prompt, system_prompt)
    - 支持模型热切换、接口扩容
    """

    _instance: Optional[LLMAdapter] = None

    def __init__(
        self,
        model_name: str = "gpt-4o",
        api_base: str = "https://api.openai.com/v1",
        api_key: str = "sk-placeholder",
        temperature: float = 0.0,
        max_tokens: int = 4096,
        timeout: int = 60,
        **kwargs: Any,
    ) -> None:
        self._llm = ChatOpenAI(
            model=model_name,
            base_url=api_base,
            api_key=SecretStr(api_key),
            temperature=temperature,
            max_completion_tokens=max_tokens,
            timeout=timeout,
            **kwargs,
        )
        logger.info(
            "LLMAdapter initialized: model=%s, api_base=%s",
            model_name,
            api_base,
        )

    @classmethod
    def initialize(
        cls,
        model_name: str = "gpt-4o",
        api_base: str = "https://api.openai.com/v1",
        api_key: str = "sk-placeholder",
        temperature: float = 0.0,
        max_tokens: int = 4096,
        timeout: int = 60,
        **kwargs: Any,
    ) -> LLMAdapter:
        """初始化全局单例"""
        cls._instance = cls(
            model_name=model_name,
            api_base=api_base,
            api_key=api_key,
            temperature=temperature,
            max_tokens=max_tokens,
            timeout=timeout,
            **kwargs,
        )
        return cls._instance

    @classmethod
    def get_instance(cls) -> LLMAdapter:
        """获取全局单例，未初始化时抛出异常"""
        if cls._instance is None:
            raise RuntimeError(
                "LLMAdapter 未初始化，请先调用 LLMAdapter.initialize()"
            )
        return cls._instance

    def call(self, prompt: str, system_prompt: str = "") -> str:
        """
        统一LLM调用接口

        Args:
            prompt: 用户提示词
            system_prompt: 系统提示词（可选）

        Returns:
            模型生成的文本内容
        """
        from langchain_core.messages import HumanMessage, SystemMessage

        messages: list = []
        if system_prompt:
            messages.append(SystemMessage(content=system_prompt))
        messages.append(HumanMessage(content=prompt))

        try:
            response = self._llm.invoke(messages)
            content = response.content
            # content can be str or list (multi-modal); normalize to str
            if isinstance(content, list):
                content = "\n".join(
                    part if isinstance(part, str) else str(part)
                    for part in content
                )
            logger.debug(
                "LLM call success: prompt_len=%d, response_len=%d",
                len(prompt),
                len(content),
            )
            return content
        except Exception as e:
            logger.error("LLM call failed: %s", e)
            raise LLMCallError(str(e)) from e

    def call_json(self, prompt: str, system_prompt: str = "") -> dict:
        """
        调用LLM并解析JSON格式返回

        Args:
            prompt: 用户提示词
            system_prompt: 系统提示词

        Returns:
            解析后的字典

        Raises:
            ValueError: 返回内容无法解析为JSON
        """
        raw = self.call(prompt, system_prompt)
        # 尝试提取JSON块（兼容markdown代码块包裹）
        text = raw.strip()
        if text.startswith("```"):
            lines = text.split("\n")
            # 去掉首尾的```行
            lines = [l for l in lines if not l.strip().startswith("```")]
            text = "\n".join(lines)
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            logger.warning("LLM返回非标准JSON，尝试修复: %s", text[:200])
            # 尝试提取第一个 { ... } 块
            start = text.find("{")
            end = text.rfind("}") + 1
            if start != -1 and end > start:
                try:
                    return json.loads(text[start:end])
                except json.JSONDecodeError:
                    pass
            raise LLMCallError(f"无法解析LLM返回的JSON: {text[:200]}") from None

    @classmethod
    def reset(cls) -> None:
        """重置单例（主要用于测试）"""
        cls._instance = None


# 便捷访问函数
def get_llm() -> LLMAdapter:
    """获取全局LLM适配器实例"""
    return LLMAdapter.get_instance()
