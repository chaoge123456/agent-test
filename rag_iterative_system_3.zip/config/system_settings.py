# -*- coding: utf-8 -*-
"""
全局系统参数配置
- 迭代阈值、最大轮次、检索TopK等
- 所有核心运行参数集中管理
- 支持环境变量覆盖
- 迭代式检索开关
- 置信度累加器参数
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import List


@dataclass
class SystemSettings:
    """
    系统全局配置

    所有参数均支持环境变量覆盖，优先级: 环境变量 > 代码设定 > 默认值
    """

    # ---- 迭代控制 ----
    max_iterations: int = 3                 # 最大迭代轮次
    min_information_gain: float = 0.05      # 最小信息增益阈值（低于此值视为无新信息）
    consecutive_no_gain_rounds: int = 2     # 连续无增益轮次阈值
    enable_iterative_retrieval: bool = False  # 是否启用迭代式检索（默认关闭）

    # ---- 检索参数 ----
    default_top_k: int = 5                  # 默认检索文档数量
    max_retrieved_docs_per_round: int = 20  # 单轮最大检索文档数
    score_threshold: float = 0.3            # 最低相似度分数阈值

    # ---- 上下文控制 ----
    max_context_length: int = 8000          # 最大上下文字符长度
    max_total_documents: int = 50           # 全流程累计最大文档数

    # ---- 查询改写 ----
    max_rewrite_queries: int = 3            # 每轮最大改写查询数

    # ---- 去重与过滤 ----
    dedup_similarity_threshold: float = 0.95  # 去重相似度阈值
    min_doc_length: int = 20                # 最短有效文档字符数

    # ---- 高置信度累加器 ----
    confidence_threshold: float = 0.6       # reranker得分阈值
    min_novelty_threshold: float = 0.1      # 最小新颖度阈值（信息增益筛选）

    # ---- LLM调用 ----
    llm_model: str = "gpt-4o"              # 模型名称
    llm_api_base: str = "https://api.openai.com/v1"
    llm_api_key: str = "sk-placeholder"
    llm_temperature: float = 0.0
    llm_max_tokens: int = 4096
    llm_timeout: int = 60

    # ---- 重试与容错 ----
    max_retries: int = 3                    # 最大重试次数
    retry_delay: float = 1.0               # 重试间隔（秒）
    enable_fallback: bool = True            # 是否启用降级兜底

    # ---- 日志与观测 ----
    log_level: str = "INFO"                # 日志级别
    enable_iteration_logging: bool = True   # 是否记录迭代详细日志


def load_settings() -> SystemSettings:
    """
    加载系统配置，环境变量优先

    环境变量命名规则: RAG_大写字段名
    例如: RAG_MAX_ITERATIONS=5
    """
    def _env(name: str, default: str) -> str:
        return os.environ.get(f"RAG_{name}", default)

    return SystemSettings(
        max_iterations=int(_env("MAX_ITERATIONS", "3")),
        min_information_gain=float(_env("MIN_INFORMATION_GAIN", "0.05")),
        consecutive_no_gain_rounds=int(_env("CONSECUTIVE_NO_GAIN_ROUNDS", "2")),
        enable_iterative_retrieval=_env("ENABLE_ITERATIVE_RETRIEVAL", "false").lower() == "true",
        default_top_k=int(_env("DEFAULT_TOP_K", "5")),
        max_retrieved_docs_per_round=int(_env("MAX_RETRIEVED_DOCS_PER_ROUND", "20")),
        score_threshold=float(_env("SCORE_THRESHOLD", "0.3")),
        max_context_length=int(_env("MAX_CONTEXT_LENGTH", "8000")),
        max_total_documents=int(_env("MAX_TOTAL_DOCUMENTS", "50")),
        max_rewrite_queries=int(_env("MAX_REWRITE_QUERIES", "3")),
        dedup_similarity_threshold=float(_env("DEDUP_SIMILARITY_THRESHOLD", "0.95")),
        min_doc_length=int(_env("MIN_DOC_LENGTH", "20")),
        confidence_threshold=float(_env("CONFIDENCE_THRESHOLD", "0.6")),
        min_novelty_threshold=float(_env("MIN_NOVELTY_THRESHOLD", "0.1")),
        llm_model=_env("LLM_MODEL", "gpt-4o"),
        llm_api_base=_env("LLM_API_BASE", "https://api.openai.com/v1"),
        llm_api_key=_env("LLM_API_KEY", "sk-placeholder"),
        llm_temperature=float(_env("LLM_TEMPERATURE", "0.0")),
        llm_max_tokens=int(_env("LLM_MAX_TOKENS", "4096")),
        llm_timeout=int(_env("LLM_TIMEOUT", "60")),
        max_retries=int(_env("MAX_RETRIES", "3")),
        retry_delay=float(_env("RETRY_DELAY", "1.0")),
        enable_fallback=_env("ENABLE_FALLBACK", "true").lower() == "true",
        log_level=_env("LOG_LEVEL", "INFO"),
        enable_iteration_logging=_env("ENABLE_ITERATION_LOGGING", "true").lower() == "true",
    )


# 全局配置单例
_settings: SystemSettings | None = None


def get_settings() -> SystemSettings:
    """获取全局系统配置"""
    global _settings
    if _settings is None:
        _settings = load_settings()
    return _settings


def set_settings(settings: SystemSettings) -> None:
    """手动设置全局配置（主要用于测试）"""
    global _settings
    _settings = settings
