"""
Basic Usage Example for Milvus RAG System

This example demonstrates:
1. Creating a knowledge base
2. Adding documents with all representations
3. Performing various searches
4. Cascade delete operations
"""

import os
import sys

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
from milvus_rag_system.core.rag_manager import RAGManager
from milvus_rag_system.utils.snowflake import init_id_generator

# Configuration
MILVUS_URI = "http://localhost:19530"
DB_NAME = "rag_example"


def create_sample_vector(dim: int) -> list:
    """Create a random sample vector"""
    return np.random.random(dim).tolist()


def example_knowledge_base_management():
    """Example: Knowledge base CRUD operations"""
    print("\n" + "="*60)
    print("Example 1: Knowledge Base Management")
    print("="*60)
    
    # Initialize RAG Manager
    manager = RAGManager(
        uri=MILVUS_URI,
        db_name=DB_NAME
    )
    
    # Create knowledge base
    kb_data = {
        "kb_name": "AI Research Papers",
        "description": "A collection of AI and machine learning research papers",
        "tags": ["AI", "ML", "Research", "Papers"],
        "vector": create_sample_vector(768),  # Semantic routing vector
        "metadata": {
            "category": "research",
            "language": "en",
            "total_docs": 0
        }
    }
    
    result = manager.create_knowledge_base(kb_data)
    print(f"Created knowledge base: {result}")
    
    kb_id = result["kb_id"]
    
    # List knowledge bases
    kbs = manager.kb_table.list_knowledge_bases()
    print(f"\nTotal knowledge bases: {len(kbs)}")
    for kb in kbs:
        print(f"  - {kb['kb_id']}: {kb['kb_name']}")
    
    return manager, kb_id


def example_document_ingestion(manager: RAGManager, kb_id: int):
    """Example: Document ingestion with all representations"""
    print("\n" + "="*60)
    print("Example 2: Document Ingestion")
    print("="*60)
    
    # 1. Add document metadata
    doc_table = manager.get_doc_table(kb_id)
    
    doc_data = {
        "kb_id": kb_id,
        "doc_name": "Attention_Is_All_You_Need.pdf",
        "tags": ["transformer", "attention", "nlp"],
        "keywords": ["self-attention", "transformer", "seq2seq"],
        "abstract": "We propose a new simple network architecture, the Transformer, based solely on attention mechanisms...",
        "vector": create_sample_vector(768),
        "organize": ["page", "chunk"],
        "metadata": {
            "path": "/docs/attention.pdf",
            "doc_type": "pdf",
            "pages": 10,
            "char_count": 15000,
            "language": "en",
            "source": "arxiv"
        }
    }
    
    result = doc_table.add_document(doc_data)
    doc_id = result["doc_id"]
    print(f"Added document: {result}")
    
    # 2. Add page abstracts
    page_abs_table = manager.get_page_abs_table(kb_id)
    
    for page_num in range(1, 4):  # Add first 3 pages
        page_data = {
            "doc_id": doc_id,
            "page_id": page_num,
            "abstract": f"Page {page_num} describes the transformer architecture and attention mechanisms...",
            "vector": create_sample_vector(512),  # Multimodal embedding
            "page_path": f"/docs/attention.pdf?page={page_num}",
            "keyword": ["attention", "transformer"],
            "metadata": {
                "elements": ["text", "figures"],
                "has_tables": False,
                "prev_page": page_num - 1 if page_num > 1 else None,
                "next_page": page_num + 1
            }
        }
        result = page_abs_table.add_page_abstract(page_data)
        print(f"  Added page abstract: page={page_num}, row_id={result['row_id']}")
    
    # 3. Add page tokens (ColPali/ColQwen style multi-vectors)
    page_token_table = manager.get_page_token_table(kb_id)
    
    for page_num in range(1, 3):  # Add tokens for first 2 pages
        # Generate multiple token vectors per page (e.g., 16 patches)
        num_patches = 16
        token_vectors = [create_sample_vector(128) for _ in range(num_patches)]
        
        result = page_token_table.add_page_tokens(
            doc_id=doc_id,
            page_id=page_num,
            token_vectors=token_vectors,
            metadata={"model": "colpali", "patch_size": 32}
        )
        print(f"  Added page tokens: page={page_num}, patches={result['patch_count']}")
    
    # 4. Add document chunks
    chunk_table = manager.get_chunk_table(kb_id)
    
    chunks = []
    for i, content in enumerate([
        "The Transformer architecture revolutionized NLP by introducing self-attention mechanisms.",
        "Multi-head attention allows the model to attend to different representation subspaces.",
        "Positional encoding provides sequence order information to the model."
    ]):
        chunk = {
            "doc_id": doc_id,
            "page_id": (i % 3) + 1,  # Distribute across pages
            "type": "text",
            "content": content,
            "vector": create_sample_vector(768),
            "keyword": ["transformer", "attention"],
            "metadata": {
                "char_count": len(content),
                "prev_chunk": i - 1 if i > 0 else None,
                "next_chunk": i + 1 if i < 2 else None
            }
        }
        chunks.append(chunk)
    
    result = chunk_table.add_chunks_batch(chunks)
    print(f"  Added {result['insert_count']} chunks")
    
    return {"doc_id": doc_id, "status": "completed"}


def example_searches(manager: RAGManager, kb_id: int):
    """Example: Various search operations"""
    print("\n" + "="*60)
    print("Example 3: Search Operations")
    print("="*60)
    
    # 1. Semantic search in knowledge bases
    print("\n1. Knowledge base semantic search:")
    query_vector = create_sample_vector(768)
    results = manager.kb_table.search_by_semantic(
        query_vector=query_vector,
        top_k=5
    )
    for hits in results:
        for hit in hits:
            print(f"  - {hit['entity']['kb_name']} (score: {hit['distance']:.4f})")
    
    # 2. Search within a KB's documents
    print("\n2. Document vector search:")
    doc_table = manager.get_doc_table(kb_id)
    doc_results = doc_table.search_by_vector(
        query_vector=query_vector,
        top_k=3
    )
    for hits in doc_results:
        for hit in hits:
            print(f"  - {hit['entity']['doc_name']} (score: {hit['distance']:.4f})")
    
    # 3. Chunk content search
    print("\n3. Chunk content search:")
    chunk_table = manager.get_chunk_table(kb_id)
    chunk_results = chunk_table.search_by_vector(
        query_vector=query_vector,
        top_k=3
    )
    for hits in chunk_results:
        for hit in hits:
            content = hit['entity']['content'][:80] + "..."
            print(f"  - {content} (score: {hit['distance']:.4f})")
    
    # 4. MaxSim search on page tokens (ColPali style)
    print("\n4. MaxSim search on page tokens (Late Interaction):")
    page_token_table = manager.get_page_token_table(kb_id)
    
    # Create multiple query token vectors (simulating ColPali query)
    query_token_vectors = [create_sample_vector(128) for _ in range(8)]
    
    maxsim_results = page_token_table.search_with_maxsim(
        query_vectors=query_token_vectors,
        top_k=5
    )
    
    for r in maxsim_results:
        print(f"  - Doc {r['doc_id']}, Page {r['page_id']}: "
              f"score={r['score']:.4f}, patches={r['patch_count']}")


def example_cascade_delete(manager: RAGManager, kb_id: int):
    """Example: Cascade delete operations"""
    print("\n" + "="*60)
    print("Example 4: Cascade Delete")
    print("="*60)
    
    # First, get a document to delete
    doc_table = manager.get_doc_table(kb_id)
    docs = doc_table.list_documents(limit=1)
    
    if not docs:
        print("No documents found to delete")
        return
    
    doc_id = docs[0]["doc_id"]
    doc_name = docs[0]["doc_name"]
    
    print(f"\nCascading delete for document: {doc_name} (ID: {doc_id})")
    
    # Perform cascade delete
    result = manager.cascade_delete_document(kb_id, doc_id)
    
    print("\nDelete results:")
    for key, value in result.get("deleted", {}).items():
        print(f"  - {key}: {value}")


def main():
    """Main entry point"""
    print("="*60)
    print("Milvus RAG System - Basic Usage Example")
    print("="*60)
    
    try:
        # Initialize RAG Manager
        print("\nInitializing RAG Manager...")
        manager = RAGManager(
            uri=MILVUS_URI,
            db_name=DB_NAME
        )
        
        # Ensure knowledge base collection exists
        manager.kb_table.create_collection()
        
        # Example 1: Knowledge Base Management
        manager_example, kb_id = example_knowledge_base_management()
        
        # Example 2: Document Ingestion
        example_document_ingestion(manager, kb_id)
        
        # Example 3: Search Operations
        example_searches(manager, kb_id)
        
        # Example 4: Cascade Delete
        example_cascade_delete(manager, kb_id)
        
        print("\n" + "="*60)
        print("All examples completed successfully!")
        print("="*60)
        
    except Exception as e:
        print(f"\nError: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()