"""
Validation utilities for data fields
"""

from typing import Any, List, Dict, Optional, Union


def validate_int64(value: Any, field_name: str = "field") -> int:
    """Validate and convert to int64"""
    if value is None:
        raise ValueError(f"{field_name} is required")
    try:
        val = int(value)
        # Check int64 range
        if not -(2**63) <= val <= 2**63 - 1:
            raise ValueError(f"{field_name} out of int64 range")
        return val
    except (TypeError, ValueError) as e:
        raise ValueError(f"{field_name} must be a valid int64: {e}")


def validate_varchar(value: Any, max_length: int, field_name: str = "field", required: bool = True) -> Optional[str]:
    """Validate varchar field"""
    if value is None or value == "":
        if required:
            raise ValueError(f"{field_name} is required")
        return None
    
    if not isinstance(value, str):
        value = str(value)
    
    if len(value) > max_length:
        raise ValueError(f"{field_name} exceeds maximum length of {max_length}")
    
    return value


def validate_array(value: Any, max_capacity: int, element_max_length: int, field_name: str = "field", required: bool = True) -> Optional[List[str]]:
    """Validate array field"""
    if value is None:
        if required:
            raise ValueError(f"{field_name} is required")
        return None
    
    if not isinstance(value, list):
        if isinstance(value, str):
            value = [value]
        else:
            value = list(value)
    
    if len(value) > max_capacity:
        raise ValueError(f"{field_name} exceeds maximum capacity of {max_capacity}")
    
    # Validate and convert elements
    validated = []
    for item in value:
        str_item = str(item)
        if len(str_item) > element_max_length:
            str_item = str_item[:element_max_length]
        validated.append(str_item)
    
    return validated


def validate_json(value: Any, field_name: str = "field", required: bool = False) -> Optional[Dict]:
    """Validate JSON field"""
    if value is None:
        if required:
            raise ValueError(f"{field_name} is required")
        return None
    
    if isinstance(value, dict):
        return value
    
    if isinstance(value, str):
        import json
        try:
            parsed = json.loads(value)
            if not isinstance(parsed, dict):
                raise ValueError(f"{field_name} must be a JSON object")
            return parsed
        except json.JSONDecodeError as e:
            raise ValueError(f"{field_name} must be valid JSON: {e}")
    
    raise ValueError(f"{field_name} must be a dict or JSON string")


def validate_vector(value: Any, dim: int, field_name: str = "field", required: bool = True) -> Optional[List[float]]:
    """Validate vector field"""
    if value is None:
        if required:
            raise ValueError(f"{field_name} is required")
        return None
    
    if not isinstance(value, (list, tuple)):
        raise ValueError(f"{field_name} must be a list or tuple")
    
    if len(value) != dim:
        raise ValueError(f"{field_name} must have exactly {dim} dimensions, got {len(value)}")
    
    # Validate all elements are numeric
    try:
        vector = [float(v) for v in value]
    except (TypeError, ValueError) as e:
        raise ValueError(f"{field_name} must contain numeric values: {e}")
    
    return vector


def validate_page_organize(value: Any, field_name: str = "organize") -> List[str]:
    """Validate page organization types"""
    if value is None:
        raise ValueError(f"{field_name} is required")
    
    if isinstance(value, str):
        value = [value]
    
    valid_types = {"tree", "page", "chunk"}
    validated = []
    
    for item in value:
        str_item = str(item).lower()
        if str_item not in valid_types:
            raise ValueError(f"Invalid organize type: {item}. Must be one of {valid_types}")
        validated.append(str_item)
    
    return validated