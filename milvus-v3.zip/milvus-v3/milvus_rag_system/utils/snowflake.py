"""
Snowflake ID Generator
Generates unique 64-bit IDs similar to Twitter's Snowflake algorithm
Format (64 bits total):
- 1 bit: Sign (always 0)
- 41 bits: Timestamp (milliseconds since custom epoch)
- 5 bits: Datacenter ID (0-31)
- 5 bits: Worker ID (0-31)
- 12 bits: Sequence number (0-4095)
"""

import time
import threading
from typing import Optional


# Custom epoch: January 1, 2024 00:00:00 UTC
EPOCH = 1704067200000  # milliseconds

# Bit lengths
TIMESTAMP_BITS = 41
DATACENTER_BITS = 5
WORKER_BITS = 5
SEQUENCE_BITS = 12

# Maximum values
MAX_DATACENTER_ID = (1 << DATACENTER_BITS) - 1  # 31
MAX_WORKER_ID = (1 << WORKER_BITS) - 1  # 31
MAX_SEQUENCE = (1 << SEQUENCE_BITS) - 1  # 4095

# Shifts
WORKER_SHIFT = SEQUENCE_BITS
DATACENTER_SHIFT = SEQUENCE_BITS + WORKER_BITS
TIMESTAMP_SHIFT = SEQUENCE_BITS + WORKER_BITS + DATACENTER_BITS


class SnowflakeIDGenerator:
    """Thread-safe Snowflake ID Generator"""
    
    _instance: Optional['SnowflakeIDGenerator'] = None
    _lock = threading.Lock()
    
    def __new__(cls, datacenter_id: int = 1, worker_id: int = 1) -> 'SnowflakeIDGenerator':
        """Singleton pattern to ensure only one generator per process"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance
    
    def __init__(self, datacenter_id: int = 1, worker_id: int = 1):
        """
        Initialize the Snowflake ID Generator
        
        Args:
            datacenter_id: Datacenter ID (0-31)
            worker_id: Worker ID (0-31)
            
        Raises:
            ValueError: If datacenter_id or worker_id is out of range
        """
        if self._initialized:
            return
            
        if not 0 <= datacenter_id <= MAX_DATACENTER_ID:
            raise ValueError(f"datacenter_id must be between 0 and {MAX_DATACENTER_ID}")
        
        if not 0 <= worker_id <= MAX_WORKER_ID:
            raise ValueError(f"worker_id must be between 0 and {MAX_WORKER_ID}")
        
        self.datacenter_id = datacenter_id
        self.worker_id = worker_id
        self._sequence = 0
        self._last_timestamp = -1
        self._lock = threading.Lock()
        self._initialized = True
    
    def _current_timestamp(self) -> int:
        """Get current timestamp in milliseconds"""
        return int(time.time() * 1000)
    
    def _wait_next_millis(self, last_timestamp: int) -> int:
        """Wait until next millisecond"""
        timestamp = self._current_timestamp()
        while timestamp <= last_timestamp:
            timestamp = self._current_timestamp()
        return timestamp
    
    def generate(self) -> int:
        """
        Generate a unique Snowflake ID
        
        Returns:
            Unique 64-bit integer ID
        """
        with self._lock:
            timestamp = self._current_timestamp()
            
            # Handle clock going backwards
            if timestamp < self._last_timestamp:
                raise RuntimeError(
                    f"Clock moved backwards. Refusing to generate ID. "
                    f"Last timestamp: {self._last_timestamp}, Current: {timestamp}"
                )
            
            if timestamp == self._last_timestamp:
                # Same millisecond, increment sequence
                self._sequence = (self._sequence + 1) & MAX_SEQUENCE
                if self._sequence == 0:
                    # Sequence overflow, wait for next millisecond
                    timestamp = self._wait_next_millis(self._last_timestamp)
            else:
                # New millisecond, reset sequence
                self._sequence = 0
            
            self._last_timestamp = timestamp
            
            # Generate ID
            id_value = (
                ((timestamp - EPOCH) << TIMESTAMP_SHIFT) |
                (self.datacenter_id << DATACENTER_SHIFT) |
                (self.worker_id << WORKER_SHIFT) |
                self._sequence
            )
            
            return id_value
    
    def parse(self, id_value: int) -> dict:
        """
        Parse a Snowflake ID into its components
        
        Args:
            id_value: The Snowflake ID to parse
            
        Returns:
            Dictionary with timestamp, datacenter_id, worker_id, and sequence
        """
        sequence = id_value & MAX_SEQUENCE
        worker_id = (id_value >> WORKER_SHIFT) & MAX_WORKER_ID
        datacenter_id = (id_value >> DATACENTER_SHIFT) & MAX_DATACENTER_ID
        timestamp = (id_value >> TIMESTAMP_SHIFT) + EPOCH
        
        return {
            "timestamp": timestamp,
            "datetime": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(timestamp / 1000)),
            "datacenter_id": datacenter_id,
            "worker_id": worker_id,
            "sequence": sequence
        }


# Global ID generator instance
_id_generator: Optional[SnowflakeIDGenerator] = None


def init_id_generator(datacenter_id: int = 1, worker_id: int = 1) -> SnowflakeIDGenerator:
    """Initialize the global ID generator"""
    global _id_generator
    _id_generator = SnowflakeIDGenerator(datacenter_id, worker_id)
    return _id_generator


def generate_id() -> int:
    """Generate a unique Snowflake ID"""
    global _id_generator
    if _id_generator is None:
        raise RuntimeError("ID generator not initialized. Call init_id_generator() first.")
    return _id_generator.generate()


def parse_id(id_value: int) -> dict:
    """Parse a Snowflake ID"""
    global _id_generator
    if _id_generator is None:
        # Create a temporary instance just for parsing
        temp = SnowflakeIDGenerator(0, 0)
        return temp.parse(id_value)
    return _id_generator.parse(id_value)