"""
BaseTable: Abstract base class for all Milvus vector tables
Provides common functionality for schema management, CRUD operations, and index management
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Tuple, Union
from datetime import datetime
import logging

from pymilvus import (
    MilvusClient, DataType, FieldSchema, CollectionSchema,
    AnnSearchRequest, RRFRanker, WeightedRanker
)
from pymilvus.exceptions import MilvusException

from ..config import settings
from ..utils.snowflake import generate_id

logger = logging.getLogger(__name__)


class BaseTable(ABC):
    """
    Abstract base class for Milvus vector tables
    
    Attributes:
        collection_name: Name of the Milvus collection
        client: MilvusClient instance
        dim: Vector dimension for this table
    """
    
    def __init__(
        self,
        collection_name: str,
        uri: str = None,
        token: str = None,
        db_name: str = None,
        dim: int = None
    ):
        """
        Initialize BaseTable
        
        Args:
            collection_name: Name of the collection
            uri: Milvus server URI
            token: Authentication token
            db_name: Database name
            dim: Vector dimension
        """
        self.collection_name = collection_name
        self.uri = uri or settings.MILVUS_URI
        self.token = token or settings.MILVUS_TOKEN
        self.db_name = db_name or settings.MILVUS_DB_NAME
        self.dim = dim or self._get_default_dim()
        
        # Initialize client (lazy connection)
        self._client: Optional[MilvusClient] = None
        
        logger.info(f"Initialized {self.__class__.__name__} for collection: {collection_name}")
    
    @property
    def client(self) -> MilvusClient:
        """Get or create MilvusClient"""
        if self._client is None:
            self._client = MilvusClient(
                uri=self.uri,
                token=self.token if self.token else None,
                db_name=self.db_name
            )
        return self._client
    
    @abstractmethod
    def _get_default_dim(self) -> int:
        """Get default vector dimension for this table type"""
        pass
    
    @abstractmethod
    def _create_schema(self) -> CollectionSchema:
        """Create collection schema - must be implemented by subclasses"""
        pass
    
    def _create_index_params(self) -> Dict:
        """Create index parameters for vector fields"""
        index_params = self.client.prepare_index_params()
        
        # Get vector field names from schema
        schema = self._create_schema()
        vector_fields = [
            field.name for field in schema.fields
            if field.dtype in [DataType.FLOAT_VECTOR, DataType.FLOAT16_VECTOR, 
                           DataType.BFLOAT16_VECTOR, DataType.SPARSE_FLOAT_VECTOR]
        ]
        
        for field_name in vector_fields:
            index_params.add_index(
                field_name=field_name,
                index_type=settings.VECTOR_INDEX_TYPE,
                metric_type=settings.METRIC_TYPE,
                params=self._get_index_params()
            )
        
        return index_params
    
    def _get_index_params(self) -> Dict:
        """Get index-specific parameters"""
        index_type = settings.VECTOR_INDEX_TYPE.upper()
        
        if index_type == "HNSW":
            return {
                "M": settings.HNSW_M,
                "efConstruction": settings.HNSW_EF_CONSTRUCTION
            }
        elif index_type in ["IVF_FLAT", "IVF_SQ8", "IVF_PQ"]:
            return {"nlist": settings.IVF_NLIST}
        else:
            return {}
    
    def create_collection(self, drop_existing: bool = False) -> bool:
        """
        Create the collection with schema and indexes
        
        Args:
            drop_existing: If True, drop existing collection first
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Check if collection exists
            if self.client.has_collection(self.collection_name):
                if drop_existing:
                    logger.info(f"Dropping existing collection: {self.collection_name}")
                    self.client.drop_collection(self.collection_name)
                else:
                    logger.info(f"Collection {self.collection_name} already exists")
                    return True
            
            # Create schema
            schema = self._create_schema()
            
            # Create index parameters
            index_params = self._create_index_params()
            
            # Create collection
            self.client.create_collection(
                collection_name=self.collection_name,
                schema=schema,
                index_params=index_params
            )
            
            logger.info(f"Successfully created collection: {self.collection_name}")
            return True
            
        except MilvusException as e:
            logger.error(f"Failed to create collection {self.collection_name}: {e}")
            raise
    
    def drop_collection(self) -> bool:
        """Drop the collection"""
        try:
            if self.client.has_collection(self.collection_name):
                self.client.drop_collection(self.collection_name)
                logger.info(f"Dropped collection: {self.collection_name}")
            return True
        except MilvusException as e:
            logger.error(f"Failed to drop collection {self.collection_name}: {e}")
            raise
    
    def insert(self, data: Union[Dict, List[Dict]], auto_generate_id: bool = True) -> Dict:
        """
        Insert data into collection
        
        Args:
            data: Single record or list of records
            auto_generate_id: If True, auto-generate primary key
            
        Returns:
            Insert result with ids
        """
        try:
            # Ensure data is a list
            if isinstance(data, dict):
                data = [data]
            
            # Auto-generate IDs if requested
            if auto_generate_id:
                for record in data:
                    if 'id' not in record:
                        record['id'] = generate_id()
            
            result = self.client.insert(
                collection_name=self.collection_name,
                data=data
            )
            
            return result
            
        except MilvusException as e:
            logger.error(f"Failed to insert data: {e}")
            raise
    
    def upsert(self, data: Union[Dict, List[Dict]]) -> Dict:
        """Upsert data (insert or update)"""
        try:
            if isinstance(data, dict):
                data = [data]
            
            result = self.client.upsert(
                collection_name=self.collection_name,
                data=data
            )
            return result
            
        except MilvusException as e:
            logger.error(f"Failed to upsert data: {e}")
            raise
    
    def delete(self, ids: Union[int, str, List[int], List[str]], 
               expr: str = None) -> Dict:
        """
        Delete records by IDs or expression
        
        Args:
            ids: Single ID or list of IDs
            expr: Boolean expression for deletion
        """
        try:
            if ids is not None:
                if not isinstance(ids, list):
                    ids = [ids]
                result = self.client.delete(
                    collection_name=self.collection_name,
                    ids=ids
                )
            elif expr:
                result = self.client.delete(
                    collection_name=self.collection_name,
                    filter=expr
                )
            else:
                raise ValueError("Either ids or expr must be provided")
            
            return result
            
        except MilvusException as e:
            logger.error(f"Failed to delete data: {e}")
            raise
    
    def search_by_vector(self, vector: List[float], top_k: int = None,
                        output_fields: List[str] = None, 
                        filter_expr: str = None,
                        search_params: Dict = None) -> List[List[Dict]]:
        """
        Search by vector similarity
        
        Args:
            vector: Query vector
            top_k: Number of results to return
            output_fields: Fields to include in results
            filter_expr: Boolean expression for filtering
            search_params: Custom search parameters
            
        Returns:
            Search results grouped by query
        """
        try:
            if top_k is None:
                top_k = settings.DEFAULT_TOP_K
            
            if output_fields is None:
                output_fields = ["*"]
            
            # Default search params
            default_params = {
                "metric_type": settings.METRIC_TYPE,
                "params": {}
            }
            
            # Add index-specific params
            if settings.VECTOR_INDEX_TYPE.upper() == "HNSW":
                default_params["params"]["ef"] = settings.DEFAULT_EF
            elif settings.VECTOR_INDEX_TYPE.upper().startswith("IVF"):
                default_params["params"]["nprobe"] = settings.DEFAULT_NPROBE
            
            if search_params:
                default_params.update(search_params)
            
            results = self.client.search(
                collection_name=self.collection_name,
                data=[vector],
                limit=top_k,
                output_fields=output_fields,
                filter=filter_expr,
                search_params=default_params
            )
            
            return results
            
        except MilvusException as e:
            logger.error(f"Failed to search: {e}")
            raise
    
    def query(self, expr: str = None, output_fields: List[str] = None,
             limit: int = None, offset: int = 0) -> List[Dict]:
        """
        Query by expression
        
        Args:
            expr: Boolean expression
            output_fields: Fields to return
            limit: Maximum number of results
            offset: Number of results to skip
        """
        try:
            if output_fields is None:
                output_fields = ["*"]
            
            results = self.client.query(
                collection_name=self.collection_name,
                filter=expr,
                output_fields=output_fields,
                limit=limit,
                offset=offset
            )
            
            return results
            
        except MilvusException as e:
            logger.error(f"Failed to query: {e}")
            raise
    
    def get_by_id(self, id_value: Union[int, str], output_fields: List[str] = None) -> Optional[Dict]:
        """Get a single record by ID"""
        try:
            if output_fields is None:
                output_fields = ["*"]
            
            results = self.client.get(
                collection_name=self.collection_name,
                ids=[id_value],
                output_fields=output_fields
            )
            
            return results[0] if results else None
            
        except MilvusException as e:
            logger.error(f"Failed to get record: {e}")
            raise
    
    def get_stats(self) -> Dict:
        """Get collection statistics"""
        try:
            stats = self.client.get_collection_stats(self.collection_name)
            return stats
        except MilvusException as e:
            logger.error(f"Failed to get stats: {e}")
            raise
    
    def load(self) -> None:
        """Load collection into memory"""
        try:
            self.client.load_collection(self.collection_name)
            logger.info(f"Loaded collection: {self.collection_name}")
        except MilvusException as e:
            logger.error(f"Failed to load collection: {e}")
            raise
    
    def release(self) -> None:
        """Release collection from memory"""
        try:
            self.client.release_collection(self.collection_name)
            logger.info(f"Released collection: {self.collection_name}")
        except MilvusException as e:
            logger.error(f"Failed to release collection: {e}")
            raise
    
    def exists(self) -> bool:
        """Check if collection exists"""
        return self.client.has_collection(self.collection_name)