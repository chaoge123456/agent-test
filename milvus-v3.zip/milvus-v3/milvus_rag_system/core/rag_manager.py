"""
RAG Manager - Central manager for all RAG operations
Coordinates KnowledgeBase, Documents, Pages, and Chunks
Provides high-level operations with cascade delete and cross-KB search
"""

from typing import Any, Dict, List, Optional, Tuple, Union
import logging

from pymilvus import MilvusClient

from ..config import settings
from ..utils.snowflake import generate_id, init_id_generator
from .base_table import BaseTable

# Import all table classes
from ..models.knowledge_table import KnowledgeTable
from ..models.document_table import DocumentTable
from ..models.page_abs_table import PageAbsTable
from ..models.page_token_table import PageTokenTable
from ..models.chunk_table import ChunkTable

logger = logging.getLogger(__name__)


class RAGManager:
    """
    Central manager for RAG operations
    
    Responsibilities:
    1. Knowledge base lifecycle management
    2. Document ingestion and management
    3. Cross-KB and within-KB search
    4. Cascade delete operations
    5. Multi-vector aggregation (MaxSim)
    """
    
    def __init__(
        self,
        uri: str = None,
        token: str = None,
        db_name: str = None,
        init_snowflake: bool = True
    ):
        """
        Initialize RAG Manager
        
        Args:
            uri: Milvus URI
            token: Auth token
            db_name: Database name
            init_snowflake: Whether to initialize Snowflake ID generator
        """
        self.uri = uri or settings.MILVUS_URI
        self.token = token or settings.MILVUS_TOKEN
        self.db_name = db_name or settings.MILVUS_DB_NAME
        
        # Initialize Snowflake ID generator
        if init_snowflake:
            init_id_generator(
                datacenter_id=settings.DATACENTER_ID,
                worker_id=settings.WORKER_ID
            )
        
        # Knowledge base table (global)
        self.kb_table = KnowledgeTable(
            uri=self.uri,
            token=self.token,
            db_name=self.db_name
        )
        
        # Per-KB tables (initialized on demand)
        self._doc_tables: Dict[int, DocumentTable] = {}
        self._page_abs_tables: Dict[int, PageAbsTable] = {}
        self._page_token_tables: Dict[int, PageTokenTable] = {}
        self._chunk_tables: Dict[int, ChunkTable] = {}
        
        logger.info("RAG Manager initialized")
    
    # =========================================================================
    # Table Access Helpers
    # =========================================================================
    
    def get_doc_table(self, kb_id: int) -> DocumentTable:
        """Get or create document table for a KB"""
        if kb_id not in self._doc_tables:
            self._doc_tables[kb_id] = DocumentTable(
                kb_id=kb_id,
                uri=self.uri,
                token=self.token,
                db_name=self.db_name
            )
        return self._doc_tables[kb_id]
    
    def get_page_abs_table(self, kb_id: int) -> PageAbsTable:
        """Get or create page abstract table for a KB"""
        if kb_id not in self._page_abs_tables:
            from ..models.page_abs_table import PageAbsTable
            self._page_abs_tables[kb_id] = PageAbsTable(
                kb_id=kb_id,
                uri=self.uri,
                token=self.token,
                db_name=self.db_name
            )
        return self._page_abs_tables[kb_id]
    
    def get_page_token_table(self, kb_id: int) -> PageTokenTable:
        """Get or create page token table for a KB"""
        if kb_id not in self._page_token_tables:
            self._page_token_tables[kb_id] = PageTokenTable(
                kb_id=kb_id,
                uri=self.uri,
                token=self.token,
                db_name=self.db_name
            )
        return self._page_token_tables[kb_id]
    
    def get_chunk_table(self, kb_id: int) -> ChunkTable:
        """Get or create chunk table for a KB"""
        if kb_id not in self._chunk_tables:
            self._chunk_tables[kb_id] = ChunkTable(
                kb_id=kb_id,
                uri=self.uri,
                token=self.token,
                db_name=self.db_name
            )
        return self._chunk_tables[kb_id]
    
    # =========================================================================
    # Knowledge Base Operations
    # =========================================================================
    
    def create_knowledge_base(self, data: Dict) -> Dict:
        """
        Create a new knowledge base with all its collections
        
        Args:
            data: Knowledge base data
            
        Returns:
            Result with kb_id and collection status
        """
        # Create knowledge base record
        kb_result = self.kb_table.add_knowledge_base(data)
        kb_id = kb_result["kb_id"]
        
        # Create all sub-collections for this KB
        results = {
            "kb_id": kb_id,
            "collections": {}
        }
        
        # Document table
        try:
            doc_table = self.get_doc_table(kb_id)
            doc_table.create_collection()
            results["collections"]["documents"] = "created"
        except Exception as e:
            results["collections"]["documents"] = f"error: {str(e)}"
            logger.error(f"Failed to create document collection for KB {kb_id}: {e}")
        
        # Page abstract table
        try:
            page_abs_table = self.get_page_abs_table(kb_id)
            page_abs_table.create_collection()
            results["collections"]["page_abs"] = "created"
        except Exception as e:
            results["collections"]["page_abs"] = f"error: {str(e)}"
            logger.error(f"Failed to create page_abs collection for KB {kb_id}: {e}")
        
        # Page token table
        try:
            page_token_table = self.get_page_token_table(kb_id)
            page_token_table.create_collection()
            results["collections"]["page_token"] = "created"
        except Exception as e:
            results["collections"]["page_token"] = f"error: {str(e)}"
            logger.error(f"Failed to create page_token collection for KB {kb_id}: {e}")
        
        # Chunk table
        try:
            chunk_table = self.get_chunk_table(kb_id)
            chunk_table.create_collection()
            results["collections"]["chunks"] = "created"
        except Exception as e:
            results["collections"]["chunks"] = f"error: {str(e)}"
            logger.error(f"Failed to create chunk collection for KB {kb_id}: {e}")
        
        return results
    
    def delete_knowledge_base(self, kb_id: int, cascade: bool = True) -> Dict:
        """
        Delete a knowledge base and optionally all its data
        
        Args:
            kb_id: Knowledge base ID
            cascade: If True, delete all related collections
            
        Returns:
            Delete result
        """
        results = {
            "kb_id": kb_id,
            "cascade": cascade,
            "deleted": {}
        }
        
        if cascade:
            # Delete all sub-collections
            try:
                chunk_table = self.get_chunk_table(kb_id)
                chunk_table.drop_collection()
                results["deleted"]["chunks"] = True
            except Exception as e:
                results["deleted"]["chunks"] = str(e)
            
            try:
                page_token_table = self.get_page_token_table(kb_id)
                page_token_table.drop_collection()
                results["deleted"]["page_token"] = True
            except Exception as e:
                results["deleted"]["page_token"] = str(e)
            
            try:
                page_abs_table = self.get_page_abs_table(kb_id)
                page_abs_table.drop_collection()
                results["deleted"]["page_abs"] = True
            except Exception as e:
                results["deleted"]["page_abs"] = str(e)
            
            try:
                doc_table = self.get_doc_table(kb_id)
                doc_table.drop_collection()
                results["deleted"]["documents"] = True
            except Exception as e:
                results["deleted"]["documents"] = str(e)
        
        # Delete knowledge base record
        try:
            self.kb_table.delete_knowledge_base(kb_id)
            results["deleted"]["knowledge_base"] = True
        except Exception as e:
            results["deleted"]["knowledge_base"] = str(e)
        
        return results
    
    def cascade_delete_document(self, kb_id: int, doc_id: int) -> Dict:
        """
        Cascade delete a document and all its related data
        
        Args:
            kb_id: Knowledge base ID
            doc_id: Document ID
            
        Returns:
            Delete result
        """
        results = {
            "kb_id": kb_id,
            "doc_id": doc_id,
            "deleted": {}
        }
        
        # Delete chunks
        try:
            chunk_table = self.get_chunk_table(kb_id)
            result = chunk_table.delete_by_document(doc_id)
            results["deleted"]["chunks"] = result.get("delete_count", 0)
        except Exception as e:
            results["deleted"]["chunks"] = str(e)
        
        # Delete page tokens
        try:
            page_token_table = self.get_page_token_table(kb_id)
            result = page_token_table.delete_by_document(doc_id)
            results["deleted"]["page_tokens"] = result.get("delete_count", 0)
        except Exception as e:
            results["deleted"]["page_tokens"] = str(e)
        
        # Delete page abstracts
        try:
            page_abs_table = self.get_page_abs_table(kb_id)
            result = page_abs_table.delete_by_document(doc_id)
            results["deleted"]["page_abstracts"] = result.get("delete_count", 0)
        except Exception as e:
            results["deleted"]["page_abstracts"] = str(e)
        
        # Delete document metadata
        try:
            doc_table = self.get_doc_table(kb_id)
            result = doc_table.delete_document(doc_id)
            results["deleted"]["document"] = result.get("delete_count", 0)
        except Exception as e:
            results["deleted"]["document"] = str(e)
        
        return results