"""
Page Abstract Table - Page-level summary vectors
Stores VLM-generated page descriptions and multimodal embeddings
"""

from typing import Any, Dict, List, Optional, Union
from datetime import datetime
import logging

from pymilvus import DataType, FieldSchema, CollectionSchema

from ..core.base_table import BaseTable
from ..config import settings
from ..utils.validators import (
    validate_int64, validate_varchar, validate_array,
    validate_json, validate_vector
)
from ..utils.snowflake import generate_id

logger = logging.getLogger(__name__)


class PageAbsTable(BaseTable):
    """
    Page abstract table (page-level summary vectors)
    Primary key: row_id (int64)
    Foreign keys: doc_id (int64), page_id (int64)
    Features: abstract (VLM generated), vector (multimodal embedding), metadata
    """
    
    def __init__(
        self,
        kb_id: int,
        uri: str = None,
        token: str = None,
        db_name: str = None
    ):
        """
        Initialize PageAbsTable for a specific knowledge base
        
        Args:
            kb_id: Knowledge base ID
            uri: Milvus URI
            token: Auth token
            db_name: Database name
        """
        self.kb_id = kb_id
        collection_name = settings.PAGE_ABS_COLLECTION_TEMPLATE.format(kb_id=kb_id)
        
        super().__init__(
            collection_name=collection_name,
            uri=uri,
            token=token,
            db_name=db_name,
            dim=settings.MULTIMODAL_VECTOR_DIM
        )
    
    def _get_default_dim(self) -> int:
        """Get default vector dimension"""
        return settings.MULTIMODAL_VECTOR_DIM
    
    def _create_schema(self) -> CollectionSchema:
        """Create collection schema for page abstracts"""
        fields = [
            # Primary key - row ID (image/page unique ID)
            FieldSchema(
                name="row_id",
                dtype=DataType.INT64,
                is_primary=True,
                description="Page/image unique ID"
            ),
            # Foreign key - document ID
            FieldSchema(
                name="doc_id",
                dtype=DataType.INT64,
                description="Document ID (foreign key)"
            ),
            # Page ID (page number within document)
            FieldSchema(
                name="page_id",
                dtype=DataType.INT64,
                description="Page number in document"
            ),
            # Abstract - VLM generated description
            FieldSchema(
                name="abstract",
                dtype=DataType.VARCHAR,
                max_length=10000,
                description="VLM generated image/page description"
            ),
            # Vector - multimodal embedding
            FieldSchema(
                name="vector",
                dtype=DataType.FLOAT_VECTOR,
                dim=self.dim,
                description="Multimodal embedding vector"
            ),
            # Page storage path
            FieldSchema(
                name="page_path",
                dtype=DataType.VARCHAR,
                max_length=512,
                description="Page storage path"
            ),
            # Keywords
            FieldSchema(
                name="keyword",
                dtype=DataType.ARRAY,
                element_type=DataType.VARCHAR,
                max_capacity=100,
                max_length=128,
                description="Page keywords"
            ),
            # Metadata - JSON field for page elements
            FieldSchema(
                name="metadata",
                dtype=DataType.JSON,
                description="Page elements info (text, tables, images, pre, next)"
            ),
            # Timestamps
            FieldSchema(
                name="created_at",
                dtype=DataType.INT64,
                description="Creation timestamp"
            ),
            FieldSchema(
                name="updated_at",
                dtype=DataType.INT64,
                description="Last update timestamp"
            )
        ]
        
        schema = CollectionSchema(
            fields=fields,
            description=f"Page abstract table for KB {self.kb_id}",
            enable_dynamic_field=True
        )
        
        return schema
    
    def validate_data(self, data: Dict, for_update: bool = False) -> Dict:
        """Validate page abstract data"""
        validated = {}
        
        # row_id
        if "row_id" in data:
            validated["row_id"] = validate_int64(data["row_id"], "row_id")
        elif not for_update:
            validated["row_id"] = generate_id()
        
        # doc_id (foreign key, required)
        if "doc_id" in data:
            validated["doc_id"] = validate_int64(data["doc_id"], "doc_id")
        elif not for_update:
            raise ValueError("doc_id is required")
        
        # page_id (required)
        if "page_id" in data:
            validated["page_id"] = validate_int64(data["page_id"], "page_id")
        elif not for_update:
            raise ValueError("page_id is required")
        
        # abstract (required)
        if "abstract" in data or not for_update:
            validated["abstract"] = validate_varchar(
                data.get("abstract"), 10000, "abstract", required=not for_update
            )
        
        # vector (required)
        if "vector" in data or not for_update:
            validated["vector"] = validate_vector(
                data.get("vector"),
                self.dim,
                "vector",
                required=not for_update
            )
        
        # page_path (required)
        if "page_path" in data or not for_update:
            validated["page_path"] = validate_varchar(
                data.get("page_path"), 512, "page_path", required=not for_update
            )
        
        # keyword
        if "keyword" in data:
            validated["keyword"] = validate_array(
                data["keyword"], 100, 128, "keyword", required=False
            ) or []
        
        # metadata
        if "metadata" in data:
            validated["metadata"] = validate_json(data["metadata"], "metadata") or {}
        
        # Timestamps
        now = int(datetime.now().timestamp() * 1000)
        if not for_update:
            validated["created_at"] = data.get("created_at", now)
        validated["updated_at"] = now
        
        return validated
    
    def add_page_abstract(self, data: Dict) -> Dict:
        """Add a new page abstract"""
        validated_data = self.validate_data(data, for_update=False)
        result = self.insert(validated_data)
        
        return {
            "row_id": validated_data["row_id"],
            "doc_id": validated_data["doc_id"],
            "page_id": validated_data["page_id"],
            "insert_count": result.get("insert_count", 1)
        }
    
    def update_page_abstract(self, row_id: int, data: Dict) -> Dict:
        """Update a page abstract"""
        validated_data = self.validate_data(data, for_update=True)
        validated_data["row_id"] = row_id
        
        result = self.upsert(validated_data)
        
        return {
            "row_id": row_id,
            "upsert_count": result.get("upsert_count", 1)
        }
    
    def delete_page_abstract(self, row_id: int) -> Dict:
        """Delete a page abstract by ID"""
        result = self.delete(ids=[row_id])
        
        return {
            "row_id": row_id,
            "delete_count": result.get("delete_count", 0)
        }
    
    def delete_by_document(self, doc_id: int) -> Dict:
        """Delete all page abstracts for a document"""
        result = self.delete(expr=f"doc_id == {doc_id}")
        
        return {
            "doc_id": doc_id,
            "delete_count": result.get("delete_count", 0)
        }
    
    def get_page_abstract(self, row_id: int) -> Optional[Dict]:
        """Get a page abstract by ID"""
        return self.get_by_id(row_id)
    
    def list_by_document(self, doc_id: int, limit: int = 1000) -> List[Dict]:
        """List all page abstracts for a document"""
        return self.query(
            expr=f"doc_id == {doc_id}",
            output_fields=["*"],
            limit=limit
        )
    
    def search_by_vector(self, query_vector: List[float], top_k: int = 10,
                         filter_expr: str = None) -> List[List[Dict]]:
        """Search page abstracts by vector similarity"""
        return self.search_by_vector(
            vector=query_vector,
            top_k=top_k,
            output_fields=["row_id", "doc_id", "page_id", "abstract"],
            filter_expr=filter_expr
        )