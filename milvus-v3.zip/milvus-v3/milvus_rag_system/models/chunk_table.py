"""
Chunk Table - Document chunk vectors
Stores text chunks from OCR with embeddings
"""

from typing import Any, Dict, List, Optional, Union
from datetime import datetime
import logging

from pymilvus import DataType, FieldSchema, CollectionSchema

from ..core.base_table import BaseTable
from ..config import settings
from ..utils.validators import (
    validate_int64, validate_varchar, validate_array,
    validate_json, validate_vector
)
from ..utils.snowflake import generate_id

logger = logging.getLogger(__name__)


class ChunkTable(BaseTable):
    """
    Document chunk table
    Primary key: chunk_id (int64)
    Foreign keys: doc_id (int64), page_id (optional, int64)
    Features: content, type, vector, metadata with references
    """
    
    def __init__(
        self,
        kb_id: int,
        uri: str = None,
        token: str = None,
        db_name: str = None
    ):
        """
        Initialize ChunkTable for a specific knowledge base
        
        Args:
            kb_id: Knowledge base ID
            uri: Milvus URI
            token: Auth token
            db_name: Database name
        """
        self.kb_id = kb_id
        collection_name = settings.CHUNK_COLLECTION_TEMPLATE.format(kb_id=kb_id)
        
        super().__init__(
            collection_name=collection_name,
            uri=uri,
            token=token,
            db_name=db_name,
            dim=settings.TEXT_VECTOR_DIM
        )
    
    def _get_default_dim(self) -> int:
        """Get default vector dimension"""
        return settings.TEXT_VECTOR_DIM
    
    def _create_schema(self) -> CollectionSchema:
        """Create collection schema for document chunks"""
        fields = [
            # Primary key - chunk ID
            FieldSchema(
                name="chunk_id",
                dtype=DataType.INT64,
                is_primary=True,
                description="Chunk unique ID"
            ),
            # Foreign key - document ID
            FieldSchema(
                name="doc_id",
                dtype=DataType.INT64,
                description="Document ID (foreign key)"
            ),
            # Page ID (optional)
            FieldSchema(
                name="page_id",
                dtype=DataType.INT64,
                description="Page number in document (optional)"
            ),
            # Chunk type
            FieldSchema(
                name="type",
                dtype=DataType.VARCHAR,
                max_length=32,
                description="Chunk type: text, table, image_caption, etc."
            ),
            # Content
            FieldSchema(
                name="content",
                dtype=DataType.VARCHAR,
                max_length=65536,
                description="Chunk text content (caption for images)"
            ),
            # Vector - embedding
            FieldSchema(
                name="vector",
                dtype=DataType.FLOAT_VECTOR,
                dim=self.dim,
                description="Embedding vector"
            ),
            # Metadata - JSON with references and links
            FieldSchema(
                name="metadata",
                dtype=DataType.JSON,
                description="Display/hidden references, pre/next chunk links"
            ),
            # Keywords
            FieldSchema(
                name="keyword",
                dtype=DataType.ARRAY,
                element_type=DataType.VARCHAR,
                max_capacity=100,
                max_length=128,
                description="Chunk keywords"
            ),
            # Timestamps
            FieldSchema(
                name="created_at",
                dtype=DataType.INT64,
                description="Creation timestamp"
            ),
            FieldSchema(
                name="updated_at",
                dtype=DataType.INT64,
                description="Last update timestamp"
            )
        ]
        
        schema = CollectionSchema(
            fields=fields,
            description=f"Document chunk table for KB {self.kb_id}",
            enable_dynamic_field=True
        )
        
        return schema
    
    def validate_data(self, data: Dict, for_update: bool = False) -> Dict:
        """Validate chunk data"""
        validated = {}
        
        # chunk_id
        if "chunk_id" in data:
            validated["chunk_id"] = validate_int64(data["chunk_id"], "chunk_id")
        elif not for_update:
            validated["chunk_id"] = generate_id()
        
        # doc_id
        if "doc_id" in data:
            validated["doc_id"] = validate_int64(data["doc_id"], "doc_id")
        elif not for_update:
            raise ValueError("doc_id is required")
        
        # page_id (optional)
        if "page_id" in data:
            validated["page_id"] = validate_int64(data["page_id"], "page_id")
        
        # type
        if "type" in data or not for_update:
            type_val = data.get("type", "text")
            validated["type"] = str(type_val)[:32]
        
        # content
        if "content" in data or not for_update:
            validated["content"] = validate_varchar(
                data.get("content"), 65536, "content", required=not for_update
            )
        
        # vector
        if "vector" in data or not for_update:
            validated["vector"] = validate_vector(
                data.get("vector"),
                self.dim,
                "vector",
                required=not for_update
            )
        
        # metadata
        if "metadata" in data:
            validated["metadata"] = validate_json(data["metadata"], "metadata") or {}
        
        # keyword
        if "keyword" in data:
            validated["keyword"] = validate_array(
                data["keyword"], 100, 128, "keyword", required=False
            ) or []
        
        # Timestamps
        now = int(datetime.now().timestamp() * 1000)
        if not for_update:
            validated["created_at"] = data.get("created_at", now)
        validated["updated_at"] = now
        
        return validated
    
    def add_chunk(self, data: Dict) -> Dict:
        """Add a new chunk"""
        validated_data = self.validate_data(data, for_update=False)
        result = self.insert(validated_data)
        
        return {
            "chunk_id": validated_data["chunk_id"],
            "doc_id": validated_data["doc_id"],
            "insert_count": result.get("insert_count", 1)
        }
    
    def add_chunks_batch(self, chunks: List[Dict]) -> Dict:
        """Add multiple chunks in batch"""
        validated_chunks = []
        for chunk in chunks:
            validated_data = self.validate_data(chunk, for_update=False)
            validated_chunks.append(validated_data)
        
        result = self.insert(validated_chunks)
        
        return {
            "insert_count": result.get("insert_count", 0),
            "chunk_ids": [c["chunk_id"] for c in validated_chunks]
        }
    
    def update_chunk(self, chunk_id: int, data: Dict) -> Dict:
        """Update a chunk"""
        validated_data = self.validate_data(data, for_update=True)
        validated_data["chunk_id"] = chunk_id
        
        result = self.upsert(validated_data)
        
        return {
            "chunk_id": chunk_id,
            "upsert_count": result.get("upsert_count", 1)
        }
    
    def delete_chunk(self, chunk_id: int) -> Dict:
        """Delete a chunk"""
        result = self.delete(ids=[chunk_id])
        
        return {
            "chunk_id": chunk_id,
            "delete_count": result.get("delete_count", 0)
        }
    
    def delete_by_document(self, doc_id: int) -> Dict:
        """Delete all chunks for a document"""
        result = self.delete(expr=f"doc_id == {doc_id}")
        
        return {
            "doc_id": doc_id,
            "delete_count": result.get("delete_count", 0)
        }
    
    def get_chunk(self, chunk_id: int) -> Optional[Dict]:
        """Get a chunk by ID"""
        return self.get_by_id(chunk_id)
    
    def list_by_document(self, doc_id: int, limit: int = 1000) -> List[Dict]:
        """List all chunks for a document"""
        return self.query(
            expr=f"doc_id == {doc_id}",
            output_fields=["*"],
            limit=limit
        )
    
    def list_by_page(self, doc_id: int, page_id: int) -> List[Dict]:
        """List all chunks for a specific page"""
        return self.query(
            expr=f"doc_id == {doc_id} && page_id == {page_id}",
            output_fields=["*"]
        )
    
    def search_by_vector(self, query_vector: List[float], top_k: int = 10,
                         filter_expr: str = None) -> List[List[Dict]]:
        """Search chunks by vector similarity"""
        return self.search_by_vector(
            vector=query_vector,
            top_k=top_k,
            output_fields=["chunk_id", "doc_id", "page_id", "type", "content"],
            filter_expr=filter_expr
        )