"""
Page Token Table - Page-level multi-vector representation (ColPali/ColQwen style)
Stores multiple vectors per page for fine-grained retrieval
"""

from typing import Any, Dict, List, Optional, Tuple, Union
from datetime import datetime
import logging
import numpy as np

from pymilvus import DataType, FieldSchema, CollectionSchema

from ..core.base_table import BaseTable
from ..config import settings
from ..utils.validators import validate_int64, validate_json
from ..utils.snowflake import generate_id

logger = logging.getLogger(__name__)


class PageTokenTable(BaseTable):
    """
    Page token table (page-level multi-vector table)
    Primary key: vec_id (int64) - unique for each token vector
    Business keys: doc_id + page_id + patch_id
    Features: token_vector (per-patch vector), metadata
    
    Query results must be grouped by (doc_id, page_id) and aggregated
    using MaxSim algorithm to compute page-level final score
    """
    
    def __init__(
        self,
        kb_id: int,
        uri: str = None,
        token: str = None,
        db_name: str = None
    ):
        """
        Initialize PageTokenTable for a specific knowledge base
        
        Args:
            kb_id: Knowledge base ID
            uri: Milvus URI
            token: Auth token
            db_name: Database name
        """
        self.kb_id = kb_id
        collection_name = settings.PAGE_TOKEN_COLLECTION_TEMPLATE.format(kb_id=kb_id)
        
        super().__init__(
            collection_name=collection_name,
            uri=uri,
            token=token,
            db_name=db_name,
            dim=settings.TOKEN_VECTOR_DIM
        )
    
    def _get_default_dim(self) -> int:
        """Get default vector dimension"""
        return settings.TOKEN_VECTOR_DIM
    
    def _create_schema(self) -> CollectionSchema:
        """Create collection schema for page tokens"""
        fields = [
            # Primary key - vector ID (unique for each token)
            FieldSchema(
                name="vec_id",
                dtype=DataType.INT64,
                is_primary=True,
                description="Primary key for each token vector"
            ),
            # Token vector
            FieldSchema(
                name="token_vector",
                dtype=DataType.FLOAT_VECTOR,
                dim=self.dim,
                description="Patch token vector (ColPali/ColQwen style)"
            ),
            # Patch ID (index of the patch in the page)
            FieldSchema(
                name="patch_id",
                dtype=DataType.INT16,
                description="Patch index within page"
            ),
            # Document ID (foreign key)
            FieldSchema(
                name="doc_id",
                dtype=DataType.INT64,
                description="Document ID (foreign key)"
            ),
            # Page ID (page number)
            FieldSchema(
                name="page_id",
                dtype=DataType.INT64,
                description="Page number in document"
            ),
            # Metadata
            FieldSchema(
                name="metadata",
                dtype=DataType.JSON,
                description="Additional metadata"
            ),
            # Timestamps
            FieldSchema(
                name="created_at",
                dtype=DataType.INT64,
                description="Creation timestamp"
            ),
            FieldSchema(
                name="updated_at",
                dtype=DataType.INT64,
                description="Last update timestamp"
            )
        ]
        
        schema = CollectionSchema(
            fields=fields,
            description=f"Page token table for KB {self.kb_id}",
            enable_dynamic_field=True
        )
        
        return schema
    
    def validate_data(self, data: Dict, for_update: bool = False) -> Dict:
        """Validate page token data"""
        validated = {}
        
        # vec_id
        if "vec_id" in data:
            validated["vec_id"] = validate_int64(data["vec_id"], "vec_id")
        elif not for_update:
            validated["vec_id"] = generate_id()
        
        # token_vector
        if "token_vector" in data or not for_update:
            validated["token_vector"] = validate_vector(
                data.get("token_vector"),
                self.dim,
                "token_vector",
                required=not for_update
            )
        
        # patch_id
        if "patch_id" in data or not for_update:
            patch_id = data.get("patch_id", 0)
            validated["patch_id"] = int(patch_id)
        
        # doc_id
        if "doc_id" in data:
            validated["doc_id"] = validate_int64(data["doc_id"], "doc_id")
        elif not for_update:
            raise ValueError("doc_id is required")
        
        # page_id
        if "page_id" in data:
            validated["page_id"] = validate_int64(data["page_id"], "page_id")
        elif not for_update:
            raise ValueError("page_id is required")
        
        # metadata
        if "metadata" in data:
            validated["metadata"] = validate_json(data["metadata"], "metadata") or {}
        
        # Timestamps
        now = int(datetime.now().timestamp() * 1000)
        if not for_update:
            validated["created_at"] = data.get("created_at", now)
        validated["updated_at"] = now
        
        return validated
    
    def add_token(self, data: Dict) -> Dict:
        """Add a new token vector"""
        validated_data = self.validate_data(data, for_update=False)
        result = self.insert(validated_data)
        
        return {
            "vec_id": validated_data["vec_id"],
            "doc_id": validated_data["doc_id"],
            "page_id": validated_data["page_id"],
            "patch_id": validated_data["patch_id"],
            "insert_count": result.get("insert_count", 1)
        }
    
    def add_page_tokens(self, doc_id: int, page_id: int, 
                        token_vectors: List[List[float]],
                        metadata: Dict = None) -> Dict:
        """
        Add multiple token vectors for a page (ColPali/ColQwen style)
        
        Args:
            doc_id: Document ID
            page_id: Page number
            token_vectors: List of token vectors (one per patch)
            metadata: Optional metadata
            
        Returns:
            Insert result with vec_ids
        """
        records = []
        for patch_id, vector in enumerate(token_vectors):
            record = {
                "vec_id": generate_id(),
                "token_vector": vector,
                "patch_id": patch_id,
                "doc_id": doc_id,
                "page_id": page_id,
                "metadata": metadata or {}
            }
            records.append(record)
        
        result = self.insert(records)
        
        return {
            "doc_id": doc_id,
            "page_id": page_id,
            "patch_count": len(token_vectors),
            "insert_count": result.get("insert_count", 0),
            "vec_ids": [r["vec_id"] for r in records]
        }
    
    def search_with_maxsim(
        self,
        query_vectors: List[List[float]],
        top_k: int = 10,
        filter_expr: str = None
    ) -> List[Dict]:
        """
        Search using MaxSim algorithm (Late Interaction)
        
        This implements the core idea of ColBERT/ColPali:
        1. Query has multiple token vectors
        2. Each query token retrieves candidate documents
        3. MaxSim scores are computed per (doc, page)
        4. Final ranking by aggregated MaxSim score
        
        Args:
            query_vectors: List of query token vectors
            top_k: Number of top results to return
            filter_expr: Filter expression
            
        Returns:
            List of results with MaxSim scores, grouped by (doc_id, page_id)
        """
        # Step 1: Collect all candidates using each query token
        all_results = []
        
        for q_idx, q_vector in enumerate(query_vectors):
            results = self.search_by_vector(
                vector=q_vector,
                top_k=top_k * 3,  # Retrieve more to ensure good coverage
                output_fields=["vec_id", "doc_id", "page_id", "patch_id"],
                filter_expr=filter_expr
            )
            
            # Flatten results
            for hits in results:
                for hit in hits:
                    all_results.append({
                        "vec_id": hit["id"],
                        "doc_id": hit["entity"]["doc_id"],
                        "page_id": hit["entity"]["page_id"],
                        "patch_id": hit["entity"]["patch_id"],
                        "score": hit["distance"],
                        "q_idx": q_idx
                    })
        
        # Step 2: Group by (doc_id, page_id)
        groups = {}
        for r in all_results:
            key = (r["doc_id"], r["page_id"])
            if key not in groups:
                groups[key] = []
            groups[key].append(r)
        
        # Step 3: Compute MaxSim for each group
        final_results = []
        for (doc_id, page_id), group in groups.items():
            # Create score matrix: query_tokens x patches
            q_count = len(query_vectors)
            
            # For each query token, find max score among patches
            max_sims = []
            for q_idx in range(q_count):
                q_scores = [r["score"] for r in group if r["q_idx"] == q_idx]
                if q_scores:
                    max_sims.append(max(q_scores))
                else:
                    max_sims.append(0.0)
            
            # Final score: sum of max similarities
            final_score = sum(max_sims)
            
            # Get patch count for this page
            patch_count = len(set(r["patch_id"] for r in group))
            
            final_results.append({
                "doc_id": doc_id,
                "page_id": page_id,
                "score": final_score,
                "patch_count": patch_count,
                "query_match_count": len(group)
            })
        
        # Step 4: Sort by score and return top_k
        final_results.sort(key=lambda x: x["score"], reverse=True)
        return final_results[:top_k]
    
    def get_page_tokens(self, doc_id: int, page_id: int) -> List[Dict]:
        """Get all token vectors for a specific page"""
        return self.query(
            expr=f"doc_id == {doc_id} && page_id == {page_id}",
            output_fields=["*"]
        )
    
    def delete_by_document(self, doc_id: int) -> Dict:
        """Delete all token vectors for a document"""
        result = self.delete(expr=f"doc_id == {doc_id}")
        
        return {
            "doc_id": doc_id,
            "delete_count": result.get("delete_count", 0)
        }
    
    def get_patch_count(self, doc_id: int, page_id: int) -> int:
        """Get the number of patches (token vectors) for a page"""
        results = self.query(
            expr=f"doc_id == {doc_id} && page_id == {page_id}",
            output_fields=["patch_id"]
        )
        return len(results)