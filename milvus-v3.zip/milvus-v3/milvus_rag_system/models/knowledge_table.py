"""
Knowledge Table - Knowledge base metadata management
Stores knowledge base information for semantic routing
"""

from typing import Any, Dict, List, Optional, Union
from datetime import datetime
import logging

from pymilvus import DataType, FieldSchema, CollectionSchema

from ..core.base_table import BaseTable
from ..config import settings
from ..utils.validators import (
    validate_int64, validate_varchar, validate_array,
    validate_json, validate_vector
)
from ..utils.snowflake import generate_id

logger = logging.getLogger(__name__)


class KnowledgeTable(BaseTable):
    """
    Knowledge base table
    Primary key: kb_id (int64)
    Features: kb_name, description, tags, vector (for semantic routing), metadata
    """
    
    def __init__(
        self,
        collection_name: str = "knowledge_bases",
        uri: str = None,
        token: str = None,
        db_name: str = None
    ):
        """
        Initialize KnowledgeTable
        
        Args:
            collection_name: Collection name (default: knowledge_bases)
            uri: Milvus URI
            token: Auth token
            db_name: Database name
        """
        super().__init__(
            collection_name=collection_name,
            uri=uri,
            token=token,
            db_name=db_name,
            dim=settings.TEXT_VECTOR_DIM
        )
    
    def _get_default_dim(self) -> int:
        """Get default vector dimension"""
        return settings.TEXT_VECTOR_DIM
    
    def _create_schema(self) -> CollectionSchema:
        """Create collection schema for knowledge base"""
        fields = [
            # Primary key - knowledge base ID
            FieldSchema(
                name="kb_id",
                dtype=DataType.INT64,
                is_primary=True,
                description="Knowledge base unique ID"
            ),
            # Knowledge base name
            FieldSchema(
                name="kb_name",
                dtype=DataType.VARCHAR,
                max_length=512,
                description="Knowledge base name"
            ),
            # Knowledge base description
            FieldSchema(
                name="description",
                dtype=DataType.VARCHAR,
                max_length=10000,
                description="Knowledge base description"
            ),
            # Tags - array of strings
            FieldSchema(
                name="tags",
                dtype=DataType.ARRAY,
                element_type=DataType.VARCHAR,
                max_capacity=100,
                max_length=128,
                description="Knowledge base tags"
            ),
            # Vector - for semantic routing
            FieldSchema(
                name="vector",
                dtype=DataType.FLOAT_VECTOR,
                dim=self.dim,
                description="Knowledge base description/document aggregate vector"
            ),
            # Metadata - JSON field
            FieldSchema(
                name="metadata",
                dtype=DataType.JSON,
                description="Knowledge base metadata"
            ),
            # Created at timestamp
            FieldSchema(
                name="created_at",
                dtype=DataType.INT64,
                description="Creation timestamp (milliseconds)"
            ),
            # Updated at timestamp
            FieldSchema(
                name="updated_at",
                dtype=DataType.INT64,
                description="Last update timestamp (milliseconds)"
            )
        ]
        
        schema = CollectionSchema(
            fields=fields,
            description="Knowledge base table for RAG system",
            enable_dynamic_field=True
        )
        
        return schema
    
    def validate_data(self, data: Dict, for_update: bool = False) -> Dict:
        """
        Validate knowledge base data
        
        Args:
            data: Raw data dictionary
            for_update: Whether this is for update (allows partial data)
            
        Returns:
            Validated data dictionary
        """
        validated = {}
        
        # kb_id - generate if not provided
        if "kb_id" in data:
            validated["kb_id"] = validate_int64(data["kb_id"], "kb_id")
        elif not for_update:
            validated["kb_id"] = generate_id()
        
        # kb_name (required for insert)
        if "kb_name" in data or not for_update:
            validated["kb_name"] = validate_varchar(
                data.get("kb_name"), 512, "kb_name", required=not for_update
            )
        
        # description (required for insert)
        if "description" in data or not for_update:
            validated["description"] = validate_varchar(
                data.get("description"), 10000, "description", required=not for_update
            )
        
        # tags (required for insert)
        if "tags" in data or not for_update:
            validated["tags"] = validate_array(
                data.get("tags", []),
                settings.MAX_ARRAY_CAPACITY,
                settings.MAX_ARRAY_ELEMENT_LENGTH,
                "tags",
                required=not for_update
            ) or []
        
        # vector (required for insert)
        if "vector" in data or not for_update:
            validated["vector"] = validate_vector(
                data.get("vector"),
                self.dim,
                "vector",
                required=not for_update
            )
        
        # metadata (optional)
        if "metadata" in data:
            validated["metadata"] = validate_json(data["metadata"], "metadata") or {}
        
        # Timestamps
        now = int(datetime.now().timestamp() * 1000)
        if not for_update:
            validated["created_at"] = data.get("created_at", now)
        validated["updated_at"] = now
        
        return validated
    
    def add_knowledge_base(self, data: Dict) -> Dict:
        """
        Add a new knowledge base
        
        Args:
            data: Knowledge base data
            
        Returns:
            Insert result with kb_id
        """
        validated_data = self.validate_data(data, for_update=False)
        result = self.insert(validated_data)
        
        return {
            "kb_id": validated_data["kb_id"],
            "insert_count": result.get("insert_count", 1)
        }
    
    def update_knowledge_base(self, kb_id: int, data: Dict) -> Dict:
        """
        Update a knowledge base
        
        Args:
            kb_id: Knowledge base ID
            data: Update data
            
        Returns:
            Update result
        """
        # Validate update data
        validated_data = self.validate_data(data, for_update=True)
        validated_data["kb_id"] = kb_id
        
        # Upsert the record
        result = self.upsert(validated_data)
        
        return {
            "kb_id": kb_id,
            "upsert_count": result.get("upsert_count", 1)
        }
    
    def delete_knowledge_base(self, kb_id: int) -> Dict:
        """
        Delete a knowledge base by ID
        
        Args:
            kb_id: Knowledge base ID
            
        Returns:
            Delete result
        """
        result = self.delete(ids=[kb_id])
        
        return {
            "kb_id": kb_id,
            "delete_count": result.get("delete_count", 0)
        }
    
    def get_knowledge_base(self, kb_id: int) -> Optional[Dict]:
        """
        Get a knowledge base by ID
        
        Args:
            kb_id: Knowledge base ID
            
        Returns:
            Knowledge base data or None
        """
        return self.get_by_id(kb_id)
    
    def list_knowledge_bases(self, limit: int = 100, offset: int = 0) -> List[Dict]:
        """
        List all knowledge bases
        
        Args:
            limit: Maximum number of results
            offset: Number of results to skip
            
        Returns:
            List of knowledge base data
        """
        return self.query(
            expr=None,
            output_fields=["*"],
            limit=limit,
            offset=offset
        )
    
    def search_by_semantic(self, query_vector: List[float], top_k: int = 10,
                           filter_expr: str = None) -> List[List[Dict]]:
        """
        Search knowledge bases by semantic similarity
        
        Args:
            query_vector: Query embedding vector
            top_k: Number of results
            filter_expr: Filter expression
            
        Returns:
            Search results with distances
        """
        return self.search_by_vector(
            vector=query_vector,
            top_k=top_k,
            output_fields=["kb_id", "kb_name", "description", "tags", "metadata"],
            filter_expr=filter_expr
        )