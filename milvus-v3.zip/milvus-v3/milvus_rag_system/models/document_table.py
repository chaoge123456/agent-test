"""
Document Table - Document metadata management
Stores document-level metadata for each knowledge base
"""

from typing import Any, Dict, List, Optional, Union
from datetime import datetime
import logging

from pymilvus import DataType, FieldSchema, CollectionSchema

from ..core.base_table import BaseTable
from ..config import settings
from ..utils.validators import (
    validate_int64, validate_varchar, validate_array,
    validate_json, validate_vector, validate_page_organize
)
from ..utils.snowflake import generate_id

logger = logging.getLogger(__name__)


class DocumentTable(BaseTable):
    """
    Document metadata table
    Primary key: doc_id (int64)
    Foreign key: kb_id (int64) - references knowledge base
    Features: doc metadata, abstract, vector (abstract+keywords embedding)
    """
    
    def __init__(
        self,
        kb_id: int,
        uri: str = None,
        token: str = None,
        db_name: str = None
    ):
        """
        Initialize DocumentTable for a specific knowledge base
        
        Args:
            kb_id: Knowledge base ID (used for collection naming)
            uri: Milvus URI
            token: Auth token
            db_name: Database name
        """
        self.kb_id = kb_id
        collection_name = settings.DOCUMENT_COLLECTION_TEMPLATE.format(kb_id=kb_id)
        
        super().__init__(
            collection_name=collection_name,
            uri=uri,
            token=token,
            db_name=db_name,
            dim=settings.TEXT_VECTOR_DIM
        )
    
    def _get_default_dim(self) -> int:
        """Get default vector dimension"""
        return settings.TEXT_VECTOR_DIM
    
    def _create_schema(self) -> CollectionSchema:
        """Create collection schema for document metadata"""
        fields = [
            # Primary key - document ID
            FieldSchema(
                name="doc_id",
                dtype=DataType.INT64,
                is_primary=True,
                description="Document unique ID"
            ),
            # Foreign key - knowledge base ID
            FieldSchema(
                name="kb_id",
                dtype=DataType.INT64,
                description="Knowledge base ID (foreign key)"
            ),
            # Document name
            FieldSchema(
                name="doc_name",
                dtype=DataType.VARCHAR,
                max_length=512,
                description="File name"
            ),
            # Tags
            FieldSchema(
                name="tags",
                dtype=DataType.ARRAY,
                element_type=DataType.VARCHAR,
                max_capacity=100,
                max_length=128,
                description="Document tags"
            ),
            # Keywords
            FieldSchema(
                name="keywords",
                dtype=DataType.ARRAY,
                element_type=DataType.VARCHAR,
                max_capacity=100,
                max_length=128,
                description="Keywords"
            ),
            # Abstract - document summary
            FieldSchema(
                name="abstract",
                dtype=DataType.VARCHAR,
                max_length=10000,
                description="Document abstract (LLM generated)"
            ),
            # Vector - embedding of (abstract + keywords)
            FieldSchema(
                name="vector",
                dtype=DataType.FLOAT_VECTOR,
                dim=self.dim,
                description="Embedding vector (abstract + keywords)"
            ),
            # Organize - page organization types
            FieldSchema(
                name="organize",
                dtype=DataType.ARRAY,
                element_type=DataType.VARCHAR,
                max_capacity=10,
                max_length=32,
                description="Organization types (tree, page, chunk)"
            ),
            # Metadata - JSON field
            FieldSchema(
                name="metadata",
                dtype=DataType.JSON,
                description="Document metadata (path, type, pages, etc.)"
            ),
            # Relation - JSON field for document relations
            FieldSchema(
                name="relation",
                dtype=DataType.JSON,
                description="Document relations"
            ),
            # Timestamps
            FieldSchema(
                name="created_at",
                dtype=DataType.INT64,
                description="Creation timestamp"
            ),
            FieldSchema(
                name="updated_at",
                dtype=DataType.INT64,
                description="Last update timestamp"
            )
        ]
        
        schema = CollectionSchema(
            fields=fields,
            description=f"Document metadata table for KB {self.kb_id}",
            enable_dynamic_field=True
        )
        
        return schema
    
    def validate_data(self, data: Dict, for_update: bool = False) -> Dict:
        """Validate document data"""
        validated = {}
        
        # doc_id
        if "doc_id" in data:
            validated["doc_id"] = validate_int64(data["doc_id"], "doc_id")
        elif not for_update:
            validated["doc_id"] = generate_id()
        
        # kb_id (foreign key)
        if "kb_id" in data:
            validated["kb_id"] = validate_int64(data["kb_id"], "kb_id")
        else:
            validated["kb_id"] = self.kb_id
        
        # doc_name
        if "doc_name" in data or not for_update:
            validated["doc_name"] = validate_varchar(
                data.get("doc_name"), 512, "doc_name", required=not for_update
            )
        
        # tags
        if "tags" in data:
            validated["tags"] = validate_array(
                data["tags"], 100, 128, "tags", required=False
            ) or []
        
        # keywords
        if "keywords" in data:
            validated["keywords"] = validate_array(
                data["keywords"], 100, 128, "keywords", required=False
            ) or []
        
        # abstract
        if "abstract" in data:
            validated["abstract"] = validate_varchar(
                data.get("abstract"), 10000, "abstract", required=False
            )
        
        # vector
        if "vector" in data or not for_update:
            validated["vector"] = validate_vector(
                data.get("vector"),
                self.dim,
                "vector",
                required=not for_update
            )
        
        # organize
        if "organize" in data or not for_update:
            validated["organize"] = validate_page_organize(
                data.get("organize", ["page"]), "organize"
            )
        
        # metadata
        if "metadata" in data:
            validated["metadata"] = validate_json(data["metadata"], "metadata") or {}
        
        # relation
        if "relation" in data:
            validated["relation"] = validate_json(data["relation"], "relation")
        
        # Timestamps
        now = int(datetime.now().timestamp() * 1000)
        if not for_update:
            validated["created_at"] = data.get("created_at", now)
        validated["updated_at"] = now
        
        return validated
    
    def add_document(self, data: Dict) -> Dict:
        """Add a new document"""
        validated_data = self.validate_data(data, for_update=False)
        result = self.insert(validated_data)
        
        return {
            "doc_id": validated_data["doc_id"],
            "insert_count": result.get("insert_count", 1)
        }
    
    def update_document(self, doc_id: int, data: Dict) -> Dict:
        """Update a document"""
        validated_data = self.validate_data(data, for_update=True)
        validated_data["doc_id"] = doc_id
        
        result = self.upsert(validated_data)
        
        return {
            "doc_id": doc_id,
            "upsert_count": result.get("upsert_count", 1)
        }
    
    def delete_document(self, doc_id: int) -> Dict:
        """Delete a document"""
        result = self.delete(ids=[doc_id])
        
        return {
            "doc_id": doc_id,
            "delete_count": result.get("delete_count", 0)
        }
    
    def get_document(self, doc_id: int) -> Optional[Dict]:
        """Get a document by ID"""
        return self.get_by_id(doc_id)
    
    def list_documents(
        self,
        filter_expr: str = None,
        limit: int = 100,
        offset: int = 0
    ) -> List[Dict]:
        """List documents with optional filtering"""
        return self.query(
            expr=filter_expr,
            output_fields=["*"],
            limit=limit,
            offset=offset
        )
    
    def search_by_vector(
        self,
        query_vector: List[float],
        top_k: int = 10,
        filter_expr: str = None
    ) -> List[List[Dict]]:
        """Search documents by vector similarity"""
        return self.search_by_vector(
            vector=query_vector,
            top_k=top_k,
            output_fields=["doc_id", "doc_name", "abstract", "metadata"],
            filter_expr=filter_expr
        )
    
    def count_documents(self) -> int:
        """Get total document count"""
        stats = self.get_stats()
        return stats.get("row_count", 0)