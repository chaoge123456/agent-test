"""
Milvus RAG System

A comprehensive RAG (Retrieval-Augmented Generation) system built on Milvus vector database.

Features:
- Multi-level document representation (Knowledge Base -> Document -> Page -> Chunk)
- Multi-modal vector support (text, image, multi-vector per page)
- Late Interaction with MaxSim algorithm (ColPali/ColQwen style)
- Cascade delete and cross-KB search
- Snowflake ID generation for distributed systems
"""

__version__ = "1.0.0"

from .core.rag_manager import RAGManager
from .core.base_table import BaseTable
from .models.knowledge_table import KnowledgeTable
from .models.document_table import DocumentTable
from .models.page_abs_table import PageAbsTable
from .models.page_token_table import PageTokenTable
from .models.chunk_table import ChunkTable
from .utils.snowflake import generate_id, init_id_generator
from .config import settings

__all__ = [
    "RAGManager",
    "BaseTable",
    "KnowledgeTable",
    "DocumentTable",
    "PageAbsTable",
    "PageTokenTable",
    "ChunkTable",
    "generate_id",
    "init_id_generator",
    "settings"
]