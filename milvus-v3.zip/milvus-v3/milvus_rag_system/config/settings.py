"""
Milvus RAG System Configuration
All configurations are centralized here with environment variable support
"""

import os


# =============================================================================
# Milvus Connection Configuration
# =============================================================================
MILVUS_URI = os.getenv("MILVUS_URI", "http://localhost:19530")
MILVUS_TOKEN = os.getenv("MILVUS_TOKEN", "")
MILVUS_DB_NAME = os.getenv("MILVUS_DB_NAME", "rag_database")

# =============================================================================
# Vector Configuration
# =============================================================================
# Dimension for text embedding vectors
TEXT_VECTOR_DIM = int(os.getenv("TEXT_VECTOR_DIM", "768"))

# Dimension for multimodal/image embedding vectors
MULTIMODAL_VECTOR_DIM = int(os.getenv("MULTIMODAL_VECTOR_DIM", "512"))

# Dimension for vision model (ColPali/ColQwen style) token vectors
TOKEN_VECTOR_DIM = int(os.getenv("TOKEN_VECTOR_DIM", "128"))

# =============================================================================
# Index Configuration
# =============================================================================
# Index type for vector fields: IVF_FLAT, HNSW, IVF_SQ8, etc.
VECTOR_INDEX_TYPE = os.getenv("VECTOR_INDEX_TYPE", "HNSW")

# Metric type: COSINE, L2, IP
METRIC_TYPE = os.getenv("METRIC_TYPE", "COSINE")

# HNSW specific parameters
HNSW_M = int(os.getenv("HNSW_M", "16"))
HNSW_EF_CONSTRUCTION = int(os.getenv("HNSW_EF_CONSTRUCTION", "200"))

# IVF specific parameters
IVF_NLIST = int(os.getenv("IVF_NLIST", "128"))

# =============================================================================
# Scalar Index Configuration
# =============================================================================
# Index type for scalar fields (for efficient filtering)
SCALAR_INDEX_TYPE = os.getenv("SCALAR_INDEX_TYPE", "INVERTED")

# =============================================================================
# Snowflake ID Generator Configuration
# =============================================================================
# Data center ID (0-31)
DATACENTER_ID = int(os.getenv("DATACENTER_ID", "1"))

# Worker ID (0-31)
WORKER_ID = int(os.getenv("WORKER_ID", "1"))

# =============================================================================
# Batch Processing Configuration
# =============================================================================
# Batch size for bulk insert operations
BATCH_INSERT_SIZE = int(os.getenv("BATCH_INSERT_SIZE", "1000"))

# Maximum number of retries for failed operations
MAX_RETRIES = int(os.getenv("MAX_RETRIES", "3"))

# Retry delay in seconds
RETRY_DELAY = float(os.getenv("RETRY_DELAY", "1.0"))

# =============================================================================
# Search Configuration
# =============================================================================
# Default top-k for search results
DEFAULT_TOP_K = int(os.getenv("DEFAULT_TOP_K", "10"))

# Default nprobe for IVF indexes
DEFAULT_NPROBE = int(os.getenv("DEFAULT_NPROBE", "10"))

# Default ef for HNSW search
DEFAULT_EF = int(os.getenv("DEFAULT_EF", "64"))

# =============================================================================
# Collection Naming Configuration
# =============================================================================
# Template for document collection name: {kb_id}_documents
DOCUMENT_COLLECTION_TEMPLATE = "{kb_id}_documents"

# Template for page_abs collection name: {kb_id}_page_abs
PAGE_ABS_COLLECTION_TEMPLATE = "{kb_id}_page_abs"

# Template for page_token collection name: {kb_id}_page_token
PAGE_TOKEN_COLLECTION_TEMPLATE = "{kb_id}_page_token"

# Template for chunk collection name: {kb_id}_chunks
CHUNK_COLLECTION_TEMPLATE = "{kb_id}_chunks"

# =============================================================================
# Field Constraints
# =============================================================================
# Maximum length for VarChar fields
MAX_VARCHAR_LENGTH = 65535

# Maximum capacity for ARRAY fields
MAX_ARRAY_CAPACITY = 1000

# Maximum length for array elements
MAX_ARRAY_ELEMENT_LENGTH = 512

# Maximum size for JSON field (in bytes, approximate)
MAX_JSON_SIZE = 65536