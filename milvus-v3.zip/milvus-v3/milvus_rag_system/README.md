# Milvus RAG System

A comprehensive Retrieval-Augmented Generation (RAG) system built on Milvus vector database, supporting multi-level document representation and multi-modal retrieval.

## Features

### Multi-Level Document Representation
- **Knowledge Base**: Top-level organization unit with semantic routing vectors
- **Document**: Document-level metadata with abstracts and keyword embeddings
- **Page**: Page-level representations including VLM-generated summaries
- **Chunk**: Fine-grained text chunks from OCR with embeddings

### Multi-Modal Vector Support
- **Text Embeddings**: 768-dimensional vectors for text content
- **Multimodal Embeddings**: 512-dimensional vectors for page summaries
- **Token Vectors**: 128-dimensional multi-vectors per page (ColPali/ColQwen style)

### Advanced Retrieval
- **Late Interaction**: MaxSim algorithm for fine-grained relevance scoring
- **Multi-Vector Aggregation**: Group and aggregate results by page/document
- **Cross-KB Search**: Unified search across knowledge bases
- **Cascade Delete**: Clean removal of documents and related data

### System Features
- **Snowflake ID Generation**: Distributed unique ID generation
- **Single Database, Multiple Collections**: Logical isolation via naming
- **Configurable Index Types**: HNSW, IVF_FLAT, etc.
- **Environment Variable Support**: Flexible configuration

## Installation

```bash
# Install dependencies
pip install pymilvus numpy

# Or install from requirements.txt
pip install -r requirements.txt
```

## Quick Start

```python
from milvus_rag_system.core.rag_manager import RAGManager
import numpy as np

# Initialize RAG Manager
manager = RAGManager(
    uri="http://localhost:19530",
    db_name="my_rag_db"
)

# Create a knowledge base
kb_result = manager.create_knowledge_base({
    "kb_name": "Research Papers",
    "description": "AI and ML research papers",
    "tags": ["AI", "ML"],
    "vector": np.random.random(768).tolist()
})

kb_id = kb_result["kb_id"]

# Add a document with all representations
doc_table = manager.get_doc_table(kb_id)
doc_result = doc_table.add_document({
    "doc_name": "paper.pdf",
    "abstract": "Transformer architecture...",
    "vector": np.random.random(768).tolist()
})

# Search documents
doc_results = doc_table.search_by_vector(
    query_vector=np.random.random(768).tolist(),
    top_k=5
)

# Cascade delete a document
manager.cascade_delete_document(kb_id, doc_result["doc_id"])

# Delete knowledge base (with cascade)
manager.delete_knowledge_base(kb_id, cascade=True)
```

## Architecture

```
milvus_rag_system/
├── config/             # Configuration settings
│   └── settings.py     # All configurable parameters
├── core/               # Core components
│   ├── base_table.py   # Abstract base class for tables
│   └── rag_manager.py  # Central manager for all operations
├── models/             # Table implementations
│   ├── knowledge_table.py
│   ├── document_table.py
│   ├── page_abs_table.py
│   ├── page_token_table.py
│   └── chunk_table.py
├── utils/              # Utilities
│   ├── snowflake.py    # ID generation
│   └── validators.py   # Data validation
└── examples/           # Example usage
    └── basic_usage.py
```

## Configuration

All configuration is centralized in `config/settings.py` and can be overridden via environment variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `MILVUS_URI` | `http://localhost:19530` | Milvus server URI |
| `MILVUS_DB_NAME` | `rag_database` | Database name |
| `TEXT_VECTOR_DIM` | `768` | Text embedding dimension |
| `MULTIMODAL_VECTOR_DIM` | `512` | Multimodal embedding dimension |
| `TOKEN_VECTOR_DIM` | `128` | Token vector dimension |
| `VECTOR_INDEX_TYPE` | `HNSW` | Vector index type |
| `METRIC_TYPE` | `COSINE` | Distance metric |
| `DATACENTER_ID` | `1` | Snowflake datacenter ID |
| `WORKER_ID` | `1` | Snowflake worker ID |

## Advanced Features

### MaxSim Algorithm (Late Interaction)

The `PageTokenTable` implements the MaxSim algorithm for fine-grained relevance scoring:

```python
# Query has multiple token vectors (ColPali style)
query_tokens = [vector1, vector2, ..., vectorN]

# Search with MaxSim aggregation
results = page_token_table.search_with_maxsim(
    query_vectors=query_tokens,
    top_k=10
)

# Results include aggregated scores per (doc_id, page_id)
for r in results:
    print(f"Doc {r['doc_id']}, Page {r['page_id']}: score={r['score']}")
```

### Cascade Delete

Remove a document and all its related data:

```python
# Delete document + all page abstracts, tokens, and chunks
result = manager.cascade_delete_document(kb_id, doc_id)

print(f"Deleted {result['deleted']['chunks']} chunks")
print(f"Deleted {result['deleted']['page_tokens']} page tokens")
```

## License

MIT License - See LICENSE file for details

## Contributing

Contributions are welcome! Please submit issues and pull requests.

## Support

For questions and support, please open an issue on GitHub.