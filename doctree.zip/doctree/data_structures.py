"""
数据结构定义模块
"""

from dataclasses import dataclass, field
from typing import List, Optional, Any, Dict
from enum import Enum


class NodeType(Enum):
    """节点类型枚举"""
    DOCUMENT = "document"
    TITLE = "title"
    PARAGRAPH = "paragraph"
    TEXT = "text"
    TABLE = "table"
    TABLE_TITLE = "table_title"
    IMAGE = "image"
    FIGURE_TITLE = "figure_title"
    ABSTRACT = "abstract"
    REFERENCE = "reference"
    DOC_TITLE = "doc_title"
    FOOTNOTE = "footnote"
    HEADER = "header"
    FOOTER = "footer"
    ALGORITHM = "algorithm"
    FORMULA = "formula"
    CONTENT = "content"
    ASIDE_TEXT = "aside_text"


@dataclass
class BBox:
    """边界框"""
    x1: float
    y1: float
    x2: float
    y2: float
    
    @classmethod
    def from_list(cls, coords: List[float]) -> 'BBox':
        """从列表创建边界框"""
        return cls(coords[0], coords[1], coords[2], coords[3])
    
    def to_list(self) -> List[float]:
        """转换为列表"""
        return [self.x1, self.y1, self.x2, self.y2]
    
    def height(self) -> float:
        """获取高度"""
        return self.y2 - self.y1
    
    def width(self) -> float:
        """获取宽度"""
        return self.x2 - self.x1
    
    def center_y(self) -> float:
        """获取中心y坐标"""
        return (self.y1 + self.y2) / 2


@dataclass
class LayoutBox:
    """版面分析框"""
    box_id: int
    cls_id: int
    label: str
    coordinate: BBox
    page_index: int
    recognize: str
    title_level: Optional[int] = None
    box_name: Optional[str] = None
    score: Optional[float] = None
    is_cross_page_start: bool = False
    is_cross_page_end: bool = False
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'LayoutBox':
        """从字典创建"""
        return cls(
            box_id=data.get("box_id", 0),
            cls_id=data.get("cls_id", 0),
            label=data.get("label", ""),
            coordinate=BBox.from_list(data.get("coordinate", [0, 0, 0, 0])),
            page_index=data.get("page_index", 0),
            recognize=data.get("recognize", ""),
            title_level=data.get("title_level"),
            box_name=data.get("box_name"),
            score=data.get("score")
        )


@dataclass
class TreeNode:
    """文档树节点"""
    node_id: str
    type: NodeType
    text: str
    page_range: List[int] = field(default_factory=list)
    level: Optional[int] = None
    children: List['TreeNode'] = field(default_factory=list)
    bbox: Optional[BBox] = None
    original_boxes: List[LayoutBox] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典（用于输出）"""
        result = {
            "node_id": self.node_id,
            "type": self.type.value,
            "text": self.text,
            "page_range": self.page_range
        }
        if self.level is not None:
            result["level"] = self.level
        if self.children:
            result["children"] = [child.to_dict() for child in self.children]
        if self.metadata:
            result["metadata"] = self.metadata
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TreeNode':
        """从字典创建"""
        node = cls(
            node_id=data["node_id"],
            type=NodeType(data["type"]),
            text=data["text"],
            page_range=data.get("page_range", [])
        )
        if "level" in data:
            node.level = data["level"]
        if "children" in data:
            node.children = [cls.from_dict(child) for child in data["children"]]
        if "metadata" in data:
            node.metadata = data["metadata"]
        return node
    
    def add_child(self, child: 'TreeNode') -> None:
        """添加子节点"""
        self.children.append(child)
    
    def find_node_by_id(self, node_id: str) -> Optional['TreeNode']:
        """根据ID查找节点"""
        if self.node_id == node_id:
            return self
        for child in self.children:
            found = child.find_node_by_id(node_id)
            if found:
                return found
        return None
    
    def get_all_descendants(self) -> List['TreeNode']:
        """获取所有后代节点"""
        result = []
        for child in self.children:
            result.append(child)
            result.extend(child.get_all_descendants())
        return result
    
    def update_page_range(self) -> None:
        """更新页面范围（基于子节点）"""
        if not self.children:
            return
        all_pages = set()
        for child in self.children:
            if child.page_range:
                all_pages.update(child.page_range)
        if all_pages:
            self.page_range = [min(all_pages), max(all_pages)]


@dataclass
class PageData:
    """单页数据"""
    page_index: int
    boxes: List[LayoutBox]
    input_path: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'PageData':
        """从字典创建"""
        return cls(
            page_index=data.get("page_index", 0),
            boxes=[LayoutBox.from_dict(box) for box in data.get("boxes", [])],
            input_path=data.get("input_path")
        )


@dataclass
class DocumentTree:
    """完整文档树"""
    root: TreeNode
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为输出格式"""
        return {
            "document": self.root.to_dict(),
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'DocumentTree':
        """从字典创建"""
        return cls(
            root=TreeNode.from_dict(data["document"]),
            metadata=data.get("metadata", {})
        )
