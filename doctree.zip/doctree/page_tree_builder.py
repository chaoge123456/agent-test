"""
页面内层级构建模块
"""

import json
from typing import List, Dict, Any, Optional, Tuple

try:
    from .data_structures import (
        LayoutBox, PageData, TreeNode, NodeType, BBox
    )
    from .llm_client import LLMClient, PromptBuilder
except ImportError:
    from data_structures import (
        LayoutBox, PageData, TreeNode, NodeType, BBox
    )
    from llm_client import LLMClient, PromptBuilder


class RuleBasedPageTreeBuilder:
    """基于规则的页面内树构建器"""
    
    LABEL_TO_NODE_TYPE = {
        "paragraph_title": NodeType.TITLE,
        "text": NodeType.TEXT,
        "table": NodeType.TABLE,
        "table_title": NodeType.TABLE_TITLE,
        "image": NodeType.IMAGE,
        "figure_title": NodeType.FIGURE_TITLE,
        "abstract": NodeType.ABSTRACT,
        "reference": NodeType.REFERENCE,
        "doc_title": NodeType.DOC_TITLE,
        "content": NodeType.CONTENT,
        "aside_text": NodeType.ASIDE_TEXT
    }
    
    def __init__(self):
        self.node_counter = 0
    
    def _generate_node_id(self, prefix: str = "node") -> str:
        """生成唯一节点ID"""
        self.node_counter += 1
        return f"{prefix}_{self.node_counter}"
    
    def _filter_noise_boxes(self, boxes: List[LayoutBox]) -> List[LayoutBox]:
        """过滤噪声元素（页眉、页脚等）"""
        noise_labels = {"header", "footer", "footnote", "number", 
                       "header_image", "footer_image", "seal"}
        return [box for box in boxes if box.label not in noise_labels]
    
    def _is_potential_cross_page(self, box: LayoutBox, page_boxes: List[LayoutBox]) -> bool:
        """判断元素是否可能跨页开始"""
        last_box_ids = [b.box_id for b in sorted(page_boxes, key=lambda x: x.box_id)[-3:]]
        if box.box_id not in last_box_ids:
            return False
        
        text = box.recognize.strip()
        if not text:
            return False
        
        incomplete_endings = ["，", "、", "；", ",", ";", "（", "("]
        if text[-1] in incomplete_endings:
            return True
        
        if box.label in ["table", "image"]:
            return True
        
        return False
    
    def build_tree(self, page_data: PageData, use_llm: bool = False, 
                  llm_client: Optional[LLMClient] = None) -> Tuple[TreeNode, List[Dict[str, Any]]]:
        if use_llm and llm_client:
            return self._build_tree_with_llm(page_data, llm_client)
        else:
            return self._build_tree_rule_based(page_data)
    
    def _build_tree_rule_based(self, page_data: PageData) -> Tuple[TreeNode, List[Dict[str, Any]]]:
        filtered_boxes = self._filter_noise_boxes(page_data.boxes)
        sorted_boxes = sorted(filtered_boxes, key=lambda x: x.box_id)
        
        root = TreeNode(
            node_id=f"page_{page_data.page_index}_root",
            type=NodeType.CONTENT,
            text=f"第{page_data.page_index}页",
            page_range=[page_data.page_index, page_data.page_index]
        )
        
        cross_page_candidates = []
        stack = [root]
        
        for box in sorted_boxes:
            node_type = self.LABEL_TO_NODE_TYPE.get(box.label, NodeType.TEXT)
            
            node = TreeNode(
                node_id=self._generate_node_id(box.label),
                type=node_type,
                text=box.recognize,
                page_range=[page_data.page_index, page_data.page_index],
                level=box.title_level,
                bbox=box.coordinate,
                original_boxes=[box]
            )
            
            if node_type == NodeType.TITLE and box.title_level is not None:
                while len(stack) > 1:
                    top = stack[-1]
                    if top.type == NodeType.TITLE and top.level is not None:
                        if top.level >= box.title_level:
                            stack.pop()
                        else:
                            break
                    else:
                        break
                
                stack[-1].add_child(node)
                stack.append(node)
            else:
                stack[-1].add_child(node)
            
            if self._is_potential_cross_page(box, sorted_boxes):
                cross_page_candidates.append({
                    "box_id": box.box_id,
                    "node_id": node.node_id,
                    "reason": "位于页面末尾，可能跨页"
                })
        
        return root, cross_page_candidates
    
    def _build_tree_with_llm(self, page_data: PageData, 
                            llm_client: LLMClient) -> Tuple[TreeNode, List[Dict[str, Any]]]:
        boxes_input = []
        for box in page_data.boxes:
            box_dict = {
                "box_id": box.box_id,
                "label": box.label,
                "recognize": box.recognize,
                "title_level": box.title_level,
                "coordinate": box.coordinate.to_list()
            }
            boxes_input.append(box_dict)
        
        prompt = PromptBuilder.build_page_tree_prompt(boxes_input)
        messages = [{"role": "user", "content": prompt}]
        
        try:
            result = llm_client.chat_with_json(messages, temperature=0.3)
            return self._parse_llm_tree_result(result, page_data)
        except Exception as e:
            print(f"LLM构建树失败，回退到规则方法: {e}")
            return self._build_tree_rule_based(page_data)
    
    def _parse_llm_tree_result(self, result: Dict[str, Any], 
                               page_data: PageData) -> Tuple[TreeNode, List[Dict[str, Any]]]:
        def dict_to_node(data: Dict[str, Any]) -> TreeNode:
            node = TreeNode(
                node_id=data["node_id"],
                type=NodeType(data.get("type", "text")),
                text=data.get("text", ""),
                page_range=data.get("page_range", [page_data.page_index, page_data.page_index]),
                level=data.get("level")
            )
            if "children" in data:
                node.children = [dict_to_node(child) for child in data["children"]]
            return node
        
        tree_root = dict_to_node(result["tree"])
        cross_page_candidates = result.get("cross_page_candidates", [])
        
        return tree_root, cross_page_candidates


class PageTreeCompressor:
    """页面树压缩器 - 用于减少上下文"""
    
    @staticmethod
    def compress(tree: TreeNode, keep_full_text: bool = False) -> Dict[str, Any]:
        result = {
            "node_id": tree.node_id,
            "type": tree.type.value,
            "page_range": tree.page_range
        }
        
        if tree.type == NodeType.TITLE or keep_full_text:
            result["text"] = tree.text
        else:
            result["text"] = tree.text[:50] + "..." if len(tree.text) > 50 else tree.text
        
        if tree.level is not None:
            result["level"] = tree.level
        
        if tree.children:
            result["children"] = [
                PageTreeCompressor.compress(child, keep_full_text) 
                for child in tree.children
            ]
        
        return result
    
    @staticmethod
    def extract_title_skeleton(tree: TreeNode) -> Dict[str, Any]:
        if tree.type != NodeType.TITLE and tree.type != NodeType.DOCUMENT:
            if not tree.children:
                return None
        
        result = {
            "node_id": tree.node_id,
            "type": tree.type.value,
            "text": tree.text,
            "page_range": tree.page_range
        }
        
        if tree.level is not None:
            result["level"] = tree.level
        
        children_skeletons = []
        for child in tree.children:
            skeleton = PageTreeCompressor.extract_title_skeleton(child)
            if skeleton:
                children_skeletons.append(skeleton)
        
        if children_skeletons:
            result["children"] = children_skeletons
        
        return result
