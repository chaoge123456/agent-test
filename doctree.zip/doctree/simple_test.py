"""
简化测试脚本
"""

import json
from pathlib import Path

# 导入完整系统
from full_system import DocumentTreeBuilder, print_tree_preview


def main():
    print("=" * 60)
    print("Document Tree Organizer - Test")
    print("=" * 60)
    
    data_dir = Path("data")
    
    if not data_dir.exists():
        print(f"Error: Data directory not found: {data_dir}")
        return
    
    json_files = sorted(list(data_dir.glob("*.json")))
    print(f"\nFound {len(json_files)} data files:")
    for f in json_files:
        print(f"  - {f.name}")
    
    print("\n[1/5] Initializing builder...")
    builder = DocumentTreeBuilder()
    print("  Builder initialized")
    
    print("\n[2/5] Building document tree...")
    doc_tree = builder.build_from_directory(str(data_dir))
    print("  Document tree built")
    
    print("\n[3/5] Saving output...")
    output_dir = Path("output")
    output_dir.mkdir(exist_ok=True)
    output_path = output_dir / "document_tree.json"
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(doc_tree.to_dict(), f, ensure_ascii=False, indent=2)
    print(f"  Saved to: {output_path}")
    
    print("\n[4/5] Statistics:")
    print("  -" * 30)
    print(f"  Title: {doc_tree.metadata.get('title', 'N/A')}")
    print(f"  Total pages: {doc_tree.metadata.get('total_pages', 0)}")
    print(f"  Main content start: {doc_tree.metadata.get('main_content_start_page', 0)}")
    print(f"  Root children: {len(doc_tree.root.children)}")
    
    all_nodes = [doc_tree.root] + doc_tree.root.get_all_descendants()
    type_counts = {}
    for node in all_nodes:
        t = node.type.value
        type_counts[t] = type_counts.get(t, 0) + 1
    
    print(f"\n  Node type counts:")
    for t, count in sorted(type_counts.items()):
        print(f"    {t}: {count}")
    
    print("\n[5/5] Tree preview:")
    print("  -" * 30)
    print_tree_preview(doc_tree.root, max_depth=3)
    
    print("\n" + "=" * 60)
    print("Test complete!")
    print("=" * 60)


if __name__ == "__main__":
    main()
