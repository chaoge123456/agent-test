"""
自动化文档树组织系统 - 完整单文件版本
"""

import json
import os
from dataclasses import dataclass, field
from typing import List, Optional, Any, Dict, Tuple
from enum import Enum
from pathlib import Path
from openai import OpenAI


# ==================== 数据结构定义 ====================

class NodeType(Enum):
    """节点类型枚举"""
    DOCUMENT = "document"
    TITLE = "title"
    PARAGRAPH = "paragraph"
    TEXT = "text"
    TABLE = "table"
    TABLE_TITLE = "table_title"
    IMAGE = "image"
    FIGURE_TITLE = "figure_title"
    ABSTRACT = "abstract"
    REFERENCE = "reference"
    DOC_TITLE = "doc_title"
    FOOTNOTE = "footnote"
    HEADER = "header"
    FOOTER = "footer"
    ALGORITHM = "algorithm"
    FORMULA = "formula"
    CONTENT = "content"
    ASIDE_TEXT = "aside_text"


@dataclass
class BBox:
    """边界框"""
    x1: float
    y1: float
    x2: float
    y2: float
    
    @classmethod
    def from_list(cls, coords: List[float]) -> 'BBox':
        return cls(coords[0], coords[1], coords[2], coords[3])
    
    def to_list(self) -> List[float]:
        return [self.x1, self.y1, self.x2, self.y2]


@dataclass
class LayoutBox:
    """版面分析框"""
    box_id: int
    cls_id: int
    label: str
    coordinate: BBox
    page_index: int
    recognize: str
    title_level: Optional[int] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'LayoutBox':
        return cls(
            box_id=data.get("box_id", 0),
            cls_id=data.get("cls_id", 0),
            label=data.get("label", ""),
            coordinate=BBox.from_list(data.get("coordinate", [0, 0, 0, 0])),
            page_index=data.get("page_index", 0),
            recognize=data.get("recognize", ""),
            title_level=data.get("title_level")
        )


@dataclass
class TreeNode:
    """文档树节点"""
    node_id: str
    type: NodeType
    text: str
    page_range: List[int] = field(default_factory=list)
    level: Optional[int] = None
    children: List['TreeNode'] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        result = {
            "node_id": self.node_id,
            "type": self.type.value,
            "text": self.text,
            "page_range": self.page_range
        }
        if self.level is not None:
            result["level"] = self.level
        if self.children:
            result["children"] = [child.to_dict() for child in self.children]
        return result
    
    def add_child(self, child: 'TreeNode') -> None:
        self.children.append(child)
    
    def get_all_descendants(self) -> List['TreeNode']:
        result = []
        for child in self.children:
            result.append(child)
            result.extend(child.get_all_descendants())
        return result
    
    def update_page_range(self) -> None:
        if not self.children:
            return
        all_pages = set()
        for child in self.children:
            if child.page_range:
                all_pages.update(child.page_range)
        if all_pages:
            self.page_range = [min(all_pages), max(all_pages)]


@dataclass
class PageData:
    """单页数据"""
    page_index: int
    boxes: List[LayoutBox]
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'PageData':
        return cls(
            page_index=data.get("page_index", 0),
            boxes=[LayoutBox.from_dict(box) for box in data.get("boxes", [])]
        )


@dataclass
class DocumentTree:
    """完整文档树"""
    root: TreeNode
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "document": self.root.to_dict(),
            "metadata": self.metadata
        }


# ==================== LLM客户端 ====================

class LLMClient:
    """LLM客户端封装"""
    
    def __init__(self, api_key: str, model: str = "deepseek-chat", 
                 base_url: str = "https://api.deepseek.com"):
        self.client = OpenAI(api_key=api_key, base_url=base_url)
        self.model = model
    
    def chat(self, messages: List[Dict[str, str]]) -> str:
        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=0.7
        )
        return response.choices[0].message.content


# ==================== 页面内树构建器 ====================

class RuleBasedPageTreeBuilder:
    """基于规则的页面内树构建器"""
    
    LABEL_TO_NODE_TYPE = {
        "paragraph_title": NodeType.TITLE,
        "text": NodeType.TEXT,
        "table": NodeType.TABLE,
        "table_title": NodeType.TABLE_TITLE,
        "image": NodeType.IMAGE,
        "figure_title": NodeType.FIGURE_TITLE,
        "abstract": NodeType.ABSTRACT,
        "reference": NodeType.REFERENCE,
        "doc_title": NodeType.DOC_TITLE,
        "content": NodeType.CONTENT
    }
    
    def __init__(self):
        self.node_counter = 0
    
    def _generate_node_id(self, prefix: str = "node") -> str:
        self.node_counter += 1
        return f"{prefix}_{self.node_counter}"
    
    def _filter_noise_boxes(self, boxes: List[LayoutBox]) -> List[LayoutBox]:
        noise_labels = {"header", "footer", "footnote", "number", 
                       "header_image", "footer_image", "seal"}
        return [box for box in boxes if box.label not in noise_labels]
    
    def build_tree(self, page_data: PageData) -> Tuple[TreeNode, List[Dict[str, Any]]]:
        filtered_boxes = self._filter_noise_boxes(page_data.boxes)
        sorted_boxes = sorted(filtered_boxes, key=lambda x: x.box_id)
        
        root = TreeNode(
            node_id=f"page_{page_data.page_index}_root",
            type=NodeType.CONTENT,
            text=f"第{page_data.page_index}页",
            page_range=[page_data.page_index, page_data.page_index]
        )
        
        cross_page_candidates = []
        stack = [root]
        
        for box in sorted_boxes:
            node_type = self.LABEL_TO_NODE_TYPE.get(box.label, NodeType.TEXT)
            
            node = TreeNode(
                node_id=self._generate_node_id(box.label),
                type=node_type,
                text=box.recognize,
                page_range=[page_data.page_index, page_data.page_index],
                level=box.title_level
            )
            
            if node_type == NodeType.TITLE and box.title_level is not None:
                while len(stack) > 1:
                    top = stack[-1]
                    if top.type == NodeType.TITLE and top.level is not None:
                        if top.level >= box.title_level:
                            stack.pop()
                        else:
                            break
                    else:
                        break
                stack[-1].add_child(node)
                stack.append(node)
            else:
                stack[-1].add_child(node)
            
            if box.box_id in [b.box_id for b in sorted_boxes[-3:]]:
                cross_page_candidates.append({"box_id": box.box_id})
        
        return root, cross_page_candidates


# ==================== 正文起始检测器 ====================

class MainContentDetector:
    """正文起始检测器"""
    
    def detect(self, pages: List[PageData]) -> Tuple[int, Dict[str, Any]]:
        preliminary_pages = []
        
        for i, page in enumerate(pages):
            page_info = self._analyze_page(page)
            page_type = page_info["type"]
            
            if page_type == "main_content":
                return i, {
                    "main_content_start_page": i,
                    "confidence": 0.9,
                    "preliminary_pages": preliminary_pages
                }
            else:
                preliminary_pages.append({
                    "page_index": i,
                    "type": page_type
                })
        
        return 0, {
            "main_content_start_page": 0,
            "confidence": 0.5,
            "preliminary_pages": preliminary_pages
        }
    
    def _analyze_page(self, page: PageData) -> Dict[str, Any]:
        has_section_title = False
        
        for box in page.boxes:
            if box.label == "paragraph_title" and box.title_level and box.title_level >= 2:
                has_section_title = True
        
        if has_section_title:
            return {"type": "main_content", "confidence": 0.9}
        
        return {"type": "unknown", "confidence": 0.5}


# ==================== 跨页合并器 ====================

class CrossPageMerger:
    """跨页合并器"""
    
    def __init__(self):
        self.merge_count = 0
    
    def merge_pages(
        self,
        page_trees: List[Tuple[TreeNode, List[Dict[str, Any]]]],
        pages_data: List[PageData]
    ) -> TreeNode:
        if not page_trees:
            raise ValueError("没有页面树可合并")
        
        doc_root = TreeNode(
            node_id="doc_root",
            type=NodeType.DOCUMENT,
            text="文档",
            page_range=[0, len(page_trees) - 1]
        )
        
        if len(page_trees) == 1:
            doc_root.children = page_trees[0][0].children
            doc_root.update_page_range()
            return doc_root
        
        current_root = page_trees[0][0]
        
        for i in range(1, len(page_trees)):
            next_tree = page_trees[i][0]
            current_root = self._merge_rule_based(current_root, next_tree)
        
        doc_root.children = current_root.children
        doc_root.update_page_range()
        
        return doc_root
    
    def _merge_rule_based(self, prev_tree: TreeNode, curr_tree: TreeNode) -> TreeNode:
        for child in curr_tree.children:
            prev_tree.add_child(child)
        prev_tree.update_page_range()
        return prev_tree


# ==================== 主流程 ====================

class DocumentTreeBuilder:
    """文档树构建器 - 主入口类"""
    
    def __init__(self, api_key: Optional[str] = None):
        self.page_tree_builder = RuleBasedPageTreeBuilder()
        self.content_detector = MainContentDetector()
        self.cross_page_merger = CrossPageMerger()
    
    def build_from_directory(self, directory: str, pattern: str = "*.json") -> DocumentTree:
        dir_path = Path(directory)
        file_paths = sorted(list(dir_path.glob(pattern)))
        return self.build_from_files([str(p) for p in file_paths])
    
    def build_from_files(self, file_paths: List[str]) -> DocumentTree:
        pages = []
        for file_path in file_paths:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                pages.append(PageData.from_dict(data))
        return self.build_from_pages(pages)
    
    def build_from_pages(self, pages: List[PageData]) -> DocumentTree:
        main_start_page, detection_info = self.content_detector.detect(pages)
        print(f"正文起始页: {main_start_page}")
        
        page_trees = []
        for page in pages:
            tree, candidates = self.page_tree_builder.build_tree(page)
            page_trees.append((tree, candidates))
            print(f"第{page.page_index}页树构建完成，跨页候选: {len(candidates)}")
        
        merged_root = self.cross_page_merger.merge_pages(page_trees, pages)
        print(f"跨页合并完成")
        
        doc_title = self._extract_document_title(pages)
        merged_root.text = doc_title
        merged_root.page_range = [0, len(pages) - 1]
        
        doc_tree = DocumentTree(
            root=merged_root,
            metadata={
                "title": doc_title,
                "total_pages": len(pages),
                "main_content_start_page": main_start_page
            }
        )
        
        return doc_tree
    
    def _extract_document_title(self, pages: List[PageData]) -> str:
        for page in pages[:3]:
            for box in page.boxes:
                if box.label == "doc_title" and box.recognize:
                    return box.recognize
        for page in pages[:3]:
            for box in page.boxes:
                if box.label == "paragraph_title" and box.recognize:
                    return box.recognize
        return "未命名文档"


# ==================== 测试函数 ====================

def print_tree_preview(node, indent=0, max_depth=3, current_depth=0):
    if current_depth > max_depth:
        return
    prefix = "  " * indent
    node_type = node.type.value
    text_preview = node.text[:40] + "..." if len(node.text) > 40 else node.text
    level_str = f" (level={node.level})" if node.level else ""
    page_str = f" pages={node.page_range}" if node.page_range else ""
    print(f"{prefix}├─ {node_type}{level_str}: {text_preview}{page_str}")
    for child in node.children:
        print_tree_preview(child, indent + 1, max_depth, current_depth + 1)


def main():
    print("=" * 60)
    print("自动化文档树组织系统 - 测试")
    print("=" * 60)
    
    data_dir = Path("data")
    
    if not data_dir.exists():
        print(f"错误: 数据目录不存在: {data_dir}")
        return
    
    json_files = sorted(list(data_dir.glob("*.json")))
    print(f"\n找到 {len(json_files)} 个数据文件:")
    for f in json_files:
        print(f"  - {f.name}")
    
    print("\n[1/5] 初始化文档树构建器...")
    builder = DocumentTreeBuilder()
    print("  ✓ 构建器初始化完成")
    
    print("\n[2/5] 开始构建文档树...")
    doc_tree = builder.build_from_directory(str(data_dir))
    print("  ✓ 文档树构建完成")
    
    print("\n[3/5] 保存输出结果...")
    output_dir = Path("output")
    output_dir.mkdir(exist_ok=True)
    output_path = output_dir / "document_tree.json"
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(doc_tree.to_dict(), f, ensure_ascii=False, indent=2)
    print(f"  ✓ 结果已保存到: {output_path}")
    
    print("\n[4/5] 文档树统计:")
    print("  -" * 30)
    print(f"  文档标题: {doc_tree.metadata.get('title', 'N/A')}")
    print(f"  总页数: {doc_tree.metadata.get('total_pages', 0)}")
    print(f"  正文起始页: {doc_tree.metadata.get('main_content_start_page', 0)}")
    print(f"  根节点类型: {doc_tree.root.type.value}")
    print(f"  根节点子节点数: {len(doc_tree.root.children)}")
    
    all_nodes = [doc_tree.root] + doc_tree.root.get_all_descendants()
    type_counts = {}
    for node in all_nodes:
        t = node.type.value
        type_counts[t] = type_counts.get(t, 0) + 1
    
    print(f"\n  节点类型统计:")
    for t, count in sorted(type_counts.items()):
        print(f"    {t}: {count}")
    
    print("\n[5/5] 树结构预览:")
    print("  -" * 30)
    print_tree_preview(doc_tree.root, max_depth=3)
    
    print("\n" + "=" * 60)
    print("测试完成!")
    print("=" * 60)


if __name__ == "__main__":
    main()
