"""
独立运行测试脚本 - 避免相对导入问题
"""

import json
import os
import sys
from pathlib import Path

# 添加当前目录到路径
sys.path.insert(0, str(Path(__file__).parent))

from data_structures import PageData, DocumentTree, TreeNode, NodeType, LayoutBox, BBox
from llm_client import LLMClient, PromptBuilder
from page_tree_builder import RuleBasedPageTreeBuilder, PageTreeCompressor
from content_detector import MainContentDetector
from cross_page_merger import CrossPageMerger


class DocumentTreeBuilder:
    """文档树构建器 - 主入口类"""
    
    def __init__(
        self,
        api_key: str = None,
        model: str = "deepseek-chat",
        base_url: str = "https://api.deepseek.com",
        use_llm_for_page_tree: bool = False,
        use_llm_for_content_detection: bool = True,
        use_llm_for_cross_page: bool = False
    ):
        self.llm_client = None
        if api_key:
            self.llm_client = LLMClient(
                api_key=api_key,
                model=model,
                base_url=base_url
            )
        
        self.use_llm_for_page_tree = use_llm_for_page_tree
        self.use_llm_for_content_detection = use_llm_for_content_detection
        self.use_llm_for_cross_page = use_llm_for_cross_page
        
        self.page_tree_builder = RuleBasedPageTreeBuilder()
        self.content_detector = MainContentDetector(
            use_llm=use_llm_for_content_detection,
            llm_client=self.llm_client
        )
        self.cross_page_merger = CrossPageMerger(
            use_llm=use_llm_for_cross_page,
            llm_client=self.llm_client
        )
    
    def build_from_files(self, file_paths):
        pages = []
        for file_path in file_paths:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                pages.append(PageData.from_dict(data))
        return self.build_from_pages(pages)
    
    def build_from_directory(self, directory, pattern="*.json"):
        dir_path = Path(directory)
        file_paths = sorted(list(dir_path.glob(pattern)))
        return self.build_from_files([str(p) for p in file_paths])
    
    def build_from_pages(self, pages):
        main_start_page, detection_info = self.content_detector.detect(pages)
        print(f"正文起始页: {main_start_page}")
        
        page_trees = []
        for page in pages:
            tree, candidates = self.page_tree_builder.build_tree(
                page,
                use_llm=self.use_llm_for_page_tree,
                llm_client=self.llm_client
            )
            page_trees.append((tree, candidates))
            print(f"第{page.page_index}页树构建完成，跨页候选: {len(candidates)}")
        
        merged_root = self.cross_page_merger.merge_pages(page_trees, pages)
        print(f"跨页合并完成，合并次数: {self.cross_page_merger.merge_count}")
        
        doc_title = self._extract_document_title(pages)
        merged_root.text = doc_title
        merged_root.page_range = [0, len(pages) - 1]
        
        doc_tree = DocumentTree(
            root=merged_root,
            metadata={
                "title": doc_title,
                "total_pages": len(pages),
                "main_content_start_page": main_start_page,
                "detection_info": detection_info
            }
        )
        
        return doc_tree
    
    def _extract_document_title(self, pages):
        for page in pages[:3]:
            for box in page.boxes:
                if box.label == "doc_title" and box.recognize:
                    return box.recognize
        for page in pages[:3]:
            for box in page.boxes:
                if box.label == "paragraph_title" and box.recognize:
                    return box.recognize
        return "未命名文档"


def print_tree_preview(node, indent=0, max_depth=3, current_depth=0):
    if current_depth > max_depth:
        return
    prefix = "  " * indent
    node_type = node.type.value
    text_preview = node.text[:40] + "..." if len(node.text) > 40 else node.text
    level_str = f" (level={node.level})" if node.level else ""
    page_str = f" pages={node.page_range}" if node.page_range else ""
    print(f"{prefix}├─ {node_type}{level_str}: {text_preview}{page_str}")
    for child in node.children:
        print_tree_preview(child, indent + 1, max_depth, current_depth + 1)


def main():
    print("=" * 60)
    print("自动化文档树组织系统 - 测试")
    print("=" * 60)
    
    api_key = "sk-71345ea7232d4739b41c16dabd51d0b8"
    data_dir = Path("data")
    
    if not data_dir.exists():
        print(f"错误: 数据目录不存在: {data_dir}")
        return
    
    json_files = sorted(list(data_dir.glob("*.json")))
    print(f"\n找到 {len(json_files)} 个数据文件:")
    for f in json_files:
        print(f"  - {f.name}")
    
    print("\n[1/5] 初始化文档树构建器...")
    builder = DocumentTreeBuilder(
        api_key=api_key,
        use_llm_for_page_tree=False,
        use_llm_for_content_detection=False,
        use_llm_for_cross_page=False
    )
    print("  ✓ 构建器初始化完成")
    
    print("\n[2/5] 开始构建文档树...")
    doc_tree = builder.build_from_directory(str(data_dir))
    print("  ✓ 文档树构建完成")
    
    print("\n[3/5] 保存输出结果...")
    output_dir = Path("output")
    output_dir.mkdir(exist_ok=True)
    output_path = output_dir / "document_tree.json"
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(doc_tree.to_dict(), f, ensure_ascii=False, indent=2)
    print(f"  ✓ 结果已保存到: {output_path}")
    
    print("\n[4/5] 文档树统计:")
    print("  -" * 30)
    print(f"  文档标题: {doc_tree.metadata.get('title', 'N/A')}")
    print(f"  总页数: {doc_tree.metadata.get('total_pages', 0)}")
    print(f"  正文起始页: {doc_tree.metadata.get('main_content_start_page', 0)}")
    print(f"  根节点类型: {doc_tree.root.type.value}")
    print(f"  根节点子节点数: {len(doc_tree.root.children)}")
    
    all_nodes = [doc_tree.root] + doc_tree.root.get_all_descendants()
    type_counts = {}
    for node in all_nodes:
        t = node.type.value
        type_counts[t] = type_counts.get(t, 0) + 1
    
    print(f"\n  节点类型统计:")
    for t, count in sorted(type_counts.items()):
        print(f"    {t}: {count}")
    
    print("\n[5/5] 树结构预览:")
    print("  -" * 30)
    print_tree_preview(doc_tree.root, max_depth=3)
    
    print("\n" + "=" * 60)
    print("测试完成!")
    print("=" * 60)


if __name__ == "__main__":
    main()
