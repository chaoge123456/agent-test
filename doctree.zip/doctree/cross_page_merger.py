"""
跨页整合模块
"""

from typing import List, Dict, Any, Optional, Tuple
from data_structures import TreeNode, NodeType, LayoutBox, PageData
from llm_client import LLMClient, PromptBuilder
from page_tree_builder import PageTreeCompressor


class CrossPageMerger:
    """跨页合并器"""
    
    def __init__(self, use_llm: bool = False, llm_client: Optional[LLMClient] = None):
        self.use_llm = use_llm
        self.llm_client = llm_client
        self.merge_count = 0
    
    def merge_pages(
        self,
        page_trees: List[Tuple[TreeNode, List[Dict[str, Any]]]],
        pages_data: List[PageData]
    ) -> TreeNode:
        """
        合并多个页面的树
        
        Args:
            page_trees: 页面树列表，每个元素是(树节点, 跨页候选列表)
            pages_data: 原始页面数据
            
        Returns:
            合并后的根节点
        """
        if not page_trees:
            raise ValueError("没有页面树可合并")
        
        # 创建文档根节点
        doc_root = TreeNode(
            node_id="doc_root",
            type=NodeType.DOCUMENT,
            text="文档",
            page_range=[0, len(page_trees) - 1]
        )
        
        if len(page_trees) == 1:
            # 只有一页，直接添加
            doc_root.children = page_trees[0][0].children
            doc_root.update_page_range()
            return doc_root
        
        # 增量合并
        current_root = page_trees[0][0]
        
        for i in range(1, len(page_trees)):
            next_tree = page_trees[i][0]
            prev_candidates = page_trees[i-1][1]
            
            if self.use_llm and self.llm_client:
                current_root = self._merge_with_llm(
                    current_root, next_tree,
                    pages_data[i-1], pages_data[i]
                )
            else:
                current_root = self._merge_rule_based(
                    current_root, next_tree, prev_candidates
                )
        
        doc_root.children = current_root.children
        doc_root.update_page_range()
        
        return doc_root
    
    def _merge_rule_based(
        self,
        prev_tree: TreeNode,
        curr_tree: TreeNode,
        prev_candidates: List[Dict[str, Any]]
    ) -> TreeNode:
        """基于规则的合并"""
        # 找到前一页的最后一个可附加节点
        last_appendable = self._find_last_appendable_node(prev_tree)
        
        if last_appendable and prev_candidates:
            # 尝试将当前页的内容附加到前一页的最后一个节点
            candidate_node_ids = [c["node_id"] for c in prev_candidates]
            
            if last_appendable.node_id in candidate_node_ids or self._should_append(last_appendable, curr_tree):
                # 附加当前页的子节点
                for child in curr_tree.children:
                    last_appendable.add_child(child)
                
                # 更新页面范围
                last_appendable.update_page_range()
                self.merge_count += 1
                return prev_tree
        
        # 如果不能附加，直接合并子节点
        for child in curr_tree.children:
            prev_tree.add_child(child)
        
        prev_tree.update_page_range()
        return prev_tree
    
    def _find_last_appendable_node(self, tree: TreeNode) -> Optional[TreeNode]:
        """找到最后一个可附加内容的节点"""
        if not tree.children:
            return None
        
        last_child = tree.children[-1]
        
        # 标题或段落可以附加
        appendable_types = [NodeType.TITLE, NodeType.PARAGRAPH, NodeType.TEXT]
        
        if last_child.type in appendable_types:
            # 如果有子节点，递归查找
            if last_child.children:
                deeper = self._find_last_appendable_node(last_child)
                return deeper if deeper else last_child
            return last_child
        
        return None
    
    def _should_append(self, prev_node: TreeNode, curr_tree: TreeNode) -> bool:
        """判断是否应该附加"""
        # 检查前一节点文本是否以非结束标点结尾
        text = prev_node.text.strip()
        if not text:
            return False
        
        incomplete_endings = ["，", "、", "；", ",", ";", "（", "(", "—"]
        if text[-1] in incomplete_endings:
            return True
        
        # 检查当前页第一个节点类型是否匹配
        if curr_tree.children:
            first_curr = curr_tree.children[0]
            # 如果当前页以文本开头，可能是续接
            if first_curr.type in [NodeType.TEXT, NodeType.PARAGRAPH]:
                return True
        
        return False
    
    def _merge_with_llm(
        self,
        prev_tree: TreeNode,
        curr_tree: TreeNode,
        prev_page: PageData,
        curr_page: PageData
    ) -> TreeNode:
        """使用LLM合并"""
        # 压缩树以减少token
        prev_compressed = PageTreeCompressor.compress(prev_tree, keep_full_text=True)
        curr_compressed = PageTreeCompressor.compress(curr_tree, keep_full_text=True)
        
        # 准备box数据
        prev_boxes = [{"box_id": b.box_id, "label": b.label, "recognize": b.recognize} 
                     for b in prev_page.boxes[-5:]]  # 只取最后5个
        curr_boxes = [{"box_id": b.box_id, "label": b.label, "recognize": b.recognize} 
                     for b in curr_page.boxes[:5]]  # 只取前5个
        
        prompt = PromptBuilder.build_cross_page_merge_prompt(
            prev_compressed, curr_compressed, prev_boxes, curr_boxes
        )
        messages = [{"role": "user", "content": prompt}]
        
        try:
            result = self.llm_client.chat_with_json(messages, temperature=0.3)
            return self._apply_llm_merge_result(prev_tree, curr_tree, result)
        except Exception as e:
            print(f"LLM合并失败，回退到规则方法: {e}")
            return self._merge_rule_based(prev_tree, curr_tree, [])
    
    def _apply_llm_merge_result(
        self,
        prev_tree: TreeNode,
        curr_tree: TreeNode,
        result: Dict[str, Any]
    ) -> TreeNode:
        """应用LLM合并结果"""
        # 简单实现：如果有合并建议，尝试应用
        merges = result.get("cross_page_merges", [])
        
        if merges:
            # 有明确的合并建议
            print(f"LLM建议合并 {len(merges)} 处跨页内容")
            # TODO: 实现更复杂的合并逻辑
            pass
        
        # 回退到简单合并
        return self._merge_rule_based(prev_tree, curr_tree, [])


class BBoxHelper:
    """BBox辅助工具 - 用于跨页判断"""
    
    @staticmethod
    def is_same_column(box1: LayoutBox, box2: LayoutBox, tolerance: float = 50.0) -> bool:
        """判断是否在同一列"""
        return abs(box1.coordinate.x1 - box2.coordinate.x1) < tolerance
    
    @staticmethod
    def is_page_bottom(box: LayoutBox, page_height: float = 1600.0, threshold: float = 0.8) -> bool:
        """判断是否在页面底部"""
        return box.coordinate.y2 > page_height * threshold
    
    @staticmethod
    def is_page_top(box: LayoutBox, threshold: float = 200.0) -> bool:
        """判断是否在页面顶部"""
        return box.coordinate.y1 < threshold
    
    @staticmethod
    def estimate_title_level_from_bbox(boxes: List[LayoutBox]) -> Dict[int, int]:
        """
        从bbox推断标题级别（辅助方法）
        
        原理：通常高级标题字体更大、位置更靠左
        """
        title_boxes = [b for b in boxes if b.label == "paragraph_title"]
        if not title_boxes:
            return {}
        
        # 按高度排序（假设字体大小与高度正相关）
        sorted_by_height = sorted(title_boxes, key=lambda b: -b.coordinate.height())
        
        level_map = {}
        current_level = 1
        last_height = None
        
        for box in sorted_by_height:
            if last_height is not None:
                # 如果高度差异较大，提升级别
                height_ratio = box.coordinate.height() / last_height
                if height_ratio < 0.85:
                    current_level += 1
            
            level_map[box.box_id] = current_level
            last_height = box.coordinate.height()
        
        return level_map
