"""
LLM调用模块
"""

import json
from typing import Optional, Dict, Any, List
from openai import OpenAI


class LLMClient:
    """LLM客户端封装"""
    
    def __init__(
        self,
        api_key: str,
        model: str = "deepseek-chat",
        base_url: str = "https://api.deepseek.com",
        temperature: float = 0.7,
        max_tokens: Optional[int] = None
    ):
        self.client = OpenAI(
            api_key=api_key,
            base_url=base_url
        )
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
    
    def chat(
        self,
        messages: List[Dict[str, str]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None
    ) -> str:
        """发送聊天请求"""
        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=temperature if temperature is not None else self.temperature,
            max_tokens=max_tokens if max_tokens is not None else self.max_tokens
        )
        return response.choices[0].message.content
    
    def chat_with_json(
        self,
        messages: List[Dict[str, str]],
        temperature: Optional[float] = None
    ) -> Dict[str, Any]:
        """发送聊天请求并解析JSON响应"""
        response = self.chat(messages, temperature=temperature)
        # 尝试提取JSON部分
        try:
            # 先尝试直接解析
            return json.loads(response)
        except json.JSONDecodeError:
            # 尝试提取 ```json ... ``` 包裹的部分
            if "```json" in response and "```" in response.split("```json", 1)[1]:
                json_str = response.split("```json", 1)[1].split("```", 1)[0].strip()
                return json.loads(json_str)
            elif "```" in response:
                json_str = response.split("```", 1)[1].split("```", 1)[0].strip()
                return json.loads(json_str)
            raise


class PromptBuilder:
    """提示词构建器"""
    
    @staticmethod
    def build_page_tree_prompt(boxes: List[Dict[str, Any]]) -> str:
        """构建页面内层级构建提示词"""
        boxes_json = json.dumps(boxes, ensure_ascii=False, indent=2)
        
        return f"""你是一个文档结构分析专家。请根据以下页面元素列表，构建该页面的层级树结构。

输入元素列表（按阅读顺序排序，box_id从小到大）：
```json
{boxes_json}
```

任务说明：
1. 标题应成为父节点，包含后续文本/图表，直到下一个同级或更高级标题
2. title_level越小，标题级别越高（1 > 2 > 3...）
3. 对于跨页的元素，标记可能跨页开始的元素（在页面末尾、内容不完整的元素）
4. 忽略页眉页脚（header, footer）等辅助元素

输出格式要求（JSON）：
```json
{{
  "tree": {{
    "node_id": "page_0_root",
    "type": "page_root",
    "children": [
      {{
        "node_id": "title_1",
        "type": "title",
        "level": 1,
        "text": "标题文本",
        "page_range": [0, 0],
        "box_ids": [0],
        "may_cross_page": false,
        "children": [
          {{
            "node_id": "para_1",
            "type": "paragraph",
            "text": "段落文本",
            "page_range": [0, 0],
            "box_ids": [1],
            "may_cross_page": false
          }}
        ]
      }}
    ]
  }},
  "cross_page_candidates": [
    {{
      "box_id": 5,
      "reason": "位于页面底部，文本可能不完整"
    }}
  ]
}}
```

注意事项：
- node_id必须唯一
- type可以是: title, paragraph, text, table, image, figure_title, table_title, abstract, reference
- may_cross_page标记是否可能跨页
- box_ids记录使用的原始box_id列表

请直接输出JSON，不要包含其他文字。"""
    
    @staticmethod
    def build_main_content_detection_prompt(pages_data: List[Dict[str, Any]]) -> str:
        """构建正文起始识别提示词"""
        pages_json = json.dumps(pages_data, ensure_ascii=False, indent=2)
        
        return f"""你是一个文档分析专家。请分析以下文档前几页的内容，判断正文从哪一页开始。

页面内容摘要：
```json
{pages_json}
```

任务说明：
1. 分析是否存在封面、标题页、摘要、目录等前置内容
2. 正文通常从章节标题开始
3. 注意区分doc_title（文档标题）和正文章节标题

输出格式要求（JSON）：
```json
{{
  "main_content_start_page": 0,
  "confidence": 0.9,
  "reasoning": "第0页包含文档标题和第一章标题，正文从第0页开始",
  "preliminary_pages": [
    {{
      "page_index": 0,
      "type": "title_page",
      "description": "包含文档标题"
    }}
  ]
}}
```

请直接输出JSON，不要包含其他文字。"""
    
    @staticmethod
    def build_cross_page_merge_prompt(
        prev_tree: Dict[str, Any],
        curr_tree: Dict[str, Any],
        prev_page_boxes: List[Dict[str, Any]],
        curr_page_boxes: List[Dict[str, Any]]
    ) -> str:
        """构建跨页合并提示词"""
        prev_tree_json = json.dumps(prev_tree, ensure_ascii=False, indent=2)
        curr_tree_json = json.dumps(curr_tree, ensure_ascii=False, indent=2)
        
        return f"""你是一个文档结构合并专家。请分析相邻两页的文档树，识别并合并跨页的元素。

前一页（第N页）的树结构：
```json
{prev_tree_json}
```

当前页（第N+1页）的树结构：
```json
{curr_tree_json}
```

任务说明：
1. 检查前一页末尾的元素是否与当前页开头的元素属于同一逻辑单元
2. 跨页的可能情况：
   - 标题在前一页底部，内容在当前页
   - 段落跨页（前一页段落不完整）
   - 表格跨页
   - 列表跨页
3. 合并时保持层级关系正确

输出格式要求（JSON）：
```json
{{
  "merged_tree": {{
    // 合并后的树结构
  }},
  "cross_page_merges": [
    {{
      "type": "paragraph",
      "prev_node_id": "para_x",
      "curr_node_id": "para_y",
      "merged_node_id": "para_merged"
    }}
  ],
  "uncertain_cases": [
    {{
      "nodes": ["node_a", "node_b"],
      "reason": "不确定是否应该合并"
    }}
  ]
}}
```

请直接输出JSON，不要包含其他文字。"""
    
    @staticmethod
    def build_tree_compression_prompt(tree: Dict[str, Any]) -> str:
        """构建树压缩提示词（用于减少上下文）"""
        tree_json = json.dumps(tree, ensure_ascii=False, indent=2)
        
        return f"""请压缩以下文档树，保留关键结构信息，减少token使用。

原始树：
```json
{tree_json}
```

压缩要求：
1. 保留完整的标题层级结构
2. 保留标题文本
3. 正文内容可以简化为摘要或占位符
4. 保留page_range信息
5. 保留节点类型

输出压缩后的JSON树。"""
