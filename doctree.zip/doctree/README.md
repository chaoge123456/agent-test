# 自动化文档树组织系统

将扫描版或数字文档自动解析为层次化的文档树结构。

## 功能特性

1. **页面内层级构建**: 基于规则或LLM从页面元素构建局部树
2. **正文起始识别**: 自动检测文档正文从哪一页开始
3. **跨页整合策略**: 识别并合并跨页的标题、段落、表格等元素
4. **减少上下文策略**: 支持树压缩和增量合并，应对LLM上下文窗口限制
5. **BBox信息利用**: 使用坐标信息辅助判断标题层级和跨页连续性

## 安装

```bash
pip install -r requirements.txt
```

## 快速开始

### 基本使用

```python
from doc_tree_builder import DocumentTreeBuilder

# 创建构建器
builder = DocumentTreeBuilder(
    api_key="your-api-key",
    use_llm_for_page_tree=False,      # 页面内树使用规则方法（更快）
    use_llm_for_content_detection=True,  # 正文检测使用LLM
    use_llm_for_cross_page=False       # 跨页合并使用规则方法
)

# 从目录构建
doc_tree = builder.build_from_directory("data/")

# 保存结果
import json
with open("output_tree.json", "w", encoding="utf-8") as f:
    json.dump(doc_tree.to_dict(), f, ensure_ascii=False, indent=2)
```

### 运行测试

```bash
# 基本测试（不使用LLM，速度快）
python test_doc_tree.py

# 或使用主程序
python -m doctree.doc_tree_builder
```

## 模块说明

### 数据结构 (`data_structures.py`)

- `TreeNode`: 文档树节点
- `LayoutBox`: 版面分析框
- `DocumentTree`: 完整文档树
- `NodeType`: 节点类型枚举

### LLM客户端 (`llm_client.py`)

- `LLMClient`: 封装OpenAI兼容API调用
- `PromptBuilder`: 各阶段提示词构建器

### 页面内树构建 (`page_tree_builder.py`)

- `RuleBasedPageTreeBuilder`: 基于规则的构建器
- `PageTreeCompressor`: 树压缩器

### 正文起始检测 (`content_detector.py`)

- `MainContentDetector`: 检测正文从哪一页开始

### 跨页合并 (`cross_page_merger.py`)

- `CrossPageMerger`: 跨页内容合并
- `BBoxHelper`: BBox辅助工具

### 主流程 (`doc_tree_builder.py`)

- `DocumentTreeBuilder`: 主入口类，协调整个流程

## 配置选项

| 选项 | 说明 | 默认值 |
|------|------|--------|
| `use_llm_for_page_tree` | 使用LLM构建页面内树 | False |
| `use_llm_for_content_detection` | 使用LLM检测正文起始 | True |
| `use_llm_for_cross_page` | 使用LLM进行跨页合并 | False |

## 输出格式

```json
{
  "document": {
    "node_id": "doc_root",
    "type": "document",
    "text": "文档标题",
    "page_range": [0, 10],
    "children": [...]
  },
  "metadata": {
    "title": "文档标题",
    "total_pages": 11,
    "main_content_start_page": 0
  }
}
```

## 提示词设计

系统为各阶段设计了专门的提示词：

1. **页面内层级构建**: 指导LLM从元素列表构建树
2. **正文起始识别**: 分析前几页内容判断正文起始
3. **跨页合并**: 识别相邻页之间的跨页元素
4. **树压缩**: 保留结构的同时减少token使用

## 项目结构

```
doctree/
├── __init__.py
├── data_structures.py      # 数据结构定义
├── llm_client.py           # LLM客户端
├── page_tree_builder.py    # 页面内树构建
├── content_detector.py     # 正文起始检测
├── cross_page_merger.py    # 跨页合并
├── doc_tree_builder.py     # 主流程
├── test_doc_tree.py        # 测试脚本
├── requirements.txt
└── README.md
```

## 许可证

MIT License
