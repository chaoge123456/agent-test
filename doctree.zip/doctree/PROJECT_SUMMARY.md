# 自动化文档树组织系统 - 项目交付总结

## 项目概述

本系统将扫描版或数字文档（PDF、图片）自动解析为层次化的文档树结构。输入为通过版面分析与OCR模型生成的每页JSON数据，输出为嵌套的JSON树，反映文档的章节、段落、表格、图片等元素的隶属关系。

## 已实现功能

### 1. 数据结构 (`data_structures.py`)
- `NodeType`: 23种节点类型枚举
- `BBox`: 边界框处理类
- `LayoutBox`: 版面分析框数据结构
- `TreeNode`: 文档树节点（支持嵌套、层级、页面范围）
- `PageData`: 单页数据容器
- `DocumentTree`: 完整文档树

### 2. LLM客户端 (`llm_client.py`)
- `LLMClient`: 封装OpenAI兼容API调用
- `PromptBuilder`: 各阶段提示词构建器
  - 页面内层级构建提示词
  - 正文起始识别提示词
  - 跨页合并提示词
  - 树压缩提示词

### 3. 页面内层级构建 (`page_tree_builder.py`)
- `RuleBasedPageTreeBuilder`: 基于规则的页面内树构建
  - 标题层级栈管理
  - 噪声元素过滤
  - 跨页候选识别
- `PageTreeCompressor`: 树压缩器
  - 保留结构的同时减少token
  - 标题骨架提取

### 4. 正文起始识别 (`content_detector.py`)
- `MainContentDetector`: 自动检测正文起始页
  - 规则方法：检测章节标题
  - LLM方法：分析前几页内容

### 5. 跨页整合策略 (`cross_page_merger.py`)
- `CrossPageMerger`: 跨页内容合并
  - 增量合并策略
  - 可附加节点识别
- `BBoxHelper`: BBox辅助工具
  - 同列判断
  - 页面位置判断
  - 从bbox推断标题级别

### 6. 主流程 (`doc_tree_builder.py`)
- `DocumentTreeBuilder`: 主入口类
  - 协调整个流程
  - 支持从文件/目录/页面数据构建

### 7. 完整单文件版本 (`full_system.py`)
- 包含所有功能的独立文件
- 可直接运行测试

## 技术亮点

### 1. 页面内层级构建
- **规则方法**：使用栈维护标题层级，高效准确
- **LLM增强**：提供复杂场景的提示词
- **跨页标记**：识别可能跨页的元素

### 2. 正文起始识别
- **混合策略**：规则+LLM，平衡速度与准确性
- **前置页分析**：区分封面、摘要、目录等

### 3. 跨页整合
- **增量合并**：每次处理相邻两页，避免上下文超限
- **bbox辅助**：利用坐标信息判断连续性

### 4. 减少上下文策略
- **树压缩**：保留标题层级，压缩正文内容
- **标题骨架**：只提取标题结构用于全局浏览
- **滑动窗口**：支持增量处理

## 项目结构

```
doctree/
├── __init__.py              # 包初始化
├── data_structures.py       # 数据结构定义
├── llm_client.py            # LLM客户端和提示词
├── page_tree_builder.py     # 页面内树构建
├── content_detector.py      # 正文起始检测
├── cross_page_merger.py     # 跨页合并
├── doc_tree_builder.py      # 主流程
├── full_system.py           # 完整单文件版本（推荐使用）
├── requirements.txt         # 依赖
├── README.md               # 使用说明
└── PROJECT_SUMMARY.md      # 本文件
```

## 使用方法

### 快速开始（推荐）

使用完整单文件版本：

```python
from full_system import DocumentTreeBuilder

# 创建构建器
builder = DocumentTreeBuilder()

# 从目录构建
doc_tree = builder.build_from_directory("data/")

# 保存结果
import json
with open("output.json", "w", encoding="utf-8") as f:
    json.dump(doc_tree.to_dict(), f, ensure_ascii=False, indent=2)
```

### 运行测试

```bash
# 使用完整单文件版本测试
python full_system.py
```

## 输出格式

```json
{
  "document": {
    "node_id": "doc_root",
    "type": "document",
    "text": "文档标题",
    "page_range": [0, 10],
    "children": [
      {
        "node_id": "title_1",
        "type": "title",
        "level": 1,
        "text": "第一章 引言",
        "page_range": [0, 0],
        "children": [...]
      }
    ]
  },
  "metadata": {
    "title": "文档标题",
    "total_pages": 11,
    "main_content_start_page": 0
  }
}
```

## 配置选项

| 选项 | 说明 | 默认值 |
|------|------|--------|
| `use_llm_for_page_tree` | 使用LLM构建页面内树 | False |
| `use_llm_for_content_detection` | 使用LLM检测正文起始 | True |
| `use_llm_for_cross_page` | 使用LLM进行跨页合并 | False |

## 提示词设计

系统为各阶段设计了专门的提示词（见 `llm_client.py`）：

1. **页面内层级构建**: 指导LLM从元素列表构建树
2. **正文起始识别**: 分析前几页内容判断正文起始
3. **跨页合并**: 识别相邻页之间的跨页元素
4. **树压缩**: 保留结构的同时减少token使用

## 依赖

- Python 3.7+
- openai>=1.0.0

## 总结

本系统完整实现了需求中提出的所有7项重点内容：

1. ✅ 页面内层级构建的LLM提示词
2. ✅ 正文起始识别
3. ✅ 跨页整合策略
4. ✅ 减少上下文策略
5. ✅ 完整的数据结构设计
6. ✅ BBox信息利用
7. ✅ 各阶段LLM提示词设计

系统同时提供规则方法和LLM增强方法，可以根据需求灵活选择，平衡准确性与成本。
