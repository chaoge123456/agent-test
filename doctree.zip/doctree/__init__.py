"""
自动化文档树组织系统
"""

from .doc_tree_builder import DocumentTreeBuilder

__version__ = "1.0.0"
__all__ = ["DocumentTreeBuilder"]
