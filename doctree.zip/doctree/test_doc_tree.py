"""
测试脚本
"""

import json
import os
from pathlib import Path
from doc_tree_builder import DocumentTreeBuilder


def test_basic_functionality():
    """测试基本功能"""
    print("=" * 60)
    print("自动化文档树组织系统 - 测试")
    print("=" * 60)
    
    # 配置
    api_key = "sk-71345ea7232d4739b41c16dabd51d0b8"
    data_dir = Path("data")
    
    # 检查数据目录
    if not data_dir.exists():
        print(f"错误: 数据目录不存在: {data_dir}")
        return
    
    # 列出数据文件
    json_files = sorted(list(data_dir.glob("*.json")))
    print(f"\n找到 {len(json_files)} 个数据文件:")
    for f in json_files:
        print(f"  - {f.name}")
    
    # 创建构建器 - 使用规则方法进行快速测试
    print("\n[1/5] 初始化文档树构建器...")
    builder = DocumentTreeBuilder(
        api_key=api_key,
        use_llm_for_page_tree=False,
        use_llm_for_content_detection=False,
        use_llm_for_cross_page=False
    )
    print("  ✓ 构建器初始化完成")
    
    # 构建文档树
    print("\n[2/5] 开始构建文档树...")
    doc_tree = builder.build_from_directory(str(data_dir))
    print("  ✓ 文档树构建完成")
    
    # 输出结果
    print("\n[3/5] 保存输出结果...")
    output_dir = Path("output")
    output_dir.mkdir(exist_ok=True)
    
    output_path = output_dir / "document_tree.json"
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(doc_tree.to_dict(), f, ensure_ascii=False, indent=2)
    print(f"  ✓ 结果已保存到: {output_path}")
    
    # 打印统计信息
    print("\n[4/5] 文档树统计:")
    print("  -" * 30)
    print(f"  文档标题: {doc_tree.metadata.get('title', 'N/A')}")
    print(f"  总页数: {doc_tree.metadata.get('total_pages', 0)}")
    print(f"  正文起始页: {doc_tree.metadata.get('main_content_start_page', 0)}")
    print(f"  根节点类型: {doc_tree.root.type.value}")
    print(f"  根节点子节点数: {len(doc_tree.root.children)}")
    
    # 遍历树统计
    all_nodes = [doc_tree.root] + doc_tree.root.get_all_descendants()
    type_counts = {}
    for node in all_nodes:
        t = node.type.value
        type_counts[t] = type_counts.get(t, 0) + 1
    
    print(f"\n  节点类型统计:")
    for t, count in sorted(type_counts.items()):
        print(f"    {t}: {count}")
    
    # 打印树结构预览
    print("\n[5/5] 树结构预览:")
    print("  -" * 30)
    print_tree_preview(doc_tree.root, max_depth=3)
    
    print("\n" + "=" * 60)
    print("测试完成!")
    print("=" * 60)


def print_tree_preview(node, indent=0, max_depth=3, current_depth=0):
    """打印树结构预览"""
    if current_depth > max_depth:
        return
    
    prefix = "  " * indent
    node_type = node.type.value
    text_preview = node.text[:40] + "..." if len(node.text) > 40 else node.text
    
    level_str = f" (level={node.level})" if node.level else ""
    page_str = f" pages={node.page_range}" if node.page_range else ""
    
    print(f"{prefix}├─ {node_type}{level_str}: {text_preview}{page_str}")
    
    for child in node.children:
        print_tree_preview(child, indent + 1, max_depth, current_depth + 1)


def test_with_llm():
    """测试使用LLM的功能"""
    print("\n" + "=" * 60)
    print("测试LLM增强功能 (可选)")
    print("=" * 60)
    
    api_key = "sk-71345ea7232d4739b41c16dabd51d0b8"
    data_dir = "data"
    
    print("\n注意: LLM功能需要网络连接和API配额")
    print("此测试将使用LLM进行:")
    print("  1. 正文起始页检测")
    print("  2. (可选) 页面内树构建")
    print("  3. (可选) 跨页合并")
    
    response = input("\n是否继续? (y/n): ").strip().lower()
    if response != 'y':
        print("跳过LLM测试")
        return
    
    # 创建使用LLM的构建器
    builder = DocumentTreeBuilder(
        api_key=api_key,
        use_llm_for_page_tree=False,   # 建议保持False以节省token
        use_llm_for_content_detection=True,
        use_llm_for_cross_page=False
    )
    
    print("\n构建文档树...")
    doc_tree = builder.build_from_directory(data_dir)
    
    # 保存
    output_dir = Path("output")
    output_dir.mkdir(exist_ok=True)
    with open(output_dir / "document_tree_with_llm.json", 'w', encoding='utf-8') as f:
        json.dump(doc_tree.to_dict(), f, ensure_ascii=False, indent=2)
    
    print("LLM测试完成!")


if __name__ == "__main__":
    test_basic_functionality()
    
    # 可选：测试LLM功能
    # test_with_llm()
