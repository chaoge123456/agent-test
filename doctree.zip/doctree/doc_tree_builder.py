"""
主流程模块 - 文档树构建器
"""

import json
import os
from pathlib import Path
from typing import List, Dict, Any, Optional

from data_structures import PageData, DocumentTree, TreeNode, NodeType
from llm_client import LLMClient
from page_tree_builder import RuleBasedPageTreeBuilder, PageTreeCompressor
from content_detector import MainContentDetector
from cross_page_merger import CrossPageMerger


class DocumentTreeBuilder:
    """文档树构建器 - 主入口类"""
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "deepseek-chat",
        base_url: str = "https://api.deepseek.com",
        use_llm_for_page_tree: bool = False,
        use_llm_for_content_detection: bool = True,
        use_llm_for_cross_page: bool = False
    ):
        """
        初始化文档树构建器
        
        Args:
            api_key: LLM API密钥
            model: 模型名称
            base_url: API基础URL
            use_llm_for_page_tree: 是否使用LLM构建页面内树
            use_llm_for_content_detection: 是否使用LLM检测正文起始
            use_llm_for_cross_page: 是否使用LLM进行跨页合并
        """
        self.llm_client = None
        if api_key:
            self.llm_client = LLMClient(
                api_key=api_key,
                model=model,
                base_url=base_url
            )
        
        self.use_llm_for_page_tree = use_llm_for_page_tree
        self.use_llm_for_content_detection = use_llm_for_content_detection
        self.use_llm_for_cross_page = use_llm_for_cross_page
        
        self.page_tree_builder = RuleBasedPageTreeBuilder()
        self.content_detector = MainContentDetector(
            use_llm=use_llm_for_content_detection,
            llm_client=self.llm_client
        )
        self.cross_page_merger = CrossPageMerger(
            use_llm=use_llm_for_cross_page,
            llm_client=self.llm_client
        )
    
    def build_from_files(self, file_paths: List[str]) -> DocumentTree:
        """
        从文件列表构建文档树
        
        Args:
            file_paths: JSON文件路径列表（按页序排列）
            
        Returns:
            文档树对象
        """
        pages = []
        for file_path in file_paths:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                pages.append(PageData.from_dict(data))
        
        return self.build_from_pages(pages)
    
    def build_from_directory(self, directory: str, pattern: str = "*.json") -> DocumentTree:
        """
        从目录构建文档树
        
        Args:
            directory: 目录路径
            pattern: 文件匹配模式
            
        Returns:
            文档树对象
        """
        dir_path = Path(directory)
        file_paths = sorted(list(dir_path.glob(pattern)))
        return self.build_from_files([str(p) for p in file_paths])
    
    def build_from_pages(self, pages: List[PageData]) -> DocumentTree:
        """
        从页面数据列表构建文档树
        
        Args:
            pages: 页面数据列表（按页序排列）
            
        Returns:
            文档树对象
        """
        # 1. 检测正文起始页
        main_start_page, detection_info = self.content_detector.detect(pages)
        print(f"正文起始页: {main_start_page}")
        
        # 2. 为每个页面构建局部树
        page_trees = []
        for page in pages:
            tree, candidates = self.page_tree_builder.build_tree(
                page,
                use_llm=self.use_llm_for_page_tree,
                llm_client=self.llm_client
            )
            page_trees.append((tree, candidates))
            print(f"第{page.page_index}页树构建完成，跨页候选: {len(candidates)}")
        
        # 3. 合并跨页内容
        merged_root = self.cross_page_merger.merge_pages(page_trees, pages)
        print(f"跨页合并完成，合并次数: {self.cross_page_merger.merge_count}")
        
        # 4. 提取文档标题
        doc_title = self._extract_document_title(pages)
        
        # 5. 构建最终文档树
        merged_root.text = doc_title
        merged_root.page_range = [0, len(pages) - 1]
        
        doc_tree = DocumentTree(
            root=merged_root,
            metadata={
                "title": doc_title,
                "total_pages": len(pages),
                "main_content_start_page": main_start_page,
                "detection_info": detection_info
            }
        )
        
        return doc_tree
    
    def _extract_document_title(self, pages: List[PageData]) -> str:
        """从页面中提取文档标题"""
        for page in pages[:3]:  # 只检查前3页
            for box in page.boxes:
                if box.label == "doc_title" and box.recognize:
                    return box.recognize
        
        # 如果没有doc_title，找第一个paragraph_title
        for page in pages[:3]:
            for box in page.boxes:
                if box.label == "paragraph_title" and box.recognize:
                    return box.recognize
        
        return "未命名文档"


def main():
    """测试主函数"""
    import sys
    
    # 配置
    api_key = "sk-71345ea7232d4739b41c16dabd51d0b8"
    data_dir = "data"
    
    # 创建构建器（默认不使用LLM以快速测试，可根据需要开启）
    builder = DocumentTreeBuilder(
        api_key=api_key,
        use_llm_for_page_tree=False,      # 页面内树使用规则方法（更快）
        use_llm_for_content_detection=False,  # 正文检测使用规则方法
        use_llm_for_cross_page=False       # 跨页合并使用规则方法
    )
    
    # 构建文档树
    print("开始构建文档树...")
    doc_tree = builder.build_from_directory(data_dir)
    
    # 输出结果
    output_path = "output_tree.json"
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(doc_tree.to_dict(), f, ensure_ascii=False, indent=2)
    
    print(f"文档树已保存到: {output_path}")
    
    # 打印摘要
    print("\n文档树摘要:")
    print(f"标题: {doc_tree.metadata.get('title', 'N/A')}")
    print(f"总页数: {doc_tree.metadata.get('total_pages', 0)}")
    print(f"根节点子节点数: {len(doc_tree.root.children)}")


if __name__ == "__main__":
    main()
