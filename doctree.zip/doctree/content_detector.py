"""
正文起始识别模块
"""

from typing import List, Dict, Any, Optional, Tuple

try:
    from .data_structures import PageData, LayoutBox, NodeType
    from .llm_client import LLMClient, PromptBuilder
except ImportError:
    from data_structures import PageData, LayoutBox, NodeType
    from llm_client import LLMClient, PromptBuilder


class MainContentDetector:
    """正文起始检测器"""
    
    def __init__(self, use_llm: bool = True, llm_client: Optional[LLMClient] = None):
        self.use_llm = use_llm
        self.llm_client = llm_client
    
    def detect(self, pages: List[PageData]) -> Tuple[int, Dict[str, Any]]:
        if self.use_llm and self.llm_client:
            return self._detect_with_llm(pages)
        else:
            return self._detect_rule_based(pages)
    
    def _detect_rule_based(self, pages: List[PageData]) -> Tuple[int, Dict[str, Any]]:
        preliminary_pages = []
        
        for i, page in enumerate(pages):
            page_info = self._analyze_page(page)
            page_type = page_info["type"]
            
            if page_type == "main_content":
                return i, {
                    "main_content_start_page": i,
                    "confidence": page_info["confidence"],
                    "reasoning": f"第{i}页包含章节标题，判定为正文起始",
                    "preliminary_pages": preliminary_pages
                }
            else:
                preliminary_pages.append({
                    "page_index": i,
                    "type": page_type,
                    "description": page_info.get("description", "")
                })
        
        return 0, {
            "main_content_start_page": 0,
            "confidence": 0.5,
            "reasoning": "未明确检测到正文起始，默认从第0页开始",
            "preliminary_pages": preliminary_pages
        }
    
    def _analyze_page(self, page: PageData) -> Dict[str, Any]:
        has_doc_title = False
        has_abstract = False
        has_section_title = False
        has_content = False
        
        for box in page.boxes:
            if box.label == "doc_title":
                has_doc_title = True
            elif box.label == "abstract":
                has_abstract = True
            elif box.label == "paragraph_title" and box.title_level and box.title_level >= 2:
                has_section_title = True
            elif box.label == "text" and len(box.recognize) > 50:
                has_content = True
        
        if has_section_title:
            return {
                "type": "main_content",
                "confidence": 0.9,
                "description": "包含章节标题"
            }
        elif has_abstract:
            return {
                "type": "abstract",
                "confidence": 0.8,
                "description": "包含摘要"
            }
        elif has_doc_title and not has_content:
            return {
                "type": "title_page",
                "confidence": 0.7,
                "description": "标题页"
            }
        else:
            return {
                "type": "unknown",
                "confidence": 0.5,
                "description": "未知类型"
            }
    
    def _detect_with_llm(self, pages: List[PageData]) -> Tuple[int, Dict[str, Any]]:
        pages_summary = []
        for i, page in enumerate(pages[:5]):
            summary = self._summarize_page(page)
            summary["page_index"] = i
            pages_summary.append(summary)
        
        prompt = PromptBuilder.build_main_content_detection_prompt(pages_summary)
        messages = [{"role": "user", "content": prompt}]
        
        try:
            result = self.llm_client.chat_with_json(messages, temperature=0.3)
            start_page = result.get("main_content_start_page", 0)
            return start_page, result
        except Exception as e:
            print(f"LLM检测失败，回退到规则方法: {e}")
            return self._detect_rule_based(pages)
    
    def _summarize_page(self, page: PageData) -> Dict[str, Any]:
        labels = []
        titles = []
        texts = []
        
        for box in page.boxes:
            labels.append(box.label)
            if box.label in ["paragraph_title", "doc_title"]:
                titles.append(box.recognize)
            if box.label == "text" and len(box.recognize) > 20:
                texts.append(box.recognize[:100])
        
        return {
            "labels": list(set(labels)),
            "titles": titles[:3],
            "text_preview": texts[:2],
            "box_count": len(page.boxes)
        }
