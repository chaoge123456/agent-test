"""
快速验证测试
"""

import json
from pathlib import Path

print("=" * 60)
print("快速验证测试")
print("=" * 60)

# 1. 测试数据读取
data_dir = Path("data")
json_files = sorted(list(data_dir.glob("*.json")))
print(f"\n1. 找到 {len(json_files)} 个数据文件")

test_file = json_files[0]
print(f"   测试文件: {test_file.name}")

with open(test_file, 'r', encoding='utf-8') as f:
    data = json.load(f)
    page_idx = data.get("page_index")
    boxes = data.get("boxes", [])
    print(f"   页面索引: {page_idx}")
    print(f"   元素数量: {len(boxes)}")
    
    # 打印前几个元素类型
    labels = [box.get("label", "N/A") for box in boxes[:3]]
    print(f"   元素类型: {labels}")

# 2. 测试full_system.py导入
print("\n2. 测试模块导入...")
try:
    import full_system
    print("   OK: full_system.py 导入成功")
    
    # 测试数据结构
    from full_system import NodeType, BBox, LayoutBox, TreeNode, PageData
    print("   OK: 数据结构导入成功")
    
    # 测试核心类
    from full_system import RuleBasedPageTreeBuilder, MainContentDetector, DocumentTreeBuilder
    print("   OK: 核心类导入成功")
    
except Exception as e:
    print(f"   ERROR: {e}")
    import traceback
    traceback.print_exc()

# 3. 简单的构建测试
print("\n3. 尝试构建文档树...")
try:
    from full_system import DocumentTreeBuilder
    
    builder = DocumentTreeBuilder()
    doc_tree = builder.build_from_directory(str(data_dir))
    
    print("   OK: 文档树构建成功")
    print(f"   文档标题: {doc_tree.metadata.get('title')}")
    print(f"   总页数: {doc_tree.metadata.get('total_pages')}")
    print(f"   根节点子节点数: {len(doc_tree.root.children)}")
    
    # 保存输出
    output_dir = Path("output")
    output_dir.mkdir(exist_ok=True)
    output_path = output_dir / "quick_test_output.json"
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(doc_tree.to_dict(), f, ensure_ascii=False, indent=2)
    print(f"   输出已保存到: {output_path}")
    
except Exception as e:
    print(f"   ERROR: {e}")
    import traceback
    traceback.print_exc()

print("\n" + "=" * 60)
print("测试完成")
print("=" * 60)
