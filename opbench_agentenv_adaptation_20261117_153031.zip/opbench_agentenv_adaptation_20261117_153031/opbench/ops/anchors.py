"""锚点引擎 —— vfs/blk 事件流的阶段锚点匹配（规范 §2 锚点表）。

输入 metrics.parse_vfs_log 的事件列表 + 相位边界，输出锚点时刻与
阶段窗口（start_ns/end_ns/anchor 精度档）。
"""
from __future__ import annotations

from dataclasses import dataclass, field

from opbench.core.metrics import parse_vfs_log, parse_blk_log


# Task-led models.  The marker listed beside a stage is its *end* boundary;
# the final synchronous stage always ends at API return, followed by TAIL.
TASK_STAGE_MODELS = {
    "start": ("S", [
        ("解析与准入", "storage_attach"), ("存储装配", "state_restore"),
        ("状态恢复", "vcpu_activate"), ("激活与返回", None),
    ], "TAIL"),
    "pause": ("P", [
        ("一致性屏障", "vcpu_quiesced"), ("VM状态导出", "vm_state_exported"),
        ("持久化提交", "snapshot_durable"), ("发布与返回", None),
    ], "TAIL"),
    "resume": ("R", [
        ("恢复解析", "storage_attach"), ("存储重装配", "state_restore"),
        ("VM状态回填", "vcpu_activate"), ("激活与返回", None),
    ], "TAIL"),
    "checkpoint": ("C", [
        ("一致性准备", "capture_begin"), ("状态捕获", "vm_state_exported"),
        ("快照持久化", "snapshot_durable"), ("发布与返回", None),
    ], "TAIL"),
    "fork": ("F", [
        ("source捕获", "source_capture_done"), ("共享状态派生", "child_storage_begin"),
        ("child存储装配", "child_restore_begin"), ("child恢复激活", "all_children_ready"),
        ("汇总与返回", None),
    ], "TAIL"),
}


def build_task_stage_windows(op: str, api_start_ns: int, api_end_ns: int,
                             tail_end_ns: int | None, markers,
                             child_id: str | None = None) -> tuple[list[dict], dict]:
    """Build task windows from internal markers, with an honest coarse fallback."""
    prefix, stages, _ = TASK_STAGE_MODELS[op]
    marker_names = [marker for _, marker in stages if marker]
    raw = [markers.boundary(marker, child_id=child_id) for marker in marker_names]
    missing = [name for name, ts in zip(marker_names, raw) if not ts]
    if not any(raw):
        windows = [{"stage_id": f"{prefix}0", "stage_name": "API控制路径(推定)",
                    "start_ns": api_start_ns, "end_ns": api_end_ns,
                    "boundary_source": {"start": "api_boundary", "end": "api_boundary"}}]
        if tail_end_ns and tail_end_ns > api_end_ns:
            windows.append({"stage_id": f"{prefix}{len(stages)}", "stage_name": "TAIL",
                            "start_ns": api_end_ns, "end_ns": tail_end_ns,
                            "boundary_source": {"start": "api_boundary", "end": "tail_boundary"}})
        return windows, {"quality": "inferred", "marker_count": 0,
                         "missing_markers": marker_names}

    boundaries, out_of_order, previous = [], False, api_start_ns
    for timestamp in raw:
        if not timestamp:
            timestamp = previous
        if timestamp < previous:
            timestamp, out_of_order = previous, True
        boundaries.append(timestamp)
        previous = timestamp
    ends = boundaries + [api_end_ns]
    starts = [api_start_ns] + boundaries
    windows = []
    for index, ((name, marker), start, end) in enumerate(zip(stages, starts, ends)):
        windows.append({"stage_id": f"{prefix}{index}", "stage_name": name,
                        "start_ns": start, "end_ns": max(start, end),
                        "boundary_source": {"start": "api_boundary" if index == 0 else "marker",
                                            "end": "api_boundary" if marker is None else "marker"}})
    if tail_end_ns and tail_end_ns > api_end_ns:
        windows.append({"stage_id": f"{prefix}{len(stages)}", "stage_name": "TAIL",
                        "start_ns": api_end_ns, "end_ns": tail_end_ns,
                        "boundary_source": {"start": "api_boundary", "end": "tail_boundary"}})
    return windows, {"quality": "direct" if not missing and not out_of_order else "degraded",
                     "marker_count": len(raw) - len(missing), "missing_markers": missing,
                     "out_of_order": out_of_order}


@dataclass
class Anchor:
    name: str          # 锚点名（如 first_vm_state_w）
    ts_ns: int = 0
    precision: str = "event"  # event | window | poll | boundary
    meta: dict = field(default_factory=dict)

    @property
    def found(self) -> bool:
        return self.ts_ns > 0

    @property
    def ts(self) -> int:
        return self.ts_ns


class VfsStream:
    """一个相位窗口内的 vfs 事件流视图（按 kind/name 索引）。"""

    def __init__(self, events: list[dict], start_ns: int, end_ns: int):
        self.events = [e for e in events if start_ns <= e["ts"] <= end_ns]
        self.events.sort(key=lambda e: e["ts"])

    def first(self, kind: str, name_glob: str | None = None) -> dict | None:
        for e in self.events:
            if e["kind"] != kind:
                continue
            if name_glob and name_glob not in e.get("name", ""):
                continue
            return e
        return None

    def last(self, kind: str, name_glob: str | None = None) -> dict | None:
        for e in reversed(self.events):
            if e["kind"] != kind:
                continue
            if name_glob and name_glob not in e.get("name", ""):
                continue
            return e
        return None

    def all(self, kind: str, name_glob: str | None = None) -> list[dict]:
        return [e for e in self.events
                if e["kind"] == kind
                and (not name_glob or name_glob in e.get("name", ""))]


# ── 通用锚点提取函数 ───────────────────────────────────────────────

def pid_appear_anchor(blk_events: list[dict], vfs_events: list[dict],
                      pid: int, after_ns: int = 0) -> Anchor:
    """进程首次出现锚点（pid 集新增的等价事件级实现）。"""
    ts = 0
    for e in vfs_events:
        if e.get("pid") == pid and e["ts"] >= after_ns:
            ts = e["ts"]
            break
    if not ts:
        for e in blk_events:
            if e.get("pid") == pid and e["ts"] >= after_ns:
                ts = e["ts"]
                break
    return Anchor("pid_first_seen", ts, "event", {"pid": pid})


def vm_state_anchors(vfs: VfsStream) -> tuple[Anchor, Anchor]:
    """vm_state.bin 写窗口（firecracker 进程流）。P1/C1/R3 的骨架。"""
    f = vfs.first("W", "vm_state.bin")
    l = vfs.last("W", "vm_state.bin")
    return (Anchor("first_vm_state_w", f["ts"] if f else 0),
            Anchor("last_vm_state_w", l["ts"] if l else 0))


def commit_anchors(vfs: VfsStream) -> tuple[Anchor, Anchor]:
    """overlaybd.commit.tmp 写窗口（overlaybd 进程流，API 时延主体）。"""
    f = vfs.first("W", "overlaybd.commit.tmp")
    l = vfs.last("W", "overlaybd.commit.tmp")
    return (Anchor("first_commit_tmp_w", f["ts"] if f else 0),
            Anchor("last_commit_tmp_w", l["ts"] if l else 0))


def mem_image_anchor(vfs: VfsStream) -> Anchor:
    e = vfs.last("W", "mem_image.json")
    return Anchor("last_mem_image_w", e["ts"] if e else 0)


def upper_anchors(vfs: VfsStream) -> tuple[Anchor, Anchor]:
    """F4: W upper.index / upper.data（新沙箱写层 CoW 初始化）。"""
    u = vfs.first("W", "upper.index") or vfs.first("W", "upper.data")
    l = vfs.last("W", "upper.data") or vfs.last("W", "upper.index")
    return (Anchor("first_upper_w", u["ts"] if u else 0),
            Anchor("last_upper_w", l["ts"] if l else 0))


# ── 链式窗口构建 ───────────────────────────────────────────────────

def chained_windows(api_start_ns: int, api_end_ns: int,
                    stage_specs: list[tuple]) -> list[dict]:
    """链式窗口构建（复盘：锚缺失/乱序导致阶段重叠的统一修复）。

    stage_specs: [(stage_id, stage_name, boundary_ts_or_0, prec, a_s, a_e), ...]
    boundary 为该阶段【末边界】锚时刻序列（首阶段起点 = api_start）。
    规则：
    - 边界单调递增钳制：c[i] = max(c[i-1], b[i] if b[i] else c[i-1])
      （锚缺失 → 阶段坍缩为零窗，IO 归前一阶段；锚乱序 → clamp 防负窗/重叠）
    - 末边界固定 api_end（保证覆盖率恒 100% 且窗口互斥）
    返回窗口列表（调用方 W() 同构）。
    """
    c = api_start_ns
    starts = [api_start_ns]
    for _, _, b, _, _, _ in stage_specs[:-1]:
        c = max(c, b) if b else c
        starts.append(c)
    wins = []
    for i, (sid, name, _, prec, a_s, a_e) in enumerate(stage_specs):
        s = starts[i]
        e = starts[i + 1] if i + 1 < len(starts) else api_end_ns
        wins.append({"stage_id": sid, "stage_name": name,
                     "start_ns": s, "end_ns": e,
                     "anchor": {"start": a_s, "end": a_e, "precision": prec}})
    return wins


def _append_tail_stage(wins: list[dict], api_end_ns: int,
                       tail_end_ns: int | None) -> list[dict]:
    """统一口径：给阶段链追加 T 尾部（api_end→tail_end），使
    阶段窗覆盖 API+TAIL 合并窗 —— 进度表与阶段表加和恒等。"""
    if tail_end_ns and tail_end_ns > api_end_ns:
        wins = wins + [{
            "stage_id": "T", "stage_name": "尾部(API后异步回写/链读)",
            "start_ns": api_end_ns, "end_ns": tail_end_ns,
            "anchor": {"start": "api_end", "end": "tail_end",
                       "precision": "boundary"}}]
    return wins


# ── 阶段窗口组装 ───────────────────────────────────────────────────

def build_stage_windows(op: str, api_start_ns: int, api_end_ns: int,
                        vfs_events: list[dict],
                        pid_infos: list[dict] | None = None,
                        tail_end_ns: int | None = None) -> list[dict]:
    """按 §2 锚点表组装阶段窗口。

    vfs_events 已是相位窗口内全集。pid_infos: [{label, pid, first_seen_ns}]
    （firecracker / overlaybd 进程出现时刻由调用端 pids 差分给出）。
    返回 [{stage_id, stage_name, start_ns, end_ns, anchor:{start,end,precision}}]
    ）
    tail_end_ns：若给定（TAIL 相结束时刻），在操作阶段链末尾追加 "T 尾部" 阶段
    （api_end → tail_end，承接 API 返回后的异步回写/链读），使
    阶段窗覆盖 API+TAIL 全窗——进度表与阶段表同口径，加和恒等。
    """
    vfs = VfsStream(vfs_events, api_start_ns, api_end_ns)
    fc_first = next((p["first_seen_ns"] for p in (pid_infos or [])
                     if "firecracker" in p.get("label", "")), 0)
    obd_first = next((p["first_seen_ns"] for p in (pid_infos or [])
                      if "overlaybd" in p.get("label", "")), 0)

    def W(sid, name, s, e, prec="event", a_s="", a_e=""):
        return {"stage_id": sid, "stage_name": name,
                "start_ns": s or api_start_ns, "end_ns": e or api_end_ns,
                "anchor": {"start": a_s, "end": a_e, "precision": prec}}

    f_vm, l_vm = vm_state_anchors(vfs)
    com_f, com_l = commit_anchors(vfs)
    mem_img = mem_image_anchor(vfs)

    if op == "pause":
        # P0 协调 | P1 vm_state 导出 | P2 状态提交 | P3 元数据收尾
        # 统一 chained_windows（单调钳制）：P1 末 = l_vm+1（单事件含边界），
        # P2 末 = mem_img+1，P3 末固定 api_end
        p1_end = None
        if l_vm.found:
            p1_end = l_vm.ts + 1 if l_vm.ts == f_vm.ts else l_vm.ts
        p2_end = (mem_img.ts + 1) if mem_img.found else None
        wins = chained_windows(api_start_ns, api_end_ns, [
            ("P0", "请求协调+vCPU停止", f_vm.ts or 0, "boundary", "api_start", "first_vm_state_w"),
            ("P1", "vm_state导出", p1_end or 0, "event", "first_vm_state_w", "last_vm_state_w"),
            ("P2", "状态提交段(合并)", p2_end or 0, "event", "first_commit_tmp_w", "last_mem_image_w"),
            ("P3", "元数据收尾", 0, "event", "last_mem_image_w", "api_end"),
        ])
        return _append_tail_stage(wins, api_end_ns, tail_end_ns)
    if op == "checkpoint":
        chain_l = vfs.last("R", "overlaybd.commit")
        chain_f = vfs.first("R", "overlaybd.commit")
        c2_end = (mem_img.ts + 1) if mem_img.found else None
        # C3 链读：commit R 事件窗（与提交尾重叠时由单调钳制收敛）
        c3_end = (chain_l["ts"] + 1) if chain_l else None
        wins = chained_windows(api_start_ns, api_end_ns, [
            ("C0", "请求协调", f_vm.ts or 0, "boundary", "api_start", "first_vm_state_w"),
            ("C1", "vm_state导出", (l_vm.ts + 1) if l_vm.found and l_vm.ts == f_vm.ts else (l_vm.ts or 0), "event", "first_vm_state_w", "last_vm_state_w"),
            ("C2", "状态提交段(合并)", c2_end or 0, "event", "first_commit_tmp_w", "last_mem_image_w"),
            ("C3", "快照链读", c3_end or 0, "event", "first_commit_r", "last_commit_r"),
            ("C4", "manifest+事务+返回", 0, "event", "last_commit_r", "api_end"),
        ])
        return _append_tail_stage(wins, api_end_ns, tail_end_ns)
    if op == "resume":
        # mem 组 = vm_state.bin + mem_image.json 两条流的并集（§2.3 R3/R4 锚点）；
        # last 必须取并集最大 ts —— 只查 mem_image 会漏 vm_state 的晚事件（负时长 bug）
        vm_r_events = [e for e in vfs.events
                       if e["kind"] == "R"
                       and ("vm_state.bin" in e["name"] or "mem_image.json" in e["name"])]
        vm_r_f = min(vm_r_events, key=lambda e: e["ts"]) if vm_r_events else None
        vm_r_l = max(vm_r_events, key=lambda e: e["ts"]) if vm_r_events else None
        # 复盘修正：统一走 chained_windows（单调递增钳制，覆盖率恒 100% 不重叠）
        wins = chained_windows(api_start_ns, api_end_ns, [
            ("R0", "请求协调", obd_first, "window", "api_start", "overlaybd_proc"),
            ("R1", "数据源定位", 0, "window", "overlaybd_proc", "~R2"),
            ("R2", "OverlayBD重装配", fc_first, "event", "overlaybd_proc", "firecracker_proc"),
            ("R3", "firecracker拉起", vm_r_f["ts"] if vm_r_f else 0, "event", "firecracker_proc", "first_mem_r"),
            ("R4", "状态回填", vm_r_l["ts"] if vm_r_l else 0, "event", "first_mem_r", "last_mem_r"),
            ("R5", "vCPU恢复+返回", 0, "event", "last_mem_r", "api_end"),
        ])
        return _append_tail_stage(wins, api_end_ns, tail_end_ns)
    if op in ("start", "fork"):
        prefix = "S" if op == "start" else "F"
        img_first = vfs.first("R", "image.json")
        # mem 组并集（同 resume 的 R4 修正）：last 必须取两流最大 ts
        mem_rs = [e for e in vfs.events
                  if e["kind"] == "R"
                  and ("vm_state.bin" in e["name"] or "mem_image.json" in e["name"])]
        mem_r_f = min(mem_rs, key=lambda e: e["ts"]) if mem_rs else None
        mem_r_l = max(mem_rs, key=lambda e: e["ts"]) if mem_rs else None
        f_up, l_up = upper_anchors(vfs)
        # 复盘修正（试运行覆盖率 200%/145%）：统一走 chained_windows ——
        # 单调递增钳制；锚缺失阶段坍缩为零窗（IO 归前一阶段），
        # 覆盖率恒 100%，窗口互斥不重叠。
        if op == "start":
            wins = chained_windows(api_start_ns, api_end_ns, [
                ("S0", "请求协调", img_first["ts"] if img_first else 0, "window", "api_start", "first_image_json_r"),
                ("S1", "数据源解析", obd_first or fc_first or 0, "window", "first_image_json_r", "overlaybd_proc"),
                ("S2", "OverlayBD装配", fc_first, "event", "overlaybd_proc", "firecracker_proc"),
                ("S3", "firecracker拉起", fc_first, "event", "firecracker_proc", "pid_set_new"),
                # S4 guest boot 吃满到 api_end（fc_first→api_end 是 boot 后层读主体）；
                # S5 尾部事务是 api_end 处的 boundary 占位 → 零窗
                ("S4", "guest boot", api_end_ns, "window", "pid_set_new", "api_end"),
                ("S5", "尾部事务", api_end_ns, "boundary", "api_end", "api_end"),
            ])
            return _append_tail_stage(wins, api_end_ns, tail_end_ns)
        else:
            wins = chained_windows(api_start_ns, api_end_ns, [
                ("F0", "请求协调", img_first["ts"] if img_first else 0, "window", "api_start", "first_image_json_r"),
                ("F1", "数据源解析", obd_first or fc_first or 0, "window", "first_image_json_r", "overlaybd_proc"),
                ("F2", "OverlayBD装配", fc_first, "event", "overlaybd_proc", "firecracker_proc"),
                ("F3", "firecracker拉起", mem_r_f["ts"] if mem_r_f else 0, "event", "firecracker_proc", "first_mem_r"),
                ("F4", "状态回填+boot", mem_r_l["ts"] if mem_r_l else 0, "event", "first_mem_r", "last_mem_r|first_upper_w"),
                ("F5", "尾部事务", 0, "event", "last_mem_r", "api_end"),
            ])
            return _append_tail_stage(wins, api_end_ns, tail_end_ns)
    raise ValueError(f"unknown op: {op}")
