"""pause 测量 —— 规范 §2.2。

阶段 P0-P3（P4 异步写回由 TAIL 相位指标承载）。
额外指标：dirty_drain_ms（基线=BASE 相位 Dirty 均值）、
mem/rootfs_commit_bytes（产物分账）。
"""
from __future__ import annotations

from pathlib import Path

from opbench.core import cli as aenv_cli
from opbench.core.metrics import parse_proc_sample, dirty_drain_ms
from opbench.core.procs import mono_ns
from opbench.ops.base import OperationMeasurer
from opbench.ops.anchors import build_stage_windows


class PauseMeasurer(OperationMeasurer):
    op_name = "pause"
    # 复盘修正：内核 writeback 实测 200MB 脏页需 12-24s 回写（burst 式），
    # TAIL 10s 不够覆盖 P4 异步写回 → dirty_drain_ms 恒 null。放宽到 30s。
    tail_s = 30.0

    def api_phase_body(self, collector, ph):
        t0 = mono_ns()
        try:
            out = self.api.pause(self.sid)
            rc = 0
        except Exception as exc:
            out, rc = str(exc), 1
        t1 = mono_ns()
        # 有效性：rc==0（§1.5.3）
        return {"rc": rc, "api_duration_ms": (t1 - t0) / 1e6,
                "response": out}

    def build_stage_windows(self, api_start_ns, api_end_ns, vfs_events, pid_infos, tail_end_ns=None):
        return build_stage_windows("pause", api_start_ns, api_end_ns,
                                   vfs_events, pid_infos, tail_end_ns)

    def extra_metrics(self, out_dir: Path, result: dict):
        sp = out_dir / "proc_sample.csv"
        if not sp.exists() or "phase" not in result:
            return
        phases = result["phase"]
        # api_start/end 从 phase_summary 取（BASE 均值 → dirty 基线）
        import csv
        with open(out_dir / "phase_summary.csv") as f:
            rows = list(csv.DictReader(f))
        api = next(r for r in rows if r["phase_id"].endswith("_API"))
        base = next(r for r in rows if r["phase_id"].endswith("_BASE"))
        base_dirty = phases.get("pause_BASE", {}).get("proc", {}).get("dirty_kb_mean", 0)
        sample_rows = parse_proc_sample(sp)
        result["dirty_drain"] = dirty_drain_ms(
            sample_rows, int(api["end_mono_ns"]),
            int(api["end_mono_ns"]) + int(self.tail_s * 1e9) + 1_000_000_000,
            base_dirty)
        result["dirty_baseline_kb"] = base_dirty
