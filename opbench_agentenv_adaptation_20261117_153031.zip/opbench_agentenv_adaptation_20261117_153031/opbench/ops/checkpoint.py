"""checkpoint（snapshot create）测量 —— 规范 §2.4。

阶段 C0-C4；快照名带 os.urandom 后缀（aenv 无 snapshot delete，只增不删）；
chain_read_bytes（checkpoint 特有组）。
"""
from __future__ import annotations

from opbench.core import cli as aenv_cli
from opbench.core.procs import mono_ns
from opbench.ops.base import OperationMeasurer
from opbench.ops.anchors import build_stage_windows


class CheckpointMeasurer(OperationMeasurer):
    op_name = "checkpoint_snapshot"
    # 复盘修正：与 pause 同款异步写回 → TAIL 放宽覆盖 dirty_drain
    tail_s = 30.0

    def __init__(self, run_id, out_root, sid, snap_prefix="opbench_snap",
                 cold=True):
        super().__init__(run_id, out_root, sid, cold=cold)
        self.snap_name = f"{snap_prefix}_{aenv_cli.new_suffix()}"
        self.result["snapshot_name"] = self.snap_name

    def api_phase_body(self, collector, ph):
        t0 = mono_ns()
        try:
            out = self.api.create_snapshot(self.sid, self.snap_name)
            rc = 0
        except Exception as exc:
            out, rc = str(exc), 1
        t1 = mono_ns()
        return {"rc": rc, "api_duration_ms": (t1 - t0) / 1e6,
                "response": out}

    def build_stage_windows(self, api_start_ns, api_end_ns, vfs_events, pid_infos, tail_end_ns=None):
        windows = build_stage_windows("checkpoint", api_start_ns, api_end_ns,
                                      vfs_events, pid_infos, tail_end_ns)
        # C3 链读窗口补 chain_read_bytes
        self._chain_window = next((w for w in windows if w["stage_id"] == "C3"), None)
        return windows

    def extra_metrics(self, out_dir, result):
        # chain_read_bytes：C3 窗口内 overlaybd.commit R 事件求和（§2.4）
        from opbench.core.metrics import parse_vfs_log
        cw = getattr(self, "_chain_window", None)
        if cw:
            vfs_events = parse_vfs_log(out_dir / "vfs.log")
            total = sum(e["bytes"] for e in vfs_events
                        if e["kind"] == "R" and "overlaybd.commit" in e["name"]
                        and cw["start_ns"] <= e["ts"] <= cw["end_ns"])
            result["chain_read_MB"] = round(total / (1 << 20), 3)
        # 复盘补齐：dirty_drain（与 pause 对称，基线 = BASE 相 Dirty 均值）
        import csv
        from opbench.core.metrics import parse_proc_sample, dirty_drain_ms
        sp = out_dir / "proc_sample.csv"
        if not sp.exists() or "phase" not in result:
            return
        with open(out_dir / "phase_summary.csv") as f:
            rows_ps = list(csv.DictReader(f))
        api = next(r for r in rows_ps if r["phase_id"].endswith("_API"))
        base_dirty = result["phase"].get("checkpoint_snapshot_BASE", {}).get(
            "proc", {}).get("dirty_kb_mean", 0)
        result["dirty_drain"] = dirty_drain_ms(
            parse_proc_sample(sp), int(api["end_mono_ns"]),
            int(api["end_mono_ns"]) + int(self.tail_s * 1e9) + 1_000_000_000,
            base_dirty)
        result["dirty_baseline_kb"] = base_dirty
