"""resume 测量 —— 规范 §2.3。前置：沙箱处于 paused。

阶段 R0-R5；TAIL 4s；cached_kb 交叉验证（API 相位下降量 ≈ blk 读量）。
"""
from __future__ import annotations

from opbench.core import cli as aenv_cli
from opbench.core.procs import mono_ns
from opbench.ops.base import OperationMeasurer
from opbench.ops.anchors import build_stage_windows


class ResumeMeasurer(OperationMeasurer):
    op_name = "resume"
    tail_s = 4.0

    def api_phase_body(self, collector, ph):
        t0 = mono_ns()
        try:
            out = self.api.resume(self.sid, timeout=1800)
            rc = 0
        except Exception as exc:
            out, rc = str(exc), 1
        t1 = mono_ns()
        return {"rc": rc, "api_duration_ms": (t1 - t0) / 1e6,
                "response": out}

    def build_stage_windows(self, api_start_ns, api_end_ns, vfs_events, pid_infos, tail_end_ns=None):
        return build_stage_windows("resume", api_start_ns, api_end_ns,
                                   vfs_events, pid_infos, tail_end_ns)

    def extra_metrics(self, out_dir, result):
        # cached 交叉验证（§2.3）：API 相位 cached 下降量 vs blk 读量
        api = result.get("phase", {}).get(self.op_name + "_API") or \
              result.get("phase", {}).get("API")
        if api:
            proc = api["proc"]
            result["cross_check"] = {
                "cached_drop_MB": round((proc["cached_kb_start"] - proc["cached_kb_end"]) / 1024, 1),
                "blk_read_MB": api["io"]["read_MB"],
                "note": "偏差>20%需解释（§2.3）",
            }
