"""OperationMeasurer 基类 —— 规范 §3 SOP 13 步的标准实现。

子类只需提供：
- op_name
- api_phase_body(collector, ph) -> dict   # API 相位内执行的 aenv 操作
- build_stage_windows(api_start_ns, api_end_ns, vfs_events, pid_infos) -> list[dict]
- tail_s（TAIL 相位时长：4s 或 10s）
- post_api(collector) -> dict（可选：tail_ready_ms 等操作特有后处理）
- extra_metrics(out_dir, result)（可选：dirty_drain/分账等）
"""
from __future__ import annotations

import json
import time
from pathlib import Path

from opbench.core import cli as aenv_cli
from opbench.core.api import AgentEnvApi
from opbench.core.markers import MarkerIndex, read_markers
from opbench.core import coldcache
from opbench.core.metrics import (parse_proc_sample, phase_metrics,
                                  stage_metrics, dirty_drain_ms)
from opbench.core.procs import (Collector, Phase, pids_of_uid, du_snapshot,
                                artifact_delta, mono_ns)
from opbench.ops.anchors import build_task_stage_windows


def task_stage_operation(operation: str) -> str | None:
    """Map externally meaningful operation labels to task-stage models."""
    return {"start": "start", "pause": "pause", "resume": "resume",
            "checkpoint_snapshot": "checkpoint", "fork_native": "fork"}.get(operation)


class OperationMeasurer:
    op_name: str = "base"
    tail_s: float = 4.0
    base_s: float = 1.0
    warmup_s: float = 1.5

    def __init__(self, run_id: str, out_root: str | Path, sid: str,
                 cold: bool = True, artifacts_snapshot: bool = True):
        self.run_id = run_id
        # 卫生 §1.5.2：run 目录名必须含完整 run_id，禁止前缀重叠
        self.out_dir = Path(out_root) / run_id
        self.sid = sid
        self.cold = cold
        self.artifacts_snapshot = artifacts_snapshot
        self.result: dict = {"run_id": run_id, "operation": self.op_name,
                             "sid": sid, "phase": {}, "stage": {}}
        self._api: AgentEnvApi | None = None

    @property
    def api(self) -> AgentEnvApi:
        if self._api is None:
            self._api = AgentEnvApi.from_environment()
        return self._api

    # ── 子类钩子 ─────────────────────────────────────────────────

    def api_phase_body(self, collector: Collector, ph: Phase) -> dict:
        raise NotImplementedError

    def build_stage_windows(self, api_start_ns: int, api_end_ns: int,
                            vfs_events: list, pid_infos: list,
                            tail_end_ns: int | None = None) -> list[dict]:
        return []

    def post_api(self, collector: Collector, api_res: dict) -> dict:
        return {}

    def extra_metrics(self, out_dir: Path, result: dict) -> None:
        return None

    # ── SOP 13 步 ───────────────────────────────────────────────

    def measure(self) -> dict:
        # 2. 产物前快照
        pre_art = du_snapshot(self.sid) if self.artifacts_snapshot else {}

        # 3. 冷缓存构造（三步）
        if self.cold:
            self.result["cold_cache"] = coldcache.make_cold()

        # 4-8. 采集 + 三相
        collector = Collector(self.run_id, self.out_dir)
        collector.start(warmup_s=self.warmup_s)
        try:
            with collector.phase(f"{self.op_name}_BASE", "BASE") as ph_base:
                time.sleep(self.base_s)

            pid_before = set(collector.pid_set)
            with collector.phase(f"{self.op_name}_API", "API") as ph_api:
                api_res = self.api_phase_body(collector, ph_api)
            new_pids = collector.refresh_pid_set()
            self.result["new_pids"] = new_pids
            # start/fork 在 API 内解析出新 sid —— 回写到顶层供清理与分账
            if api_res.get("sid"):
                self.sid = api_res["sid"]
                self.result["sid"] = api_res["sid"]

            with collector.phase(f"{self.op_name}_TAIL", "TAIL"):
                time.sleep(self.tail_s)

            collector.stop()

            # post_api 在 TAIL 后执行（如 fork 子沙箱清理）
            post = self.post_api(collector, api_res)
            if post:
                self.result["post_api"] = post
        finally:
            collector.stop()  # 幂等保护

        self.result["collector_health"] = collector.health()

        # 9. 产物后快照
        post_art = du_snapshot(self.sid) if self.artifacts_snapshot else {}
        if self.artifacts_snapshot:
            delta = artifact_delta(pre_art, post_art)
            # 复盘修正：硬编码路径匹配（mem_overlaybd/overlaybd.commit 等）
            # 与实际 artifacts 布局不符（分账恒 0）。改为鲁棒分组：
            # groups = <sid>/ 下的一级子目录聚合（负值=删除/缩减）；
            # commit_bytes = 文件名含 "commit" 的增量聚合；total = du 总差。
            prefix = (str(next(iter(post_art), "")) if post_art else "")
            prefix = prefix.rsplit(f"/{self.sid}", 1)[0] + f"/{self.sid}/"
            groups: dict[str, int] = {}
            commit_bytes = 0
            for k, v in delta.items():
                rel = k[len(prefix):] if k.startswith(prefix) else k
                top = rel.split("/", 1)[0] if "/" in rel else "(root)"
                groups[top] = groups.get(top, 0) + v
                if "commit" in rel.rsplit("/", 1)[-1].lower():
                    commit_bytes += v
            self.result["artifact_delta_bytes"] = {
                "groups": {k: v for k, v in sorted(groups.items()) if v != 0},
                "commit_bytes": commit_bytes,
                "total": sum(delta.values()),
            }
        # 驱动因子：操作完成后沙箱产物总体积（负载建模的"状态量"观测）
        # du_snapshot 增量是 delta，这里补总量口径：产物后快照的字节和
        if self.artifacts_snapshot and post_art:
            self.result["artifact_total_bytes"] = sum(post_art.values())

        collector.write_phase_summary(self.op_name)

        # 10-11. 有效性 + 指标
        rc = api_res.get("rc")
        self.result["rc"] = rc
        self.result["valid"] = (rc == 0 and self.result["collector_health"]["healthy"])
        self.result["api_duration_ms"] = api_res.get("api_duration_ms")

        phases = [ph.to_row(self.run_id, self.op_name) for ph in collector.phases]
        self.result["phase"] = phase_metrics(self.out_dir, phases)

        # 阶段切分（锚点表）
        api_ph = next(p for p in phases if p["phase_id"].endswith("_API"))
        api_start, api_end = api_ph["start_mono_ns"], api_ph["end_mono_ns"]
        from opbench.core.metrics import parse_vfs_log
        vfs_events = parse_vfs_log(self.out_dir / "vfs.log")
        pid_infos = self._resolve_pid_infos(collector, api_start, api_end)
        tail_ph = next(p for p in phases if p["phase_id"].endswith("_TAIL"))
        task_op = task_stage_operation(self.op_name)
        if task_op:
            markers = MarkerIndex(read_markers(self.out_dir / "phase_markers.jsonl",
                                                self.run_id))
            windows, quality = build_task_stage_windows(
                task_op, api_start, api_end, tail_ph["end_mono_ns"], markers)
            self.result["stage_quality"] = quality
        else:
            windows = self.build_stage_windows(api_start, api_end, vfs_events, pid_infos,
                                               tail_ph["end_mono_ns"])
            self.result["stage_quality"] = {"quality": "legacy", "marker_count": 0,
                                            "missing_markers": []}
        if windows:
            self.result["stage"] = stage_metrics(self.out_dir, windows)
            # 复盘标注（规范 §3.3.1 观测下界）：大块数据读走块层直读（vfs 盲区），
            # 以 vfs 元数据为锚的阶段（如 R4 实体回填、S4 boot 层读）会把
            # 块层读量归到后续阶段窗口 —— 报告解读时须注意此归属偏差
            self.result["blind_spot_note"] = (
                "vfs锚点对块层直读是盲区（§1.2/§3.3.1）："
                "start/resume/fork 的实体读量归因只到 blk 口径，"
                "R4/F4 窗口可能低估（实体回填落在后续窗口）")

        self.extra_metrics(self.out_dir, self.result)
        drain = self.result.get("dirty_drain")
        if drain is not None:
            self.result["tail_censored"] = not drain.get("drained", False)

        # 12. 增量落盘
        self._write_results()
        return self.result

    def _resolve_pid_infos(self, collector: Collector,
                           api_start_ns: int, api_end_ns: int) -> list[dict]:
        """新 pid 的首次出现时刻——事件级精度（§1.2 进程集规则）。

        HostSampler 50ms 采样对 <1s 的 API 相太粗（且 ~2s 才刷 pid 集），
        因此首现时刻取 vfs.log / blk.log 中该 pid 最早事件；comm 从
        vfs/blk 事件的 comm 字段直接取（bpftrace 已带）。"""
        from opbench.core.metrics import parse_blk_log, parse_vfs_log
        infos = []
        vfs_events = parse_vfs_log(self.out_dir / "vfs.log")
        blk_events = parse_blk_log(self.out_dir / "blk.log")
        # comm 兜底：proc_sample.csv（若事件里没有该 pid）
        comm_fallback: dict[int, str] = {}
        sp = self.out_dir / "proc_sample.csv"
        if sp.exists():
            for r in parse_proc_sample(sp):
                comm_fallback.setdefault(r["pid"], r["comm"])
        for pid in (self.result.get("new_pids") or []):
            first, comm, src = 0, "", ""
            for e in vfs_events:
                if e.get("pid") == pid and (first == 0 or e["ts"] < first):
                    if first == 0 or e["ts"] < first:
                        first, comm, src = e["ts"], e["comm"], "vfs"
            for e in blk_events:
                if e.get("pid") == pid and (first == 0 or e["ts"] < first):
                    # Completion records intentionally have no comm field; use
                    # it only when this earliest block event is an issue.
                    first, comm, src = e["ts"], e.get("comm", ""), "blk"
            if not comm:
                comm = comm_fallback.get(pid, "")
            infos.append({"pid": pid, "label": comm, "first_seen_ns": first,
                          "source": src})
        return infos

    def summary(self) -> dict:
        """results.json 聚合用的精简摘要（复盘修正：避免百级 run 下全量 JSON 膨胀；
        完整数据保留在各自 run 目录的 result.json 四件套中）。"""
        r = self.result
        api = r.get("phase", {}).get(f"{self.op_name}_API", {})
        return {
            "run_id": r.get("run_id"), "operation": self.op_name,
            "sid": r.get("sid"), "rc": r.get("rc"), "valid": r.get("valid"),
            "api_duration_ms": r.get("api_duration_ms"),
            "trace": r.get("trace"), "step": r.get("step"), "rep": r.get("rep"),
            "api_io": {k: api.get("io", {}).get(k) for k in
                       ("read_MB", "write_MB", "mb_s_peak_r", "mb_s_peak_w")},
            "api_cpu_peak": api.get("proc", {}).get("cpu_peak"),
            "stages_ms": {k: round(v.get("duration_ms", 0), 1)
                          for k, v in (r.get("stage") or {}).items()},
            "dirty_drain_ms": (r.get("dirty_drain") or {}).get("dirty_drain_ms"),
            "post": r.get("post_api") if self.op_name in ("start", "fork_native") else None,
        }

    def _write_results(self) -> None:
        out = self.out_dir / "result.json"
        with open(out, "w", encoding="utf-8") as f:
            json.dump(self.result, f, ensure_ascii=False, indent=2, default=str)
        # SOP 步骤12：append 到共享 results.json（增量落盘，崩溃不丢）——只存摘要
        from opbench.core.procs import append_results_json
        append_results_json(self.out_dir.parent, self.summary())
