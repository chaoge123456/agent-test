"""Native fork measurement — AgentENV POST /sandboxes/{id}/fork.

阶段 F0-F5；TAIL 10s；fork 子沙箱测量后 delete（校验 rc，§1.5.5）。
"""
from __future__ import annotations

import time

from opbench.core.procs import mono_ns
from opbench.ops.base import OperationMeasurer
from opbench.ops.anchors import build_stage_windows


class ForkMeasurer(OperationMeasurer):
    op_name = "fork_native"
    tail_s = 10.0

    def __init__(self, run_id, out_root, source_sid, ttl=3600, count=1):
        super().__init__(run_id, out_root, sid=source_sid, artifacts_snapshot=False)
        self.source_sid = source_sid
        self.ttl = ttl
        self.count = count
        self.child_sids: list[str] = []

    def api_phase_body(self, collector, ph):
        t0 = mono_ns()
        try:
            out = self.api.fork_sandbox(self.source_sid, count=self.count, timeout=self.ttl)
            children = [item.get("sandbox", {}) for item in (out or []) if item.get("sandbox")]
            self.child_sids = [child.get("sandboxID", "") for child in children if child.get("sandboxID")]
            sid = self.child_sids[0] if self.child_sids else ""
            if not sid:
                raise RuntimeError(f"fork response has no successful child: {out!r}")
            rc = 0
        except RuntimeError as e:
            sid, out, rc = "", str(e), 1
        t1 = mono_ns()
        self.sid = sid
        return {"rc": rc, "sid": sid, "api_duration_ms": (t1 - t0) / 1e6,
                "response": out, "source_sid": self.source_sid, "child_count": self.count}

    def build_stage_windows(self, api_start_ns, api_end_ns, vfs_events, pid_infos, tail_end_ns=None):
        return build_stage_windows("fork", api_start_ns, api_end_ns,
                                   vfs_events, pid_infos, tail_end_ns)

    def post_api(self, collector, api_res):
        sid = api_res.get("sid") or self.sid
        if not sid:
            return {"error": "fork failed, no child sid"}
        t0 = time.monotonic()
        ok = self.api.wait_for_state(sid, "running", poll_interval_s=2.0,
                                     timeout_s=60.0)
        ready_ms = (time.monotonic() - t0) * 1000
        deleted = []
        for child_sid in self.child_sids or [sid]:
            try:
                self.api.delete(child_sid)
                deleted.append(child_sid)
            except Exception:
                pass
        return {"child_sid": sid, "tail_ready_ms": round(ready_ms, 0),
                "state_running": ok, "child_sids": self.child_sids,
                "children_deleted": deleted}
