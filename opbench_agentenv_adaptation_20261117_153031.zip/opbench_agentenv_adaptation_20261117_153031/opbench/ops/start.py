"""start（模板/镜像启动）测量 —— 规范 §2.1。

阶段 S0-S5；TAIL 10s（捕捉 boot 后层读尾巴）；
tail_ready_ms = state 翻转 running 时刻 − api_end（语义边界，单列）。
"""
from __future__ import annotations

import time

from opbench.core.procs import mono_ns
from opbench.ops.base import OperationMeasurer
from opbench.ops.anchors import build_stage_windows


class StartMeasurer(OperationMeasurer):
    op_name = "start"
    tail_s = 10.0

    def __init__(self, run_id, out_root, target, ttl=3600, cold=None):
        # start 无已存在的 sid；target 为模板/镜像/快照名
        super().__init__(run_id, out_root, sid="", artifacts_snapshot=False)
        self.target = target
        self.ttl = ttl
        self.cold_target = cold

    def api_phase_body(self, collector, ph):
        t0 = mono_ns()
        try:
            out = (self.api.start_cold(self.cold_target, timeout=600)
                   if self.cold_target else self.api.start_from_snapshot(self.target, timeout=self.ttl))
            sid = out.get("sandboxID", "") if isinstance(out, dict) else ""
            if not sid:
                raise RuntimeError(f"start response has no sandboxID: {out!r}")
            self.sid = sid
            rc = 0
        except RuntimeError as e:
            rc = 1
            sid = ""
            out = str(e)
        t1 = mono_ns()
        return {"rc": rc, "sid": sid, "api_duration_ms": (t1 - t0) / 1e6,
                "response": out}

    def build_stage_windows(self, api_start_ns, api_end_ns, vfs_events, pid_infos, tail_end_ns=None):
        return build_stage_windows("start", api_start_ns, api_end_ns,
                                   vfs_events, pid_infos, tail_end_ns)

    def post_api(self, collector, api_res):
        """state 翻轮询 → tail_ready_ms（§2.1 语义边界）。"""
        sid = api_res.get("sid") or self.sid
        if not sid:
            return {"tail_ready_ms": None, "error": "no sid"}
        t0 = time.monotonic()
        ok = self.api.wait_for_state(sid, "running", poll_interval_s=2.0,
                                     timeout_s=60.0)
        ready_ms = (time.monotonic() - t0) * 1000
        return {"sid": sid, "tail_ready_ms": round(ready_ms, 0),
                "state_running": ok}
