"""场景②：pause / checkpoint —— 任意轨迹任意步骤的状态点测量（§2.2/§2.4）。

语义：Stepper 先把轨迹重放到第 step 步（--keep 保留沙箱），在该状态点
上按固定顺序 [checkpoint(先) → pause(后)] 测量（§1.5 状态依赖链）。
"""
from __future__ import annotations

from pathlib import Path

from opbench.replay.stepper import Stepper
from opbench.ops.pause import PauseMeasurer
from opbench.ops.checkpoint import CheckpointMeasurer
from opbench.ops.resume import ResumeMeasurer


def _setup_state(stepper: Stepper, step: int, ttl: int = 3600) -> str:
    return stepper.replay_to(step, ttl=ttl)["sandbox_id"]


def run_pause_checkpoint(run_id: str, out_root: str | Path, stepper: Stepper,
                         step: int, ops: tuple[str, ...] = ("checkpoint", "pause"),
                         reps: int = 1, ttl: int = 3600,
                         resume_between: bool = True) -> dict:
    """在轨迹第 step 步状态点测 checkpoint+pause。

    rep 序列（§3.1 ③-⑦）：checkpoint(测) → pause(测) → resume --timeout →
    轮询 running → 下一 rep。r0/r1+ 由 rep 编号分组。
    """
    out_root = Path(out_root)
    sid = _setup_state(stepper, step, ttl=ttl)
    fp = stepper.state_fingerprint(sid)
    results = {"trace": stepper.trace_id, "step": step,
               "total_steps": stepper.total_steps, "sid": sid,
               "state_fingerprint": fp, "runs": []}
    try:
        for rep in range(reps):
            for op in ops:
                if op == "checkpoint":
                    m = CheckpointMeasurer(f"{run_id}_{op}_rep{rep:02d}",
                                           out_root, sid, snap_prefix=run_id)
                else:
                    m = PauseMeasurer(f"{run_id}_{op}_rep{rep:02d}",
                                      out_root, sid)
                r = m.measure()
                results["runs"].append(r)
            if resume_between and rep < reps - 1 and "pause" in ops:
                # §3.1 ④：resume --timeout 恢复 running 再测下一个
                from opbench.core import cli as aenv_cli
                aenv_cli.resume_sandbox(sid, ttl=1800)
                aenv_cli.wait_state(sid, "running", interval_s=5, max_s=60)
    finally:
        # 清理交调用端（scenarios/cli.py 显式删除）——这里只保留 sid 供上层
        results["cleanup_sid"] = sid
    return results