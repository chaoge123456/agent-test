"""场景①：start —— 任意轨迹（或镜像）的启动各阶段测量（§2.1）。

用法：
    python3 -m opbench.senarios...  # 见 scenarios/cli.py
    run_start(run_id, out_root, target, cold_target=None, reps=1)
"""
from __future__ import annotations

from pathlib import Path

from opbench.ops.start import StartMeasurer


def run_start(run_id: str, out_root: str | Path, target: str,
              cold_target: str | None = None, ttl: int = 3600,
              reps: int = 1, cold: bool = True) -> list[dict]:
    """target：模板名 / ocidir 镜像路径 / 快照名。
    reps 次（r0/r1+ 语义由 rep 编号承载）。"""
    results = []
    for rep in range(reps):
        m = StartMeasurer(f"{run_id}_rep{rep:02d}", out_root, target,
                          ttl=ttl, cold=cold_target)
        # start 每次 run 前都 drop（cold 臂），首个 run 也如此
        r = m.measure()
        results.append(r)
        if m.sid:
            from opbench.core import cli as aenv_cli
            if not aenv_cli.delete_sandbox(m.sid):
                r["cleanup_warn"] = f"delete sid={m.sid} rc!=0"
    return results