"""场景③：原生 fork —— 一个 source capture 派生 N 个 children。"""
from __future__ import annotations

from pathlib import Path

from opbench.replay.stepper import Stepper
from opbench.ops.fork import ForkMeasurer


def run_fork(run_id: str, out_root: str | Path, stepper: Stepper,
             step: int, n_children: int = 1, ttl: int = 3600) -> dict:
    out_root = Path(out_root)
    sid = stepper.replay_to(step, ttl=ttl)["sandbox_id"]
    results = {"trace": stepper.trace_id, "step": step, "sid": sid,
               "n_children": n_children,
               "state_fingerprint": stepper.state_fingerprint(sid), "runs": []}
    m = ForkMeasurer(f"{run_id}_fork_native", out_root, sid, ttl=ttl,
                     count=n_children)
    results["runs"].append(m.measure())
    results["cleanup_sid"] = sid
    return results
