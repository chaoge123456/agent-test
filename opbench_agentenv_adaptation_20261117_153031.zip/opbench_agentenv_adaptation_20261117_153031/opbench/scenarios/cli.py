"""场景 CLI —— 四类顶层需求的统一入口（规范 §3 SOP 固化）。

用法：
    # ① start：任意轨迹（模板）/镜像
    python3 -m opbench.scenarios.cli start --target <模板|镜像> [--cold-target ocidir://...] [--reps 3]

    # ② pause/checkpoint：任意轨迹 × 任意步骤
    python3 -m opbench.scenarios.cli pause --trace <id> --step 25 [--ops checkpoint,pause] [--reps 3]
      step 可为绝对步数或百分数（如 50%→round(total*0.5)）

    # ③ fork：任意轨迹 × 任意步骤 × N 个子沙箱
    python3 -m opbench.scenarios.cli fork --trace <id> --step 50% --children 3

    # ④ resume：任意轨迹 × 任意步骤（先 pause 再测 resume）
    python3 -m opbench.scenarios.cli resume --trace <id> --step 25
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

# Current development VM defaults.  The target-host experiment must pass
# explicit paths rather than inheriting the retired /mnt/old_home layout.
OUT_ROOT_DEFAULT = "/tmp/opbench-results"
TRACE_DIR_DEFAULT = "/tmp/opbench-traces"


def _stamp_run_id(op: str) -> str:
    """run_id 卫生（§1.5.1）：唯一前缀 + 时间戳。"""
    return f"{op}_{time.strftime('%Y%m%d_%H%M%S')}"


def _resolve_step(stepper, step_arg: str) -> int:
    if step_arg.endswith("%"):
        pct = int(step_arg[:-1])
        return round(stepper.total_steps * pct / 100)
    return int(step_arg)


def _make_stepper(args) -> "Stepper":
    from opbench.replay.stepper import Stepper
    return Stepper(args.trace, args.trace_dir)


def _cleanup(sid: str) -> None:
    if not sid:
        return
    from opbench.core import cli as aenv_cli
    if not aenv_cli.delete_sandbox(sid):
        print(f"warn: delete sid={sid} rc!=0", file=sys.stderr)


def cmd_start(args) -> None:
    from opbench.scenarios.measure_start import run_start
    results = run_start(_stamp_run_id("start"), args.out_root, args.target,
                        cold_target=args.cold_target, ttl=args.ttl,
                        reps=args.reps)
    print(json.dumps([{k: r.get(k) for k in
                       ("run_id", "rc", "api_duration_ms", "sid")} for r in results],
                     indent=2))


def cmd_pause(args) -> None:
    from opbench.scenarios.measure_pause import run_pause_checkpoint
    stepper = _make_stepper(args)
    step = _resolve_step(stepper, args.step)
    ops = tuple(o.strip() for o in args.ops.split(","))
    res = run_pause_checkpoint(_stamp_run_id("pause"), args.out_root, stepper,
                               step, ops=ops, reps=args.reps, ttl=args.ttl)
    _cleanup(res.get("cleanup_sid"))
    print(json.dumps({k: v for k, v in res.items() if k != "runs"},
                     indent=2, default=str))
    for r in res.get("runs", []):
        print(f"  {r['run_id']}: rc={r['rc']} api_ms={r['api_duration_ms']}")


def cmd_fork(args) -> None:
    from opbench.scenarios.measure_fork import run_fork
    stepper = _make_stepper(args)
    step = _resolve_step(stepper, args.step)
    res = run_fork(_stamp_run_id("fork"), args.out_root, stepper, step,
                   n_children=args.children, ttl=args.ttl)
    _cleanup(res.get("cleanup_sid"))
    print(json.dumps({k: v for k, v in res.items() if k != "runs"},
                     indent=2, default=str))
    for r in res.get("runs", []):
        print(f"  {r['run_id']}: rc={r['rc']} api_ms={r['api_duration_ms']}")


def cmd_resume(args) -> None:
    from opbench.scenarios.measure_resume import run_resume
    stepper = _make_stepper(args)
    step = _resolve_step(stepper, args.step)
    res = run_resume(_stamp_run_id("resume"), args.out_root, stepper, step,
                     ttl=args.ttl)
    _cleanup(res.get("cleanup_sid"))
    print(json.dumps({k: v for k, v in res.items() if k != "runs"},
                     indent=2, default=str))
    for r in res.get("runs", []):
        print(f"  {r['run_id']}: rc={r['rc']} api_ms={r['api_duration_ms']}")


def main(argv=None) -> None:
    p = argparse.ArgumentParser(prog="opbench")
    sub = p.add_subparsers(dest="cmd", required=True)

    def common(sp):
        sp.add_argument("--out-root", default=OUT_ROOT_DEFAULT)
        sp.add_argument("--ttl", type=int, default=3600)
        sp.add_argument("--reps", type=int, default=1)

    s1 = sub.add_parser("start", help="沙箱启动各阶段测量")
    s1.add_argument("--target", required=True, help="模板/镜像名")
    s1.add_argument("--cold-target", default=None, help="ocidir 资源 override（仅 --cold 可用）")
    common(s1)

    for name, help_ in (("pause", "pause/checkpoint 各阶段测量"),
                        ("fork", "fork 各阶段测量"),
                        ("resume", "resume 各阶段测量（先 pause）")):
        sp = sub.add_parser(name, help=help_)
        sp.add_argument("--trace", required=True)
        sp.add_argument("--trace-dir", default=TRACE_DIR_DEFAULT)
        sp.add_argument("--step", required=True,
                        help="步骤序号或百分数（如 25 / 50%）")
        common(sp)
    # fork 专用
    sub.choices["fork"].add_argument("--children", type=int, default=1)
    # pause 专用
    sub.choices["pause"].add_argument("--ops", default="checkpoint,pause",
                                      help="逗号分隔：checkpoint,pause")

    args = p.parse_args(argv)
    {"start": cmd_start, "pause": cmd_pause,
     "fork": cmd_fork, "resume": cmd_resume}[args.cmd](args)


if __name__ == "__main__":
    main()
