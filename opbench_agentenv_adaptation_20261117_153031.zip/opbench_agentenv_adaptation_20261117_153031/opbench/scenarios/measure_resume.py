"""场景④：resume —— 任意轨迹任意步骤，先 pause 再测 resume（§2.3）。"""
from __future__ import annotations

from pathlib import Path

from opbench.replay.stepper import Stepper
from opbench.ops.pause import PauseMeasurer
from opbench.ops.resume import ResumeMeasurer


def run_resume(run_id: str, out_root: str | Path, stepper: Stepper,
               step: int, ttl: int = 3600) -> dict:
    """轨迹第 step 步 → pause（不测量）→ cold 构造 → resume（测量）。

    pause 不占 run 槽（仅状态构造），resume 是被测操作。
    """
    out_root = Path(out_root)
    sid = stepper.replay_to(step, ttl=ttl)["sandbox_id"]
    from opbench.core import cli as aenv_cli
    results = {"trace": stepper.trace_id, "step": step, "sid": sid,
               "state_fingerprint": stepper.state_fingerprint(sid), "runs": []}
    # pause（状态构造，非测量）
    rc, out, _ = aenv_cli.pause_sandbox(sid, timeout=600)
    results["prep_pause_rc"] = rc
    if rc != 0:
        results["error"] = f"prep pause rc={rc}: {out[-200:]}"
        return results
    m = ResumeMeasurer(f"{run_id}_resume_rep00", out_root, sid)
    results["runs"].append(m.measure())
    results["cleanup_sid"] = sid
    return results