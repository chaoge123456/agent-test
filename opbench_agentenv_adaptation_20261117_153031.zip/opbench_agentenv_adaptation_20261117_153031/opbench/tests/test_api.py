import json
import unittest

from opbench.core.api import AgentEnvApi, MissingApiKeyError


class RecordingTransport:
    def __init__(self):
        self.calls = []

    def request(self, method, url, headers, body, timeout):
        self.calls.append((method, url, headers, body, timeout))
        return 201, {"sandboxID": "child-1"}


class SequenceTransport:
    def __init__(self, responses):
        self.responses = iter(responses)
        self.calls = []

    def request(self, method, url, headers, body, timeout):
        self.calls.append((method, url, headers, body, timeout))
        return 200, next(self.responses)


class AgentEnvApiTests(unittest.TestCase):
    def test_snapshot_start_posts_template_id_and_timeout(self):
        transport = RecordingTransport()
        api = AgentEnvApi(api_key="secret-value", transport=transport)

        api.start_from_snapshot("lifecycle-bench-checkpoint", timeout=900)

        method, url, headers, body, timeout = transport.calls[0]
        self.assertEqual((method, url, timeout), ("POST", "http://127.0.0.1:8000/sandboxes", 900))
        self.assertEqual(headers["X-API-Key"], "secret-value")
        self.assertEqual(json.loads(body), {"templateID": "lifecycle-bench-checkpoint", "timeout": 900})

    def test_cold_start_posts_image_to_cold_endpoint(self):
        transport = RecordingTransport()
        api = AgentEnvApi(api_key="secret-value", transport=transport)

        api.start_cold("docker.io/library/ubuntu:24.04", timeout=900)

        method, url, _, body, _ = transport.calls[0]
        self.assertEqual((method, url), ("POST", "http://127.0.0.1:8000/sandboxes-cold"))
        self.assertEqual(json.loads(body), {"image": "docker.io/library/ubuntu:24.04", "timeout": 900})

    def test_missing_key_fails_without_request_or_secret_in_message(self):
        transport = RecordingTransport()
        with self.assertRaises(MissingApiKeyError) as raised:
            AgentEnvApi.from_environment(env={}, transport=transport)

        self.assertEqual(transport.calls, [])
        self.assertNotIn("secret", str(raised.exception).lower())

    def test_lifecycle_and_native_fork_use_documented_endpoints(self):
        transport = RecordingTransport()
        api = AgentEnvApi(api_key="secret-value", transport=transport)

        api.pause("source")
        api.resume("source", timeout=1800)
        api.create_snapshot("source", "bench-snapshot")
        api.fork_sandbox("source", count=3, timeout=900)
        api.delete("child-1")

        self.assertEqual(
            [(method, url, json.loads(body) if body else None) for method, url, _, body, _ in transport.calls],
            [
                ("POST", "http://127.0.0.1:8000/sandboxes/source/pause", None),
                ("POST", "http://127.0.0.1:8000/sandboxes/source/resume", {"timeout": 1800}),
                ("POST", "http://127.0.0.1:8000/sandboxes/source/snapshots", {"name": "bench-snapshot"}),
                ("POST", "http://127.0.0.1:8000/sandboxes/source/fork", {"count": 3, "timeout": 900}),
                ("DELETE", "http://127.0.0.1:8000/sandboxes/child-1", None),
            ],
        )

    def test_get_sandbox_uses_same_authenticated_http_client(self):
        transport = RecordingTransport()
        api = AgentEnvApi(api_key="secret-value", transport=transport)

        api.get_sandbox("source")

        method, url, headers, body, _ = transport.calls[0]
        self.assertEqual((method, url, body), ("GET", "http://127.0.0.1:8000/sandboxes/source", None))
        self.assertEqual(headers["X-API-Key"], "secret-value")

    def test_wait_for_state_polls_only_the_http_api(self):
        transport = SequenceTransport([{"state": "starting"}, {"state": "running"}])
        api = AgentEnvApi(api_key="secret-value", transport=transport)

        ready = api.wait_for_state("source", "running", timeout_s=1,
                                   poll_interval_s=0, sleep=lambda _: None)

        self.assertTrue(ready)
        self.assertEqual([call[0] for call in transport.calls], ["GET", "GET"])

