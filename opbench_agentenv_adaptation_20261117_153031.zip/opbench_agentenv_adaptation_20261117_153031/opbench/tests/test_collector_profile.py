import tempfile
import unittest
import json
from pathlib import Path
from unittest.mock import patch

from opbench.core import procs
from opbench.core.procs import Collector
from opbench.core.runtime import RuntimeProfile


class CollectorProfileTests(unittest.TestCase):
    def test_materializes_block_filter_from_runtime_devices(self):
        profile = RuntimeProfile("/var/lib/aenv", 999, {"sda": 8388608}, {"ublkb0": 271581185})
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            bpf = root / "bpf"
            bpf.mkdir()
            (bpf / "blk.bt").write_text("/ __OPBENCH_DEVICE_FILTER__ / { }\n")
            (bpf / "vfs.bt").write_text("BEGIN { }\n")
            collector = Collector("run", root / "out", bpf_dir=bpf, runtime=profile)

            script = collector.materialize_block_script().read_text()

        self.assertIn("args->dev == 8388608", script)
        self.assertIn("args->dev == 271581185", script)
        self.assertNotIn("__OPBENCH_DEVICE_FILTER__", script)

    def test_health_reports_exited_probe_as_unhealthy(self):
        profile = RuntimeProfile("/var/lib/aenv", 999, {"sda": 8388608}, {})
        with tempfile.TemporaryDirectory() as directory:
            collector = Collector("run", Path(directory) / "out", runtime=profile)
            collector.procs = {"blk": type("Exited", (), {"poll": lambda self: 1})()}

            health = collector.health()

        self.assertFalse(health["healthy"])
        self.assertEqual(health["failed_probes"], {"blk": 1})

    def test_writes_manifest_with_logical_io_boundary(self):
        profile = RuntimeProfile("/var/lib/aenv", 999, {"sda": 8388608}, {"ublkb0": 271581185})
        with tempfile.TemporaryDirectory() as directory:
            out = Path(directory) / "out"
            collector = Collector("run", out, runtime=profile)
            manifest = collector.write_manifest()

            data = json.loads(manifest.read_text())

        self.assertEqual(data["io_boundary"], "guest_logical")
        self.assertEqual(data["devices"]["logical"], {"sda": 8388608})

    def test_artifact_snapshot_uses_privileged_du_without_path_stat(self):
        root = Path("/private/aenv/artifacts")

        class Completed:
            stdout = "12 /private/aenv/artifacts/sandbox-a\n"

        with (patch.object(procs, "ARTIFACTS_ROOT", root),
              patch.object(procs.subprocess, "run", return_value=Completed()) as run):
            snapshot = procs.du_snapshot("sandbox-a")

        self.assertEqual(snapshot, {"/private/aenv/artifacts/sandbox-a": 12})
        self.assertEqual(run.call_args.args[0][:3], ["sudo", "-n", "du"])
