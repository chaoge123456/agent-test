import unittest

from opbench.core.markers import MarkerIndex
from opbench.ops.anchors import build_task_stage_windows


class TaskStageTests(unittest.TestCase):
    def test_start_marker_windows_follow_task_boundaries(self):
        markers = MarkerIndex([
            {"phase": "storage_attach", "event": "begin", "ts_ns": 20},
            {"phase": "state_restore", "event": "begin", "ts_ns": 40},
            {"phase": "vcpu_activate", "event": "begin", "ts_ns": 70},
        ])

        windows, quality = build_task_stage_windows("start", 10, 100, 150, markers)

        self.assertEqual([(w["stage_id"], w["start_ns"], w["end_ns"])
                          for w in windows],
                         [("S0", 10, 20), ("S1", 20, 40),
                          ("S2", 40, 70), ("S3", 70, 100), ("S4", 100, 150)])
        self.assertEqual(quality["quality"], "direct")
        self.assertEqual(windows[1]["boundary_source"]["start"], "marker")

    def test_missing_markers_fall_back_to_single_inferred_api_window(self):
        windows, quality = build_task_stage_windows("resume", 10, 100, 150, MarkerIndex([]))

        self.assertEqual([(w["stage_id"], w["start_ns"], w["end_ns"])
                          for w in windows], [("R0", 10, 100), ("R4", 100, 150)])
        self.assertEqual(quality["quality"], "inferred")
        self.assertEqual(quality["missing_markers"], ["storage_attach", "state_restore", "vcpu_activate"])

    def test_out_of_order_markers_are_clamped_and_degraded(self):
        markers = MarkerIndex([
            {"phase": "storage_attach", "event": "begin", "ts_ns": 50},
            {"phase": "state_restore", "event": "begin", "ts_ns": 30},
            {"phase": "vcpu_activate", "event": "begin", "ts_ns": 70},
        ])

        windows, quality = build_task_stage_windows("start", 10, 100, None, markers)

        self.assertEqual([(w["start_ns"], w["end_ns"]) for w in windows],
                         [(10, 50), (50, 50), (50, 70), (70, 100)])
        self.assertEqual(quality["quality"], "degraded")
