import unittest
from pathlib import Path


class LatencyScriptContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.script = (Path(__file__).resolve().parents[2] /
                      "agentenv-analysis" / "benchmark_lifecycle_latency.sh").read_text()

    def test_requires_explicit_template_and_uses_redacted_credentials(self):
        self.assertIn('--template', self.script)
        self.assertIn('AENV_API_KEY', self.script)
        self.assertNotIn('/var/lib/aenv/secrets/api-key', self.script)
        self.assertIn('results.jsonl', self.script)

    def test_measures_http_lifecycle_and_cleans_disposable_sandboxes(self):
        for endpoint in ('/sandboxes', '/pause', '/resume', '/snapshots', '/fork'):
            self.assertIn(endpoint, self.script)
        self.assertIn('cleanup_sandboxes', self.script)
        self.assertIn('trap cleanup_sandboxes EXIT', self.script)
        self.assertIn('native_fork', self.script)
