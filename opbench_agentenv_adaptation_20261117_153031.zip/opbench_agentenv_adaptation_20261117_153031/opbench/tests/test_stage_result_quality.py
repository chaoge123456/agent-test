import unittest

from opbench.ops.base import task_stage_operation


class StageResultQualityTests(unittest.TestCase):
    def test_result_operation_names_map_to_task_models(self):
        self.assertEqual(task_stage_operation("checkpoint_snapshot"), "checkpoint")
        self.assertEqual(task_stage_operation("fork_native"), "fork")
        self.assertEqual(task_stage_operation("start"), "start")

    def test_unknown_operation_has_no_task_stage_model(self):
        self.assertIsNone(task_stage_operation("unknown"))
