import unittest
from pathlib import Path


class ProfileScriptContractTests(unittest.TestCase):
    def test_lifecycle_operations_use_http_and_do_not_read_service_secret(self):
        script = (Path(__file__).resolve().parents[2] /
                  "agentenv-analysis" / "run_realistic_profiles.sh").read_text()

        self.assertIn('$HOME/.config/aenv/credentials', script)
        self.assertIn('"$API_URL/sandboxes"', script)
        self.assertNotIn('/var/lib/aenv/secrets/api-key', script)
        self.assertIn('fork_native.stdout', script)
        self.assertNotIn('fork.stdout', script)
        self.assertIn('trap cleanup_sandboxes EXIT', script)
        for cli_lifecycle in ('aenv start', 'aenv pause', 'aenv resume',
                              'aenv snapshot create', 'aenv delete'):
            self.assertNotIn(cli_lifecycle, script)
