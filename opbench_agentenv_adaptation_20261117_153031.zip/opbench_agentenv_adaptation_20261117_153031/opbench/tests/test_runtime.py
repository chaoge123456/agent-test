import unittest

from opbench.core.runtime import RuntimeProfile, normalize_block_device


class RuntimeProfileTests(unittest.TestCase):
    def test_normalizes_root_partition_to_parent_disk(self):
        self.assertEqual(normalize_block_device("sda1", {"sda": "8:0", "sda1": "8:1"}), "sda")

    def test_discovers_root_and_ublk_devices_without_static_nvme_ids(self):
        profile = RuntimeProfile.from_system(
            aenv_home="/var/lib/aenv",
            uid_reader=lambda _: 999,
            root_device_reader=lambda: "sda",
            block_device_reader=lambda: {"sda": "8:0", "ublkb0": "259:1", "ublkb3": "259:4"},
        )

        self.assertEqual(profile.aenv_home, "/var/lib/aenv")
        self.assertEqual(profile.aenv_uid, 999)
        self.assertEqual(profile.logical_devices, {"sda": 8 << 20})
        self.assertEqual(profile.ublk_devices, {"ublkb0": (259 << 20) | 1, "ublkb3": (259 << 20) | 4})
        self.assertNotIn(271581188, profile.logical_devices.values())

