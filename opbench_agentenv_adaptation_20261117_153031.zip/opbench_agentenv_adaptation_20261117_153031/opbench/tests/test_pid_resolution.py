import tempfile
import unittest
from pathlib import Path

from opbench.ops.base import OperationMeasurer


class PidResolutionTests(unittest.TestCase):
    def test_completion_without_comm_does_not_break_pid_resolution(self):
        with tempfile.TemporaryDirectory() as directory:
            out = Path(directory)
            (out / "vfs.log").write_text("")
            (out / "blk.log").write_text("C|10|8|0|8|R|0|42\n")
            measurer = OperationMeasurer("run", out.parent, "sid")
            measurer.out_dir = out
            measurer.result["new_pids"] = [42]

            infos = measurer._resolve_pid_infos(None, 0, 20)

        self.assertEqual(infos, [{"pid": 42, "label": "", "first_seen_ns": 10,
                                  "source": "blk"}])
