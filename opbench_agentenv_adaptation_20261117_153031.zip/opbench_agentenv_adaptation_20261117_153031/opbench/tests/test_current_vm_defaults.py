import unittest

from opbench.scenarios import cli


class CurrentVmDefaultsTests(unittest.TestCase):
    def test_cli_defaults_are_writable_current_vm_paths(self):
        self.assertEqual(cli.OUT_ROOT_DEFAULT, "/tmp/opbench-results")
        self.assertEqual(cli.TRACE_DIR_DEFAULT, "/tmp/opbench-traces")
