import json
import tempfile
import unittest
from pathlib import Path

from opbench.core.markers import MarkerIndex, read_markers


class MarkerTests(unittest.TestCase):
    def test_reader_filters_operation_and_ignores_malformed_lines(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "phase_markers.jsonl"
            path.write_text("\n".join([
                json.dumps({"op_id": "run-a", "phase": "storage_attach", "event": "begin", "ts_ns": 10}),
                "not-json",
                json.dumps({"op_id": "run-b", "phase": "storage_attach", "event": "begin", "ts_ns": 20}),
            ]))
            records = read_markers(path, "run-a")

        self.assertEqual(records, [{"op_id": "run-a", "phase": "storage_attach", "event": "begin", "ts_ns": 10}])

    def test_index_selects_boundary_for_requested_child_only(self):
        index = MarkerIndex([
            {"op_id": "run", "phase": "child_restore", "event": "begin", "ts_ns": 10, "child_id": "a"},
            {"op_id": "run", "phase": "child_restore", "event": "begin", "ts_ns": 20, "child_id": "b"},
        ])

        self.assertEqual(index.boundary("child_restore", child_id="b"), 20)
        self.assertEqual(index.boundary("child_restore", child_id="missing"), 0)
