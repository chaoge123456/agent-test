import tempfile
import unittest
from pathlib import Path

from opbench.core.metrics import dirty_drain_ms, io_stats, parse_blk_log


class BlockLogTests(unittest.TestCase):
    def test_retains_issue_and_completion_events(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "blk.log"
            path.write_text(
                "I|10|8388608|4096|R|firecracker|12\n"
                "C|30|8388608|0|8|R|0|12\n"
            )

            events = parse_blk_log(path)

        self.assertEqual([event["kind"] for event in events], ["I", "C"])
        self.assertEqual(events[1]["nr_sector"], 8)

    def test_completion_latency_is_derived_from_matching_issue(self):
        events = [
            {"kind": "I", "ts": 10_000, "dev": 1, "sector": 16, "nr_sector": 8,
             "bytes": 4096, "rwbs": "R", "comm": "fc", "pid": 1},
            {"kind": "C", "ts": 35_000, "dev": 1, "sector": 16, "nr_sector": 8,
             "rwbs": "R", "error": 0, "pid": 1},
        ]

        stats = io_stats(events, 0, 100_000)

        self.assertEqual(stats.latency_count_r, 1)
        self.assertEqual(stats.latency_us_p50_r, 25.0)
        self.assertEqual(stats.unmatched_completions, 0)

    def test_latency_percentiles_use_nearest_rank(self):
        events = []
        for i in range(100):
            events.extend([
                {"kind": "I", "ts": i * 1_000_000, "dev": 1, "sector": i, "nr_sector": 8,
                 "bytes": 4096, "rwbs": "R", "comm": "fc", "pid": 1},
                {"kind": "C", "ts": i * 1_000_000 + (i + 1) * 1_000, "dev": 1, "sector": i,
                 "nr_sector": 8, "rwbs": "R", "error": 0, "pid": 1},
            ])

        stats = io_stats(events, 0, 100_000_000)

        self.assertEqual(stats.latency_us_p95_r, 95.0)
        self.assertEqual(stats.latency_us_p99_r, 99.0)

    def test_dirty_drain_marks_tail_as_not_censored_when_baseline_returns(self):
        rows = [
            {"ts": 100, "dirty_kb": 9000},
            {"ts": 200, "dirty_kb": 1024},
        ]

        result = dirty_drain_ms(rows, 0, 300, baseline_dirty_kb=1024)

        self.assertTrue(result["drained"])
