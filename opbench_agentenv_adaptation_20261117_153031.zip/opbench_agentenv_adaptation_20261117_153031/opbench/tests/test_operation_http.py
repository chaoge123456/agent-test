import unittest

from opbench.ops.checkpoint import CheckpointMeasurer
from opbench.ops.fork import ForkMeasurer
from opbench.ops.start import StartMeasurer


class HttpOnlyApi:
    def __init__(self):
        self.waits = []
        self.deleted = []

    def wait_for_state(self, sid, state, **kwargs):
        self.waits.append((sid, state, kwargs))
        return True

    def delete(self, sid):
        self.deleted.append(sid)


class OperationHttpTests(unittest.TestCase):
    def test_start_ready_check_uses_http_api(self):
        api = HttpOnlyApi()
        measurer = StartMeasurer("run", "/tmp/out", "snapshot")
        measurer._api = api

        result = measurer.post_api(None, {"sid": "started"})

        self.assertTrue(result["state_running"])
        self.assertEqual(api.waits[0][0:2], ("started", "running"))

    def test_native_fork_has_distinct_label_and_uses_http_ready_check(self):
        api = HttpOnlyApi()
        measurer = ForkMeasurer("run", "/tmp/out", "source")
        measurer._api = api
        measurer.child_sids = ["child"]

        result = measurer.post_api(None, {"sid": "child"})

        self.assertEqual(measurer.op_name, "fork_native")
        self.assertTrue(result["state_running"])
        self.assertEqual(api.waits[0][0:2], ("child", "running"))
        self.assertEqual(api.deleted, ["child"])

    def test_checkpoint_has_snapshot_specific_operation_label(self):
        self.assertEqual(CheckpointMeasurer.op_name, "checkpoint_snapshot")
