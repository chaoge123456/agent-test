"""Small, dependency-free client for the local AgentENV HTTP control plane."""
from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request
from dataclasses import dataclass


class MissingApiKeyError(RuntimeError):
    pass


class ApiResponseError(RuntimeError):
    pass


class UrlLibTransport:
    def request(self, method: str, url: str, headers: dict[str, str],
                body: str | None, timeout: int) -> tuple[int, object]:
        request = urllib.request.Request(
            url, data=body.encode() if body is not None else None,
            headers=headers, method=method,
        )
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                raw = response.read().decode()
                return response.status, json.loads(raw) if raw else None
        except urllib.error.HTTPError as error:
            raw = error.read().decode(errors="replace")
            raise ApiResponseError(f"AgentENV HTTP {error.code}: {raw[-500:]}") from None


@dataclass
class AgentEnvApi:
    api_key: str
    base_url: str = "http://127.0.0.1:8000"
    transport: object | None = None

    def __post_init__(self) -> None:
        if not self.api_key:
            raise MissingApiKeyError("AgentENV API key environment variable is required")
        if self.transport is None:
            self.transport = UrlLibTransport()

    @classmethod
    def from_environment(cls, *, env=None, api_key_env: str = "AENV_API_KEY",
                         base_url: str = "http://127.0.0.1:8000", transport=None) -> "AgentEnvApi":
        env = os.environ if env is None else env
        key = env.get(api_key_env)
        if not key:
            raise MissingApiKeyError(f"set {api_key_env} before running opbench")
        return cls(api_key=key, base_url=base_url, transport=transport)

    def _request(self, method: str, path: str, payload: dict | None = None,
                 timeout: int = 600):
        body = json.dumps(payload) if payload is not None else None
        status, response = self.transport.request(
            method, self.base_url + path,
            {"X-API-Key": self.api_key, "Content-Type": "application/json"},
            body, timeout,
        )
        if status not in (200, 201, 204):
            raise ApiResponseError(f"AgentENV unexpected HTTP {status}")
        return response

    def _post(self, path: str, payload: dict | None = None, timeout: int = 600):
        return self._request("POST", path, payload, timeout)

    def start_from_snapshot(self, target: str, *, timeout: int = 300):
        return self._post("/sandboxes", {"templateID": target, "timeout": timeout}, timeout)

    def start_cold(self, image: str, *, timeout: int = 600):
        return self._post("/sandboxes-cold", {"image": image, "timeout": timeout}, timeout)

    def pause(self, sid: str):
        return self._post(f"/sandboxes/{sid}/pause")

    def resume(self, sid: str, *, timeout: int):
        return self._post(f"/sandboxes/{sid}/resume", {"timeout": timeout})

    def create_snapshot(self, sid: str, name: str):
        return self._post(f"/sandboxes/{sid}/snapshots", {"name": name})

    def fork_sandbox(self, sid: str, *, count: int = 1, timeout: int | None = None):
        payload = {"count": count}
        if timeout is not None:
            payload["timeout"] = timeout
        return self._post(f"/sandboxes/{sid}/fork", payload)

    def delete(self, sid: str):
        return self._request("DELETE", f"/sandboxes/{sid}")

    def get_sandbox(self, sid: str):
        return self._request("GET", f"/sandboxes/{sid}")

    def wait_for_state(self, sid: str, expected: str, *, timeout_s: float = 60,
                       poll_interval_s: float = 2, sleep=time.sleep) -> bool:
        """Poll sandbox state through the same authenticated HTTP boundary."""
        deadline = time.monotonic() + timeout_s
        while True:
            sandbox = self.get_sandbox(sid)
            if isinstance(sandbox, dict) and sandbox.get("state") == expected:
                return True
            if time.monotonic() >= deadline:
                return False
            sleep(poll_interval_s)

