"""Optional AgentENV lifecycle phase-marker sidecar support."""
from __future__ import annotations

import json
from pathlib import Path


def read_markers(path: str | Path, op_id: str) -> list[dict]:
    """Read valid JSONL records belonging to one measured operation."""
    path = Path(path)
    if not path.exists():
        return []
    records = []
    for line in path.read_text(encoding="utf-8").splitlines():
        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            continue
        if (isinstance(record, dict) and record.get("op_id") == op_id
                and isinstance(record.get("ts_ns"), int)):
            records.append(record)
    return records


class MarkerIndex:
    def __init__(self, records: list[dict]):
        self.records = sorted(records, key=lambda record: record["ts_ns"])

    def boundary(self, phase: str, event: str = "begin",
                 child_id: str | None = None) -> int:
        for record in self.records:
            if record.get("phase") != phase or record.get("event") != event:
                continue
            if child_id is not None and record.get("child_id") != child_id:
                continue
            return record["ts_ns"]
        return 0
