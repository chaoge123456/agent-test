"""aenv CLI 封装 — 事实参数表单一来源（实测核验）。

约定（与《AgentENV五操作阶段划分与测量方法》v4 §1.5 对齐）：
- aenv resume <sid> 延长用 --timeout，不认 --ttl（rc=2 静默失败）
- aenv list --output json 字段名 sandboxID / state
- aenv snapshot create 要求沙箱 running（paused → HTTP 400）
- aenv start -d stdout 最后一行 = 新沙箱 UUID（36 字符 4 连字符）
- 资源 override 仅 --cold + ocidir 路径可用
"""
from __future__ import annotations

import json
import re
import subprocess
import time

AENV = "aenv"
UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I)


def _run(cmd: list[str], timeout: int = 300, check: bool = False) -> tuple[int, str, str]:
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    if check and p.returncode != 0:
        raise RuntimeError(f"{cmd} rc={p.returncode}\n{p.stdout[-500:]}\n{p.stderr[-500:]}")
    return p.returncode, p.stdout, p.stderr


# ── 沙箱生命周期 ────────────────────────────────────────────────────

def start_sandbox(target: str, ttl: int = 3600, cold: str | None = None,
                  timeout: int = 300) -> tuple[str, str]:
    """启动沙箱（模板或镜像或快照）。返回 (sid, stdout)。"""
    cmd = [AENV, "start", "-d", target, "--timeout", str(ttl)]
    if cold:
        cmd = [AENV, "start", "-d", target, "--cold", cold, "--timeout", str(ttl)]
    rc, out, err = _run(cmd, timeout=timeout)
    if rc != 0:
        raise RuntimeError(f"aenv start rc={rc}: {err[-500:]}")
    sid = out.strip().splitlines()[-1].strip()
    if not UUID_RE.match(sid):
        raise RuntimeError(f"aenv start stdout 无 UUID: {out[-300:]}")
    return sid, out


def delete_sandbox(sid: str, timeout: int = 60) -> bool:
    """删除沙箱并校验返回码。"""
    rc, _, _ = _run([AENV, "delete", sid], timeout=timeout)
    return rc == 0


def pause_sandbox(sid: str, timeout: int = 300) -> tuple[int, str]:
    return _run([AENV, "pause", sid], timeout=timeout)


def resume_sandbox(sid: str, ttl: int = 1800, timeout: int = 300) -> tuple[int, str]:
    return _run([AENV, "resume", sid, "--timeout", str(ttl)], timeout=timeout)


def snapshot_create(sid: str, name: str, timeout: int = 300) -> tuple[int, str]:
    return _run([AENV, "snapshot", "create", sid, "--name", name], timeout=timeout)


def sandbox_state(sid: str, timeout: int = 60) -> str | None:
    """读 aenv list 的 state 字段（不是 status）。"""
    rc, out, _ = _run([AENV, "list", "--output", "json"], timeout=timeout)
    if rc != 0:
        return None
    try:
        lst = json.loads(out)
    except json.JSONDecodeError:
        return None
    return next((e.get("state") for e in lst if e.get("sandboxID") == sid), None)


def wait_state(sid: str, state: str = "running", interval_s: float = 5.0,
               max_s: float = 60.0) -> bool:
    """轮询 aenv list 直到 state 匹配。"""
    deadline = time.time() + max_s
    while time.time() < deadline:
        time.sleep(interval_s)
        if sandbox_state(sid) == state:
            return True
    return False


def exec_in_sandbox(sid: str, cmd: str, timeout: int = 60) -> tuple[int, str]:
    """aenv exec——注意必须用 bash -c 包装（直接给命令会因 nice 包装失败）。"""
    return _run([AENV, "exec", sid, "bash", "-c", cmd], timeout=timeout)


def extend_ttl(sid: str, ttl: int = 1800) -> tuple[int, str]:
    """延长沙箱存活——resume 的 --timeout。"""
    return resume_sandbox(sid, ttl=ttl)


# ── 工具 ────────────────────────────────────────────────────────────

def new_suffix(nbytes: int = 3) -> str:
    import os
    return os.urandom(nbytes).hex()