"""Runtime discovery for the AgentENV host under measurement."""
from __future__ import annotations

import os
import pwd
from dataclasses import dataclass
from pathlib import Path


def dev_t(major_minor: str) -> int:
    major, minor = (int(part) for part in major_minor.split(":", 1))
    return (major << 20) | minor


def normalize_block_device(device: str, devices: dict[str, str]) -> str:
    """Map a mounted partition name to the longest known parent disk name."""
    parents = [name for name in devices if name != device and device.startswith(name)]
    return max(parents, key=len) if parents else device


def _root_device() -> str:
    source = os.popen("findmnt -T /var/lib/aenv -no SOURCE 2>/dev/null").read().strip()
    return Path(source).name or "sda"


def _block_devices() -> dict[str, str]:
    root = Path("/sys/class/block")
    return {
        entry.name: (entry / "dev").read_text().strip()
        for entry in root.iterdir()
        if (entry / "dev").exists()
    }


@dataclass(frozen=True)
class RuntimeProfile:
    aenv_home: str
    aenv_uid: int
    logical_devices: dict[str, int]
    ublk_devices: dict[str, int]
    bpftrace_command: tuple[str, ...] = ("sudo", "-n", "bpftrace")

    @classmethod
    def from_system(cls, *, aenv_home: str = "/var/lib/aenv",
                    uid_reader=None, root_device_reader=None,
                    block_device_reader=None) -> "RuntimeProfile":
        uid_reader = uid_reader or (lambda user: pwd.getpwnam(user).pw_uid)
        root_device_reader = root_device_reader or _root_device
        block_device_reader = block_device_reader or _block_devices
        devices = block_device_reader()
        root_device = normalize_block_device(root_device_reader(), devices)
        if root_device not in devices:
            raise RuntimeError(f"root block device {root_device!r} was not discovered")
        return cls(
            aenv_home=aenv_home,
            aenv_uid=uid_reader("aenv"),
            logical_devices={root_device: dev_t(devices[root_device])},
            ublk_devices={name: dev_t(value) for name, value in devices.items()
                          if name.startswith("ublkb")},
        )

