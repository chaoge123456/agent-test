"""采集编排：三相测量窗口 + bpftrace 探针 + HostSampler + 产物快照。

设计（对齐 v4 §1.1/§1.2/§3）：
- 三相 BASE(1s) → API → TAIL(4/10s)，mono_ns 打点
- blk/vfs 两个 bpftrace 探针，输出落 /dev/shm（tmpfs）避免自污染
- HostSampler 50ms：pid 集 CPU%/RSS + 全机 CPU + Cached/Dirty
- Dirty 基线 = BASE 相位均值（dirty_drain_ms 用）
- 产物级 du 快照（run 前/后差分 → mem/rootfs_commit_bytes 分账）
"""
from __future__ import annotations

import json
import os
import signal
import subprocess
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path

from opbench.core.runtime import RuntimeProfile

AENV_UID = 999
SHM_DIR = "/dev/shm/aenv_opbench"
ARTIFACTS_ROOT = Path("/var/lib/aenv/persisted-sandboxes/artifacts")


def mono_ns() -> int:
    return time.monotonic_ns()


def _meminfo() -> dict[str, int]:
    out = {}
    for line in open("/proc/meminfo"):
        k, v = line.split(":", 1)
        out[k.strip()] = int(v.strip().split()[0])
    return out


def host_cpu_jiffies() -> tuple[int, int]:
    vals = [int(x) for x in open("/proc/stat").readline().split()[1:]]
    idle = vals[3] + (vals[4] if len(vals) > 4 else 0)
    return sum(vals) - idle, sum(vals)


def pids_of_uid(uid: int = AENV_UID) -> list[int]:
    pids = []
    for entry in os.listdir("/proc"):
        if not entry.isdigit():
            continue
        try:
            if os.stat(f"/proc/{entry}").st_uid == uid:
                pids.append(int(entry))
        except OSError:
            continue
    return sorted(pids)


def read_proc_io(pids: list[int]) -> dict[int, dict[str, int]]:
    out = {}
    for p in pids:
        try:
            d = {}
            with open(f"/proc/{p}/io") as f:
                for line in f:
                    k, v = line.split(":")
                    d[k.strip()] = int(v)
            out[p] = d
        except OSError:
            continue
    return out


# ── HostSampler ────────────────────────────────────────────────────

class HostSampler(threading.Thread):
    """50ms 周期采样：pid 集 CPU%/RSS、全机 CPU%、Cached/Dirty。"""

    def __init__(self, out_path: Path, pid_set: list[int], interval_s: float = 0.05):
        super().__init__(daemon=True)
        self.out_path = out_path
        self.interval = interval_s
        self._pids_init = list(pid_set)
        self._stopped = False
        self._pid_cpu_prev: dict[int, tuple[int, int, int]] = {}
        self._host_prev = host_cpu_jiffies()
        self._fh = None

    def _sample_pids(self):
        rows = []
        now = mono_ns()
        for p in list(self._pid_set):
            try:
                parts = open(f"/proc/{p}/stat").read().rsplit(")", 1)[1].split()
                utime, stime = int(parts[11]), int(parts[12])
                try:
                    comm = open(f"/proc/{p}/comm").read().strip()
                except OSError:
                    comm = ""
                try:
                    rss_kb = int(next(l for l in open(f"/proc/{p}/status")
                                      if l.startswith("VmRSS:")).split()[1])
                except Exception:
                    rss_kb = 0
                prev = self._pid_cpu_prev.get(p)
                cpu_pct = 0.0
                if prev:
                    dt = (now - prev[0]) / 1e9
                    if dt > 0:
                        cpu_pct = (utime + stime - prev[1] - prev[2]) / dt / os.sysconf("SC_CLK_TCK") * 100
                self._pid_cpu_prev[p] = (now, utime, stime)
                rows.append((now, p, comm, round(cpu_pct, 1), rss_kb))
            except (OSError, IndexError, ValueError):
                self._pid_set.discard(p)
        return rows

    def run(self):
        self._pid_set = set(self._pids_init)
        self._fh = open(self.out_path, "w", buffering=1)
        self._fh.write("ts_ns,pid,comm,cpu_pct,rss_kb,host_cpu_busy_pct,cached_kb,dirty_kb\n")
        ticks = 0
        clk_tck = os.sysconf("SC_CLK_TCK")
        while not self._stopped:
            busy, total = host_cpu_jiffies()
            db, dt = busy - self._host_prev[0], total - self._host_prev[1]
            host_pct = round(db / dt * 100, 1) if dt > 0 else 0.0
            self._host_prev = (busy, total)
            mi = _meminfo()
            ticks += 1
            if ticks % 40 == 0:  # ~2s 刷新 pid 集（捕获新生 firecracker/overlaybd）
                try:
                    self._pid_set |= set(pids_of_uid())
                except Exception:
                    pass
            for ts, p, comm, cpu, rss in self._sample_pids():
                self._fh.write(f"{ts},{p},{comm},{cpu},{rss},{host_pct},"
                               f"{mi.get('Cached', 0)},{mi.get('Dirty', 0)}\n")
            self._fh.flush()
            time.sleep(self.interval)

    def stop(self):
        self._stopped = True
        self.join(timeout=2)
        try:
            self._fh.close()
        except Exception:
            pass


# ── Phase ──────────────────────────────────────────────────────────

@dataclass
class Phase:
    phase_id: str
    phase_name: str
    start_ns: int
    end_ns: int = 0
    status: str = "ok"
    error: str = ""

    def close(self, status: str = "ok", error: str = "") -> None:
        self.end_ns = mono_ns()
        self.status = status
        self.error = error

    @property
    def duration_ms(self) -> float:
        return (self.end_ns - self.start_ns) / 1e6 if self.end_ns else 0.0

    def to_row(self, run_id: str, operation: str) -> dict:
        return {
            "run_id": run_id, "operation": operation,
            "phase_id": self.phase_id, "phase_name": self.phase_name,
            "start_mono_ns": self.start_ns, "end_mono_ns": self.end_ns,
            "duration_ms": round(self.duration_ms, 3),
            "status": self.status, "error": self.error,
        }


# ── 产物 du 快照（mem/rootfs 分账）────────────────────────────────

def du_snapshot(sid: str) -> dict[str, int]:
    """递归 du -sb artifacts/<sid>/。返回 {相对路径: 字节}。"""
    root = ARTIFACTS_ROOT / sid
    out: dict[str, int] = {}
    # AgentENV stores artifacts below /var/lib/aenv with service-user-only
    # directory traversal.  The collector normally runs as the login user,
    # while BPF is already launched through passwordless sudo; use the same
    # privilege boundary here instead of calling Path.exists(), which itself
    # raises PermissionError on the parent directory.
    p = subprocess.run(["sudo", "-n", "du", "-sb", str(root)],
                       capture_output=True, text=True, timeout=120)
    for line in p.stdout.splitlines():
        parts = line.split(None, 1)
        if len(parts) == 2:
            out[parts[1].strip()] = int(parts[0])
    return out


def artifact_delta(pre: dict[str, int], post: dict[str, int]) -> dict[str, int]:
    return {k: post.get(k, 0) - pre.get(k, 0) for k in set(pre) | set(post)}


# ── Collector：三相会话 ────────────────────────────────────────────

class Collector:
    """一次 run 的采集会话（SOP 步骤 4-8）。"""

    def __init__(self, run_id: str, out_dir: str | Path, bpf_dir: str | None = None,
                 runtime: RuntimeProfile | None = None):
        self.run_id = run_id
        self.out_dir = Path(out_dir)
        self.out_dir.mkdir(parents=True, exist_ok=True)
        self.bpf_dir = Path(bpf_dir or Path(__file__).resolve().parent.parent / "bpf")
        self.runtime = runtime or RuntimeProfile.from_system()
        self.shm_dir = Path(SHM_DIR) / run_id
        self.procs: dict[str, subprocess.Popen] = {}
        self._last_health = {"healthy": True, "failed_probes": {}}
        self.sampler: HostSampler | None = None
        self.phases: list[Phase] = []
        self.pid_set: list[int] = []
        self._bt_files = {"blk": self.shm_dir / "blk.log", "vfs": self.shm_dir / "vfs.log"}

    def health(self) -> dict:
        if not self.procs:
            return self._last_health
        failed = {name: rc for name, proc in self.procs.items()
                  if (rc := proc.poll()) is not None}
        self._last_health = {"healthy": not failed, "failed_probes": failed}
        return self._last_health

    def materialize_block_script(self) -> Path:
        """Generate the block filter for the devices discovered for this run."""
        source = (self.bpf_dir / "blk.bt").read_text()
        devices = sorted(set(self.runtime.logical_devices.values()) | set(self.runtime.ublk_devices.values()))
        if not devices:
            raise RuntimeError("runtime discovery selected no block devices")
        predicate = " || ".join(f"args->dev == {device}" for device in devices)
        self.shm_dir.mkdir(parents=True, exist_ok=True)
        target = self.shm_dir / "blk.generated.bt"
        target.write_text(source.replace("__OPBENCH_DEVICE_FILTER__", predicate))
        return target

    def write_manifest(self) -> Path:
        path = self.out_dir / "run_manifest.json"
        payload = {
            "schema": "opbench/1",
            "run_id": self.run_id,
            "io_boundary": "guest_logical",
            "aenv_home": self.runtime.aenv_home,
            "aenv_uid": self.runtime.aenv_uid,
            "devices": {"logical": self.runtime.logical_devices,
                        "ublk": self.runtime.ublk_devices},
            "bpftrace_command": list(self.runtime.bpftrace_command),
            "collector_health": self.health(),
        }
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return path

    def start(self, warmup_s: float = 1.5) -> None:
        self.pid_set = pids_of_uid()
        self.shm_dir.mkdir(parents=True, exist_ok=True)
        self.write_manifest()
        generated_blk = self.materialize_block_script()
        for name, script in (("blk", generated_blk), ("vfs", self.bpf_dir / "vfs.bt")):
            fh = open(self._bt_files[name], "w", buffering=1)
            p = subprocess.Popen([*self.runtime.bpftrace_command, str(script)],
                                 stdout=fh, stderr=subprocess.STDOUT)
            p._log_fh = fh  # type: ignore[attr-defined]
            self.procs[name] = p
        time.sleep(warmup_s)
        health = self.health()
        if not health["healthy"]:
            self.stop()
            raise RuntimeError(f"bpftrace probe startup failed: {health['failed_probes']}")
        self.sampler = HostSampler(self.out_dir / "proc_sample.csv", sorted(self.pid_set))
        self.sampler.start()

    def phase(self, phase_id: str, name: str) -> "PhaseCtx":
        return PhaseCtx(self, phase_id, name)

    def begin_phase(self, phase_id: str, name: str) -> Phase:
        ph = Phase(phase_id=phase_id, phase_name=name, start_ns=mono_ns())
        self.phases.append(ph)
        return ph

    def end_phase(self, ph: Phase, status: str = "ok", error: str = "") -> None:
        ph.close(status, error)

    def refresh_pid_set(self) -> list[int]:
        new = sorted(set(pids_of_uid()) - set(self.pid_set))
        self.pid_set = sorted(set(self.pid_set) | set(new))
        return new

    def stop(self) -> None:
        self.health()
        for name, p in self.procs.items():
            try:
                p.send_signal(signal.SIGINT)
                p.wait(timeout=5)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass
            try:
                p._log_fh.close()  # type: ignore[attr-defined]
            except Exception:
                pass
        self.procs.clear()
        if self.sampler:
            self.sampler.stop()
            self.sampler = None
        import shutil
        for name, src in self._bt_files.items():
            if src.exists():
                shutil.copy(src, self.out_dir / f"{name}.log")
        self.write_manifest()

    def write_phase_summary(self, operation: str) -> None:
        with open(self.out_dir / "phase_summary.csv", "w", newline="") as f:
            f.write("run_id,operation,phase_id,phase_name,start_mono_ns,end_mono_ns,"
                    "duration_ms,status,error\n")
            for ph in self.phases:
                f.write(",".join(str(x) for x in [
                    self.run_id, operation, ph.phase_id, ph.phase_name,
                    ph.start_ns, ph.end_ns, round(ph.duration_ms, 3),
                    ph.status, ph.error]) + "\n")


def append_results_json(out_root: str | Path, entry: dict) -> None:
    """SOP 步骤12：append + 全量重写 results.json（崩溃不丢已完成数据）。

    结构 {schema: 'opbench/1', entries: [...]}；按 run_id 去重（重跑覆盖）。
    坏数据不删除（§1.5.7）——valid=False 的条目保留，聚合端按 valid 过滤。
    """
    out_root = Path(out_root)
    path = out_root / "results.json"
    data = {"schema": "opbench/1", "entries": []}
    if path.exists():
        try:
            loaded = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(loaded, dict) and isinstance(loaded.get("entries"), list):
                data = loaded
            elif isinstance(loaded, list):
                data["entries"] = loaded
        except json.JSONDecodeError:
            data["corrupt_backup"] = True
    rid = entry.get("run_id")
    if rid:
        data["entries"] = [e for e in data["entries"] if e.get("run_id") != rid]
    data["entries"].append(entry)
    out_root.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, default=str)


class PhaseCtx:
    def __init__(self, c: Collector, phase_id: str, name: str):
        self.c, self.phase_id, self.name = c, phase_id, name

    def __enter__(self) -> Phase:
        self.ph = self.c.begin_phase(self.phase_id, self.name)
        return self.ph

    def __exit__(self, exc_type, exc, tb):
        if exc_type:
            self.c.end_phase(self.ph, "error", str(exc)[:200])
        else:
            self.c.end_phase(self.ph)
        return False
