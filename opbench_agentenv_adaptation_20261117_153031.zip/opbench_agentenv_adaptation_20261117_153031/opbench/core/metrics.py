"""指标计算 —— 规范 §1.3 全部公式的唯一实现。

口径（§1.3 口径三原则）：
- 量用 blk 层（read_MB/write_MB/iops/peak）；
- pause/checkpoint 的提交写另报 vfs_commit_bytes（含文件名归因）；
- 阶段/相位时延只由锚点差计算。

输入：
- blk.log / vfs.log（Collector 产物）；
- proc_sample.csv（HostSampler 产物）；
- phase_summary.csv（相位边界）；
- 锚点切分（ops 层给出 stage_windows: [{stage_id, start_ns, end_ns, ...}]）。
"""
from __future__ import annotations

import csv
import math
from collections import defaultdict, deque
from dataclasses import dataclass, field
from pathlib import Path

MB = 1 << 20
KB = 1 << 10


# ── 日志解析 ────────────────────────────────────────────────────────

def parse_blk_log(path: str | Path) -> list[dict]:
    """解析 blk.log：I|ts|dev|bytes|rwbs|comm|pid（完成口径事件含 I 与 C，
    计量用 I 行的 bytes；C 行用于时延对账，这里都保留）。"""
    out = []
    p = Path(path)
    if not p.exists():
        return out
    for line in p.read_text().splitlines():
        parts = line.split("|")
        if not parts:
            continue
        kind = parts[0]
        if kind == "I" and len(parts) >= 7:
            enriched = len(parts) >= 9
            if enriched:
                ts, dev, sector, nr_sector, nbytes, rwbs, comm, pid = parts[1:9]
            else:
                ts, dev, nbytes, rwbs, comm, pid = parts[1:7]
            try:
                out.append({"kind": "I", "ts": int(ts), "dev": int(dev),
                            "bytes": int(nbytes), "rwbs": rwbs,
                            "comm": comm, "pid": int(pid),
                            **({"sector": int(sector), "nr_sector": int(nr_sector)} if enriched else {})})
            except ValueError:
                continue
        elif kind == "C" and len(parts) >= 8:
            ts, dev, sector, nr_sector, rwbs, error, pid = parts[1:8]
            try:
                out.append({"kind": "C", "ts": int(ts), "dev": int(dev),
                            "sector": int(sector), "nr_sector": int(nr_sector),
                            "rwbs": rwbs, "error": int(error), "pid": int(pid)})
            except ValueError:
                continue
    return out


def parse_vfs_log(path: str | Path) -> list[dict]:
    r"""解析 vfs.log：R/W|ts|pid|comm|req_bytes|ino|name；S|ts|pid|comm|op|ino|name；
    O/U/M 类似。只保留可计量的 R/W/S 行 + 锚点用的 O 行。"""
    out = []
    p = Path(path)
    if not p.exists():
        return out
    for line in p.read_text().splitlines():
        parts = line.split("|")
        if not parts:
            continue
        kind = parts[0]
        try:
            if kind in ("R", "W") and len(parts) >= 7:
                out.append({"kind": kind, "ts": int(parts[1]), "pid": int(parts[2]),
                            "comm": parts[3], "bytes": int(parts[4]),
                            "ino": int(parts[5]), "name": parts[6]})
            elif kind == "S" and len(parts) >= 7:
                out.append({"kind": "S", "ts": int(parts[1]), "pid": int(parts[2]),
                            "comm": parts[3], "op": parts[4],
                            "ino": int(parts[5]), "name": parts[6]})
            elif kind == "O" and len(parts) >= 6:
                out.append({"kind": "O", "ts": int(parts[1]), "pid": int(parts[2]),
                            "comm": parts[3], "flags": parts[4], "ino": parts[5],
                            "name": parts[6] if len(parts) > 6 else ""})
        except ValueError:
            continue
    return out


# ── blk 层指标（量唯一口径，仅物理 nvme 双盘）────────────────────────

PHYS_DEV_FILTER = ("nvme",)


@dataclass
class IOStats:
    read_MB: float = 0.0
    write_MB: float = 0.0
    read_MB_by_dev: dict = field(default_factory=dict)
    write_MB_by_dev: dict = field(default_factory=dict)
    iops_r: float = 0.0
    iops_w: float = 0.0
    mb_s_mean_r: float = 0.0
    mb_s_mean_w: float = 0.0
    mb_s_peak_r: float = 0.0
    mb_s_peak_w: float = 0.0
    iops_peak_r: float = 0.0
    iops_peak_w: float = 0.0
    event_count_r: int = 0
    event_count_w: int = 0
    duration_s: float = 0.0
    # 请求大小分布（4K/32K/128K/512K/1M+ 五桶）：连接"字节量→IOPS"的钥匙，
    # 负载合成时用于把字节数换算成设备无关的请求流
    reqsize_hist_r: dict = field(default_factory=dict)
    reqsize_hist_w: dict = field(default_factory=dict)
    latency_count_r: int = 0
    latency_count_w: int = 0
    latency_us_p50_r: float | None = None
    latency_us_p50_w: float | None = None
    latency_us_p95_r: float | None = None
    latency_us_p95_w: float | None = None
    latency_us_p99_r: float | None = None
    latency_us_p99_w: float | None = None
    unmatched_completions: int = 0

    def to_dict(self) -> dict:
        return {
            "read_MB": round(self.read_MB, 3),
            "write_MB": round(self.write_MB, 3),
            "read_MB_by_dev": {k: round(v, 3) for k, v in self.read_MB_by_dev.items()},
            "write_MB_by_dev": {k: round(v, 3) for k, v in self.write_MB_by_dev.items()},
            "iops_r": round(self.iops_r, 1),
            "iops_w": round(self.iops_w, 1),
            "mb_s_mean_r": round(self.mb_s_mean_r, 3),
            "mb_s_mean_w": round(self.mb_s_mean_w, 3),
            "mb_s_peak_r": round(self.mb_s_peak_r, 3),
            "mb_s_peak_w": round(self.mb_s_peak_w, 3),
            "iops_peak_r": round(self.iops_peak_r, 1),
            "iops_peak_w": round(self.iops_peak_w, 1),
            "event_count_r": self.event_count_r,
            "event_count_w": self.event_count_w,
            "reqsize_hist_r": self.reqsize_hist_r,
            "reqsize_hist_w": self.reqsize_hist_w,
            "duration_s": round(self.duration_s, 6),
            "latency_count_r": self.latency_count_r,
            "latency_count_w": self.latency_count_w,
            "latency_us_p50_r": self.latency_us_p50_r,
            "latency_us_p50_w": self.latency_us_p50_w,
            "latency_us_p95_r": self.latency_us_p95_r,
            "latency_us_p95_w": self.latency_us_p95_w,
            "latency_us_p99_r": self.latency_us_p99_r,
            "latency_us_p99_w": self.latency_us_p99_w,
            "unmatched_completions": self.unmatched_completions,
        }


def _is_read(rwbs: str) -> bool:
    return rwbs.startswith("R") or rwbs.startswith("RM")


def _is_write(rwbs: str) -> bool:
    return rwbs.startswith("W") or rwbs.startswith("WM")


# 请求大小直方图桶边界（字节）：<=4K, <=32K, <=128K, <=512K, >512K
REQSIZE_BUCKETS = (4 * KB, 32 * KB, 128 * KB, 512 * KB)


def _reqsize_key(nbytes: int) -> str:
    for i, lim in enumerate(REQSIZE_BUCKETS):
        if nbytes <= lim:
            return ("4K", "32K", "128K", "512K")[i]
    return "1M+"


def io_stats(events: list[dict], start_ns: int, end_ns: int) -> IOStats:
    """窗口内 blk 层统计（§1.3 read/write/iops/mean/peak 公式）。

    events 须先经 PHYS_DEV_FILTER 过滤（blk.bt 已只采集物理盘 + dm，
    这里按 dev 名过滤在调用端完成；此函数信任输入）。
    """
    st = IOStats(duration_s=max((end_ns - start_ns) / 1e9, 1e-9))
    buckets_r: dict[int, int] = defaultdict(int)
    buckets_w: dict[int, int] = defaultdict(int)
    buckets_r_cnt: dict[int, int] = defaultdict(int)
    buckets_w_cnt: dict[int, int] = defaultdict(int)
    pending: dict[tuple, deque] = defaultdict(deque)
    latencies_r, latencies_w = [], []
    for e in sorted(events, key=lambda event: event["ts"]):
        if not (start_ns <= e["ts"] < end_ns):
            continue
        if e["kind"] == "C":
            key = (e["dev"], e.get("sector"), e.get("nr_sector"), e["rwbs"])
            if pending[key]:
                issued = pending[key].popleft()
                latency_us = (e["ts"] - issued["ts"]) / 1000
                (latencies_r if _is_read(e["rwbs"]) else latencies_w).append(latency_us)
            else:
                st.unmatched_completions += 1
            continue
        if e["kind"] != "I":
            continue
        if "sector" in e and "nr_sector" in e:
            pending[(e["dev"], e["sector"], e["nr_sector"], e["rwbs"])].append(e)
        b = int(e["ts"] // 10_000_000)  # 10ms 桶，绝对时间对齐（与窗口起点无关）：跨窗口峰值可对账
        if _is_read(e["rwbs"]):
            st.read_MB += e["bytes"]
            st.read_MB_by_dev[e["dev"]] = st.read_MB_by_dev.get(e["dev"], 0) + e["bytes"]
            st.event_count_r += 1
            buckets_r[b] += e["bytes"]
            buckets_r_cnt[b] += 1
            k = _reqsize_key(e["bytes"])
            st.reqsize_hist_r[k] = st.reqsize_hist_r.get(k, 0) + 1
        elif _is_write(e["rwbs"]):
            st.write_MB += e["bytes"]
            st.write_MB_by_dev[e["dev"]] = st.write_MB_by_dev.get(e["dev"], 0) + e["bytes"]
            st.event_count_w += 1
            buckets_w[b] += e["bytes"]
            buckets_w_cnt[b] += 1
            k = _reqsize_key(e["bytes"])
            st.reqsize_hist_w[k] = st.reqsize_hist_w.get(k, 0) + 1
    st.read_MB /= MB
    st.write_MB /= MB
    st.read_MB_by_dev = {k: v / MB for k, v in st.read_MB_by_dev.items()}
    st.write_MB_by_dev = {k: v / MB for k, v in st.write_MB_by_dev.items()}
    st.iops_r = st.event_count_r / st.duration_s
    st.iops_w = st.event_count_w / st.duration_s
    st.mb_s_mean_r = st.read_MB / st.duration_s
    st.mb_s_mean_w = st.write_MB / st.duration_s
    st.mb_s_peak_r = (max(buckets_r.values(), default=0) * 100) / MB
    st.mb_s_peak_w = (max(buckets_w.values(), default=0) * 100) / MB
    # IOPS 峰值：10ms 桶内事件数最大值 × 100（折算每秒）
    st.iops_peak_r = max(buckets_r_cnt.values(), default=0) * 100
    st.iops_peak_w = max(buckets_w_cnt.values(), default=0) * 100
    def percentile(values: list[float], p: float) -> float:
        return values[max(0, math.ceil(p * len(values)) - 1)]

    if latencies_r:
        latencies_r.sort()
        st.latency_count_r = len(latencies_r)
        st.latency_us_p50_r = percentile(latencies_r, .50)
        st.latency_us_p95_r = percentile(latencies_r, .95)
        st.latency_us_p99_r = percentile(latencies_r, .99)
    if latencies_w:
        latencies_w.sort()
        st.latency_count_w = len(latencies_w)
        st.latency_us_p50_w = percentile(latencies_w, .50)
        st.latency_us_p95_w = percentile(latencies_w, .95)
        st.latency_us_p99_w = percentile(latencies_w, .99)
    return st


# ── vfs 层指标（commit 写归因 / fsync 计数）────────────────────────

VFS_GROUPS = {
    "overlaybd.commit.tmp": "commit_tmp",
    "overlaybd.commit": "chain_commit",
    "vm_state.bin": "vm_state",
    "mem_image.json": "mem_image",
    "upper.data": "upper_data",
    "upper.index": "upper_index",
    "image.json": "image_json",
    "image.json.tmp": "image_json_tmp",
}


def group_of(name: str) -> str:
    base = Path(name).name
    for k, g in VFS_GROUPS.items():
        if base == k:
            return g
    return "other"


def vfs_commit_bytes(events: list[dict], start_ns: int, end_ns: int) -> dict:
    """窗口内 vfs W 事件按文件分组求和（§1.3 vfs_commit_bytes）。"""
    out: dict[str, int] = defaultdict(int)
    total = 0
    for e in events:
        if e["kind"] == "W" and start_ns <= e["ts"] < end_ns:
            g = group_of(e["name"])
            out[g] += e["bytes"]
            total += e["bytes"]
    return {"total_bytes": total,
            "groups": dict(sorted(out.items(), key=lambda kv: -kv[1]))}


def fsync_count(events: list[dict], start_ns: int, end_ns: int) -> dict:
    """窗口内 S 行（fsync/fdatasync）计数与文件归属。"""
    out: dict[str, int] = defaultdict(int)
    n = 0
    for e in events:
        if e["kind"] == "S" and start_ns <= e["ts"] < end_ns:
            g = group_of(e["name"])
            out[g] += 1
            n += 1
    return {"count": n, "groups": dict(out)}


# ── proc 层指标（CPU/RSS/Dirty）────────────────────────────────────

def parse_proc_sample(path: str | Path) -> list[dict]:
    rows = []
    with open(path, newline="") as f:
        for r in csv.DictReader(f):
            try:
                rows.append({
                    "ts": int(r["ts_ns"]), "pid": int(r["pid"]), "comm": r["comm"],
                    "cpu_pct": float(r["cpu_pct"]), "rss_kb": int(r["rss_kb"]),
                    "host_cpu_busy_pct": float(r["host_cpu_busy_pct"]),
                    "cached_kb": int(r["cached_kb"]), "dirty_kb": int(r["dirty_kb"]),
                })
            except (ValueError, KeyError):
                continue
    return rows


def proc_stats(rows: list[dict], start_ns: int, end_ns: int) -> dict:
    """窗口内进程组 CPU%/RSS（求和口径）+ Cached/Dirty 均/末值。"""
    by_ts: dict[int, dict] = defaultdict(lambda: {"cpu": 0.0, "rss_max": 0})
    cached, dirty, host = [], [], []
    for r in rows:
        if not (start_ns <= r["ts"] < end_ns):
            continue
        by_ts[r["ts"]]["cpu"] += r["cpu_pct"]
        by_ts[r["ts"]]["rss_max"] += r["rss_kb"]
        if not cached:  # 每采样 tick 全机列重复，取首行
            pass
    # 全机列：同 ts 只取一次
    seen_ts = set()
    for r in rows:
        if not (start_ns <= r["ts"] < end_ns) or r["ts"] in seen_ts:
            continue
        seen_ts.add(r["ts"])
        cached.append(r["cached_kb"])
        dirty.append(r["dirty_kb"])
        host.append(r["host_cpu_busy_pct"])
    cpus = [v["cpu"] for v in by_ts.values()]
    rss = [v["rss_max"] for v in by_ts.values()]
    return {
        "cpu_pct": round(sum(cpus) / len(cpus), 1) if cpus else 0.0,
        "cpu_peak": round(max(cpus), 1) if cpus else 0.0,
        "rss_kb_mean": round(sum(rss) / len(rss)) if rss else 0,
        "rss_kb_max": max(rss) if rss else 0,
        "host_cpu_busy_pct_mean": round(sum(host) / len(host), 1) if host else 0.0,
        "cached_kb_mean": round(sum(cached) / len(cached)) if cached else 0,
        "cached_kb_start": cached[0] if cached else 0,
        "cached_kb_end": cached[-1] if cached else 0,
        "dirty_kb_mean": round(sum(dirty) / len(dirty)) if dirty else 0,
        "dirty_kb_end": dirty[-1] if dirty else 0,
        "sample_ticks": len(cpus),
    }


def dirty_drain_ms(rows: list[dict], api_end_ns: int, tail_end_ns: int,
                   baseline_dirty_kb: int, tolerance_kb: int = 5 * 1024) -> dict:
    """§1.3 dirty_drain_ms：Dirty 回落到 BASE 基线±tolerance 的首个采样点。"""
    seen_ts = set()
    first_ts = None
    last_dirty = None
    for r in rows:
        if not (api_end_ns <= r["ts"] <= tail_end_ns) or r["ts"] in seen_ts:
            continue
        seen_ts.add(r["ts"])
        if first_ts is None and abs(r["dirty_kb"] - baseline_dirty_kb) <= tolerance_kb:
            first_ts = r["ts"]
        last_dirty = r["dirty_kb"]
    if first_ts is not None:
        return {"dirty_drain_ms": round((first_ts - api_end_ns) / 1e6, 1),
                "drained": True, "residual_dirty_kb": last_dirty}
    return {"dirty_drain_ms": None, "drained": False,
            "residual_dirty_kb": last_dirty}


# ── 相位聚合 ────────────────────────────────────────────────────────

def phase_metrics(out_dir: str | Path, phases: list[dict]) -> dict:
    """按相位（BASE/API/TAIL）汇总 §1.3 全部指标。
    phases: [{phase_id, phase_name, start_mono_ns, end_mono_ns, ...}]
    返回 {phase_id: {io, vfs_commit, fsync, proc}}"""
    out_dir = Path(out_dir)
    blk = parse_blk_log(out_dir / "blk.log")
    vfs = parse_vfs_log(out_dir / "vfs.log")
    sample_path = out_dir / "proc_sample.csv"
    rows = parse_proc_sample(sample_path) if sample_path.exists() else []
    result = {}
    for ph in phases:
        s, e = ph["start_mono_ns"], ph["end_mono_ns"]
        if e <= s:
            continue
        result[ph["phase_id"]] = {
            "phase_name": ph["phase_name"],
            "duration_ms": round((e - s) / 1e6, 3),
            "io": io_stats(blk, s, e).to_dict(),
            "vfs_commit": vfs_commit_bytes(vfs, s, e),
            "fsync": fsync_count(vfs, s, e),
            "proc": proc_stats(rows, s, e),
        }
    return result


def stage_metrics(out_dir: str | Path, stage_windows: list[dict],
                  sample_rows: list[dict] | None = None) -> dict:
    """按 §2 的阶段窗口（锚点差切分）计算指标。
    stage_windows: [{stage_id, stage_name, start_ns, end_ns, anchor: {start, end, precision}}]
    """
    out_dir = Path(out_dir)
    blk = parse_blk_log(out_dir / "blk.log")
    vfs = parse_vfs_log(out_dir / "vfs.log")
    if sample_rows is None:
        sp = out_dir / "proc_sample.csv"
        sample_rows = parse_proc_sample(sp) if sp.exists() else []
    result = {}
    for w in stage_windows:
        s, e = w["start_ns"], w["end_ns"]
        entry = {
            "stage_name": w.get("stage_name", w["stage_id"]),
            "anchor": w.get("anchor", {}),
            "boundary_source": w.get("boundary_source", {}),
        }
        if e > s:
            entry["duration_ms"] = round((e - s) / 1e6, 3)
            entry["io"] = io_stats(blk, s, e).to_dict()
            entry["vfs_commit"] = vfs_commit_bytes(vfs, s, e)
            entry["fsync"] = fsync_count(vfs, s, e)
            entry["proc"] = proc_stats(sample_rows, s, e)
        else:
            entry["duration_ms"] = 0.0
        result[w["stage_id"]] = entry
    return result
