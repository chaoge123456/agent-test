"""冷缓存构造（cold 臂三步，v4 §1.4）。

陷阱（实测曾中招）：drop_caches 只回收干净页，清不掉未落盘脏页。
若前一测量的写回未完成（如 pause 的 commit.tmp 脏页），drop 后链读
直接命中残留缓存，cold 臂实际半热。因此固定三步：

    1. sync                      （触发全部脏页 writeback）
    2. 轮询 Dirty 回落空载基线    （确认落盘完成）
    3. echo 3 > drop_caches      （立即进入测量）
"""
from __future__ import annotations

import time


def _dirty_kb() -> int:
    for line in open("/proc/meminfo"):
        if line.startswith("Dirty:"):
            return int(line.split()[1])
    return 0


def idle_dirty_kb() -> int:
    """空载基线 Dirty（当前瞬时值——调用方应在无业务写时取）。"""
    return _dirty_kb()


def make_cold(sync_timeout_s: float = 120.0, settle_s: float = 30.0,
              poll_interval_s: float = 0.5, verbose: bool = True) -> dict:
    """cold 臂三步构造。返回打点信息。

    settle_s: Dirty 归零等待上限——超过则带着残留继续（记录 residual）。
    """
    t0 = time.monotonic()
    base_dirty = _dirty_kb()
    # 1. sync
    import subprocess
    subprocess.run(["sync"], check=False)
    # 2. 等 Dirty 回落
    target = max(base_dirty, 0)
    deadline = time.monotonic() + settle_s
    synced_dirty = _dirty_kb()
    while time.monotonic() < deadline and synced_dirty > target + 1024:  # +1MB 容差
        time.sleep(poll_interval_s)
        synced_dirty = _dirty_kb()
    # 实际等待逻辑：sync 后 Dirty 应回落到接近 0；若仍高则等满 settle_s
    deadline = time.monotonic() + settle_s
    while time.monotonic() < deadline and synced_dirty > 2048:
        time.sleep(poll_interval_s)
        synced_dirty = _dirty_kb()
    residual_kb = synced_dirty
    # 3. drop_caches
    with open("/proc/sys/vm/drop_caches", "w") as f:
        f.write("3\n")
    after_kb = _dirty_kb()
    info = {
        "pre_sync_dirty_kb": base_dirty,
        "post_sync_dirty_kb": residual_kb,
        "post_drop_dirty_kb": after_kb,
        "dirty_settled": residual_kb <= 2048,
        "elapsed_ms": round((time.monotonic() - t0) * 1000, 1),
    }
    if verbose:
        print(f"[cold] pre={base_dirty}KB sync后={residual_kb}KB drop后={after_kb}KB "
              f"({info['elapsed_ms']}ms settled={info['dirty_settled']})", flush=True)
    return info