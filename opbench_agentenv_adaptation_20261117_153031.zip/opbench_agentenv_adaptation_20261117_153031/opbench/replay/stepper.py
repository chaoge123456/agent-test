"""轨迹步进器 —— "任意轨迹的任意步骤"状态构造（规范 §1.4）。

语义（用户定义）：沙箱内轨迹按计划从前往后执行到指定步骤，基于该步骤
当前的环境信息和沙箱状态测试对应操作。

轨迹源事实（tracebench/config.py）：TRACES_ROOT=<project>/data，
全部轨迹按行存于 selected_200_replay.jsonl（非每轨迹一文件），
每行 {instance_id, messages, ...}。

实现方式：复用远程 aenv_tracekit.single_replay（PYTHONPATH=code）：
    python3 -m aenv_tracekit.single_replay <instance_id> \
        --max-steps <N> --keep --ttl <ttl>

关键事实（规范 §1.4）：
- 总步数 = 轨迹 jsonl 中 messages 里 tool_calls 计数；
  禁止用探测报告的 replay.total_steps（会被 --max-steps 截断污染）。
"""
from __future__ import annotations

import json
import os
import subprocess
import tempfile
from pathlib import Path

from opbench.core import cli as aenv_cli

TRACEKIT_ROOT = "/mnt/old_home/yfc/aenv_storage_test/code"
REPLAY_JSONL = "selected_200_replay.jsonl"


def _find_trace_obj(trace_dir: str | Path, trace_id: str) -> dict:
    """在 selected_200_replay.jsonl 中按 instance_id 匹配轨迹行。"""
    path = Path(trace_dir) / REPLAY_JSONL
    if not path.exists():
        raise FileNotFoundError(f"trace jsonl not found: {path}")
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            if obj.get("instance_id") == trace_id:
                return obj
    raise LookupError(f"instance_id {trace_id!r} not found in {path}")


def total_tool_calls(trace_obj: dict) -> int:
    """轨迹总步数 = messages 里 tool_calls 计数（§1.4 唯一口径）。"""
    return sum(len(m.get("tool_calls") or [])
               for m in trace_obj.get("messages") or [])


def steps_for_pct(total: int, pct: int) -> int:
    return round(total * pct / 100)


class Stepper:
    """轨迹步进：构建/推进沙箱到指定步骤。"""

    def __init__(self, trace_id: str, trace_dir: str | Path,
                 code_root: str = TRACEKIT_ROOT):
        self.trace_id = trace_id
        self.trace_obj = _find_trace_obj(trace_dir, trace_id)
        self.total_steps = total_tool_calls(self.trace_obj)
        self.code_root = code_root

    def replay_to(self, step: int, ttl: int = 3600, timeout: int = 7200,
                  quiet: bool = True) -> dict:
        """重放轨迹前 step 步并保留沙箱。返回 {sandbox_id, report, rc}。"""
        cmd = ["python3", "-m", "aenv_tracekit.single_replay", self.trace_id,
               "--max-steps", str(step), "--keep", "--ttl", str(ttl)]
        if quiet:
            cmd.append("--quiet")
        env = dict(os.environ)
        env["PYTHONPATH"] = self.code_root
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                           env=env)
        # 报告落点：stdout 的 "[5/5] Report saved: <path>"（run/single_replay/<id>_<ts>.json）
        report_path = ""
        for line in p.stdout.splitlines():
            if "Report saved:" in line:
                report_path = line.split("Report saved:", 1)[1].strip()
                break
        report = {}
        if report_path:
            try:
                report = json.loads(Path(report_path).read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                report = {}
        sid = (report.get("env_load") or {}).get("sandbox_id") or ""
        if p.returncode != 0 or not sid:
            raise RuntimeError(
                f"single_replay rc={p.returncode} sid={sid!r}\n"
                f"stdout_tail={p.stdout[-1500:]}\nstderr_tail={p.stderr[-1500:]}")
        return {"sandbox_id": sid, "report": report,
                "steps_executed": step, "rc": p.returncode}

    # ── 状态指纹（§3.1 步骤②）────────────────────────────────────

    def state_fingerprint(self, sid: str) -> dict:
        """aenv exec free -m + du -sm /workspace —— 沙箱状态指纹。"""
        rc, out, _ = aenv_cli.exec_in_sandbox(sid, "free -m | sed -n '2p'; du -sm /workspace 2>/dev/null | tail -1", timeout=60)
        info = {"rc": rc, "raw": out.strip()}
        lines = [l for l in out.strip().splitlines() if l.strip()]
        if lines and lines[0].split()[0] == "Mem:":
            parts = lines[0].split()
            info["guest_total_mb"] = int(parts[1])
            info["guest_used_mb"] = int(parts[2])
            info["guest_cached_mb"] = int(parts[5]) if len(parts) > 5 else int(parts[4])
        if len(lines) > 1:
            try:
                info["workspace_mb"] = int(lines[1].split()[0])
            except (ValueError, IndexError):
                pass
        return info