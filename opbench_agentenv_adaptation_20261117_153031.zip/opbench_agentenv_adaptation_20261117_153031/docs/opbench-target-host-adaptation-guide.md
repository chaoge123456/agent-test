# opbench 目标机器适配说明

## 1. 目的与边界

本文说明如何将当前开发验证版 `opbench` 从 Hyper-V VM 迁移到正式目标机器，并将其改造成可用于真实轨迹实验的存储 I/O 采集工具。

当前开发环境的结论仅证明：HTTP 生命周期调用、BPF collector、逻辑块层指标、合成 workload 链路和清理路径能够工作。它**不能**代表目标机器的物理 SSD/NVMe 性能、带宽、IOPS 或容量成本。

正式目标是同时回答：

1. AgentENV 操作在 guest/逻辑存储层产生什么 I/O；
2. 宿主实际目标设备承担什么 I/O；
3. 操作成本如何被轨迹状态、脏页、rootfs 改写、镜像缓存和快照链解释；
4. API 返回后是否仍有异步写回、延迟缺页或 CoW。

## 2. 当前实现与目标环境的关键差异

| 项目 | 当前开发 VM | 正式目标机适配要求 |
|---|---|---|
| CPU/虚拟化 | Hyper-V guest，x86_64 | Ubuntu 24.04 aarch64/KVM，确认内核、KVM、Firecracker 版本 |
| 存储 | 单一 `/dev/sda` 虚拟盘 | 记录真实 NVMe/SSD/HDD、分区、文件系统、挂载参数和镜像所在设备 |
| I/O 口径 | guest logical `sda` 与 ublk | 同时采集 guest logical、AgentENV/ublk、宿主物理目标块设备 |
| API | AgentENV 0.2.5，本地 HTTP | 确认 OpenAPI 路由、响应 JSON、鉴权方式和 timeout 语义 |
| 阶段边界 | API/TAIL 可直接观测；内部阶段为 inferred | AgentENV 内部必须输出 phase marker，获得 direct 阶段边界 |
| 工作负载 | idle/code/data 合成 profile | 87 条真实轨迹重放、状态指纹、不同 step/缓存条件的重复试验 |

## 3. 迁移前必须完成的环境盘点

在安装或运行 opbench 前，保存每次实验批次的环境清单。建议写入 `environment.json`，并复制到每个 run 根目录。

```bash
uname -a
uname -m
aenv --version
firecracker --version
systemctl cat aenv
findmnt -T /var/lib/aenv -o SOURCE,TARGET,FSTYPE,OPTIONS
lsblk -o NAME,MAJ:MIN,TYPE,SIZE,MODEL,SERIAL,FSTYPE,MOUNTPOINTS
cat /proc/mounts
df -h /var/lib/aenv
cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null || true
```

必须明确以下映射，不能沿用当前 VM 的 `sda`、`ublkb*` 或设备号：

```text
AgentENV home / snapshot-store / persisted-sandboxes / image-cache
    ↓ 所在文件系统及挂载源
目标块设备或 dm/LVM/RAID 设备
    ↓ 下层物理设备
NVMe/SSD/HDD 实体盘
```

若 AgentENV 文件跨多个文件系统，必须为每条路径单独记录目标设备；不要把多个设备的 I/O 混成一个“存储成本”。

## 4. 运行时设备发现与权限

`opbench/core/runtime.py` 会从 `/var/lib/aenv` 的挂载源推导块设备，并扫描 `/sys/class/block`。迁移时验证：

1. `/var/lib/aenv` 是否仍为真实 AgentENV home；必要时新增显式环境变量覆盖，而不是修改代码中的常量。
2. 分区到父设备的归一化是否正确，例如 `nvme0n1p1 → nvme0n1`、`sda1 → sda`。
3. OverlayBD/ublk 设备是否存在，并是否应作为独立逻辑层保留。
4. `aenv` 服务实际 UID 是否仍为 `999`；VFS probe 当前按 UID 过滤，错误 UID 会导致漏采。
5. `sudo -n bpftrace` 与 `sudo -n du` 是否无交互可用。若生产机器不允许免密 sudo，应创建最小权限 sudoers 规则，只放行固定 bpftrace/du 命令。

不要用旧脚本中的静态 NVMe major:minor、旧 `/mnt/old_home` 路径或当前 VM 的 `sda` 结论。

## 5. 双层 I/O 采集设计

### 5.1 guest/逻辑层

保留现有 `blk.bt`、`vfs.bt` 和 `/proc/<pid>/io`：

- block issue/complete：字节、请求数、请求大小、平均/峰值带宽、IOPS、完成延迟；
- VFS：文件活动、commit/writeback 线索、fsync；
- proc sampler：CPU、RSS、Cached、Dirty；
- API/TAIL 时间窗口：区分同步返回与后台活动。

输出必须标注：`io_boundary=guest_logical`。

### 5.2 宿主物理层

新增独立 collector，只过滤承载 AgentENV 数据路径的实际设备。建议同时记录：

- `block:block_rq_issue`、`block:block_rq_complete`；
- `/proc/diskstats` 前后差分，作为 BPF 总量交叉核对；
- 设备队列深度、util、await 或等价指标；
- 若经过 dm-crypt、LVM、RAID、网络块设备，分别保留上/下层设备视图。

宿主 collector 的 run id、操作 id、单调时钟基准必须能与 guest collector 对齐。若不能共享 monotonic clock，应在 API 前后记录双方时间戳并保存偏移/误差。

## 6. 内部阶段 marker：正式阶段划分的前提

当前没有 AgentENV 内部 marker，因此 opbench 会把阶段质量标为：

```json
{"quality":"inferred","marker_count":0}
```

目标机适配时，应在 AgentENV 服务内部为每个 lifecycle request 写 JSONL marker。每条记录至少包括：

```json
{
  "op_id": "opbench-run-id",
  "operation": "start|pause|resume|checkpoint_snapshot|fork_native",
  "phase": "storage_attach",
  "event": "begin|end",
  "ts_ns": 123456789,
  "sandbox_id": "...",
  "child_id": "..."
}
```

推荐 marker 文件：`<run>/phase_markers.jsonl`。当前 `opbench/core/markers.py` 读取该文件，并按 `op_id` 过滤；无关、损坏行会忽略。

### marker 名称契约

| 操作 | 必需 marker（按顺序） |
|---|---|
| start from snapshot | `storage_attach` → `state_restore` → `vcpu_activate` |
| pause | `vcpu_quiesced` → `vm_state_exported` → `snapshot_durable` |
| resume | `storage_attach` → `state_restore` → `vcpu_activate` |
| checkpoint snapshot | `capture_begin` → `vm_state_exported` → `snapshot_durable` |
| native fork | `source_capture_done` → `child_storage_begin` → `child_restore_begin` → `all_children_ready` |

每个 marker 必须写入单调时钟 `ts_ns`。若 marker 缺失或乱序，opbench 会标为 `degraded`；不要以这种 run 生成正式阶段分布。

对于 `fork(count>1)`，每个 child 的装配、恢复和 ready marker 必须带 `child_id`。汇总指标和每 child 指标应同时保存，避免较慢 child 被平均值隐藏。

## 7. HTTP API 与凭据适配

生命周期操作应始终通过 `AgentEnvApi`：

| 操作 | 路由 |
|---|---|
| snapshot start | `POST /sandboxes` |
| cold start | `POST /sandboxes-cold` |
| pause | `POST /sandboxes/{id}/pause` |
| resume | `POST /sandboxes/{id}/resume` |
| checkpoint | `POST /sandboxes/{id}/snapshots` |
| native fork | `POST /sandboxes/{id}/fork` |
| delete | `DELETE /sandboxes/{id}` |

迁移时用目标 AgentENV 的 OpenAPI 文件逐项核对请求/响应字段。不得把 API key 写入代码、报告、run manifest、命令输出或 Git；运行时只通过明确环境变量 `AENV_API_KEY` 提供。

CLI 可用于非测量动作，例如真实轨迹重放、sandbox 内 workload 注入、文件指纹验证。但不要在受测 API 窗口中以 CLI 替代 lifecycle API。

## 8. 真实轨迹适配

当前 `Stepper` 仍包含开发机遗留路径：

```python
TRACEKIT_ROOT = "/mnt/old_home/yfc/aenv_storage_test/code"
REPLAY_JSONL = "selected_200_replay.jsonl"
```

目标机应改为显式 CLI 参数或环境变量，例如：

```bash
export OPBENCH_TRACEKIT_ROOT=/opt/aenv-tracekit
export OPBENCH_TRACES_ROOT=/datasets/agent-traces
```

适配检查：

1. 确认 JSONL 中 `instance_id` 唯一；
2. 以 messages 内 tool-call 数作为总 step 数；
3. replay 到指定 step 后保存 sandbox id、replay report、文件/内存/rootfs 状态指纹；
4. 每次测量使用共同基线或可复建状态，不在同一被污染 sandbox 上混合重复；
5. 用单独的 cleanup ledger 记录创建的 sandbox/snapshot，特别是 snapshot 无删除 API 时的存储增长。

## 9. 冷暖缓存与重复设计

当前开发验证通常使用 `cold=False`，避免在非 root 调试账号下错误 drop cache。正式实验必须把缓存条件显式写入 run manifest：

- `warm`：不 drop cache；
- `cold`：`sync`、等待 Dirty 回落、受控 drop cache；
- `mixed`：仅供调试，不进入正式对比。

每个 `(trace, step, profile, operation, cache_condition)` 至少重复多次；先做 5–10 次校准，检查方差和 tail 是否截断，再确定 87 条轨迹的批量重复数。

## 10. 验收清单

迁移完成前，至少满足：

- [ ] `python3 -m unittest discover -s opbench/tests -v` 全部通过；
- [ ] `python3 -m compileall -q opbench` 通过；
- [ ] start/pause/resume/checkpoint/native fork 的 HTTP E2E 均通过；
- [ ] BPF probe 启动后健康，run 后 `collector_health.healthy=true`；
- [ ] guest logical 与 host physical 两层都生成原始日志与汇总；
- [ ] `/proc/diskstats` 与 BPF 总量差异被记录和解释；
- [ ] marker 完整、单调，目标实验 run 的 `stage_quality=direct`；
- [ ] API 返回后存在 TAIL，且 tail 有 idle/censor 标记；
- [ ] native fork 的每个 child 有独立 ready/清理记录；
- [ ] 真实轨迹 replay report、状态指纹、版本、设备映射与结果一同归档。

## 11. 当前已知限制

1. 当前阶段级结果在无 marker 时只有“API 控制路径 + TAIL”，这是有意避免伪精确。
2. 当前 BPF request completion 匹配仍可能出现少量 `unmatched_completions`；目标机应将该比率纳入 run 有效性阈值。
3. `du_snapshot` 目前是顶层总量口径；正式根因分析若需要 mem/rootfs/commit 精确分账，应按目标 AgentENV 的实际 artifact 树补充分目录/文件组采样。
4. 当前 Hyper-V VM 的 I/O 结果不能作为目标物理盘容量规划输入。
