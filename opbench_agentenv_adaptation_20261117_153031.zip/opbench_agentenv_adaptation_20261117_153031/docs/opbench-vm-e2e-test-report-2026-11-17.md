# opbench VM 端到端测试报告

- 日期：2026-11-17
- 被测版本：工作区 `opbench`（本报告对应 HTTP API 统一调用与 native fork 改造后版本）
- 被测环境：`AgentENV-Ubuntu`；AgentENV `aenv 0.2.5`；本地 API `http://127.0.0.1:8000`
- 测量边界：guest logical block I/O；运行清单记录实际发现的块设备、aenv UID、BPF 命令与探针健康状态。

## 结论

代码级测试与真实 VM 的生命周期端到端测试均通过。五类受测操作均通过 AgentENV HTTP API 完成；fork 使用原生 `POST /sandboxes/{id}/fork`，未使用“snapshot 后 start”替代。BPF trace collector 在全部有效 run 中保持健康，临时源/子 sandbox 已经通过 HTTP API 清理。

这不是 87 条真实轨迹的性能结论：本次是功能、权限、采集链路和生命周期语义的验证，每种操作只运行了极少次数，并且测量器端到端 run 显式关闭了冷缓存注入。

## 自动化验证

执行命令：

```bash
python3 -m unittest discover -s opbench/tests -v
python3 -m compileall -q opbench
```

结果：15/15 单元测试通过，编译检查通过。

覆盖项包括：

- HTTP API 的 snapshot-start、cold-start、pause、resume、snapshot、native fork、delete、get；
- 缺失 API key 时不发送请求且错误信息不泄漏 key；
- 动态发现根块设备和 ublk 设备，并生成 BPF 设备过滤条件；
- block issue/completion 匹配、读写延迟分位数与 Dirty-drain tail 截断标记；
- 受保护的 AgentENV artifacts 目录以 `sudo -n du` 采样，避免普通登录用户的 `PermissionError`；
- probe 退出时 run 被标记为不健康，且 manifest 固化 `guest_logical` I/O 边界。

## VM HTTP 生命周期冒烟

使用 VM 内已有 aenv CLI credentials，但不读取、打印或写入 API key。直接 HTTP 调用已成功覆盖：

1. `POST /sandboxes`，从 `lifecycle-bench-checkpoint` 启动；
2. `POST /sandboxes/{id}/pause`；
3. `POST /sandboxes/{id}/resume`；
4. `POST /sandboxes/{id}/snapshots`；
5. `POST /sandboxes/{id}/fork`，`count=1`；
6. `DELETE /sandboxes/{child}` 与 `DELETE /sandboxes/{source}`。

该过程保留了一个命名为 `opbench_e2e_20261117_034815` 的 snapshot；这是 snapshot API 本身无删除接口造成的可审计持久化副作用。其余临时 sandbox 均已清理。

## 测量器端到端结果

下表的 API 时延是该 VM、单次运行的 smoke 值，不应用于性能比较或容量预测。

| 测量器 | HTTP API 时延 | 默认 tail | 有效性 | 关键验证 |
|---|---:|---:|---|---|
| start | 92.886 ms | 10 s | `valid=true` | HTTP 启动、动态 BPF 过滤、manifest 落盘 |
| pause | 67.590 ms | 30 s | `valid=true` | 完整 pause tail、受保护 artifacts 采样 |
| resume | 95.530 ms | 4 s | `valid=true` | HTTP resume 与 I/O 采集 |
| checkpoint | 109.040 ms | 30 s | `valid=true` | 完整 tail；`tail_censored=false` |
| native fork | 125.686 ms | 10 s | `valid=true` | 子 sandbox 进入 running，随后 HTTP delete 成功 |

所有上述有效 run 的 `collector_health` 均为：

```json
{"healthy": true, "failed_probes": {}}
```

native fork 的 post-check 还确认子 sandbox ready 约 2.01 s，且 `children_deleted` 包含创建出的子 sandbox ID。

## 清理与环境核验

- `aenv.service=active`；
- 端到端测试完成后 `active_running=0`；
- 远端落盘 7 份 `result.json`（包括短 tail 诊断 run 与完整 tail run）；
- 没有将 API key、登录密码或 sandbox 内容写入此报告。

## 已知限制与下一步

1. 本轮不是 87 条真实轨迹/多重复实验，无法回答成本分布、方差或状态特征解释力。
2. 当前 VM 是单一 Hyper-V 虚拟磁盘环境；它不等价于设计文档中 aarch64、双 NVMe 的正式目标环境。结果只能验证方法链路，不能外推 SSD 本地后端成本。
3. I/O 边界仍是 guest logical block 层；要回答“存储真正承担了什么”，正式实验还需在宿主机物理目标设备同时采集并与 guest 口径核对。
4. 本次端到端 run 设置 `cold=False`，避免测试过程主动 drop cache；冷/暖 cache 应作为正式矩阵中的独立受控变量。
5. snapshot 创建会保留测试产物。正式批量运行前应规划专用 template/store、容量上限和清理周期。
