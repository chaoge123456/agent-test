# AgentENV 合成轨迹完整链路测试

- 日期：2026-11-17
- 环境：当前 Hyper-V 开发 VM，AgentENV `0.2.5`
- 基线：`lifecycle-bench-checkpoint`
- 结果目录（VM）：`/tmp/opbench-synthetic-full-20261117`
- I/O 口径：操作开始/结束时读取 guest `/proc/diskstats` 的 `sda` 差分；扇区按 512 B 换算。

## 负载与操作链

每个 profile 独立从共同 checkpoint 启动，随后依次执行：

`start → 构造 workload → checkpoint snapshot → pause → resume → native fork → 校验 child → 删除 child/source`

| Profile | 构造状态 |
|---|---|
| idle | `/workspace/profile/profile.txt`，无额外数据/内存工作集 |
| code | 3,000 源文件、3,000 Git-object 风格文件、600 次增量改写、192 MiB tmpfs 工作集 |
| data | 192 MiB source + 192 MiB result rootfs 数据、320 MiB tmpfs 工作集 |

全部操作返回 `exit_code=0`。每个 profile 的 workload 文件指纹在操作前、resume 后和 fork child 内一致；所有临时 sandbox 已删除。

## 结果

下表 `R/W req` 为 `sda` 完成请求数差分，`R/W MiB` 为对应扇区字节差分，时延为 HTTP 生命周期命令的墙钟时间。它们反映当前 VM 的客体逻辑块层负载。

### idle

| 操作 | 时延 ms | R req | W req | R MiB | W MiB |
|---|---:|---:|---:|---:|---:|
| start | 76 | 124 | 4 | 6.27 | 0.14 |
| checkpoint snapshot | 98 | 5 | 55 | 0.43 | 16.73 |
| pause | 52 | 1 | 18 | 0.00 | 0.33 |
| resume | 81 | 1 | 13 | 0.04 | 0.23 |
| native fork | 89 | 2 | 14 | 0.14 | 0.30 |

### code

| 操作 | 时延 ms | R req | W req | R MiB | W MiB |
|---|---:|---:|---:|---:|---:|
| start | 68 | 0 | 3 | 0.00 | 0.13 |
| checkpoint snapshot | 427 | 3 | 303 | 0.01 | 299.94 |
| pause | 176 | 13 | 190 | 0.10 | 180.39 |
| resume | 87 | 120 | 13 | 4.66 | 0.25 |
| native fork | 97 | 6 | 14 | 0.59 | 0.31 |

### data

| 操作 | 时延 ms | R req | W req | R MiB | W MiB |
|---|---:|---:|---:|---:|---:|
| start | 67 | 0 | 3 | 0.00 | 0.16 |
| checkpoint snapshot | 1,678 | 8,622 | 774 | 1,010.27 | 790.36 |
| pause | 416 | 82 | 775 | 4.04 | 711.02 |
| resume | 179 | 1,405 | 13 | 60.50 | 0.24 |
| native fork | 86 | 33 | 14 | 1.17 | 0.30 |

## 平均 IOPS 与平均带宽

以下由同一操作窗口的差分计数换算：`IOPS = 请求数 / elapsed_s`，`MiB/s = 字节 / elapsed_s`。它们是**窗口平均值**，不是设备峰值、分位数或时间序列瞬时值。

| Profile | 操作 | 读 IOPS | 写 IOPS | 读 MiB/s | 写 MiB/s | 总 IOPS | 总 MiB/s |
|---|---|---:|---:|---:|---:|---:|---:|
| idle | start | 1631.6 | 52.6 | 82.49 | 1.85 | 1684.2 | 84.34 |
| idle | checkpoint | 51.0 | 561.2 | 4.42 | 170.68 | 612.2 | 175.10 |
| idle | pause | 19.2 | 346.2 | 0.08 | 6.31 | 365.4 | 6.39 |
| idle | resume | 12.3 | 160.5 | 0.53 | 2.89 | 172.8 | 3.42 |
| idle | native fork | 22.5 | 157.3 | 1.58 | 3.34 | 179.8 | 4.92 |
| code | start | 0.0 | 44.1 | 0.00 | 1.90 | 44.1 | 1.90 |
| code | checkpoint | 7.0 | 709.6 | 0.03 | 702.44 | 716.6 | 702.47 |
| code | pause | 73.9 | 1079.5 | 0.58 | 1024.95 | 1153.4 | 1025.52 |
| code | resume | 1379.3 | 149.4 | 53.52 | 2.87 | 1528.7 | 56.39 |
| code | native fork | 61.9 | 144.3 | 6.12 | 3.18 | 206.2 | 9.30 |
| data | start | 0.0 | 44.8 | 0.00 | 2.45 | 44.8 | 2.45 |
| data | checkpoint | 5138.3 | 461.3 | 602.07 | 471.01 | 5599.5 | 1073.08 |
| data | pause | 197.1 | 1863.0 | 9.72 | 1709.17 | 2060.1 | 1718.89 |
| data | resume | 7849.2 | 72.6 | 337.95 | 1.35 | 7921.8 | 339.30 |
| data | native fork | 383.7 | 162.8 | 13.58 | 3.50 | 546.5 | 17.08 |

## 初步观察

- checkpoint 与 pause 对 rootfs 改写量和实际数据工作集最敏感：data profile 的 checkpoint 读约 1.01 GiB、写约 790 MiB，时延约 1.68 s。
- code profile 主要表现为写放大：checkpoint 写约 300 MiB、pause 写约 180 MiB，而读量很小。
- resume 的读量在 data profile 显著升高（约 60.5 MiB），符合恢复后按需数据读取/页回填预期。
- native fork 在这轮单 child、暖缓存验证中仍较轻；它的成本不能据此外推到多 child、冷缓存或宿主物理存储。

## 限制

1. 每个 profile 仅一次，未报告分布、方差或置信区间。
2. `/proc/diskstats:sda` 是 guest 逻辑块层，包含同设备背景影响，不能等同宿主 NVMe/SSD 物理 I/O。
3. 本轮运行的是完整合成负载链路脚本；它记录操作级前后差分，尚未将每个 operation 同时套入 opbench BPF 的完整阶段级 trace。
4. 当前 VM 未提供 AgentENV 内部 marker，阶段级结果只能标为 `inferred`。正式目标机应输出 phase marker，并同步采集宿主物理设备。
