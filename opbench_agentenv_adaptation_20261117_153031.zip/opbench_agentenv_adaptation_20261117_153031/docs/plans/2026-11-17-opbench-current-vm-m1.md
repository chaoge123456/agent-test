# Opbench Current-VM M1 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make `opbench` produce validated logical-I/O fingerprints on the current AgentENV 0.2.5 Hyper-V VM and measure native HTTP fork as a distinct operation.

**Architecture:** Add a runtime profile that discovers AgentENV paths, UID, block devices, and privilege wrapper instead of relying on the retired dual-NVMe host constants. Keep logical `sda` and ublk observations separate, preserve issue/complete events for latency calculation, and make collector health part of validity. Every lifecycle operation is invoked through the local AgentENV HTTP API with an explicitly supplied API-key environment variable; snapshot-start remains a separately named operation.

**Tech Stack:** Python standard library, bpftrace, Linux `/sys` and `/proc`, AgentENV CLI and local HTTP API, `unittest`.

**Spec:** `C:\Users\y00938212\.codex\attachments\a2111344-e398-4807-be9e-e27188a59dca\已粘贴的文本.txt` (V2 sections 2–6), plus runtime evidence collected on 2026-11-17 from `AgentENV-Ubuntu`.

## Global Constraints

- Target current VM: AgentENV `0.2.5`, `/var/lib/aenv`, root filesystem `/dev/sda1`, root block device `sda`.
- Treat this VM's device metrics as guest logical I/O; never label them physical NVMe/SSD results.
- Start BPF only through an explicit configurable privilege wrapper and fail a run when probes are unhealthy.
- Never read, persist, log, or embed an AgentENV API key; every HTTP lifecycle request accepts it only from an explicitly named environment variable.
- `fork_native` and `start_from_snapshot` are distinct `operation` values.
- Preserve raw issue and completion events and report unmatched/completion latency quality counters.

## Review Focus

- Missing or unreadable AgentENV directories must fail configuration discovery rather than produce zero artifact metrics (Task 1).
- A block device with the same major:minor as an old static filter must not be selected unless runtime discovery selected it (Task 1).
- A failed or prematurely exited BPF process must make the run invalid even when the lifecycle API succeeds (Task 2).
- Completion without a matching issue must be counted, not silently treated as zero latency (Task 3).
- A missing native-fork API key must fail before HTTP I/O and must not expose an environment value in exceptions or result files (Task 4).

---

### Task 1: Runtime profile and HTTP API contract

**Files:**
- Create: `opbench/core/runtime.py`
- Create: `opbench/core/api.py`
- Modify: `opbench/core/procs.py`
- Test: `opbench/tests/test_runtime.py`

**Interfaces:**
- Produces `RuntimeProfile.discover(...)`, containing `aenv_home`, `aenv_uid`, `logical_devices`, `ublk_devices`, and `bpftrace_command`.
- Produces `AgentEnvApi` methods for start, pause, resume, snapshot-create, delete, and native fork, all using one local HTTP request boundary.
- `Collector` consumes a `RuntimeProfile` rather than module-level artifact-path/device constants.

- [ ] **Step 1: Write failing runtime discovery and HTTP request construction tests**

```python
def test_discovers_sda_and_ublk_without_static_nvme_ids(): ...
def test_start_posts_cold_image_in_the_api_request_body(): ...
```

- [ ] **Step 2: Run tests to verify they fail for the missing runtime profile and HTTP client**

Run: `python3 -m unittest opbench.tests.test_runtime -v`

- [ ] **Step 3: Implement `RuntimeProfile` and the credential-redacting HTTP API client**

Discover block parents from `findmnt`/`lsblk` data supplied by injectable readers; use the current VM profile by default and permit environment overrides.

- [ ] **Step 4: Run runtime tests to verify they pass**

Run: `python3 -m unittest opbench.tests.test_runtime -v`

### Task 2: Probe health, dynamic BPF filters, and run manifest

**Files:**
- Modify: `opbench/core/procs.py`
- Modify: `opbench/bpf/blk.bt`
- Modify: `opbench/bpf/vfs.bt`
- Test: `opbench/tests/test_collector_health.py`

**Interfaces:**
- `Collector.start()` records a probe-ready/failed status and exposes `health()`.
- `Collector.stop()` copies logs and returns health metadata for `result.json` and `run_manifest.json`.
- BPF receives discovered device IDs through environment variables or generated script substitution.

- [ ] **Step 1: Write failing tests for rejected probe startup and manifest device metadata**
- [ ] **Step 2: Run tests and verify expected failures**
- [ ] **Step 3: Implement probe readiness checks, explicit sudo wrapper, generated device filter, and manifest output**
- [ ] **Step 4: Run collector tests and verify they pass**

### Task 3: Block completion parsing and latency metrics

**Files:**
- Modify: `opbench/core/metrics.py`
- Test: `opbench/tests/test_block_metrics.py`

**Interfaces:**
- `parse_blk_log()` retains `I` and `C` records.
- `io_stats()` returns read/write completion counts, latency histogram/percentiles, and unmatched event counters without combining devices.

- [ ] **Step 1: Write failing tests for issue-complete latency and unmatched completion accounting**
- [ ] **Step 2: Run tests and verify expected failures**
- [ ] **Step 3: Implement request correlation and per-device completion metrics**
- [ ] **Step 4: Run block metric tests and verify they pass**

### Task 4: Native fork operation and semantics labeling

**Files:**
- Modify: `opbench/core/api.py`
- Modify: `opbench/ops/fork.py`
- Modify: `opbench/scenarios/measure_fork.py`
- Modify: `opbench/scenarios/cli.py`
- Test: `opbench/tests/test_native_fork.py`

**Interfaces:**
- `AgentEnvApi.fork_sandbox(sid, count, timeout) -> dict` posts to local `/sandboxes/{sid}/fork`.
- `ForkMeasurer` measures `fork_native`; returned child IDs are cleaned only after their results are recorded.
- Snapshot-start is exposed separately as `start_from_snapshot`, never as `fork`.

- [ ] **Step 1: Write failing tests for request construction, missing-key failure, and native operation label**
- [ ] **Step 2: Run tests and verify expected failures**
- [ ] **Step 3: Implement native fork scenario wiring without logging credentials; migrate every existing operation measurer to `AgentEnvApi`**
- [ ] **Step 4: Run native fork tests and verify they pass**

### Task 5: Tail quality and first-use probe interface

**Files:**
- Modify: `opbench/ops/base.py`
- Modify: `opbench/ops/anchors.py`
- Modify: `opbench/ops/start.py`
- Modify: `opbench/ops/resume.py`
- Modify: `opbench/ops/fork.py`
- Test: `opbench/tests/test_tail_and_probe.py`

**Interfaces:**
- Stage construction receives `tail_end_ns` and emits `T`.
- Result includes `tail_censored`, probe start/end, and separately named first-use I/O window.

- [ ] **Step 1: Write failing tests for T-stage inclusion and censored tail result**
- [ ] **Step 2: Run tests and verify expected failures**
- [ ] **Step 3: Implement tail-state fields and a configurable non-destructive first-use probe hook**
- [ ] **Step 4: Run tail/probe tests and verify they pass**

### Task 6: End-to-end static verification and VM smoke

**Files:**
- Modify: `opbench/scenarios/cli.py`
- Test: `opbench/tests/test_cli_contract.py`

- [ ] **Step 1: Add failing CLI tests for `fork-native` and runtime profile arguments**
- [ ] **Step 2: Run tests to verify expected failures**
- [ ] **Step 3: Implement only the required CLI wiring and document the Hyper-V logical-I/O boundary in result metadata**
- [ ] **Step 4: Run the complete unittest suite, Python compilation, and one disposable VM smoke run**

## Self-Review

- V2’s path/device/PID/quality requirements map to Tasks 1–3; native fork semantics map to Task 4; API-tail and lazy-use boundaries map to Task 5.
- Production physical-NVMe capacity claims are intentionally out of scope for this Hyper-V implementation and remain a target-host experiment requirement.
- Credentials, destructive cleanup beyond disposable children, and background-environment remediation are out of scope.
