# AgentENV Lifecycle Latency Comparison Script Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Provide one portable shell script that measures common AgentENV HTTP lifecycle latency identically on the current VM and a target host.

**Architecture:** A dependency-light Bash script obtains API credentials from an explicit environment variable or a user credentials TOML file, calls local HTTP endpoints with curl, and writes one redacted JSONL result record per operation. It separates API response latency from HTTP state-verification latency and deletes only disposable sandboxes/children; snapshots remain explicitly recorded persistent artifacts.

**Tech Stack:** Bash, curl, Python 3 standard library.

**Spec:** User request in this conversation for a common AgentENV-operation latency test runnable on both machines.

## Global Constraints

- Never print or persist API keys.
- Require a snapshot/template id explicitly; never assume a host-specific name.
- Use HTTP for all lifecycle operations.
- Measure native fork, not snapshot-start as a fork proxy.
- Report API latency separately from ready verification and record host/environment metadata.
- Cleanup only sandboxes/children created by the script; snapshots are retained and listed.

## Review Focus

- Missing credentials must fail before any HTTP call (Task 1).
- A failed operation must still clean created disposable sandboxes (Task 2).
- Snapshot persistence must be apparent in the output (Task 2).
- Repetition must use a fresh source sandbox per repetition (Task 2).

### Task 1: CLI and credential contract

**Files:**
- Create: `agentenv-analysis/benchmark_lifecycle_latency.sh`
- Test: `opbench/tests/test_latency_script_contract.py`

- [ ] Write a failing static contract test for required options, `AENV_API_KEY`, HTTP endpoints, and JSONL output.
- [ ] Run the test and observe failure.
- [ ] Implement argument parsing, redacted credentials loading, metadata collection, and JSONL helper.
- [ ] Re-run the contract test and observe pass.

### Task 2: Operation loop and disposable cleanup

**Files:**
- Modify: `agentenv-analysis/benchmark_lifecycle_latency.sh`
- Test: `opbench/tests/test_latency_script_contract.py`

- [ ] Write a failing contract test for start/pause/resume/snapshot/native fork/delete and cleanup trap.
- [ ] Run the test and observe failure.
- [ ] Implement one fresh-source repetition with API and ready timings, plus trap cleanup.
- [ ] Run the contract test, shell syntax check, complete unittest suite, and one current-VM one-repetition smoke run.
