# Opbench Task-Stage Model Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace file-name-led fine-grained lifecycle segmentation with a five-to-six-stage, task-led model that prefers explicit AgentENV phase markers and reports fallback quality.

**Architecture:** `anchors.py` will use a per-operation stage specification whose boundaries are marker names. Marker records, when supplied, are authoritative; existing VFS/PID events provide coarse fallback boundaries. Every stage result records the boundary source and every run records `stage_quality` so inferred windows cannot be mistaken for internal-call-chain evidence.

**Tech Stack:** Python standard library, current opbench BPF/VFS logs, JSONL marker sidecar, unittest.

**Spec:** User-approved stage model in this conversation: task-led phases, maximum six phases per operation, observable boundaries, and explicit TAIL.

## Global Constraints

- `start_from_snapshot` and `start_cold` remain distinct operation labels in results.
- Each operation has at most six task stages, including TAIL.
- Explicit marker records contain `op_id`, `operation`, `phase`, `event`, `ts_ns`, `sandbox_id`, and optional `child_id`.
- Marker-less current-VM runs remain supported but are labelled `inferred` or `degraded`.
- File-name VFS events and PID appearance are fallback evidence, never labelled direct internal markers.
- Native fork source and each child retain distinct identifiers in marker metadata.

## Review Focus

- Missing mandatory marker must downgrade quality rather than create a false direct boundary (Task 1).
- Out-of-order marker timestamps must not produce overlapping or negative windows (Task 2).
- A fork marker for one child must not be silently used for another child (Task 2).
- Marker JSONL with unrelated `op_id` must be ignored (Task 1).
- Existing marker-less runs must still emit a complete API+TAIL partition (Task 3).

### Task 1: Marker record parser and evidence selection

**Files:**
- Create: `opbench/core/markers.py`
- Test: `opbench/tests/test_markers.py`

**Interfaces:**
- `read_markers(path: Path, op_id: str) -> list[dict]` filters JSONL records by operation id.
- `MarkerIndex(records).boundary(name, event="begin", child_id=None) -> int` returns a matching timestamp or zero.

- [ ] Write failing tests for op-id filtering, child filtering, and malformed-line tolerance.
- [ ] Run `python3 -m unittest opbench.tests.test_markers -v`; observe failure.
- [ ] Implement the parser/index with no third-party dependency.
- [ ] Re-run the marker tests; observe pass.

### Task 2: Task-led stage specifications

**Files:**
- Modify: `opbench/ops/anchors.py`
- Test: `opbench/tests/test_task_stages.py`

**Interfaces:**
- `build_stage_windows(..., markers=None, child_id=None) -> tuple[list[dict], dict]` returns windows and stage-quality metadata.
- Marker boundaries use the approved S/P/R/C/F task names; fallback windows use coarse current BPF anchors.

- [ ] Write failing tests for marker-led start and fork windows, missing-marker degradation, and monotonic clamping.
- [ ] Run task-stage tests; observe failure.
- [ ] Implement five/six-stage task models and boundary-source metadata.
- [ ] Re-run task-stage tests; observe pass.

### Task 3: Result schema integration and current-VM fallback

**Files:**
- Modify: `opbench/ops/base.py`
- Modify: `opbench/ops/start.py`
- Modify: `opbench/ops/pause.py`
- Modify: `opbench/ops/resume.py`
- Modify: `opbench/ops/checkpoint.py`
- Modify: `opbench/ops/fork.py`
- Test: `opbench/tests/test_stage_result_quality.py`

**Interfaces:**
- `result["stage_quality"]` contains overall quality, marker count, and missing mandatory boundaries.
- Result stages carry `boundary_source` for both start and end.

- [ ] Write failing result-schema test for a marker-less stage build.
- [ ] Run it; observe failure.
- [ ] Wire optional `<run>/phase_markers.jsonl` into the measurer and preserve marker-less compatibility.
- [ ] Run full unit suite, compileall, and a disposable current-VM fork smoke; observe pass.

## Self-Review

- The three tasks cover marker validity, stage definitions, and externally visible result quality.
- No AgentENV service code is changed; it can adopt the documented JSONL interface on the target host.
- Current-VM BPF-only runs remain useful as inferred logical-I/O observations, but cannot claim direct internal phase evidence.
