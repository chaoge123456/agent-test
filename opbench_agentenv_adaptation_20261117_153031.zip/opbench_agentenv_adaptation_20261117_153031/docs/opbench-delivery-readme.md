# opbench 交付包说明

本交付包包含：

- `opbench/`：Python 采集器、HTTP API client、BPF 程序、五类操作测量器、真实轨迹 stepper、场景入口与单元测试；
- `agentenv-analysis/run_realistic_profiles.sh`：idle/code/data 合成负载的完整生命周期链路；
- `agentenv-analysis/benchmark_lifecycle_latency.sh`：可跨当前 VM 与目标机器运行的 HTTP 生命周期时延对比脚本；
- `docs/opbench-target-host-adaptation-guide.md`：目标机器适配说明；
- `docs/opbench-synthetic-trajectory-run-2026-11-17.md`：操作级合成链路结果；
- `docs/opbench-synthetic-stage-io-2026-11-17.md`：API/TAIL 阶段级 I/O 结果；
- `docs/opbench-vm-e2e-test-report-2026-11-17.md`：当前 VM 端到端测试报告；
- `docs/superpowers/plans/` 中与当前 opbench 改造直接相关的实施计划。

不包含完整 AgentENV 源码、API key、登录凭据、VM 临时日志、`__pycache__`、大型数据集和不相关工作区代码。

迁移到目标机器前，先阅读 `docs/opbench-target-host-adaptation-guide.md`。
