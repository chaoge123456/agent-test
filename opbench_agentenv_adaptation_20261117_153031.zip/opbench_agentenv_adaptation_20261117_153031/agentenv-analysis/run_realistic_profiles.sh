#!/usr/bin/env bash
# AgentENV scenario benchmark: runs inside the dedicated AgentENV host VM.
# Uses an existing immutable snapshot as a common base, then runs one lifecycle
# sequence per profile. Results are plain text/JSON under $HOME/bench-results.
set -euo pipefail

BASE_SNAPSHOT="${1:-lifecycle-bench-checkpoint}"
ROOT="${2:-$HOME/bench-results/profiles-$(date -u +%Y%m%dT%H%M%SZ)}"
PROFILES="${AENV_PROFILES:-idle code data}"
CREDENTIALS="${AENV_CREDENTIALS:-$HOME/.config/aenv/credentials}"
mkdir -p "$ROOT"

# Lifecycle operations deliberately share one HTTP boundary.  `aenv exec` below
# is only used to construct and fingerprint the workload inside a sandbox.
API_URL=$(sed -nE 's/^url[[:space:]]*=[[:space:]]*"?([^"[:space:]]+).*$/\1/p' "$CREDENTIALS")
API_KEY=$(sed -nE 's/^api_key[[:space:]]*=[[:space:]]*"?([^"[:space:]]+).*$/\1/p' "$CREDENTIALS")
if [[ -z "$API_URL" || -z "$API_KEY" ]]; then
  echo "missing url or api_key in $CREDENTIALS" >&2
  exit 2
fi

api_request() {
  curl -fsS -H "X-API-Key: $API_KEY" -H 'Content-Type: application/json' "$@"
}

api_start() { api_request -X POST -d "{\"templateID\":\"$1\",\"timeout\":${2:-1800}}" "$API_URL/sandboxes"; }
api_pause() { api_request -X POST -d '{}' "$API_URL/sandboxes/$1/pause"; }
api_resume() { api_request -X POST -d "{\"timeout\":${2:-1800}}" "$API_URL/sandboxes/$1/resume"; }
api_snapshot() { api_request -X POST -d "{\"name\":\"$2\"}" "$API_URL/sandboxes/$1/snapshots"; }
api_fork() { api_request -X POST -d "{\"count\":1,\"timeout\":${2:-900}}" "$API_URL/sandboxes/$1/fork"; }
api_delete() { api_request -X DELETE "$API_URL/sandboxes/$1"; }

SOURCE_TO_CLEAN=""
CHILD_TO_CLEAN=""
cleanup_sandboxes() {
  local rc=$?
  set +e
  [[ -n "$CHILD_TO_CLEAN" ]] && api_delete "$CHILD_TO_CLEAN" >/dev/null 2>&1
  [[ -n "$SOURCE_TO_CLEAN" ]] && api_delete "$SOURCE_TO_CLEAN" >/dev/null 2>&1
  exit "$rc"
}
trap cleanup_sandboxes EXIT

diskstat() {
  awk '$3=="sda" {printf "reads_completed=%s sectors_read=%s writes_completed=%s sectors_written=%s\n",$4,$6,$8,$10}' /proc/diskstats
}

space() {
  sudo du -sk /var/lib/aenv/{snapshot-store,persisted-sandboxes,firecracker-work} 2>/dev/null | sort > "$1.allocated_kib" || true
  sudo du -sk --apparent-size /var/lib/aenv/{snapshot-store,persisted-sandboxes,firecracker-work} 2>/dev/null | sort > "$1.apparent_kib" || true
}

op() {
  local out="$1" name="$2"; shift 2
  diskstat > "$out/$name.disk.before"
  space "$out/$name.space.before"
  local begin end rc
  begin=$(date +%s%N)
  set +e
  "$@" > "$out/$name.stdout" 2> "$out/$name.stderr"
  rc=$?
  set -e
  end=$(date +%s%N)
  diskstat > "$out/$name.disk.after"
  space "$out/$name.space.after"
  printf 'operation=%s\nexit_code=%s\nelapsed_ms=%s\n' "$name" "$rc" "$(((end-begin)/1000000))" > "$out/$name.summary"
  return "$rc"
}

run_guest_profile() {
  local id="$1" profile="$2" payload
  case "$profile" in
    idle)
      payload='set -eu; mkdir -p /workspace/profile; printf idle > /workspace/profile/profile.txt; sync'
      ;;
    code)
      payload='set -eu; rm -rf /workspace/profile; rm -f /dev/shm/agentenv-code-memory; mkdir -p /workspace/profile/src /workspace/profile/.git/objects; cd /workspace/profile; for i in $(seq 1 3000); do d=src/pkg$((i % 60)); mkdir -p "$d"; printf "def f%s():\\n    return %s\\n" "$i" "$i" > "$d/module_$i.py"; printf "object-%s\\n" "$i" > ".git/objects/$i"; done; for i in $(seq 1 600); do printf "# update %s\\n" "$i" >> "src/pkg$((i % 60))/module_$i.py"; done; dd if=/dev/zero of=/dev/shm/agentenv-code-memory bs=1M count=192 status=none; sync'
      ;;
    data)
      payload='set -eu; rm -rf /workspace/profile; rm -f /dev/shm/agentenv-data-memory; mkdir -p /workspace/profile; dd if=/dev/zero of=/workspace/profile/source.dat bs=1M count=192 conv=fsync status=none; dd if=/workspace/profile/source.dat of=/workspace/profile/result.dat bs=4M conv=fsync status=none; dd if=/dev/zero of=/dev/shm/agentenv-data-memory bs=1M count=320 status=none; sync'
      ;;
    *) echo "unknown profile: $profile" >&2; return 2;;
  esac
  local b64
  b64=$(printf %s "$payload" | base64 -w0)
  aenv exec "$id" sh -lc "echo '$b64' | base64 -d | sh"
}

run_profile() {
  local profile="$1" out="$ROOT/$profile"
  mkdir -p "$out"
  op "$out" start api_start "$BASE_SNAPSHOT" 1800
  local id
  id=$(python3 - "$out/start.stdout" <<'PY'
import json, sys
print(json.load(open(sys.argv[1]))['sandboxID'])
PY
)
  SOURCE_TO_CLEAN="$id"
  printf '%s\n' "$id" > "$out/sandbox_id"
  run_guest_profile "$id" "$profile" > "$out/workload.stdout" 2> "$out/workload.stderr"
  aenv exec "$id" sh -lc 'find /workspace/profile -type f -printf "%s %p\\n" | sort | sha256sum; ps -eo rss,comm | sort -nr | head -5' > "$out/workload_fingerprint.before"
  op "$out" checkpoint api_snapshot "$id" "profile-$profile-$(date +%s)"
  op "$out" pause api_pause "$id"
  op "$out" resume api_resume "$id" 1800
  aenv exec "$id" sh -lc 'find /workspace/profile -type f -printf "%s %p\\n" | sort | sha256sum; ps -eo rss,comm | sort -nr | head -5' > "$out/workload_fingerprint.after_resume"
  op "$out" fork_native api_fork "$id" 900
  python3 - "$out/fork_native.stdout" <<'PY' > "$out/fork_child_id"
import json, sys
v=json.load(open(sys.argv[1]))
print(v[0]['sandbox']['sandboxID'])
PY
  local child
  child=$(cat "$out/fork_child_id")
  CHILD_TO_CLEAN="$child"
  aenv exec "$child" sh -lc 'find /workspace/profile -type f -printf "%s %p\\n" | sort | sha256sum' > "$out/workload_fingerprint.child"
  api_delete "$child" > "$out/delete_child.stdout"
  CHILD_TO_CLEAN=""
  api_delete "$id" > "$out/delete_source.stdout"
  SOURCE_TO_CLEAN=""
}

printf 'base_snapshot=%s\nstarted_at=%s\nio_boundary=guest_logical\n' "$BASE_SNAPSHOT" "$(date -u +%FT%TZ)" > "$ROOT/run.info"
for profile in $PROFILES; do run_profile "$profile"; done
printf 'finished_at=%s\n' "$(date -u +%FT%TZ)" >> "$ROOT/run.info"
printf 'RESULTS=%s\n' "$ROOT"
