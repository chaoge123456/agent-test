#!/usr/bin/env bash
# Portable AgentENV HTTP lifecycle latency benchmark.
# Measures API response latency and post-response state verification separately.
set -euo pipefail

TEMPLATE=""
OUT_ROOT=""
REPS=3
TIMEOUT=300
READY_TIMEOUT=60
CREDENTIALS="${AENV_CREDENTIALS:-$HOME/.config/aenv/credentials}"
BASE_URL="${AENV_BASE_URL:-}"

usage() {
  cat <<'EOF'
Usage: benchmark_lifecycle_latency.sh --template ID [options]
  --template ID          Required AgentENV template/snapshot id.
  --out DIR              Results directory (default: ./aenv-latency-<UTC timestamp>).
  --reps N               Fresh-source repetitions (default: 3).
  --timeout SECONDS      Start/resume/fork API timeout (default: 300).
  --ready-timeout SEC    HTTP state verification timeout (default: 60).
  --base-url URL         AgentENV URL; defaults to AENV_BASE_URL or credentials url.
  --credentials PATH     TOML credentials file; defaults to AENV_CREDENTIALS or ~/.config/aenv/credentials.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --template) TEMPLATE="$2"; shift 2 ;;
    --out) OUT_ROOT="$2"; shift 2 ;;
    --reps) REPS="$2"; shift 2 ;;
    --timeout) TIMEOUT="$2"; shift 2 ;;
    --ready-timeout) READY_TIMEOUT="$2"; shift 2 ;;
    --base-url) BASE_URL="$2"; shift 2 ;;
    --credentials) CREDENTIALS="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "unknown argument: $1" >&2; usage >&2; exit 2 ;;
  esac
done

[[ -n "$TEMPLATE" ]] || { echo '--template is required' >&2; exit 2; }
[[ "$REPS" =~ ^[1-9][0-9]*$ ]] || { echo '--reps must be a positive integer' >&2; exit 2; }
command -v curl >/dev/null
command -v python3 >/dev/null

if [[ -z "${AENV_API_KEY:-}" && -f "$CREDENTIALS" ]]; then
  AENV_API_KEY=$(sed -nE 's/^api_key[[:space:]]*=[[:space:]]*"?([^"[:space:]]+).*$/\1/p' "$CREDENTIALS")
fi
if [[ -z "$BASE_URL" && -f "$CREDENTIALS" ]]; then
  BASE_URL=$(sed -nE 's/^url[[:space:]]*=[[:space:]]*"?([^"[:space:]]+).*$/\1/p' "$CREDENTIALS")
fi
BASE_URL="${BASE_URL:-http://127.0.0.1:8000}"
[[ -n "${AENV_API_KEY:-}" ]] || { echo 'set AENV_API_KEY or provide --credentials' >&2; exit 2; }

OUT_ROOT="${OUT_ROOT:-./aenv-latency-$(date -u +%Y%m%dT%H%M%SZ)}"
mkdir -p "$OUT_ROOT"
RESULTS="$OUT_ROOT/results.jsonl"
METADATA="$OUT_ROOT/metadata.json"

python3 - "$METADATA" "$TEMPLATE" "$BASE_URL" "$REPS" <<'PY'
import json, platform, socket, subprocess, sys
def text(command):
    try: return subprocess.check_output(command, text=True, stderr=subprocess.DEVNULL).strip()
    except Exception: return ""
json.dump({"schema":"agentenv-latency/1", "template":sys.argv[2], "base_url":sys.argv[3],
           "repetitions":int(sys.argv[4]), "hostname":socket.gethostname(),
           "kernel":platform.platform(), "machine":platform.machine(),
           "aenv_version":text(["aenv", "--version"])}, open(sys.argv[1], "w"), indent=2)
PY

CURRENT_SOURCE=""
CURRENT_CHILD=""
LAST_BODY=""
LAST_HTTP=""
LAST_API_MS=""

json_start() { python3 - "$1" "$2" <<'PY'
import json, sys
print(json.dumps({"templateID": sys.argv[1], "timeout": int(sys.argv[2])}))
PY
}
json_timeout() { python3 - "$1" <<'PY'
import json, sys
print(json.dumps({"timeout": int(sys.argv[1])}))
PY
}
json_name() { python3 - "$1" <<'PY'
import json, sys
print(json.dumps({"name": sys.argv[1]}))
PY
}
json_fork() { python3 - "$1" <<'PY'
import json, sys
print(json.dumps({"count": 1, "timeout": int(sys.argv[1])}))
PY
}

api_call() {
  local method="$1" path="$2" body="${3:-}" tmp out rc
  local -a args
  tmp=$(mktemp)
  args=(-sS -o "$tmp" -w '%{http_code}|%{time_total}' -X "$method"
        -H "X-API-Key: $AENV_API_KEY" -H 'Content-Type: application/json')
  [[ -n "$body" ]] && args+=(-d "$body")
  set +e
  out=$(curl "${args[@]}" "$BASE_URL$path")
  rc=$?
  set -e
  LAST_BODY=$(<"$tmp"); rm -f "$tmp"
  LAST_HTTP=${out%%|*}
  LAST_API_MS=$(python3 - "${out#*|}" <<'PY'
import sys
try: print(round(float(sys.argv[1]) * 1000, 3))
except ValueError: print(0)
PY
)
  [[ $rc -eq 0 && "$LAST_HTTP" =~ ^(200|201|204)$ ]]
}

parse_id() { python3 -c 'import json,sys; print(json.loads(sys.stdin.read())["sandboxID"])'; }
parse_fork_child() { python3 -c 'import json,sys; print(json.loads(sys.stdin.read())[0]["sandbox"]["sandboxID"])'; }

emit() {
  python3 - "$RESULTS" "$@" <<'PY'
import json, sys
keys = ("operation rep api_ms ready_ms expected_state http_status sandbox_id note".split())
record = dict(zip(keys, sys.argv[2:]))
record["rep"] = int(record["rep"])
for key in ("api_ms", "ready_ms"):
    record[key] = float(record[key]) if record[key] else None
with open(sys.argv[1], "a") as f: f.write(json.dumps(record) + "\n")
PY
}

wait_state() {
  local sid="$1" expected="$2" start now state
  start=$(date +%s%N)
  while true; do
    api_call GET "/sandboxes/$sid"
    state=$(printf '%s' "$LAST_BODY" | python3 -c 'import json,sys; print(json.load(sys.stdin).get("state", ""))' 2>/dev/null || true)
    if [[ "$state" == "$expected" ]]; then
      now=$(date +%s%N); echo $(( (now - start) / 1000000 )); return 0
    fi
    now=$(date +%s%N)
    (( now - start < READY_TIMEOUT * 1000000000 )) || return 1
    sleep 1
  done
}

delete_sandbox() {
  local sid="$1" label="$2" rep="$3" api_ms="" ready_ms=""
  [[ -n "$sid" ]] || return 0
  if api_call DELETE "/sandboxes/$sid"; then
    api_ms="$LAST_API_MS"
    emit "$label" "$rep" "$api_ms" "$ready_ms" "" "$LAST_HTTP" "$sid" "disposable cleanup"
  fi
}

cleanup_sandboxes() {
  local rc=$?
  set +e
  delete_sandbox "$CURRENT_CHILD" delete_child "${CURRENT_REP:-0}"
  delete_sandbox "$CURRENT_SOURCE" delete_source "${CURRENT_REP:-0}"
  exit "$rc"
}
trap cleanup_sandboxes EXIT

for ((CURRENT_REP=1; CURRENT_REP<=REPS; CURRENT_REP++)); do
  CURRENT_SOURCE=""; CURRENT_CHILD=""

  api_call POST /sandboxes "$(json_start "$TEMPLATE" "$TIMEOUT")"
  CURRENT_SOURCE=$(printf '%s' "$LAST_BODY" | parse_id)
  start_api_ms="$LAST_API_MS"; start_http="$LAST_HTTP"
  start_ready_ms=$(wait_state "$CURRENT_SOURCE" running || true)
  emit start "$CURRENT_REP" "$start_api_ms" "$start_ready_ms" running "$start_http" "$CURRENT_SOURCE" "snapshot start"

  api_call POST "/sandboxes/$CURRENT_SOURCE/pause" '{}'
  pause_api_ms="$LAST_API_MS"; pause_http="$LAST_HTTP"
  pause_ready_ms=$(wait_state "$CURRENT_SOURCE" paused || true)
  emit pause "$CURRENT_REP" "$pause_api_ms" "$pause_ready_ms" paused "$pause_http" "$CURRENT_SOURCE" ""

  api_call POST "/sandboxes/$CURRENT_SOURCE/resume" "$(json_timeout "$TIMEOUT")"
  resume_api_ms="$LAST_API_MS"; resume_http="$LAST_HTTP"
  resume_ready_ms=$(wait_state "$CURRENT_SOURCE" running || true)
  emit resume "$CURRENT_REP" "$resume_api_ms" "$resume_ready_ms" running "$resume_http" "$CURRENT_SOURCE" ""

  snapshot_name="latency_${CURRENT_REP}_$(date -u +%Y%m%dT%H%M%SZ)"
  api_call POST "/sandboxes/$CURRENT_SOURCE/snapshots" "$(json_name "$snapshot_name")"
  emit checkpoint_snapshot "$CURRENT_REP" "$LAST_API_MS" "" "" "$LAST_HTTP" "$CURRENT_SOURCE" "persistent_snapshot=$snapshot_name"

  api_call POST "/sandboxes/$CURRENT_SOURCE/fork" "$(json_fork "$TIMEOUT")"
  CURRENT_CHILD=$(printf '%s' "$LAST_BODY" | parse_fork_child)
  fork_api_ms="$LAST_API_MS"; fork_http="$LAST_HTTP"
  fork_ready_ms=$(wait_state "$CURRENT_CHILD" running || true)
  emit native_fork "$CURRENT_REP" "$fork_api_ms" "$fork_ready_ms" running "$fork_http" "$CURRENT_CHILD" "source=$CURRENT_SOURCE"

  delete_sandbox "$CURRENT_CHILD" delete_child "$CURRENT_REP"; CURRENT_CHILD=""
  delete_sandbox "$CURRENT_SOURCE" delete_source "$CURRENT_REP"; CURRENT_SOURCE=""
done

printf 'RESULTS=%s\n' "$OUT_ROOT"
