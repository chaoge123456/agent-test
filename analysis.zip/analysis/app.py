import os
import re
import json
import tempfile
from pathlib import Path
from flask import Flask, render_template, request, jsonify, send_file, abort

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024

DATA = None


def derive_pdf_path(image_path):
    if not image_path:
        return None
    p = image_path.replace('\\', '/')
    m = re.search(r'/pages/(\d+)/', p)
    if not m:
        return None
    doc_id = m.group(1)
    category_m = re.search(r'/dataset/(\w+)/pages/', p)
    if not category_m:
        return None
    category = category_m.group(1)
    base = p[:p.index('/dataset/')]
    return f"{base}/dataset/{category}/pdfs/{doc_id}.pdf"


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/upload', methods=['POST'])
def upload():
    global DATA
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    f = request.files['file']
    if not f.filename.endswith('.json'):
        return jsonify({'error': 'Only .json files accepted'}), 400
    try:
        raw = json.loads(f.read().decode('utf-8'))
    except (json.JSONDecodeError, UnicodeDecodeError) as e:
        return jsonify({'error': f'Invalid JSON: {str(e)}'}), 400

    for item in raw:
        item['pdf_path'] = derive_pdf_path(
            item.get('page_path', [''])[0] if item.get('page_path') else ''
        )
    DATA = raw
    return jsonify(DATA)


@app.route('/load_example', methods=['POST'])
def load_example():
    global DATA
    example_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'example.json')
    if not os.path.exists(example_path):
        return jsonify({'error': 'example.json not found'}), 404
    with open(example_path, 'r', encoding='utf-8') as f:
        raw = json.load(f)
    for item in raw:
        item['pdf_path'] = derive_pdf_path(
            item.get('page_path', [''])[0] if item.get('page_path') else ''
        )
    DATA = raw
    return jsonify(DATA)


@app.route('/image')
def serve_image():
    path = request.args.get('path', '')
    if not path:
        abort(404)
    path = path.replace('/', '\\')
    if not os.path.isfile(path):
        abort(404)
    return send_file(path, mimetype='image/png')


@app.route('/pdf')
def serve_pdf():
    path = request.args.get('path', '')
    if not path:
        abort(404)
    path = path.replace('/', '\\')
    if not os.path.isfile(path):
        abort(404)
    return send_file(path, mimetype='application/pdf')


if __name__ == '__main__':
    app.run(debug=True, port=5000)
