(function() {
    'use strict';

    var queries = [];
    var selectedIdx = -1;
    var currentFilter = 'all';
    var searchQuery = '';
    var lightboxImages = [];
    var lightboxIdx = 0;

    var uploadView = document.getElementById('upload-view');
    var analysisView = document.getElementById('analysis-view');
    var dropZone = document.getElementById('drop-zone');
    var fileInput = document.getElementById('file-input');
    var loadExampleBtn = document.getElementById('load-example-btn');
    var uploadStatus = document.getElementById('upload-status');
    var newUploadBtn = document.getElementById('new-upload-btn');
    var searchInput = document.getElementById('search-input');
    var filterBtns = document.querySelectorAll('.filter-btn');
    var queryList = document.getElementById('query-list');
    var queryDetail = document.getElementById('query-detail');
    var lightbox = document.getElementById('lightbox');
    var lightboxImg = document.getElementById('lightbox-img');
    var lightboxCaption = document.getElementById('lightbox-caption');
    var lightboxClose = document.getElementById('lightbox-close');
    var lightboxPrev = document.getElementById('lightbox-prev');
    var lightboxNext = document.getElementById('lightbox-next');
    var pdfModal = document.getElementById('pdf-modal');
    var pdfIframe = document.getElementById('pdf-iframe');
    var pdfModalClose = document.getElementById('pdf-modal-close');
    var pdfModalTitle = document.getElementById('pdf-modal-title');

    dropZone.addEventListener('click', function() { fileInput.click(); });

    dropZone.addEventListener('dragover', function(e) {
        e.preventDefault();
        dropZone.classList.add('drag-over');
    });

    dropZone.addEventListener('dragleave', function() {
        dropZone.classList.remove('drag-over');
    });

    dropZone.addEventListener('drop', function(e) {
        e.preventDefault();
        dropZone.classList.remove('drag-over');
        var files = e.dataTransfer.files;
        if (files.length > 0) uploadFile(files[0]);
    });

    fileInput.addEventListener('change', function() {
        if (fileInput.files.length > 0) uploadFile(fileInput.files[0]);
    });

    loadExampleBtn.addEventListener('click', function() {
        showStatus('Loading example data...', 'success');
        fetch('/load_example', { method: 'POST' })
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (data.error) { showStatus(data.error, 'error'); return; }
                loadData(data);
            })
            .catch(function(e) { showStatus('Error: ' + e.message, 'error'); });
    });

    newUploadBtn.addEventListener('click', function() {
        queries = [];
        selectedIdx = -1;
        uploadView.style.display = '';
        analysisView.style.display = 'none';
        uploadStatus.style.display = 'none';
    });

    function uploadFile(file) {
        if (!file.name.endsWith('.json')) {
            showStatus('Only .json files are accepted', 'error');
            return;
        }
        showStatus('Uploading...', 'success');
        var fd = new FormData();
        fd.append('file', file);
        fetch('/upload', { method: 'POST', body: fd })
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (data.error) { showStatus(data.error, 'error'); return; }
                loadData(data);
            })
            .catch(function(e) { showStatus('Error: ' + e.message, 'error'); });
    }

    function showStatus(msg, type) {
        uploadStatus.textContent = msg;
        uploadStatus.className = 'upload-status ' + type;
        uploadStatus.style.display = '';
    }

    function loadData(data) {
        queries = data;
        selectedIdx = -1;
        currentFilter = 'all';
        searchQuery = '';
        searchInput.value = '';
        filterBtns.forEach(function(b) { b.classList.toggle('active', b.dataset.filter === 'all'); });
        uploadView.style.display = 'none';
        analysisView.style.display = '';
        updateStats();
        renderQueryList();
        queryDetail.innerHTML = '<div class="detail-placeholder"><p>Select a query from the list to view details</p></div>';
    }

    function updateStats() {
        var total = queries.length;
        var correct = queries.filter(function(q) { return q.evaluation === 'true'; }).length;
        var incorrect = total - correct;
        var accuracy = total > 0 ? Math.round(correct / total * 100) : 0;
        document.getElementById('stat-total').textContent = total;
        document.getElementById('stat-correct').textContent = correct;
        document.getElementById('stat-incorrect').textContent = incorrect;
        document.getElementById('stat-accuracy').textContent = accuracy + '%';
    }

    filterBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            currentFilter = btn.dataset.filter;
            filterBtns.forEach(function(b) { b.classList.toggle('active', b === btn); });
            renderQueryList();
        });
    });

    searchInput.addEventListener('input', function() {
        searchQuery = searchInput.value.toLowerCase();
        renderQueryList();
    });

    function getFilteredQueries() {
        return queries.filter(function(q) {
            if (currentFilter === 'true' && q.evaluation !== 'true') return false;
            if (currentFilter === 'false' && q.evaluation !== 'false') return false;
            if (searchQuery && q.query.toLowerCase().indexOf(searchQuery) === -1) return false;
            return true;
        });
    }

    function renderQueryList() {
        var filtered = getFilteredQueries();
        var html = '';
        filtered.forEach(function(item) {
            var idx = queries.indexOf(item);
            var isCorrect = item.evaluation === 'true';
            var badgeClass = isCorrect ? 'correct' : 'incorrect';
            var badgeText = isCorrect ? 'Correct' : 'Incorrect';
            var activeClass = idx === selectedIdx ? ' active' : '';
            html += '<div class="query-item' + activeClass + '" data-idx="' + idx + '">'
                + '<span class="query-num">#' + (idx + 1) + '</span>'
                + '<div class="query-item-body">'
                + '<div class="query-text-preview">' + escapeHtml(item.query) + '</div>'
                + '</div>'
                + '<span class="eval-badge ' + badgeClass + '">' + badgeText + '</span>'
                + '</div>';
        });
        if (filtered.length === 0) {
            html = '<div class="detail-placeholder" style="padding:32px 16px;"><p>No matching queries</p></div>';
        }
        queryList.innerHTML = html;
        queryList.querySelectorAll('.query-item').forEach(function(el) {
            el.addEventListener('click', function() {
                selectQuery(parseInt(el.dataset.idx));
            });
        });
    }

    function selectQuery(idx) {
        selectedIdx = idx;
        renderQueryList();
        renderDetail(queries[idx]);
    }

    function renderDetail(item) {
        var isCorrect = item.evaluation === 'true';
        var badgeClass = isCorrect ? 'correct' : 'incorrect';
        var badgeText = isCorrect ? 'Correct' : 'Incorrect';
        var html = '<div class="detail-header">'
            + '<div class="detail-query-text">' + escapeHtml(item.query) + '</div>'
            + '<div class="detail-meta">'
            + '<span class="eval-badge ' + badgeClass + '">' + badgeText + '</span>'
            + '<span style="font-size:12px;color:var(--text-muted);">' + (item.page_path ? item.page_path.length : 0) + ' evidence pages</span>'
            + '</div></div>'
            + '<div class="detail-body">';
        html += '<div class="detail-left">';
        html += '<div class="answer-section"><div class="answer-label">Ground Truth Answer</div><div class="answer-text">' + escapeHtml(item.answer) + '</div></div>';
        var sections = parseResponse(item.response);
        sections.forEach(function(sec) {
            html += '<div class="section-card section-' + sec.type + '">'
                + '<div class="section-header" data-section>'
                + '<span>' + sec.label + '</span>'
                + '<span class="section-toggle">&#9660;</span>'
                + '</div>'
                + '<div class="section-body">' + escapeHtml(sec.content) + '</div>'
                + '</div>';
        });
        html += '</div>';
        html += '<div class="detail-right">';
        html += '<div class="right-section-label">Evidence Pages</div>';
        if (item.page_path && item.page_path.length > 0) {
            html += '<div class="image-grid">';
            item.page_path.forEach(function(p, i) {
                var fname = p.split(/[/\\]/).pop();
                var imgSrc = '/image?path=' + encodeURIComponent(p);
                html += '<div class="image-thumb" data-img-idx="' + i + '">'
                    + '<img src="' + imgSrc + '" alt="Page ' + (i+1) + '" loading="lazy">'
                    + '<div class="image-thumb-caption" title="' + escapeHtml(fname) + '">' + escapeHtml(fname) + '</div>'
                    + '</div>';
            });
            html += '</div>';
        } else {
            html += '<div class="no-images">No evidence pages</div>';
        }
        html += '<div class="right-section-label" style="margin-top:20px;">Source PDF</div>';
        if (item.pdf_path) {
            var pdfSrc = '/pdf?path=' + encodeURIComponent(item.pdf_path);
            var pdfName = item.pdf_path.split(/[/\\]/).pop();
            html += '<div class="pdf-section">'
                + '<button class="pdf-btn" data-pdf-src="' + escapeHtml(pdfSrc) + '" data-pdf-name="' + escapeHtml(pdfName) + '">'
                + '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>'
                + 'View PDF: ' + escapeHtml(pdfName)
                + '</button>'
                + '<div class="pdf-path">' + escapeHtml(item.pdf_path) + '</div>'
                + '</div>';
        } else {
            html += '<div class="no-pdf">No PDF path available</div>';
        }
        html += '</div></div>';
        queryDetail.innerHTML = html;
        queryDetail.querySelectorAll('.image-thumb').forEach(function(thumb) {
            thumb.addEventListener('click', function() {
                openLightbox(item.page_path, parseInt(thumb.dataset.imgIdx));
            });
        });
        var pdfBtn = queryDetail.querySelector('.pdf-btn');
        if (pdfBtn) {
            pdfBtn.addEventListener('click', function() {
                openPdfModal(pdfBtn.dataset.pdfSrc, pdfBtn.dataset.pdfName);
            });
        }
        queryDetail.querySelectorAll('[data-section]').forEach(function(header) {
            header.addEventListener('click', function() {
                var body = header.nextElementSibling;
                var toggle = header.querySelector('.section-toggle');
                body.classList.toggle('collapsed');
                toggle.classList.toggle('collapsed');
            });
        });
    }

    function parseResponse(response) {
        if (!response) return [];
        var sections = [];
        var observeMatch = response.match(/<observe>([\s\S]*?)<\/observe>/);
        if (observeMatch) {
            sections.push({ type: 'observe', label: 'Observation / \u89c2\u5bdf', content: observeMatch[1].trim() });
        }
        var evidenceMatch = response.match(/<evidence>([\s\S]*?)<\/evidence>/);
        if (evidenceMatch) {
            sections.push({ type: 'evidence', label: 'Evidence / \u8bc1\u636e', content: evidenceMatch[1].trim() });
        }
        var thinkingContent = extractThinking(response);
        if (thinkingContent) {
            sections.push({ type: 'thinking', label: 'Thinking / \u601d\u8003', content: thinkingContent });
        }
        var answerMatch = response.match(/<answer>([\s\S]*?)<\/answer>/);
        if (answerMatch) {
            sections.push({ type: 'answer', label: 'RAG Answer / \u56de\u7b54', content: answerMatch[1].trim() });
        }
        if (sections.length === 0) {
            sections.push({ type: 'answer', label: 'Response', content: response.trim() });
        }
        return sections;
    }

    function extractThinking(response) {
        var evidenceEnd = response.indexOf('</evidence>');
        var answerStart = response.indexOf('<answer>');
        if (evidenceEnd === -1 && answerStart === -1) return '';
        var start = evidenceEnd !== -1 ? evidenceEnd + '</evidence>'.length : 0;
        var end = answerStart !== -1 ? answerStart : response.length;
        var text = response.substring(start, end).trim();
        text = text.replace(/^\n+/, '').replace(/\n+$/, '');
        if (text.length < 10) return '';
        return text;
    }

    function openLightbox(images, idx) {
        lightboxImages = images;
        lightboxIdx = idx;
        updateLightbox();
        lightbox.style.display = '';
    }

    function updateLightbox() {
        var p = lightboxImages[lightboxIdx];
        var fname = p.split(/[/\\]/).pop();
        lightboxImg.src = '/image?path=' + encodeURIComponent(p);
        lightboxCaption.textContent = 'Page ' + (lightboxIdx + 1) + ' / ' + lightboxImages.length + '  -  ' + fname;
        lightboxPrev.style.display = lightboxIdx > 0 ? '' : 'none';
        lightboxNext.style.display = lightboxIdx < lightboxImages.length - 1 ? '' : 'none';
    }

    function closeLightbox() {
        lightbox.style.display = 'none';
        lightboxImg.src = '';
    }

    lightboxClose.addEventListener('click', closeLightbox);
    lightboxPrev.addEventListener('click', function() {
        if (lightboxIdx > 0) { lightboxIdx--; updateLightbox(); }
    });
    lightboxNext.addEventListener('click', function() {
        if (lightboxIdx < lightboxImages.length - 1) { lightboxIdx++; updateLightbox(); }
    });
    lightbox.addEventListener('click', function(e) {
        if (e.target === lightbox) closeLightbox();
    });
    document.addEventListener('keydown', function(e) {
        if (lightbox.style.display !== 'none') {
            if (e.key === 'Escape') closeLightbox();
            if (e.key === 'ArrowLeft' && lightboxIdx > 0) { lightboxIdx--; updateLightbox(); }
            if (e.key === 'ArrowRight' && lightboxIdx < lightboxImages.length - 1) { lightboxIdx++; updateLightbox(); }
        }
        if (pdfModal.style.display !== 'none' && e.key === 'Escape') closePdfModal();
    });

    function openPdfModal(src, name) {
        pdfIframe.src = src;
        pdfModalTitle.textContent = name || 'PDF Viewer';
        pdfModal.style.display = '';
    }

    function closePdfModal() {
        pdfModal.style.display = 'none';
        pdfIframe.src = '';
    }

    pdfModalClose.addEventListener('click', closePdfModal);

    function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }
})();