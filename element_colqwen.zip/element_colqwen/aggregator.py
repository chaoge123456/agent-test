"""Aggregator: combine per-token embeddings into a single element-level embedding."""

from __future__ import annotations

from enum import Enum
from typing import List

import numpy as np
import torch

from element_colqwen.spatial_mapper import PatchMapping


class AggStrategy(str, Enum):
    MEAN = "mean"              # unweighted average (stable, recommended)
    MAX = "max"                # max-pool across tokens
    WEIGHTED_MEAN = "weighted"  # weighted by overlap ratio (IoU strategy only)


def aggregate(
    image_embeddings: torch.Tensor,        # (num_image_tokens, embed_dim)
    mappings: dict,                        # {element_id: PatchMapping}
    strategy: AggStrategy = AggStrategy.MEAN,
) -> dict:
    """Aggregate image-token embeddings into per-element embeddings.

    Parameters
    ----------
    image_embeddings : torch.Tensor
        Pure image-token embeddings, shape ``(N, D)``.
    mappings : dict
        Output of ``SpatialMapper.map()``.
    strategy : AggStrategy
        Aggregation method.

    Returns
    -------
    dict
        ``{element_id: np.ndarray(embed_dim,)}``
    """
    embeds_np = image_embeddings.cpu().float().numpy()  # (N, D)
    results: dict = {}

    for elem_id, mapping in mappings.items():
        if not mapping.token_indices:
            results[elem_id] = None
            continue

        selected = embeds_np[mapping.token_indices]  # (K, D)

        if strategy == AggStrategy.MEAN:
            agg = selected.mean(axis=0)

        elif strategy == AggStrategy.MAX:
            agg = selected.max(axis=0)

        elif strategy == AggStrategy.WEIGHTED_MEAN:
            weights = np.array(mapping.weights, dtype=np.float32)  # (K,)
            # Normalise weights to sum to 1
            w_sum = weights.sum()
            if w_sum > 0:
                weights = weights / w_sum
            else:
                weights = np.ones_like(weights) / len(weights)
            agg = (selected * weights[:, None]).sum(axis=0)

        else:
            raise ValueError(f"Unknown strategy: {strategy}")

        results[elem_id] = agg

    return results
