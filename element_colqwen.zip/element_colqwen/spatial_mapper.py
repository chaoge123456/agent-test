"""Spatial mapper: map layout element bboxes to ColQwen patch token indices.

Two strategies are provided:

1. **Center-point matching** — a patch is assigned to an element if the patch
   center falls inside the element bbox.  Fast and simple.

2. **IoU-weighted matching** — every patch that overlaps the element bbox is
   assigned, with a weight proportional to the overlap ratio.  More robust,
   especially for small or boundary-crossing elements.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Tuple

from element_colqwen.utils import (
    LayoutElement,
    bbox_to_resized,
    compute_patch_grid,
    overlap_ratio,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Matching strategy enum
# ---------------------------------------------------------------------------

class MatchStrategy(str, Enum):
    CENTER = "center"       # patch center ∈ element bbox
    IOU = "iou"             # overlap-ratio ≥ threshold


# ---------------------------------------------------------------------------
# Mapping result
# ---------------------------------------------------------------------------

@dataclass
class PatchMapping:
    """Token indices and weights for a single element."""

    element_id: str
    token_indices: List[int]
    weights: List[float]  # 1.0 for center-match; overlap_ratio for iou-match


# ---------------------------------------------------------------------------
# Mapper
# ---------------------------------------------------------------------------

class SpatialMapper:
    """Map layout bounding boxes → ColQwen merged-patch token indices.

    Parameters
    ----------
    strategy : MatchStrategy
        ``CENTER`` or ``IOU``.
    iou_threshold : float
        For IOU strategy: minimum ``overlap_ratio(patch, element)`` to include
        the patch.  Ignored for CENTER strategy.
    """

    def __init__(
        self,
        strategy: MatchStrategy = MatchStrategy.IOU,
        iou_threshold: float = 0.3,
    ):
        self.strategy = strategy
        self.iou_threshold = iou_threshold

    def map(
        self,
        elements: List[LayoutElement],
        orig_w: int,
        orig_h: int,
        resized_w: int,
        resized_h: int,
        grid_h: int,
        grid_w: int,
    ) -> Dict[str, PatchMapping]:
        """Compute patch-to-element mapping for all elements.

        Returns a dict ``{element_id: PatchMapping}``.
        """
        patch_pixel_h = resized_h / grid_h
        patch_pixel_w = resized_w / grid_w

        mappings: Dict[str, PatchMapping] = {}

        for elem in elements:
            # Transform bbox to resized coordinate system
            rbbox = bbox_to_resized(elem.bbox, orig_w, orig_h, resized_w, resized_h)

            if self.strategy == MatchStrategy.CENTER:
                indices, weights = self._match_center(
                    rbbox, grid_h, grid_w, patch_pixel_h, patch_pixel_w,
                )
            else:
                indices, weights = self._match_iou(
                    rbbox, grid_h, grid_w, patch_pixel_h, patch_pixel_w,
                )

            mappings[elem.element_id] = PatchMapping(
                element_id=elem.element_id,
                token_indices=indices,
                weights=weights,
            )

            if not indices:
                logger.warning(
                    "Element '%s' (bbox=%s, resized=%s) matched 0 patches.",
                    elem.element_id, elem.bbox, rbbox,
                )

        return mappings

    # ------------------------------------------------------------------
    # Center-point matching
    # ------------------------------------------------------------------

    @staticmethod
    def _match_center(
        rbbox: List[float],
        grid_h: int,
        grid_w: int,
        patch_pixel_h: float,
        patch_pixel_w: float,
    ) -> Tuple[List[int], List[float]]:
        """Return token indices whose patch center falls inside *rbbox*."""
        indices: List[int] = []
        for ph in range(grid_h):
            cy = (ph + 0.5) * patch_pixel_h
            if cy < rbbox[1] or cy > rbbox[3]:
                continue
            for pw in range(grid_w):
                cx = (pw + 0.5) * patch_pixel_w
                if rbbox[0] <= cx <= rbbox[2]:
                    indices.append(ph * grid_w + pw)
        return indices, [1.0] * len(indices)

    # ------------------------------------------------------------------
    # IoU-weighted matching
    # ------------------------------------------------------------------

    def _match_iou(
        self,
        rbbox: List[float],
        grid_h: int,
        grid_w: int,
        patch_pixel_h: float,
        patch_pixel_w: float,
    ) -> Tuple[List[int], List[float]]:
        """Return token indices with overlap_ratio ≥ threshold and their weights."""
        indices: List[int] = []
        weights: List[float] = []

        for ph in range(grid_h):
            y1 = ph * patch_pixel_h
            y2 = y1 + patch_pixel_h
            # Early skip: patch row does not intersect element vertically
            if y2 <= rbbox[1] or y1 >= rbbox[3]:
                continue
            for pw in range(grid_w):
                x1 = pw * patch_pixel_w
                x2 = x1 + patch_pixel_w
                patch_box = [x1, y1, x2, y2]
                ratio = overlap_ratio(patch_box, rbbox)
                if ratio >= self.iou_threshold:
                    idx = ph * grid_w + pw
                    indices.append(idx)
                    weights.append(ratio)

        return indices, weights
