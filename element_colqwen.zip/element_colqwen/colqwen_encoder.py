"""ColQwen encoder: supports ColQwen2.5 / ColQwen3 / ColQwen3.5 via colpali-engine."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import List, Optional, Tuple

import torch
from PIL import Image

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Encoder output
# ---------------------------------------------------------------------------

@dataclass
class EncoderOutput:
    """Structured output from the ColQwen encoder.

    Attributes
    ----------
    image_embeddings : torch.Tensor
        Pure image-token embeddings, shape ``(num_image_tokens, embed_dim)``.
        Non-image tokens (instruction, padding) are already filtered out.
    grid_h : int
        Number of merged-patch rows (LLM-level grid height).
    grid_w : int
        Number of merged-patch columns (LLM-level grid width).
    resized_h : int
        Image height after smart_resize.
    resized_w : int
        Image width after smart_resize.
    embed_dim : int
        Embedding dimension (128 for ColQwen2/2.5, 320 for ColQwen3/3.5).
    patch_size : int
        ViT patch size (typically 14).
    spatial_merge_size : int
        Spatial merge factor (typically 2).
    """

    image_embeddings: torch.Tensor
    grid_h: int
    grid_w: int
    resized_h: int
    resized_w: int
    embed_dim: int
    patch_size: int
    spatial_merge_size: int


# ---------------------------------------------------------------------------
# Model variants registry
# ---------------------------------------------------------------------------

_MODEL_REGISTRY: dict = {
    # (model_class_name, processor_class_name) within colpali_engine.models
    "colqwen2":   ("ColQwen2",   "ColQwen2Processor"),
    "colqwen2.5": ("ColQwen2_5", "ColQwen2_5_Processor"),
    "colqwen3":   ("ColQwen3",   "ColQwen3Processor"),
    "colqwen3.5": ("ColQwen3_5", "ColQwen3_5_Processor"),
}


def _auto_detect_variant(model_name: str) -> str:
    """Infer the model variant from a HuggingFace repo name."""
    lower = model_name.lower()
    if "colqwen3.5" in lower or "colqwen3_5" in lower:
        return "colqwen3.5"
    if "colqwen3" in lower:
        return "colqwen3"
    if "colqwen2.5" in lower or "colqwen2_5" in lower:
        return "colqwen2.5"
    if "colqwen2" in lower:
        return "colqwen2"
    # Default to colqwen2.5 as the most common
    logger.warning("Cannot auto-detect variant from '%s', defaulting to colqwen2.5", model_name)
    return "colqwen2.5"


def _import_model_classes(variant: str):
    """Dynamically import model and processor classes from colpali_engine."""
    if variant not in _MODEL_REGISTRY:
        raise ValueError(
            f"Unknown variant '{variant}'. Choose from: {list(_MODEL_REGISTRY.keys())}"
        )
    model_cls_name, proc_cls_name = _MODEL_REGISTRY[variant]

    try:
        import colpali_engine.models as models_pkg  # type: ignore

        model_cls = getattr(models_pkg, model_cls_name)
        proc_cls = getattr(models_pkg, proc_cls_name)
    except (ImportError, AttributeError) as exc:
        raise ImportError(
            f"Cannot import {model_cls_name}/{proc_cls_name} from colpali_engine. "
            f"Ensure colpali-engine>=0.3.9 is installed. Error: {exc}"
        ) from exc

    return model_cls, proc_cls


# ---------------------------------------------------------------------------
# Main encoder class
# ---------------------------------------------------------------------------

class ColQwenEncoder:
    """Encode a document image with ColQwen and extract pure image-token embeddings.

    Parameters
    ----------
    model_name : str
        HuggingFace model identifier, e.g. ``"vidore/colqwen2.5-v0.2"``.
    variant : str or None
        One of ``"colqwen2"``, ``"colqwen2.5"``, ``"colqwen3"``, ``"colqwen3.5"``.
        If ``None``, auto-detected from *model_name*.
    device : str
        Torch device (``"cuda:0"``, ``"cpu"``, etc.).
    max_num_visual_tokens : int or None
        Cap on visual token count.  Affects ``max_pixels`` in the processor.
    torch_dtype : torch.dtype
        Model weight dtype.
    """

    def __init__(
        self,
        model_name: str = "vidore/colqwen2.5-v0.2",
        variant: Optional[str] = None,
        device: str = "cuda:0",
        max_num_visual_tokens: Optional[int] = None,
        torch_dtype: torch.dtype = torch.bfloat16,
    ):
        self.model_name = model_name
        self.variant = variant or _auto_detect_variant(model_name)
        self.device = device
        self.torch_dtype = torch_dtype

        model_cls, proc_cls = _import_model_classes(self.variant)

        # Build processor kwargs
        proc_kwargs: dict = {}
        if max_num_visual_tokens is not None:
            proc_kwargs["max_num_visual_tokens"] = max_num_visual_tokens

        self.model = model_cls.from_pretrained(
            model_name,
            torch_dtype=torch_dtype,
            device_map=device,
        ).eval()
        self.processor = proc_cls.from_pretrained(model_name, **proc_kwargs)

        # Cache model config
        self.patch_size: int = self.model.patch_size
        self.spatial_merge_size: int = self.model.spatial_merge_size

        logger.info(
            "ColQwenEncoder ready: variant=%s, patch_size=%d, spatial_merge=%d, device=%s",
            self.variant, self.patch_size, self.spatial_merge_size, device,
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def encode(self, image: Image.Image) -> EncoderOutput:
        """Encode a single document image.

        Parameters
        ----------
        image : PIL.Image.Image
            Document page image.  **Do not resize beforehand** — the processor
            handles dynamic resolution via ``smart_resize`` internally.

        Returns
        -------
        EncoderOutput
            Image-only embeddings + spatial grid metadata.
        """
        orig_w, orig_h = image.size  # PIL: (width, height)

        # 1. Preprocess (the processor calls smart_resize internally)
        batch = self.processor.process_images([image]).to(self.device)

        # 2. Forward pass — full sequence (image + instruction + padding tokens)
        with torch.no_grad():
            all_embeddings = self.model(**batch)  # (1, seq_len, embed_dim)

        # 3. Filter to image-only tokens
        image_mask = self.processor.get_image_mask(batch)  # (1, seq_len) bool
        image_embeddings = all_embeddings[image_mask.unsqueeze(-1).expand_as(all_embeddings)]
        image_embeddings = image_embeddings.view(-1, all_embeddings.shape[-1])
        # shape: (num_image_tokens, embed_dim)

        # 4. Derive grid dimensions
        grid_thw = batch["image_grid_thw"][0]  # [T, H, W]
        grid_h = grid_thw[1].item()
        grid_w = grid_thw[2].item()

        embed_dim = image_embeddings.shape[-1]

        # 5. Compute the resized image dimensions (for coordinate mapping)
        resized_h, resized_w = self._compute_resized_dims(orig_h, orig_w)

        # Sanity check
        expected_tokens = grid_h * grid_w
        actual_tokens = image_embeddings.shape[0]
        if expected_tokens != actual_tokens:
            logger.warning(
                "Token count mismatch: grid says %d (%d×%d), got %d tokens. "
                "Proceeding with actual token count.",
                expected_tokens, grid_h, grid_w, actual_tokens,
            )

        return EncoderOutput(
            image_embeddings=image_embeddings,
            grid_h=grid_h,
            grid_w=grid_w,
            resized_h=resized_h,
            resized_w=resized_w,
            embed_dim=embed_dim,
            patch_size=self.patch_size,
            spatial_merge_size=self.spatial_merge_size,
        )

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _compute_resized_dims(self, orig_h: int, orig_w: int) -> Tuple[int, int]:
        """Re-compute the smart_resize output dimensions.

        We need these to build the pixel-level coordinate mapping.
        The processor's image_processor stores the relevant config.
        """
        from element_colqwen.utils import smart_resize

        ip = self.processor.image_processor
        factor = self.patch_size * ip.merge_size  # typically 14 * 2 = 28
        min_pixels = ip.size.get("shortest_edge", 256 * 28 * 28)
        max_pixels = ip.size.get("longest_edge", ip.max_pixels)

        return smart_resize(
            height=orig_h,
            width=orig_w,
            factor=factor,
            min_pixels=min_pixels,
            max_pixels=max_pixels,
        )
