"""Pipeline: orchestrate layout detection → ColQwen encoding → spatial mapping → aggregation."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Dict, List, Optional

from PIL import Image

from element_colqwen.aggregator import AggStrategy, aggregate
from element_colqwen.colqwen_encoder import ColQwenEncoder
from element_colqwen.layout_detector import BaseLayoutDetector, BBoxLayoutDetector, PaddleLayoutDetector
from element_colqwen.spatial_mapper import MatchStrategy, SpatialMapper
from element_colqwen.utils import ElementResult, LayoutElement

logger = logging.getLogger(__name__)


class ElementEmbeddingPipeline:
    """End-to-end pipeline for element-level ColQwen embedding extraction.

    Parameters
    ----------
    encoder : ColQwenEncoder
        A configured encoder instance.
    layout_detector : BaseLayoutDetector or None
        Layout detector.  If ``None``, you must pass ``layout_elements`` to
        :meth:`run`.
    match_strategy : MatchStrategy
        Spatial matching strategy (``CENTER`` or ``IOU``).
    iou_threshold : float
        Overlap-ratio threshold for IOU matching.
    agg_strategy : AggStrategy
        Embedding aggregation strategy.
    """

    def __init__(
        self,
        encoder: ColQwenEncoder,
        layout_detector: Optional[BaseLayoutDetector] = None,
        match_strategy: MatchStrategy = MatchStrategy.IOU,
        iou_threshold: float = 0.3,
        agg_strategy: AggStrategy = AggStrategy.MEAN,
    ):
        self.encoder = encoder
        self.layout_detector = layout_detector
        self.match_strategy = match_strategy
        self.iou_threshold = iou_threshold
        self.agg_strategy = agg_strategy

        self.mapper = SpatialMapper(
            strategy=match_strategy,
            iou_threshold=iou_threshold,
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(
        self,
        image_path: str,
        layout_elements: Optional[List[LayoutElement]] = None,
    ) -> List[ElementResult]:
        """Run the full pipeline on a single document image.

        Parameters
        ----------
        image_path : str
            Path to the document image.
        layout_elements : list of LayoutElement or None
            Pre-computed layout elements.  If ``None``, the pipeline's
            ``layout_detector`` will be used.

        Returns
        -------
        list of ElementResult
        """
        # Step 0: Load image
        image = Image.open(image_path).convert("RGB")
        orig_w, orig_h = image.size
        logger.info("Image loaded: %s (%d×%d)", image_path, orig_w, orig_h)

        # Step 1: Layout detection
        if layout_elements is None:
            if self.layout_detector is None:
                raise ValueError(
                    "No layout_detector configured and no layout_elements provided."
                )
            layout_elements = self.layout_detector.detect(image_path)
        logger.info("Layout elements: %d", len(layout_elements))

        if not layout_elements:
            logger.warning("No layout elements found — returning empty results.")
            return []

        # Step 2: ColQwen encoding
        enc_out = self.encoder.encode(image)
        logger.info(
            "Encoded: %d image tokens, grid=%d×%d, resized=%d×%d, dim=%d",
            enc_out.image_embeddings.shape[0],
            enc_out.grid_h, enc_out.grid_w,
            enc_out.resized_h, enc_out.resized_w,
            enc_out.embed_dim,
        )

        # Step 3: Spatial mapping
        mappings = self.mapper.map(
            elements=layout_elements,
            orig_w=orig_w,
            orig_h=orig_h,
            resized_w=enc_out.resized_w,
            resized_h=enc_out.resized_h,
            grid_h=enc_out.grid_h,
            grid_w=enc_out.grid_w,
        )
        total_mapped = sum(len(m.token_indices) for m in mappings.values())
        logger.info("Spatial mapping: %d element-patch assignments", total_mapped)

        # Step 4: Aggregation
        agg_embeddings = aggregate(
            image_embeddings=enc_out.image_embeddings,
            mappings=mappings,
            strategy=self.agg_strategy,
        )

        # Step 5: Assemble results
        results: List[ElementResult] = []
        for elem in layout_elements:
            mapping = mappings.get(elem.element_id)
            embedding = agg_embeddings.get(elem.element_id)

            results.append(
                ElementResult(
                    element_id=elem.element_id,
                    label=elem.label,
                    confidence=elem.confidence,
                    bbox=elem.bbox,
                    token_indices=mapping.token_indices if mapping else [],
                    embedding=embedding,
                )
            )

        # Step 6: Validation
        self._validate(results, enc_out.embed_dim)

        logger.info("Pipeline complete: %d element embeddings produced", len(results))
        return results

    # ------------------------------------------------------------------
    # Batch convenience
    # ------------------------------------------------------------------

    def run_batch(
        self,
        image_paths: List[str],
        layout_elements_per_image: Optional[List[Optional[List[LayoutElement]]]] = None,
    ) -> List[List[ElementResult]]:
        """Run the pipeline on multiple images sequentially.

        For true batch inference (single forward pass for multiple images),
        use :meth:`run` and manage batching at the encoder level.
        """
        if layout_elements_per_image is None:
            per_image: List[Optional[List[LayoutElement]]] = [
                None for _ in image_paths
            ]
            layout_elements_per_image = per_image

        all_results: List[List[ElementResult]] = []
        for img_path, elements in zip(image_paths, layout_elements_per_image):
            results = self.run(img_path, layout_elements=elements)
            all_results.append(results)
        return all_results

    # ------------------------------------------------------------------
    # Output helpers
    # ------------------------------------------------------------------

    @staticmethod
    def save_json(results: List[ElementResult], output_path: str) -> None:
        """Save results to a JSON file."""
        data = [r.to_dict() for r in results]
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        logger.info("Results saved to %s", output_path)

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    @staticmethod
    def _validate(results: List[ElementResult], expected_dim: int) -> None:
        """Run basic sanity checks on the output."""
        empty_count = 0
        dim_mismatch = 0
        for r in results:
            if r.embedding is None or len(r.token_indices) == 0:
                empty_count += 1
                continue
            if r.embedding.shape[0] != expected_dim:
                dim_mismatch += 1
                logger.error(
                    "Element '%s': embedding dim %d != expected %d",
                    r.element_id, r.embedding.shape[0], expected_dim,
                )
        if empty_count:
            logger.warning("%d / %d elements have no embedding", empty_count, len(results))
        if dim_mismatch:
            logger.error("%d / %d elements have wrong embedding dimension", dim_mismatch, len(results))


# ---------------------------------------------------------------------------
# Factory helper
# ---------------------------------------------------------------------------

def create_pipeline(
    model_name: str = "vidore/colqwen2.5-v0.2",
    variant: Optional[str] = None,
    device: str = "cuda:0",
    max_num_visual_tokens: Optional[int] = None,
    use_paddle_layout: bool = True,
    layout_model_name: str = "PP-DocBlockLayout",
    confidence_threshold: float = 0.5,
    match_strategy: str = "iou",
    iou_threshold: float = 0.3,
    agg_strategy: str = "mean",
) -> ElementEmbeddingPipeline:
    """Convenience factory that builds the full pipeline with defaults.

    Parameters
    ----------
    model_name : str
        HuggingFace ColQwen model identifier.
    variant : str or None
        Auto-detected if ``None``.
    device : str
        Torch device.
    max_num_visual_tokens : int or None
        Cap on visual tokens.
    use_paddle_layout : bool
        If ``True``, use PaddleLayoutDetector; otherwise, a no-op detector
        (you must supply layout elements manually).
    layout_model_name : str
        PaddleX layout model name.
    confidence_threshold : float
        Layout confidence filter.
    match_strategy : str
        ``"center"`` or ``"iou"``.
    iou_threshold : float
        Overlap ratio threshold for IoU matching.
    agg_strategy : str
        ``"mean"``, ``"max"``, or ``"weighted"``.

    Returns
    -------
    ElementEmbeddingPipeline
    """
    encoder = ColQwenEncoder(
        model_name=model_name,
        variant=variant,
        device=device,
        max_num_visual_tokens=max_num_visual_tokens,
    )

    detector: Optional[BaseLayoutDetector] = None
    if use_paddle_layout:
        detector = PaddleLayoutDetector(
            model_name=layout_model_name,
            confidence_threshold=confidence_threshold,
        )

    return ElementEmbeddingPipeline(
        encoder=encoder,
        layout_detector=detector,
        match_strategy=MatchStrategy(match_strategy),
        iou_threshold=iou_threshold,
        agg_strategy=AggStrategy(agg_strategy),
    )
