"""Utility functions: coordinate transforms, data classes, smart_resize fallback."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import numpy as np
import torch


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class LayoutElement:
    """A single detected layout region."""

    element_id: str
    label: str
    confidence: float
    bbox: List[float]  # [x1, y1, x2, y2] in original pixel coordinates

    def area(self) -> float:
        return max(0.0, (self.bbox[2] - self.bbox[0]) * (self.bbox[3] - self.bbox[1]))


@dataclass
class ElementResult:
    """Final output for one element: metadata + token indices + embedding."""

    element_id: str
    label: str
    confidence: float
    bbox: List[float]                                  # original pixel coords
    token_indices: List[int] = field(default_factory=list)
    embedding: Optional[np.ndarray] = None             # shape: (embed_dim,)

    def to_dict(self) -> dict:
        return {
            "element_id": self.element_id,
            "label": self.label,
            "confidence": self.confidence,
            "bbox": self.bbox,
            "token_indices": self.token_indices,
            "embedding": self.embedding.tolist() if self.embedding is not None else None,
        }


# ---------------------------------------------------------------------------
# smart_resize — mirrors Qwen2-VL / Qwen2.5-VL preprocessing logic
# ---------------------------------------------------------------------------

def smart_resize(
    height: int,
    width: int,
    factor: int = 28,
    min_pixels: int = 256 * 28 * 28,
    max_pixels: int = 768 * 28 * 28,
) -> Tuple[int, int]:
    """Rescale dimensions to multiples of *factor* within [min_pixels, max_pixels].

    This is a faithful re-implementation of
    ``transformers.models.qwen2_vl.image_processing_qwen2_vl.smart_resize``.
    It preserves the aspect ratio.

    Returns (resized_height, resized_width).
    """
    if min_pixels < factor * factor:
        raise ValueError(f"min_pixels ({min_pixels}) must be >= factor^2 ({factor*factor})")

    h_bar = max(factor, round(height / factor) * factor)
    w_bar = max(factor, round(width / factor) * factor)

    if h_bar * w_bar > max_pixels:
        beta = math.sqrt((height * width) / max_pixels)
        h_bar = max(factor, math.floor(height / beta / factor) * factor)
        w_bar = max(factor, math.floor(width / beta / factor) * factor)
    elif h_bar * w_bar < min_pixels:
        beta = math.sqrt(min_pixels / (height * width))
        h_bar = max(factor, math.ceil(height * beta / factor) * factor)
        w_bar = max(factor, math.ceil(width * beta / factor) * factor)

    return h_bar, w_bar


# ---------------------------------------------------------------------------
# Coordinate transform helpers
# ---------------------------------------------------------------------------

def bbox_to_resized(
    bbox: List[float],
    orig_w: int,
    orig_h: int,
    resized_w: int,
    resized_h: int,
) -> List[float]:
    """Map a bbox from original image coordinates to smart_resize'd coordinates."""
    sx = resized_w / orig_w
    sy = resized_h / orig_h
    return [bbox[0] * sx, bbox[1] * sy, bbox[2] * sx, bbox[3] * sy]


def compute_patch_grid(
    resized_h: int,
    resized_w: int,
    patch_size: int = 14,
    spatial_merge_size: int = 2,
) -> Tuple[int, int, float, float]:
    """Return (grid_h, grid_w, patch_pixel_h, patch_pixel_w) at the LLM (merged) level.

    - grid_h / grid_w: number of merged tokens along each axis.
    - patch_pixel_h / patch_pixel_w: pixel coverage of each merged token in the
      resized image.
    """
    vit_grid_h = resized_h // patch_size
    vit_grid_w = resized_w // patch_size
    grid_h = vit_grid_h // spatial_merge_size
    grid_w = vit_grid_w // spatial_merge_size
    patch_pixel_h = resized_h / grid_h
    patch_pixel_w = resized_w / grid_w
    return grid_h, grid_w, patch_pixel_h, patch_pixel_w


def compute_iou(box_a: List[float], box_b: List[float]) -> float:
    """IoU between two [x1, y1, x2, y2] boxes."""
    xi1 = max(box_a[0], box_b[0])
    yi1 = max(box_a[1], box_b[1])
    xi2 = min(box_a[2], box_b[2])
    yi2 = min(box_a[3], box_b[3])
    inter = max(0.0, xi2 - xi1) * max(0.0, yi2 - yi1)
    area_a = max(0.0, (box_a[2] - box_a[0]) * (box_a[3] - box_a[1]))
    area_b = max(0.0, (box_b[2] - box_b[0]) * (box_b[3] - box_b[1]))
    union = area_a + area_b - inter
    return inter / union if union > 0 else 0.0


def overlap_ratio(patch_box: List[float], element_box: List[float]) -> float:
    """Ratio of overlap area to patch area (how much of the patch is inside the element)."""
    xi1 = max(patch_box[0], element_box[0])
    yi1 = max(patch_box[1], element_box[1])
    xi2 = min(patch_box[2], element_box[2])
    yi2 = min(patch_box[3], element_box[3])
    inter = max(0.0, xi2 - xi1) * max(0.0, yi2 - yi1)
    patch_area = max(1e-6, (patch_box[2] - patch_box[0]) * (patch_box[3] - patch_box[1]))
    return inter / patch_area
