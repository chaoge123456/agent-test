"""Quick-start example for element-level ColQwen embedding extraction.

Usage
-----
# With PP-DocBlockLayout (PaddleX):
python run_example.py --image doc.png

# With pre-supplied bounding boxes (no PaddleX):
python run_example.py --image doc.png --use-bbox-json boxes.json

# Choosing model / strategy:
python run_example.py --image doc.png --model vidore/colqwen2.5-v0.2 --match iou --agg mean
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

from element_colqwen.layout_detector import BBoxLayoutDetector
from element_colqwen.pipeline import ElementEmbeddingPipeline, create_pipeline
from element_colqwen.utils import LayoutElement

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


def parse_args():
    p = argparse.ArgumentParser(description="Element-level ColQwen embedding extraction")
    p.add_argument("--image", required=True, help="Path to document image")
    p.add_argument("--model", default="vidore/colqwen2.5-v0.2", help="ColQwen model name")
    p.add_argument("--variant", default=None, help="Force model variant (colqwen2/2.5/3/3.5)")
    p.add_argument("--device", default="cuda:0", help="Torch device")
    p.add_argument("--max-visual-tokens", type=int, default=None, help="Max visual tokens")
    p.add_argument("--match", default="iou", choices=["center", "iou"], help="Matching strategy")
    p.add_argument("--iou-threshold", type=float, default=0.3, help="IoU overlap threshold")
    p.add_argument("--agg", default="mean", choices=["mean", "max", "weighted"], help="Aggregation strategy")
    p.add_argument("--conf-threshold", type=float, default=0.5, help="Layout confidence threshold")
    p.add_argument("--output", default="element_embeddings.json", help="Output JSON path")
    p.add_argument(
        "--use-bbox-json", default=None,
        help="Path to a JSON file with pre-computed bounding boxes (skip PaddleX). "
             "Format: [{\"coordinate\": [x1,y1,x2,y2], \"label\": \"text\", \"score\": 0.9}, ...]",
    )
    return p.parse_args()


def main():
    args = parse_args()

    # --- Build pipeline ---
    if args.use_bbox_json:
        # Load pre-computed bounding boxes
        with open(args.use_bbox_json, "r", encoding="utf-8") as f:
            boxes = json.load(f)
        detector = BBoxLayoutDetector(boxes=boxes)
        pipeline = create_pipeline(
            model_name=args.model,
            variant=args.variant,
            device=args.device,
            max_num_visual_tokens=args.max_visual_tokens,
            use_paddle_layout=False,
            match_strategy=args.match,
            iou_threshold=args.iou_threshold,
            agg_strategy=args.agg,
        )
        # Override detector
        pipeline.layout_detector = detector
    else:
        pipeline = create_pipeline(
            model_name=args.model,
            variant=args.variant,
            device=args.device,
            max_num_visual_tokens=args.max_visual_tokens,
            use_paddle_layout=True,
            confidence_threshold=args.conf_threshold,
            match_strategy=args.match,
            iou_threshold=args.iou_threshold,
            agg_strategy=args.agg,
        )

    # --- Run ---
    results = pipeline.run(args.image)

    # --- Print summary ---
    print(f"\n{'='*60}")
    print(f"  Element Embedding Extraction Results")
    print(f"{'='*60}")
    print(f"  Image: {args.image}")
    print(f"  Model: {args.model}")
    print(f"  Elements: {len(results)}")
    print(f"{'='*60}")

    for r in results:
        emb_info = f"dim={r.embedding.shape[0]}" if r.embedding is not None else "NONE"
        print(
            f"  [{r.element_id}] {r.label:12s}  "
            f"conf={r.confidence:.3f}  "
            f"tokens={len(r.token_indices):4d}  "
            f"emb={emb_info}  "
            f"bbox={[round(v, 1) for v in r.bbox]}"
        )
    print()

    # --- Save ---
    pipeline.save_json(results, args.output)
    print(f"Results saved to: {args.output}")


if __name__ == "__main__":
    main()
