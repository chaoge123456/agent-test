"""Layout detection: PP-DocBlockLayout wrapper and a generic bbox interface."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, List, Optional

from element_colqwen.utils import LayoutElement

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Abstract base
# ---------------------------------------------------------------------------

class BaseLayoutDetector(ABC):
    """Interface every layout detector must implement."""

    @abstractmethod
    def detect(self, image_path: str) -> List[LayoutElement]:
        """Return layout elements for a single image."""
        ...


# ---------------------------------------------------------------------------
# PP-DocBlockLayout detector (PaddleX)
# ---------------------------------------------------------------------------

class PaddleLayoutDetector(BaseLayoutDetector):
    """Wrapper for PP-DocBlockLayout via PaddleX.

    Expected PaddleX output format::

        {
            'res': {
                'boxes': [
                    {
                        'cls_id': 0,
                        'label': 'text',
                        'score': 0.97,
                        'coordinate': [x1, y1, x2, y2]
                    }, ...
                ]
            }
        }

    Parameters
    ----------
    model_name : str
        PaddleX model identifier (default ``"PP-DocBlockLayout"``).
    confidence_threshold : float
        Discard detections below this score.
    deduplicate_iou : float
        Remove boxes whose mutual IoU exceeds this value (keep higher score).
    """

    def __init__(
        self,
        model_name: str = "PP-DocBlockLayout",
        confidence_threshold: float = 0.5,
        deduplicate_iou: float = 0.8,
    ):
        self.model_name = model_name
        self.confidence_threshold = confidence_threshold
        self.deduplicate_iou = deduplicate_iou
        self._model: Optional[object] = None

    def _load_model(self):
        if self._model is not None:
            return
        try:
            from paddlex import create_model  # type: ignore

            self._model = create_model(self.model_name)
            logger.info("Loaded PaddleX layout model: %s", self.model_name)
        except ImportError:
            raise ImportError(
                "PaddleX is required for PaddleLayoutDetector. "
                "Install with: pip install paddlex"
            )

    def detect(self, image_path: str) -> List[LayoutElement]:
        self._load_model()
        raw: Dict = self._model.predict(image_path)  # type: ignore[union-attr]

        # Navigate the nested dict structure
        boxes_raw: List[Dict] = []
        if "res" in raw:
            inner = raw["res"]
            if isinstance(inner, dict) and "boxes" in inner:
                boxes_raw = inner["boxes"]
            elif isinstance(inner, list):
                boxes_raw = inner
        # Fallback: if the model returns a list directly
        if not boxes_raw and isinstance(raw, list):
            boxes_raw = raw

        # Filter by confidence
        elements: List[LayoutElement] = []
        for idx, box in enumerate(boxes_raw):
            score = box.get("score", 0.0)
            if score < self.confidence_threshold:
                continue
            coord = box.get("coordinate", box.get("bbox", []))
            if len(coord) != 4:
                logger.warning("Skipping box %d: invalid coordinate %s", idx, coord)
                continue
            elements.append(
                LayoutElement(
                    element_id=f"element_{idx}",
                    label=box.get("label", "unknown"),
                    confidence=float(score),
                    bbox=[float(c) for c in coord],
                )
            )

        # Deduplicate
        elements = self._deduplicate(elements)
        logger.info("Detected %d layout elements after filtering", len(elements))
        return elements

    def _deduplicate(self, elements: List[LayoutElement]) -> List[LayoutElement]:
        """Remove highly-overlapping boxes, keeping the higher-confidence one."""
        from element_colqwen.utils import compute_iou

        if self.deduplicate_iou >= 1.0:
            return elements

        # Sort by confidence descending
        elements = sorted(elements, key=lambda e: e.confidence, reverse=True)
        keep: List[LayoutElement] = []
        for elem in elements:
            dominated = False
            for kept in keep:
                if compute_iou(elem.bbox, kept.bbox) > self.deduplicate_iou:
                    dominated = True
                    break
            if not dominated:
                keep.append(elem)
        return keep


# ---------------------------------------------------------------------------
# Generic bbox detector — accepts pre-computed bounding boxes directly
# ---------------------------------------------------------------------------

class BBoxLayoutDetector(BaseLayoutDetector):
    """A no-op detector that wraps pre-existing bounding boxes.

    Useful when layout detection has already been done externally.

    Parameters
    ----------
    boxes : list of dict
        Each dict must contain ``"coordinate"`` (or ``"bbox"``) as
        ``[x1, y1, x2, y2]``.  Optional keys: ``"label"``, ``"score"``.
    """

    def __init__(self, boxes: List[Dict]):
        self.boxes = boxes

    def detect(self, image_path: str) -> List[LayoutElement]:
        elements: List[LayoutElement] = []
        for idx, box in enumerate(self.boxes):
            coord = box.get("coordinate", box.get("bbox", []))
            if len(coord) != 4:
                continue
            elements.append(
                LayoutElement(
                    element_id=f"element_{idx}",
                    label=box.get("label", "Region"),
                    confidence=box.get("score", 1.0),
                    bbox=[float(c) for c in coord],
                )
            )
        return elements
