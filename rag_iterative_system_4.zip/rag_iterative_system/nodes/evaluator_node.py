# -*- coding: utf-8 -*-
"""
文档过滤、去重、信息增益量化评估节点
- 清洗过滤：文档去重、低质过滤、上下文长度裁剪
- 增益评估：量化计算单轮迭代信息增益分数
- 高置信度结果累加器（得分阈值 + 信息增益双重筛选）
- 支持RetrievalResult结构
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Set, Tuple

from rag_iterative_system.config.system_settings import get_settings
from rag_iterative_system.evaluation.filters import full_filter_pipeline
from rag_iterative_system.evaluation.metrics import (
    compute_coverage_score,
    compute_information_gain,
)
from rag_iterative_system.state.graph_state import (
    ConfidenceAccumulator,
    Document,
    GraphState,
    IterationLog,
    RetrievalNodeInfo,
    RetrievalResult,
)
from rag_iterative_system.utils.logging import get_iteration_logger

logger = logging.getLogger(__name__)


def _ensure_retrieval_results(docs: list) -> List[RetrievalResult]:
    """将混合类型文档列表统一转为 RetrievalResult 列表"""
    results: List[RetrievalResult] = []
    for doc in docs:
        if isinstance(doc, RetrievalResult):
            results.append(doc)
        elif isinstance(doc, dict):
            results.append(RetrievalResult.from_dict(doc))
        elif hasattr(doc, "content"):
            results.append(RetrievalResult(
                content=getattr(doc, "content", ""),
                source=getattr(doc, "source", "unknown"),
                score=getattr(doc, "score", 0.0),
                metadata=getattr(doc, "metadata", {}),
                doc_id=getattr(doc, "doc_id", ""),
                page_id=getattr(doc, "page_id", ""),
                chunk_id=getattr(doc, "chunk_id", ""),
            ))
    return results


def _extract_current_raw_docs(raw_documents: Any) -> List[RetrievalResult]:
    """
    从状态中提取当前轮的原始检索文档

    raw_documents是Annotated[list, operator.add]累积字段，
    这里直接当作当前轮的文档处理
    """
    if not raw_documents:
        return []

    if isinstance(raw_documents, list):
        results: List[RetrievalResult] = []
        for item in raw_documents:
            if isinstance(item, RetrievalResult):
                results.append(item)
            elif isinstance(item, Document):
                # 向后兼容
                results.append(RetrievalResult(
                    content=item.content,
                    source=item.source,
                    score=item.score,
                    metadata=item.metadata if hasattr(item, "metadata") else {},
                    doc_id=item.doc_id if hasattr(item, "doc_id") else "",
                ))
            elif isinstance(item, dict):
                results.append(RetrievalResult.from_dict(item))
        return results

    return []


def _collect_ids_from_results(
    results: List[RetrievalResult],
) -> Tuple[List[str], List[Tuple[str, str]]]:
    """
    从检索结果中收集候选 doc_id / page_id，供下钻传递

    Returns:
        (doc_ids, page_ids) - page_ids为(doc_id, page_id)元组列表
    """
    doc_ids: List[str] = []
    page_ids: List[Tuple[str, str]] = []

    seen_doc: Set[str] = set()
    seen_page: Set[str] = set()

    for result in results:
        # 收集 doc_id
        if result.doc_id and result.doc_id not in seen_doc:
            doc_ids.append(result.doc_id)
            seen_doc.add(result.doc_id)

        # 收集 (doc_id, page_id)
        if result.doc_id and result.page_id:
            page_key = f"{result.doc_id}::{result.page_id}"
            if page_key not in seen_page:
                page_ids.append((result.doc_id, result.page_id))
                seen_page.add(page_key)

    return doc_ids, page_ids


def evaluator_node(state: GraphState) -> dict:
    """
    结果评估节点

    执行完整的过滤流水线，计算信息增益，
    维护高置信度结果累加器。

    Args:
        state: 当前图状态

    Returns:
        状态更新字典
    """
    settings = get_settings()
    iter_logger = get_iteration_logger()
    iteration = state.get("iteration_count", 1)
    start_time = time.time()

    # 获取当前轮原始检索结果。raw_documents 是跨轮累积字段，不能用于本轮增益评估。
    current_raw_documents = state.get("current_raw_documents")
    if current_raw_documents is None:
        # 兼容旧状态：没有 current_raw_documents 时才回退到累积字段。
        current_raw_documents = state.get("raw_documents", [])
    raw_docs = _extract_current_raw_docs(current_raw_documents)

    # 获取历史优质文档
    doc_history = state.get("document_history", [])

    # ---- 过滤流水线 ----
    filtered_docs = full_filter_pipeline(raw_docs, history_docs=doc_history)

    # ---- 信息增益计算 ----
    information_gain = compute_information_gain(filtered_docs, doc_history)

    # ---- 历史文档合并（去重） ----
    updated_history = list(doc_history)
    existing_keys: Set[str] = set()
    for doc in updated_history:
        if isinstance(doc, RetrievalResult):
            existing_keys.add(f"{doc.doc_id}::{doc.page_id}::{doc.chunk_id}")
        else:
            existing_keys.add(doc.content.strip())

    for doc in filtered_docs:
        if isinstance(doc, RetrievalResult):
            key = f"{doc.doc_id}::{doc.page_id}::{doc.chunk_id}"
            if key not in existing_keys:
                updated_history.append(doc)
                existing_keys.add(key)
        else:
            content = doc.content.strip()
            if content not in existing_keys:
                updated_history.append(doc)
                existing_keys.add(content)

    # ---- 高置信度累加器 ----
    accumulator = state.get("confidence_accumulator")
    if accumulator is None:
        accumulator = ConfidenceAccumulator(
            confidence_threshold=settings.confidence_threshold,
            min_novelty=settings.min_novelty_threshold,
        )

    # 将过滤后结果送入累加器
    # 注意: existing_results 应为已累积结果（self.results），而非包含本轮结果的历史
    retrieval_results_for_acc = _ensure_retrieval_results(filtered_docs)
    high_confidence_new = accumulator.add_results(
        new_results=retrieval_results_for_acc,
        existing_results=None,  # 使用 accumulator 内部已累积的结果
    )

    # ---- 收集候选 ID（供漏斗下钻传递） ----
    all_retrieval_results = [
        r for r in updated_history if isinstance(r, RetrievalResult)
    ]
    candidate_doc_ids, candidate_page_ids = _collect_ids_from_results(all_retrieval_results)

    # 计算覆盖度
    original_query = state.get("original_query", "")
    coverage = compute_coverage_score(original_query, updated_history)

    iter_logger.log_evaluation(
        raw_count=len(raw_docs),
        filtered_count=len(filtered_docs),
        gain=information_gain,
    )

    logger.info(
        "评估完成 [Iter-%d]: 原始=%d, 过滤后=%d, 增益=%.4f, 覆盖度=%.2f, "
        "历史总量=%d, 累加器=%d, 候选doc=%d, 候选page=%d",
        iteration,
        len(raw_docs),
        len(filtered_docs),
        information_gain,
        coverage,
        len(updated_history),
        len(accumulator.results),
        len(candidate_doc_ids),
        len(candidate_page_ids),
    )

    # 构建迭代日志
    iter_log = IterationLog(
        iteration=iteration,
        rewritten_queries=_get_current_queries(state),
        routing_decision=_get_routing_summary(state),
        retrieved_count=len(raw_docs),
        filtered_count=len(filtered_docs),
        information_gain=information_gain,
    )

    end_time = time.time()
    duration_ms = (end_time - start_time) * 1000

    # 构建检索节点追踪信息（需求4）
    node_info = RetrievalNodeInfo(
        iteration=iteration,
        node_name="evaluator",
        status="completed",
        start_time=start_time,
        end_time=end_time,
        duration_ms=duration_ms,
        input_summary={
            "raw_docs": len(raw_docs),
            "history_docs": len(doc_history),
        },
        output_summary={
            "filtered_docs": len(filtered_docs),
            "information_gain": information_gain,
            "coverage": coverage,
            "candidate_doc_ids": len(candidate_doc_ids),
            "candidate_page_ids": len(candidate_page_ids),
            "accumulator_count": len(accumulator.results),
        },
    )

    return {
        "filtered_documents": filtered_docs,
        "document_history": updated_history,
        "information_gain": information_gain,
        "previous_gain_scores": [information_gain],
        "confidence_accumulator": accumulator,
        "candidate_doc_ids": candidate_doc_ids,
        "candidate_page_ids": candidate_page_ids,
        "iteration_logs": [iter_log],
        "retrieval_node_infos": [node_info],
    }


def _get_current_queries(state: Any) -> List[str]:
    """获取当前轮改写查询"""
    rewritten = state.get("current_rewritten_queries") or state.get("rewritten_queries", [])
    if not rewritten:
        return [state.get("original_query", "")]
    if isinstance(rewritten[-1], list):
        return rewritten[-1]
    return rewritten if isinstance(rewritten, list) else [str(rewritten)]


def _get_routing_summary(state: Any) -> str:
    """获取路由决策摘要"""
    routing = state.get("routing_decision")
    if routing is None:
        return ""
    if hasattr(routing, "reasoning"):
        return routing.reasoning[:200]
    return str(routing)[:200]
