# -*- coding: utf-8 -*-
"""
智能检索路由决策节点（检索策略规划器）
- 依托大模型语义决策，无硬编码规则
- 结合查询意图、知识库能力与历史检索全链路信息进行策略规划
- 实现检索策略的历史反思与自适应优化
- 输出管道式检索决策（RetrievalPipeline: 函数列表 + 第一个函数输入参数）
- 路由决策不仅要决定函数列表，还要为第一个函数指定完整的输入参数
- 默认知识库fallback机制
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any, Dict, List

from rag_iterative_system.config.knowledge_bases import (
    RetrievalGranularity,
    get_registry,
)
from rag_iterative_system.config.llm_config import get_llm
from rag_iterative_system.config.system_settings import get_settings
from rag_iterative_system.state.graph_state import (
    GraphState,
    RetrievalNodeInfo,
    RetrievalPipeline,
    RetrievalToolCall,
    RoutingDecision,
)
from rag_iterative_system.utils.error_handler import retry_with_backoff, RoutingError, LLMCallError
from rag_iterative_system.utils.logging import get_iteration_logger

logger = logging.getLogger(__name__)

# 路由决策系统提示词 - 检索策略规划器
ROUTING_SYSTEM_PROMPT = """你是一个智能检索策略规划专家。你的任务不仅是选择知识库和检索工具，更是基于对用户查询意图的深度理解和对历史检索效果的反思，设计最优的检索策略。

## 你的核心能力
1. **意图分析**: 理解用户查询的核心诉求、关键概念、隐含需求
2. **策略规划**: 设计多知识库、多粒度、多轮次的检索管道
3. **历史反思**: 分析历史检索结果，判断哪些策略有效、哪些需要调整
4. **自适应优化**: 根据历史信息增益、覆盖率等指标的反馈，动态调整检索方向

## 可用知识库及其检索工具
{kb_descriptions}

## 检索管道规划规则
1. 每个知识库可以规划一条检索管道，管道内函数按 doc→page→chunk 粒度顺序执行
2. 前一个函数的输出(doc_id/page_id)会自动传递给后一个函数
3. 你只需要为管道中的第一个函数指定完整输入参数(query, top_k等)
4. 如果查询明确只需要某个粒度，可以只规划单步管道
5. **首次检索**: 建议从document粒度开始（定位文档），逐步下钻到chunk粒度
6. **精确答案**: 需要精确答案时可以直接用chunk粒度
7. **多知识库并行**: 一个查询可以路由到多个知识库，每个生成独立管道，并行执行
8. **粒度适配**: 根据查询的抽象程度选择粒度 — 概念性问题→document级，具体细节→chunk级

## 历史信息利用策略
在后续检索轮次中，你需要：
1. **分析历史检索效果**: 哪些知识库提供了高价值文档？哪些工具的检索结果覆盖了查询的哪些方面？
2. **识别覆盖盲区**: 查询的哪些核心诉求还未被检索结果覆盖？
3. **调整检索方向**: 如果之前的检索方向效果不佳（信息增益低），尝试换知识库、调整粒度、更换检索模式
4. **避免重复劳动**: 如果某知识库已充分检索，不需要重复相同的管道
5. **聚焦未覆盖**: 优先针对上一轮"继续迭代原因"中指出的未覆盖方面设计策略

## 策略规划思维框架
在做出决策前，请按以下框架思考：
1. **复盘历史**: 前几轮的检索效果如何？信息增益是高是低？哪些管道产生了有价值的结果？
2. **评估现状**: 当前还有哪些信息缺口？继续迭代的原因是什么？
3. **设计策略**: 基于以上分析，本轮应该选择哪些知识库？使用什么粒度的工具？是否需要调整参数？
4. **预设验证**: 本轮策略相比前一轮有什么不同？为什么这些调整可能更有效？

默认知识库: {default_kb}

输出JSON格式：
{{
  "pipelines": [
    {{
      "kb_id": "知识库ID",
      "steps": [
        {{
          "tool_name": "检索工具注册名",
          "granularity": "document|page|chunk",
          "params": {{
            "query": "检索查询",
            "top_k": 5
          }}
        }}
      ],
      "reasoning": "为什么选择这个管道"
    }}
  ],
  "reasoning": "整体路由决策的推理过程说明（需包含对历史策略的反思和本轮策略的设计理由）"
}}"""


def _build_fallback_pipeline(
    queries: List[str],
    state: GraphState,
) -> RoutingDecision:
    """
    降级路由：为所有已启用知识库生成默认管道

    默认管道策略：
    - 有candidate_doc_ids → page级管道
    - 有candidate_page_ids → chunk级管道
    - 否则 → chunk级管道
    """
    registry = get_registry()
    settings = get_settings()
    pipelines: List[RetrievalPipeline] = []

    # 根据已有信息推断粒度
    candidate_doc_ids = state.get("candidate_doc_ids", [])
    candidate_page_ids = state.get("candidate_page_ids", [])

    for kb in registry.list_enabled():
        tools = registry.get_all_tools(kb.kb_id)

        # 确定默认粒度和工具
        if candidate_page_ids:
            granularity = RetrievalGranularity.CHUNK
        elif candidate_doc_ids:
            granularity = RetrievalGranularity.PAGE
        else:
            granularity = RetrievalGranularity.CHUNK

        # 构建管道步骤
        steps: List[RetrievalToolCall] = []
        if tools:
            # 找到目标粒度的工具
            target_tools = [t for t in tools if t.granularity == granularity]
            if not target_tools:
                target_tools = tools  # 退而求其次

            for tool in target_tools[:1]:  # 取第一个匹配的工具
                step_params = {
                    "query": queries[0] if queries else state.get("original_query", ""),
                    "top_k": kb.top_k,
                }
                # 注入候选ID
                if granularity == RetrievalGranularity.PAGE and candidate_doc_ids:
                    step_params["doc_id_list"] = candidate_doc_ids
                elif granularity == RetrievalGranularity.CHUNK:
                    if candidate_doc_ids:
                        step_params["doc_id_list"] = candidate_doc_ids
                    if candidate_page_ids:
                        step_params["page_id_list"] = candidate_page_ids

                steps.append(RetrievalToolCall(
                    tool_name=tool.name,
                    granularity=tool.granularity,
                    params=step_params,
                ))

        pipelines.append(RetrievalPipeline(
            kb_id=kb.kb_id,
            steps=steps,
            reasoning="降级路由：默认管道",
        ))

    return RoutingDecision(pipelines=pipelines, reasoning="路由决策异常降级")


@retry_with_backoff(max_retries=2, exceptions=(RoutingError, LLMCallError))
def _call_routing_llm(prompt: str, system_prompt: str) -> RoutingDecision:
    """调用LLM执行路由决策"""
    llm = get_llm()
    try:
        result = llm.call_json(prompt, system_prompt)
    except (LLMCallError, ValueError) as e:
        raise RoutingError(f"路由LLM调用失败: {e}") from e

    registry = get_registry()

    # 解析管道列表
    pipeline_data = result.get("pipelines", [])
    reasoning = result.get("reasoning", "")

    pipelines: List[RetrievalPipeline] = []
    for pipe_info in pipeline_data:
        kb_id = pipe_info.get("kb_id", "")

        # 校验知识库已注册
        try:
            kb_config = registry.get(kb_id)
        except KeyError:
            logger.warning("路由指向未注册知识库，跳过: %s", kb_id)
            continue

        # 解析管道步骤
        steps: List[RetrievalToolCall] = []
        for step_info in pipe_info.get("steps", []):
            tool_name = step_info.get("tool_name", "")
            granularity_str = step_info.get("granularity", "chunk")
            params = step_info.get("params", {})

            # 校验工具是否已注册
            try:
                tool = registry.get_tool(kb_id, tool_name)
            except KeyError:
                # 如果工具名不匹配，按粒度查找
                granularity = RetrievalGranularity(granularity_str)
                tools_by_g = registry.get_tools_by_granularity(kb_id, granularity)
                if tools_by_g:
                    tool = tools_by_g[0]
                    tool_name = tool.name
                else:
                    logger.warning(
                        "路由指定的工具 %s 未注册且无替代，跳过", tool_name
                    )
                    continue

            steps.append(RetrievalToolCall(
                tool_name=tool_name,
                granularity=RetrievalGranularity(granularity_str),
                params=params,
            ))

        pipelines.append(RetrievalPipeline(
            kb_id=kb_id,
            steps=steps,
            reasoning=pipe_info.get("reasoning", ""),
        ))

    # 如果没有有效管道，使用默认知识库fallback
    if not pipelines:
        default_kb_id = registry.get_default_kb_id()
        if default_kb_id:
            logger.warning("路由决策无有效管道，fallback到默认知识库: %s", default_kb_id)
            # 为默认KB构建单步chunk管道
            tools = registry.get_tools_by_granularity(
                default_kb_id, RetrievalGranularity.CHUNK
            )
            try:
                default_kb_config = registry.get(default_kb_id)
                fallback_top_k = default_kb_config.top_k
            except KeyError:
                fallback_top_k = 5
            steps = []
            if tools:
                steps.append(RetrievalToolCall(
                    tool_name=tools[0].name,
                    granularity=RetrievalGranularity.CHUNK,
                    params={"query": "", "top_k": fallback_top_k},
                ))
            pipelines.append(RetrievalPipeline(
                kb_id=default_kb_id,
                steps=steps,
                reasoning="Fallback到默认知识库",
            ))

    return RoutingDecision(pipelines=pipelines, reasoning=reasoning)


def _build_retrieval_history_context(state: GraphState) -> str:
    """
    构建历史检索全链路上下文，供路由节点进行策略反思。

    从状态中提取以下维度的历史信息：
    1. 每轮路由决策：选择了哪些知识库，使用了什么管道
    2. 每轮检索结果：各知识库检索到多少文档
    3. 每轮评估结果：信息增益、过滤后文档数
    4. 终止节点的继续迭代原因：还有哪些信息缺口
    5. 整体趋势：信息增益变化、覆盖度变化

    Args:
        state: 当前图状态

    Returns:
        格式化的历史检索上下文字符串，供LLM分析使用。
        首轮检索时返回空字符串。
    """
    # 从累积数据中提取历史信息
    retrieval_node_infos = state.get("retrieval_node_infos", [])
    iteration_logs = state.get("iteration_logs", [])
    previous_gain_scores = state.get("previous_gain_scores", [])
    continue_reason = state.get("continue_iteration_reason", "")

    # 如果没有历史数据（首轮），直接返回
    if not iteration_logs and not retrieval_node_infos:
        return ""

    parts: list = []
    parts.append("## 历史检索全链路记录")

    # --- 按迭代轮次组织 ---
    # 从 iteration_logs 和 retrieval_node_infos 中提取按轮次分组的信息
    iterations_seen: set = set()

    # 优先使用 iteration_logs（结构化的迭代摘要）
    if iteration_logs:
        parts.append("### 各轮迭代摘要")
        parts.append("| 轮次 | 改写查询数 | 路由KB数 | 原始文档 | 过滤文档 | 信息增益 | 判定结果 |")
        parts.append("|------|-----------|---------|---------|---------|---------|---------|")
        for log in iteration_logs:
            if not hasattr(log, "iteration"):
                continue
            iter_num = log.iteration
            iterations_seen.add(iter_num)
            q_count = len(log.rewritten_queries) if hasattr(log, "rewritten_queries") else 0
            routing = log.routing_decision[:60] if hasattr(log, "routing_decision") and log.routing_decision else "-"
            raw_count = log.retrieved_count if hasattr(log, "retrieved_count") else 0
            filtered_count = log.filtered_count if hasattr(log, "filtered_count") else 0
            gain = log.information_gain if hasattr(log, "information_gain") else 0.0
            termination = log.termination_reason[:40] if hasattr(log, "termination_reason") and log.termination_reason else (
                log.continue_iteration_reason[:40] if hasattr(log, "continue_iteration_reason") and log.continue_iteration_reason else "继续" if gain > 0 else "首轮"
            )
            parts.append(f"| {iter_num} | {q_count} | {routing} | {raw_count} | {filtered_count} | {gain:.4f} | {termination} |")

        parts.append("")

    # --- 从 retrieval_node_infos 提取详细的节点级历史 ---
    if retrieval_node_infos:
        # 按迭代分组节点信息
        iter_nodes: dict = {}
        for node_info in retrieval_node_infos:
            if not hasattr(node_info, "iteration") or not hasattr(node_info, "node_name"):
                continue
            iter_num = node_info.iteration
            if iter_num not in iter_nodes:
                iter_nodes[iter_num] = {}
            iter_nodes[iter_num][node_info.node_name] = node_info

        # 按轮次输出详细信息
        for iter_num in sorted(iter_nodes):
            nodes = iter_nodes[iter_num]
            parts.append(f"### 第{iter_num}轮 详细记录")

            # 路由决策详情
            router_info = nodes.get("router")
            if router_info and hasattr(router_info, "output_summary") and router_info.output_summary:
                out = router_info.output_summary
                parts.append(f"**🔀 路由决策**: {out.get('pipeline_count', 0)} 条管道")
                pipelines = out.get("pipelines", [])
                if pipelines:
                    for p in pipelines:
                        parts.append(f"  - {p}")
                reasoning = out.get("reasoning", "")
                if reasoning:
                    parts.append(f"  - 决策理由: {reasoning[:200]}")

            # 检索结果详情
            retrieval_info = nodes.get("retrieval")
            if retrieval_info and hasattr(retrieval_info, "output_summary") and retrieval_info.output_summary:
                out = retrieval_info.output_summary
                total = out.get("total_docs", 0)
                by_source = out.get("by_source", {})
                parts.append(f"**📊 检索结果**: 共 {total} 篇文档")
                if by_source:
                    source_detail = ", ".join(f"{kb}: {cnt}篇" for kb, cnt in by_source.items())
                    parts.append(f"  - 各知识库: {source_detail}")

            # 评估结果详情
            evaluator_info = nodes.get("evaluator")
            if evaluator_info and hasattr(evaluator_info, "output_summary") and evaluator_info.output_summary:
                out = evaluator_info.output_summary
                filtered = out.get("filtered_docs", 0)
                gain = out.get("information_gain", 0.0)
                coverage = out.get("coverage", 0.0)
                parts.append(f"**📈 评估结果**: 过滤后={filtered}篇, 信息增益={gain:.4f}, 覆盖度={coverage:.2%}")
                if gain < 0.05:
                    parts.append("  ⚠️ 信息增益低于阈值，该轮检索策略可能需要调整方向")

            # 终止判定详情
            termination_info = nodes.get("termination")
            if termination_info and hasattr(termination_info, "output_summary") and termination_info.output_summary:
                out = termination_info.output_summary
                should_continue = out.get("should_continue", True)
                term_reason = out.get("termination_reason", "")
                continue_reason_from_term = out.get("continue_iteration_reason", "")
                parts.append(f"**🔚 终止判定**: {'继续迭代' if should_continue else '终止'}")
                if term_reason:
                    parts.append(f"  - 原因: {term_reason[:200]}")
                if continue_reason_from_term:
                    parts.append(f"  - 继续迭代原因: {continue_reason_from_term[:200]}")

            parts.append("")

    # --- 整体趋势分析 ---
    if previous_gain_scores:
        gains_str = ", ".join(f"轮{i+1}={g:.4f}" for i, g in enumerate(previous_gain_scores))
        parts.append(f"### 信息增益趋势")
        parts.append(f"各轮增益: [{gains_str}]")
        # 判断趋势
        if len(previous_gain_scores) >= 2:
            if all(g < 0.05 for g in previous_gain_scores):
                parts.append("⚠️ 所有轮次信息增益均低于阈值，需要大幅调整检索策略（换知识库、换粒度、换检索模式）")
            elif previous_gain_scores[-1] < previous_gain_scores[-2]:
                parts.append("📉 信息增益呈下降趋势，建议调整检索方向")
            elif previous_gain_scores[-1] > previous_gain_scores[-2]:
                parts.append("📈 信息增益呈上升趋势，当前方向可能有效")
        parts.append("")

    # --- 当前继续迭代原因（最关键的信息缺口指示） ---
    if continue_reason:
        parts.append("### 🎯 本轮检索目标")
        parts.append(f"（来自终止节点的继续迭代指引）: {continue_reason[:500]}")

    return "\n".join(parts)


def router_node(state: GraphState) -> dict:
    """
    智能检索路由决策节点（检索策略规划器）

    根据改写后的查询列表和历史检索全链路信息，利用LLM进行策略规划：
    - 分析历史检索效果，反思策略有效性
    - 识别覆盖盲区，调整检索方向
    - 设计最优检索管道，规划多知识库并行策略

    管道内函数按 doc→page→chunk 顺序执行，
    路由决策为第一个函数指定完整输入参数。

    Args:
        state: 当前图状态

    Returns:
        状态更新字典，包含路由决策结果
    """
    settings = get_settings()
    iter_logger = get_iteration_logger()
    registry = get_registry()
    start_time = time.time()

    # 获取改写查询
    rewritten_queries = state.get("current_rewritten_queries") or state.get("rewritten_queries", [])
    if rewritten_queries and isinstance(rewritten_queries[-1], list):
        current_queries = rewritten_queries[-1]
    elif isinstance(rewritten_queries, list):
        current_queries = rewritten_queries if rewritten_queries else [state.get("original_query", "")]
    else:
        current_queries = [state.get("original_query", "")]

    original_query = state.get("original_query", "")

    # 构建知识库描述
    kb_descriptions = registry.get_descriptions_for_routing()
    if not kb_descriptions.strip():
        kb_descriptions = "（未注册任何知识库，将使用默认检索）"

    default_kb = registry.get_default_kb_id() or "无"

    system_prompt = ROUTING_SYSTEM_PROMPT.format(
        kb_descriptions=kb_descriptions,
        default_kb=default_kb,
    )

    # 获取当前迭代轮次（用于日志和上下文）
    iteration = state.get("iteration_count", 0)

    # --- 构建历史检索全链路上下文（核心新增） ---
    history_context = _build_retrieval_history_context(state)

    # 构建当前检索上下文（候选ID等即时信息）
    context_hints = []
    candidate_doc_ids = state.get("candidate_doc_ids", [])
    candidate_page_ids = state.get("candidate_page_ids", [])
    if candidate_doc_ids:
        context_hints.append(f"已定位 {len(candidate_doc_ids)} 篇候选文档，可选择page级检索下钻")
    if candidate_page_ids:
        context_hints.append(f"已定位 {len(candidate_page_ids)} 个候选页面，可选择chunk级检索下钻")

    context_str = "\n".join(context_hints) if context_hints else "无"

    # 构建带历史信息的用户提示词
    if history_context:
        # 后续轮次：包含完整历史上下文，引导LLM进行策略反思
        user_prompt = (
            f"原始查询: {original_query}\n"
            f"当前迭代轮次: 第{iteration}轮\n"
            f"当前改写查询: {json.dumps(current_queries, ensure_ascii=False)}\n"
            f"\n{history_context}\n"
            f"\n=== 当前检索上下文 ===\n"
            f"候选定位信息: {context_str}\n"
            f"\n请基于以上历史检索记录：\n"
            f"1. 复盘之前各轮的检索策略效果（哪些KB有效？哪些工具返回了高价值文档？）\n"
            f"2. 识别当前仍未被覆盖的信息缺口\n"
            f"3. 针对性地规划本轮检索管道，避免重复无效策略\n"
            f"4. 说明本轮策略相比前轮的调整理由"
        )
    else:
        # 首轮：无历史信息，使用简化提示
        user_prompt = (
            f"原始查询: {original_query}\n"
            f"当前改写查询: {json.dumps(current_queries, ensure_ascii=False)}\n"
            f"当前检索上下文: {context_str}\n\n"
            f"这是首轮检索，请根据查询意图和知识库能力，初步规划检索管道。"
        )

    try:
        routing_decision = _call_routing_llm(user_prompt, system_prompt)
    except Exception as e:
        logger.error("路由决策失败，使用降级策略: %s", str(e)[:200])
        routing_decision = _build_fallback_pipeline(current_queries, state)

    # 后处理：如果管道步骤的params.query为空，用当前改写查询填充
    for pipeline in routing_decision.pipelines:
        for step in pipeline.steps:
            if not step.params.get("query"):
                step.params["query"] = current_queries[0] if current_queries else original_query
            # 确保top_k有值
            if "top_k" not in step.params:
                try:
                    kb_config = registry.get(pipeline.kb_id)
                    step.params["top_k"] = kb_config.top_k
                except KeyError:
                    step.params["top_k"] = settings.default_top_k

            # 注入候选ID（如果步骤粒度需要且尚未指定）
            if step.granularity == RetrievalGranularity.PAGE and candidate_doc_ids:
                step.params.setdefault("doc_id_list", candidate_doc_ids)
            elif step.granularity == RetrievalGranularity.CHUNK:
                if candidate_doc_ids:
                    step.params.setdefault("doc_id_list", candidate_doc_ids)
                if candidate_page_ids:
                    step.params.setdefault("page_id_list", candidate_page_ids)

    iter_logger.log_routing(
        routing_decision.targets,
        routing_decision.reasoning,
    )

    end_time = time.time()
    duration_ms = (end_time - start_time) * 1000

    # 构建检索节点追踪信息（需求4）
    pipeline_summary = []
    for p in routing_decision.pipelines:
        tools = [s.tool_name for s in p.steps]
        pipeline_summary.append(f"{p.kb_id}:{'->'.join(tools)}")
    node_info = RetrievalNodeInfo(
        iteration=iteration,
        node_name="router",
        status="completed",
        start_time=start_time,
        end_time=end_time,
        duration_ms=duration_ms,
        input_summary={
            "current_queries": [q[:50] for q in current_queries[:3]],
            "candidate_doc_ids": len(candidate_doc_ids),
            "candidate_page_ids": len(candidate_page_ids),
            "has_history_context": bool(history_context),
            "history_context_length": len(history_context) if history_context else 0,
        },
        output_summary={
            "pipeline_count": len(routing_decision.pipelines),
            "pipelines": pipeline_summary,
            "reasoning": routing_decision.reasoning[:200] if routing_decision.reasoning else "",
        },
    )

    return {
        "routing_decision": routing_decision,
        "retrieval_node_infos": [node_info],
    }
