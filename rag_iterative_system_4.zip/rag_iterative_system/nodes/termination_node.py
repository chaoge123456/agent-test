# -*- coding: utf-8 -*-
"""
迭代条件判断、循环终止决策节点
- 多条件组合判定机制
- 可通过配置文件灵活调整阈值与规则
- 满足任一条件即刻终止迭代
- 迭代式检索开关（enable_iterative_retrieval）
- 管道式检索下钻由路由和检索节点负责，本节点只做终止判定
- 【需求3】增加LLM覆盖度判定策略，判断已检索内容是否覆盖查询诉求
- 【需求3】当需要继续迭代时，将原因同步至查询改写节点
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List

from rag_iterative_system.config.llm_config import get_llm
from rag_iterative_system.config.system_settings import get_settings
from rag_iterative_system.evaluation.metrics import compute_coverage_score
from rag_iterative_system.state.graph_state import (
    GraphState,
    RetrievalNodeInfo,
    RetrievalResult,
)
from rag_iterative_system.utils.error_handler import retry_with_backoff, LLMCallError
from rag_iterative_system.utils.logging import get_iteration_logger

logger = logging.getLogger(__name__)


# ============================================================
# Prompt: LLM覆盖度判定（需求3）
# ============================================================

LLM_COVERAGE_JUDGMENT_PROMPT = """你是一个信息覆盖度评估专家。你需要判断已检索到的文档内容是否能够完整覆盖用户的查询诉求。

判断标准：
1. 分析用户查询的核心诉求点（关键问题、关键概念、关键步骤）
2. 逐条对照已检索文档，判断每个核心诉求点是否已有对应信息支撑
3. 综合评估覆盖程度，给出明确结论

用户查询：{query}

已检索文档摘要（共{doc_count}篇）：
{doc_summaries}

请输出JSON格式：
{{"is_covered": true/false, "coverage_analysis": "逐条分析每个核心诉求点的覆盖情况", "uncovered_aspects": "未覆盖的具体方面描述（如果is_covered为false时必须填写）", "confidence": 0.0-1.0}}"""


def _check_max_iterations(
    iteration: int,
    max_iterations: int,
) -> tuple:
    """条件1: 迭代轮次达到系统设定最大上限"""
    if iteration >= max_iterations:
        return True, f"已达最大迭代轮次上限({max_iterations}轮)"
    return False, ""


def _check_low_information_gain(
    current_gain: float,
    previous_gains: List[float],
    min_gain: float,
    consecutive_threshold: int,
    current_no_gain: int,
) -> tuple:
    """条件2: 信息增益低于阈值，且连续多轮无有效新增信息"""
    if current_gain < min_gain:
        new_no_gain = current_no_gain + 1
        if new_no_gain >= consecutive_threshold:
            return True, (
                f"连续{new_no_gain}轮信息增益低于阈值"
                f"(增益={current_gain:.4f}, 阈值={min_gain})"
            )
        return False, ""
    return False, ""


def _check_coverage_complete(
    query: str,
    documents: list,
    coverage_threshold: float = 0.9,
) -> tuple:
    """条件3: 检索文档内容已完整覆盖用户查询核心诉求"""
    if not documents:
        return False, ""
    coverage = compute_coverage_score(query, documents)
    if coverage >= coverage_threshold:
        return True, f"查询覆盖度已达{coverage:.1%}，信息充分"
    return False, ""


def _check_no_new_docs(
    filtered_count: int,
    history_count: int,
    max_total: int,
) -> tuple:
    """条件4: 本轮无新增有效文档 或 历史文档已达上限"""
    if filtered_count == 0 and history_count > 0:
        return True, "本轮检索无新增有效文档"
    if history_count >= max_total:
        return True, f"历史文档数已达上限({max_total})"
    return False, ""


def _build_doc_summaries(
    documents: list, max_docs: int = 10, max_content_len: int = 150,
) -> str:
    """
    构建文档摘要文本，供LLM覆盖度判定使用

    Args:
        documents: 文档列表
        max_docs: 最大文档数量
        max_content_len: 每篇文档内容的最大长度

    Returns:
        格式化的文档摘要文本
    """
    if not documents:
        return "暂无已检索文档"

    parts: List[str] = []
    for i, doc in enumerate(documents[:max_docs]):
        if isinstance(doc, RetrievalResult):
            content = doc.content[:max_content_len]
            if len(doc.content) > max_content_len:
                content += "..."
            hierarchy = f"doc={doc.doc_id}" if doc.doc_id else ""
            if doc.page_id:
                hierarchy += f", page={doc.page_id}" if hierarchy else f"page={doc.page_id}"
            line = f"[文档{i+1}] [分数:{doc.score:.3f}]"
            if hierarchy:
                line += f" [{hierarchy}]"
            line += f"\n内容: {content}"
            parts.append(line)
        elif hasattr(doc, "content"):
            content = doc.content[:max_content_len]
            if len(doc.content) > max_content_len:
                content += "..."
            score = getattr(doc, "score", 0.0)
            parts.append(f"[文档{i+1}] [分数:{score:.3f}]\n内容: {content}")

    return "\n".join(parts) if parts else "暂无已检索文档"


@retry_with_backoff(max_retries=2, exceptions=(LLMCallError,))
def _call_llm_coverage_judgment(prompt: str, system_prompt: str) -> Dict[str, Any]:
    """调用LLM执行覆盖度判定"""
    llm = get_llm()
    result = llm.call_json(prompt, system_prompt)
    return result


def _check_llm_coverage(
    query: str,
    documents: list,
    enable_llm_judgment: bool = True,
) -> tuple:
    """
    【需求3】条件5: LLM覆盖度判定

    利用大模型判断已检索到的内容是否能够覆盖查询诉求，
    并说明原因。当判定未覆盖时，返回未覆盖的具体方面。

    Args:
        query: 用户原始查询
        documents: 已检索文档列表
        enable_llm_judgment: 是否启用LLM判定

    Returns:
        (should_terminate, reason) - should_terminate=True 表示覆盖充分可终止
        llm_judgment_detail: LLM判定的详细结果
    """
    if not enable_llm_judgment:
        return False, "", ""

    if not documents:
        return False, "", "无已检索文档，无法进行LLM覆盖度判定"

    doc_summaries = _build_doc_summaries(documents)
    system_prompt = "你是一个信息覆盖度评估专家，负责判断检索结果是否完整覆盖用户查询诉求。"
    user_prompt = LLM_COVERAGE_JUDGMENT_PROMPT.format(
        query=query,
        doc_count=len(documents),
        doc_summaries=doc_summaries,
    )

    try:
        result = _call_llm_coverage_judgment(user_prompt, system_prompt)
    except Exception as e:
        logger.warning("LLM覆盖度判定失败，跳过此条件: %s", str(e)[:200])
        return False, "", f"LLM判定失败: {str(e)[:100]}"

    is_covered = result.get("is_covered", False)
    coverage_analysis = result.get("coverage_analysis", "")
    uncovered_aspects = result.get("uncovered_aspects", "")
    confidence = result.get("confidence", 0.5)

    # 构建详细判定结果
    judgment_detail = (
        f"LLM判定: {'覆盖充分' if is_covered else '覆盖不足'} "
        f"(置信度:{confidence:.2f})\n"
        f"分析: {coverage_analysis}"
    )
    if uncovered_aspects:
        judgment_detail += f"\n未覆盖方面: {uncovered_aspects}"

    if is_covered:
        return True, f"LLM判定覆盖充分(置信度:{confidence:.2f}): {coverage_analysis[:100]}", judgment_detail
    else:
        return False, "", judgment_detail


def termination_node(state: GraphState) -> dict:
    """
    迭代终止判定节点

    多条件组合判定（满足任一即终止）:
    1. 迭代轮次达到最大上限
    2. 连续多轮信息增益低于阈值
    3. 检索文档已完整覆盖查询诉求（关键词覆盖度）
    4. 本轮无新增有效文档 或 历史文档达上限
    5. 【需求3】LLM覆盖度判定：利用大模型判断检索内容是否覆盖查询诉求

    如果 enable_iterative_retrieval=False（默认），
    则首轮检索后直接终止（除非首轮无结果）。

    【需求3】当需要继续迭代时，将原因同步至查询改写节点：
    - 终止原因 + LLM未覆盖方面 → continue_iteration_reason

    Args:
        state: 当前图状态

    Returns:
        状态更新字典，包含是否继续迭代与终止原因
    """
    settings = get_settings()
    iter_logger = get_iteration_logger()
    start_time = time.time()

    iteration = state.get("iteration_count", 1)
    information_gain = state.get("information_gain", 0.0)
    previous_gains = state.get("previous_gain_scores", [])
    doc_history = state.get("document_history", [])
    filtered_docs = state.get("filtered_documents", [])
    original_query = state.get("original_query", "")
    no_gain_rounds = state.get("no_gain_rounds", 0)

    should_terminate = False
    termination_reason = ""
    llm_coverage_judgment = ""
    continue_iteration_reason = ""

    # ---- 迭代开关检查 ----
    if not settings.enable_iterative_retrieval:
        # 非迭代模式：首轮后直接终止
        if iteration >= 1:
            should_terminate = True
            if doc_history:
                termination_reason = "迭代式检索未启用，单轮检索完成"
            else:
                termination_reason = "迭代式检索未启用，首轮无结果"

    # ---- 逐一检查终止条件 ----
    if not should_terminate:
        # 条件1: 最大迭代轮次
        terminated, reason = _check_max_iterations(
            iteration, settings.max_iterations
        )
        if terminated:
            should_terminate = True
            termination_reason = reason

    if not should_terminate:
        # 条件2: 连续低信息增益
        terminated, reason = _check_low_information_gain(
            information_gain,
            previous_gains,
            settings.min_information_gain,
            settings.consecutive_no_gain_rounds,
            no_gain_rounds,
        )
        if terminated:
            should_terminate = True
            termination_reason = reason

    if not should_terminate and not settings.enable_llm_coverage_judgment:
        # 条件3: 覆盖度充分（关键词覆盖度）。启用 LLM 覆盖判断时，避免关键词重合提前误停。
        terminated, reason = _check_coverage_complete(
            original_query, doc_history
        )
        if terminated:
            should_terminate = True
            termination_reason = reason

    if not should_terminate:
        # 条件4: 无新增文档或达上限
        terminated, reason = _check_no_new_docs(
            len(filtered_docs),
            len(doc_history),
            settings.max_total_documents,
        )
        if terminated:
            should_terminate = True
            termination_reason = reason

    if not should_terminate:
        # 条件5: 【需求3】LLM覆盖度判定
        terminated, reason, llm_judgment = _check_llm_coverage(
            original_query,
            doc_history,
            enable_llm_judgment=settings.enable_llm_coverage_judgment,
        )
        if terminated:
            should_terminate = True
            termination_reason = reason
            llm_coverage_judgment = llm_judgment
        elif llm_judgment:
            # LLM判定覆盖不足，记录判定详情
            llm_coverage_judgment = llm_judgment

    # 更新连续无增益轮次计数
    if information_gain < settings.min_information_gain:
        no_gain_rounds += 1
    else:
        no_gain_rounds = 0

    should_continue = not should_terminate

    # ---- 【需求3】当继续迭代时，构建继续迭代原因 ----
    if should_continue:
        reason_parts: List[str] = []

        # 基础信息
        reason_parts.append(f"第{iteration}轮检索后信息尚未充分覆盖查询诉求。")

        # 信息增益情况
        if information_gain < settings.min_information_gain:
            reason_parts.append(
                f"本轮信息增益较低({information_gain:.4f})，可能检索方向需要调整。"
            )

        # LLM判定的未覆盖方面
        if llm_coverage_judgment and "未覆盖方面:" in llm_coverage_judgment:
            uncovered = llm_coverage_judgment.split("未覆盖方面:")[-1].strip()
            reason_parts.append(f"LLM判定未覆盖方面: {uncovered}")

        # 关键词覆盖度不足
        coverage = compute_coverage_score(original_query, doc_history)
        if coverage < 0.9:
            reason_parts.append(
                f"关键词覆盖度仅为{coverage:.1%}，仍有查询关键词未被文档内容覆盖。"
            )

        # 文档数量较少
        if len(doc_history) < 3:
            reason_parts.append("已检索文档数量较少，建议扩大检索范围。")

        continue_iteration_reason = " ".join(reason_parts)

        logger.info(
            "继续迭代原因 [Iter-%d]: %s",
            iteration,
            continue_iteration_reason[:300],
        )

    iter_logger.log_termination(termination_reason, should_continue)

    end_time = time.time()
    duration_ms = (end_time - start_time) * 1000

    # 构建检索节点追踪信息（需求4）
    node_info = RetrievalNodeInfo(
        iteration=iteration,
        node_name="termination",
        status="completed",
        start_time=start_time,
        end_time=end_time,
        duration_ms=duration_ms,
        input_summary={
            "iteration": iteration,
            "information_gain": information_gain,
            "doc_history_count": len(doc_history),
            "filtered_count": len(filtered_docs),
        },
        output_summary={
            "should_continue": should_continue,
            "termination_reason": termination_reason,
            "llm_coverage_judgment": llm_coverage_judgment[:300] if llm_coverage_judgment else "",
            "continue_iteration_reason": continue_iteration_reason[:300] if continue_iteration_reason else "",
        },
    )

    logger.info(
        "终止判定 [Iter-%d]: 继续=%s, 增益=%.4f, 历史文档=%d, 原因=%s",
        iteration,
        should_continue,
        information_gain,
        len(doc_history),
        termination_reason or "继续迭代",
    )

    return {
        "should_continue": should_continue,
        "termination_reason": termination_reason,
        "no_gain_rounds": no_gain_rounds,
        "llm_coverage_judgment": llm_coverage_judgment,
        "continue_iteration_reason": continue_iteration_reason,
        "retrieval_node_infos": [node_info],
    }
