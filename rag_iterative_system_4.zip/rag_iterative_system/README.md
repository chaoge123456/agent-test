# 迭代式 RAG 查询系统技术文档

> 基于 LangGraph 框架的模块化、可迭代、高可扩展智能检索增强生成系统

---

## 目录

- [1. 项目概述](#1-项目概述)
- [2. 核心亮点](#2-核心亮点)
- [3. 系统架构](#3-系统架构)
- [4. 目录结构](#4-目录结构)
- [5. 快速开始](#5-快速开始)
- [6. 核心模块详解](#6-核心模块详解)
- [7. 评估算法](#7-评估算法)
- [8. 配置参数手册](#8-配置参数手册)
- [9. 容错与降级机制](#9-容错与降级机制)
- [10. 可观测性](#10-可观测性)
- [11. Mock 模式（无 API Key 测试）](#11-mock-模式无-api-key-测试)
- [12. 扩展指南](#12-扩展指南)

---

## 1. 项目概述

传统单次检索 RAG 存在信息覆盖不全、无法补充缺失上下文的问题。本系统以大模型为核心驱动，构建「查询优化 → 智能路由 → 多路管道检索 → 结果评估 → 迭代决策」全自动闭环流程。

### 核心概念：三级粒度管道式检索

本系统区别于传统 RAG 的核心创新在于 **Document → Page → Chunk** 三级粒度漏斗式检索管道：

```
Document 级 (文档定位)  →  Page 级 (页面下钻)  →  Chunk 级 (内容提取)
   粗粒度，找相关文档         中粒度，定位页面         细粒度，提取精确答案
```

每个知识库必须注册三个粒度的检索函数，路由节点根据查询意图智能决定管道步骤，前一步的检索结果（doc_id / page_id）自动传递给后一步，实现从粗到细的漏斗式信息获取。

### 迭代式闭环

当检索结果不足以回答用户问题时，系统自动进入下一轮迭代 —— 将上轮的信息增益、覆盖度、LLM 判定的未覆盖方面反馈给查询改写节点，引导新一轮更具针对性的检索，直至信息充分或达到终止条件。

| 特性 | 说明 |
|---|---|
| **迭代式闭环** | 多轮循环检索，每轮结合历史信息优化策略，自动终止 |
| **三级粒度管道检索** | Document → Page → Chunk 漏斗式下钻，前步输出自动传递 |
| **路由策略反思** | 路由节点分析历史检索全链路效果，自适应调整策略 |
| **LLM 驱动决策** | 查询改写、拆解判定、路由决策、覆盖度判定均由 LLM 语义驱动 |
| **多知识库并行检索** | 不同知识库的管道并行执行（ThreadPoolExecutor） |
| **量化评估与自适应终止** | 信息增益 + 关键词覆盖度 + LLM 语义覆盖度 + 多条件组合判定 |
| **高置信度累加器** | 双重筛选（reranker 得分 + 信息增益新颖度），保留高质量结果 |
| **统一 LLM 调用** | 全局单例 `get_llm()`，严格遵循 `llm.call(prompt, system_prompt)` 调用规范 |
| **检索过程可视化** | 自动生成交互式 HTML 报告，含迭代时间线、节点详情、LLM 判定 |
| **Mock 模式** | 无需真实 API Key 即可完整运行全流程，验证架构逻辑 |

---

## 2. 核心亮点

### 2.1 路由策略反思（Strategy Reflection）

路由节点不仅选择知识库，更是一个**检索策略规划器**：
- 复盘历史各轮检索效果（哪些 KB 有效？哪些工具返回了高价值文档？）
- 识别覆盖盲区（查询的哪些核心诉求未被覆盖？）
- 自适应调整（信息增益低？换知识库、换粒度、换检索模式）
- 避免重复劳动（已充分检索的知识库不再重复）

### 2.2 条件性查询拆解（Decomposition Judgment）

改写节点在生成检索查询前，先由 LLM 判断是否需要拆解：
- 简单/单一维度问题 → 不拆解，语义优化 + 同义词拓展
- 跨领域/多子问题 → 拆解为多条聚焦子查询
- 已有检索结果已部分覆盖 → 仅针对未覆盖方面深入

### 2.3 LLM 语义覆盖度判定

除了传统的 Jaccard 关键词覆盖度计算，系统还引入了**LLM 语义覆盖度判定**：
- 分析用户查询的核心诉求点
- 逐条对照已检索文档，判断每个诉求点是否有信息支撑
- 当判定未覆盖时，输出具体的未覆盖方面，指导下一轮检索方向

### 2.4 高置信度结果累加器（Confidence Accumulator）

双重筛选机制：
1. **reranker 得分阈值**（默认 ≥ 0.6）：过滤低质量结果
2. **信息增益新颖度**（默认 ≥ 0.1）：确保对已有结果有新增信息量

累加器中的结果优先用于最终答案生成，确保答案基于最高质量的信息。

---

## 3. 系统架构

### 3.1 核心业务流程

```
用户查询
   |
   v
+---------------------+
|  查询改写            |  ← LLM 驱动：拆解判定 → 语义优化/子问题拆解
|  + 拆解判定          |     结合高置信度结果 + 继续迭代原因
+---------+-----------+
          |
          v
+---------------------+
|  智能路由            |  ← 策略规划器：分析历史全链路效果
|  (策略反思引擎)       |     选择 KB → 规划管道步骤 → 指定参数
+---------+-----------+
          |
          v
+---------------------+
|  管道式并行检索       |  ← ThreadPoolExecutor 并行执行多 KB 管道
|  doc→page→chunk      |     前步 doc_id/page_id 自动传递
+---------+-----------+
          |
          v
+---------------------+
|  评估与过滤           |  ← 低质过滤 → 精确去重 → 近似去重 → 历史去重
|  + 信息增益计算       |     高置信度累加器双重筛选
|  + 覆盖度评估         |     关键词覆盖度 + LLM 语义覆盖度
+---------+-----------+
          |
          v
+---------------------+
|  终止判定            |  ← 5 条件组合判定:
|  (多条件决策)         |     1. 最大轮次 2. 连续低增益 3. 关键词覆盖
|                      |     4. 无新文档 5. LLM 语义覆盖
+---------+-----------+
          |
          +-- 继续迭代 → 回流至 [查询改写] (携带: LLM未覆盖方面 + 继续原因)
          |
          +-- 终止迭代 → [答案生成] (优先高置信度结果) → END
```

### 3.2 LangGraph 工作流图

```python
# 节点串联
rewrite → router → retrieval → evaluator → termination

# 条件边: 循环闭环
termination --+-- should_continue=True  → rewrite  (继续迭代)
              +-- should_continue=False → answer   (生成答案)

# 终止
answer → END
```

**状态累积机制**: `Annotated[list, operator.add]` 标注的字段在每轮迭代中自动追加而非覆盖:

| 字段 | 累积行为 | 说明 |
|---|---|---|
| `rewritten_queries` | 追加 (list) | 保留所有轮次的改写查询词组 |
| `raw_documents` | 追加 (list) | 保留所有轮次的原始检索文档 (RetrievalResult) |
| `previous_gain_scores` | 追加 (float) | 保留所有轮次的增益分数 |
| `iteration_logs` | 追加 (IterationLog) | 保留全流程迭代日志 |
| `retrieval_node_infos` | 追加 (RetrievalNodeInfo) | 保留所有节点追踪信息（可视化用） |

### 3.3 模块依赖关系

```
graph/rag_graph.py              ← 编排层 (依赖所有 nodes)
    ├── nodes/rewrite_node.py       → config/llm_config, config/system_settings
    ├── nodes/router_node.py        → config/llm_config, config/knowledge_bases
    ├── nodes/retrieval_node.py     → config/knowledge_bases, state/graph_state
    ├── nodes/evaluator_node.py     → evaluation/metrics, evaluation/filters
    ├── nodes/termination_node.py   → evaluation/metrics, config/llm_config
    └── nodes/answer_node.py        → config/llm_config, utils/error_handler

state/graph_state.py            ← 被所有 nodes 和 graph 引用
utils/error_handler.py          ← 被所有模块引用 (重试/降级/截断)
utils/logging.py                ← 被所有模块引用 (迭代感知日志)
utils/visualizer.py             ← 被 main.py 引用 (HTML 报告生成)
config/llm_config.py            ← 被所有 nodes 引用 (LLM 调用)
config/knowledge_bases.py       ← 被 router/retrieval 引用
config/system_settings.py       ← 全局配置单例
```

---

## 4. 目录结构

```
rag_iterative_system/
├── __init__.py
├── main.py                      # 入口 + 演示 (mock 模式 / 迭代模式 / 可视化)
├── requirements.txt             # 依赖: langgraph, langchain-core, langchain-openai
│
├── config/
│   ├── __init__.py
│   ├── llm_config.py            # LLM 统一适配器 (单例)
│   │                             #   - LLMAdapter: 真实 LLM 实例
│   │                             #   - MockLLMAdapter: 测试用模拟实例
│   │                             #   - call() / call_json() 统一接口
│   │                             #   - set_mock_mode() / is_mock_mode()
│   ├── knowledge_bases.py       # 知识库注册中心
│   │                             #   - KnowledgeBaseConfig: KB 元数据
│   │                             #   - RetrievalTool: 检索工具 (函数+Schema)
│   │                             #   - RetrievalGranularity: document/page/chunk
│   │                             #   - RetrievalMode: vector/keyword/hybrid
│   │                             #   - KnowledgeBaseRegistry: 注册/校验/查询
│   │                             #   - register_knowledge_base()
│   │                             #   - register_retrieval_tool()
│   └── system_settings.py       # 全局配置 (环境变量覆盖)
│                                 #   - SystemSettings dataclass
│                                 #   - 迭代/检索/去重/LLM/重试参数
│
├── state/
│   ├── __init__.py
│   └── graph_state.py           # LangGraph 状态定义
│                                 #   - GraphState (TypedDict)
│                                 #   - RetrievalResult: 统一检索结果
│                                 #   - RetrievalToolCall: 管道步骤指令
│                                 #   - RetrievalPipeline: KB 内有序检索步骤
│                                 #   - RoutingDecision: 路由决策 (含管道列表)
│                                 #   - ConfidenceAccumulator: 高置信度累加器
│                                 #   - IterationLog: 单轮迭代日志
│                                 #   - RetrievalNodeInfo: 节点追踪信息 (可视化)
│
├── nodes/
│   ├── __init__.py
│   ├── rewrite_node.py          # 查询改写 (含拆解判定)
│   │                             #   - 首轮 vs 后续轮次不同策略
│   │                             #   - LLM 判断是否需要拆解
│   │                             #   - 结合高置信度结果 + 继续迭代原因
│   ├── router_node.py           # 智能路由 (策略反思引擎)
│   │                             #   - 构建历史检索全链路上下文
│   │                             #   - 分析历史效果 → 调整策略
│   │                             #   - 输出管道式决策 (pipeline 列表)
│   │                             #   - 降级 fallback 管道
│   ├── retrieval_node.py        # 管道式多路检索
│   │                             #   - 管道内 doc→page→chunk 顺序执行
│   │                             #   - 前步输出 ID 自动传递
│   │                             #   - 多 KB 管道并行执行 (ThreadPoolExecutor)
│   ├── evaluator_node.py        # 评估过滤
│   │                             #   - 完整过滤流水线
│   │                             #   - 信息增益计算
│   │                             #   - 高置信度累加器更新
│   │                             #   - 候选 ID 收集 (供下钻)
│   ├── termination_node.py      # 终止判定 (5 条件)
│   │                             #   - 迭代开关控制
│   │                             #   - LLM 语义覆盖度判定
│   │                             #   - 构建继续迭代原因
│   └── answer_node.py           # 答案生成
│                                 #   - 优先使用高置信度累加器结果
│                                 #   - 格式化上下文 (含来源/分数标注)
│                                 #   - 截断保护 + 异常降级
│
├── evaluation/
│   ├── __init__.py
│   ├── metrics.py               # 量化算法
│   │                             #   - Jaccard / 余弦相似度
│   │                             #   - 信息增益 / 新颖度
│   │                             #   - 关键词覆盖度
│   │                             #   - 文档内容哈希 / 层次化去重键
│   └── filters.py               # 过滤流水线
│                                 #   - 低质过滤 → 精确去重 → 近似去重
│                                 #   - → 历史去重 → 长度裁剪
│
├── graph/
│   ├── __init__.py
│   └── rag_graph.py             # LangGraph 流程编排
│                                 #   - build_rag_graph()
│                                 #   - compile_rag_graph()
│                                 #   - run_rag_query()
│
└── utils/
    ├── __init__.py
    ├── logging.py               # 迭代感知日志器
    │                             #   - IterationLogger (自动附加 [Iter-N] 前缀)
    ├── error_handler.py         # 异常体系与容错
    │                             #   - 异常层次: RAGSystemError → LLMCallError 等
    │                             #   - retry_with_backoff: 指数退避重试装饰器
    │                             #   - safe_execute: 安全执行 (异常返回默认值)
    │                             #   - truncate_context: 上下文截断
    │                             #   - validate_state_integrity: 状态校验
    └── visualizer.py            # 检索过程可视化
                                  #   - RetrievalVisualizer
                                  #   - generate_html_report(): 生成 HTML
                                  #   - save_report(): 保存到 retrieval_reports/
                                  #   - 交互式时间线 / 节点详情 / LLM 判定
```

---

## 5. 快速开始

### 5.1 环境准备

```bash
# 安装依赖
pip install -r requirements.txt

# （可选）设置环境变量覆盖默认配置
export RAG_LLM_API_KEY="sk-your-api-key"
export RAG_LLM_API_BASE="https://api.openai.com/v1"
export RAG_LLM_MODEL="gpt-4o"
```

### 5.2 命令行运行

```bash
# Mock 模式（无需 API Key，使用模拟 LLM 响应 + 模拟检索）
python -m rag_iterative_system.main --mock

# Mock + 迭代式检索模式（多轮迭代）
python -m rag_iterative_system.main --mock --iterative

# Mock + 自定义查询
python -m rag_iterative_system.main --mock --query "如何实现微服务架构的容错机制？"

# 标准模式（需要配置 API Key）
python -m rag_iterative_system.main

# 不生成可视化报告
python -m rag_iterative_system.main --mock --no-visualize
```

| CLI 参数 | 说明 |
|---|---|
| `--mock` | 启用 Mock LLM 模式（无需 API Key，使用模拟 LLM 响应 + 模拟检索函数） |
| `--iterative` | 启用迭代式检索（默认单轮检索） |
| `--query` / `-q` | 自定义查询文本（默认：分布式高可用系统架构设计问题） |
| `--no-visualize` | 不生成 HTML 可视化报告 |

### 5.3 编程接入

```python
from rag_iterative_system.config.llm_config import LLMAdapter
from rag_iterative_system.config.system_settings import SystemSettings, set_settings
from rag_iterative_system.config.knowledge_bases import (
    register_knowledge_base, register_retrieval_tool,
    RetrievalGranularity, RetrievalMode,
)
from rag_iterative_system.graph.rag_graph import compile_rag_graph, run_rag_query
from rag_iterative_system.utils.logging import setup_logging

# ======== 1. 配置 ========
settings = SystemSettings(
    max_iterations=3,
    enable_iterative_retrieval=True,       # 开启迭代式检索
    enable_llm_coverage_judgment=True,     # 开启 LLM 覆盖度判定
    llm_api_key="sk-your-api-key",
    llm_api_base="https://api.openai.com/v1",
    log_level="INFO",
)
set_settings(settings)
setup_logging(settings.log_level)

# ======== 2. 初始化 LLM ========
LLMAdapter.initialize(
    model_name=settings.llm_model,
    api_base=settings.llm_api_base,
    api_key=settings.llm_api_key,
)

# ======== 3. 注册知识库 (三级检索工具) ========

# 第一步：注册知识库元数据
register_knowledge_base(
    kb_id="my_kb",
    name="My Knowledge Base",
    description="包含 XXX 领域的技术文档和最佳实践",
    domains=["技术", "开发"],
    retrieval_mode=RetrievalMode.VECTOR,
    top_k=5,
    is_default=True,
)

# 第二步：注册 document 级检索工具
def my_doc_retrieval(query, top_k=5, score_threshold=0.3, **kwargs):
    """文档级检索：返回文档摘要"""
    results = your_db.search_documents(query, limit=top_k)
    return [
        {
            "doc_id": r.id,
            "content": r.summary,
            "score": r.score,
            "source": "my_kb",
        }
        for r in results if r.score >= score_threshold
    ]

register_retrieval_tool(
    kb_id="my_kb",
    tool_name="my_kb__document",
    granularity=RetrievalGranularity.DOCUMENT,
    func=my_doc_retrieval,
    description="文档级检索，返回相关文档摘要",
    scenario="需要定位相关文档时使用",
)

# 第三步：注册 page 级检索工具
def my_page_retrieval(query, top_k=5, doc_id_list=None, score_threshold=0.3, **kwargs):
    """页面级检索：在指定文档范围内检索页面"""
    results = your_db.search_pages(query, doc_ids=doc_id_list, limit=top_k)
    return [
        {
            "doc_id": r.doc_id,
            "page_id": r.page_id,
            "content": r.page_summary,
            "score": r.score,
            "source": "my_kb",
        }
        for r in results if r.score >= score_threshold
    ]

register_retrieval_tool(
    kb_id="my_kb",
    tool_name="my_kb__page",
    granularity=RetrievalGranularity.PAGE,
    func=my_page_retrieval,
    description="页面级检索，在已定位文档内检索相关页面",
    scenario="已定位文档后，需要在文档内定位页面时使用",
)

# 第四步：注册 chunk 级检索工具
def my_chunk_retrieval(
    query, top_k=5, doc_id_list=None, page_id_list=None,
    score_threshold=0.3, **kwargs,
):
    """Chunk 级检索：返回精确内容片段"""
    results = your_db.search_chunks(
        query, doc_ids=doc_id_list, page_ids=page_id_list, limit=top_k,
    )
    return [
        {
            "doc_id": r.doc_id,
            "page_id": r.page_id,
            "chunk_id": r.chunk_id,
            "content": r.text,
            "score": r.score,
            "source": "my_kb",
        }
        for r in results if r.score >= score_threshold
    ]

register_retrieval_tool(
    kb_id="my_kb",
    tool_name="my_kb__chunk",
    granularity=RetrievalGranularity.CHUNK,
    func=my_chunk_retrieval,
    description="Chunk 级检索，返回具体内容片段",
    scenario="需要精确答案或具体内容片段时使用",
)

# ======== 4. 校验注册完整性 ========
from rag_iterative_system.config.knowledge_bases import get_registry
registry = get_registry()
missing = registry.validate_kb_tools("my_kb")
if missing:
    print(f"警告：知识库 my_kb 缺少粒度: {missing}")
else:
    print("知识库 my_kb 三级检索工具注册完整 ✓")

# ======== 5. 执行查询 ========
compiled_graph = compile_rag_graph()
result = run_rag_query("你的查询问题", compiled_graph)

# ======== 6. 获取结果 ========
print(result["final_answer"])
print(f"迭代轮次: {result['iteration_count']}")
print(f"终止原因: {result['termination_reason']}")

# 高置信度结果
accumulator = result.get("confidence_accumulator")
if accumulator and accumulator.results:
    print(f"高置信度结果数: {len(accumulator.results)}")

# 迭代日志追溯
for log in result.get("iteration_logs", []):
    print(
        f"  轮次{log.iteration}: "
        f"检索{log.retrieved_count}, "
        f"过滤{log.filtered_count}, "
        f"增益={log.information_gain:.4f}"
    )
```

### 5.4 检索函数接口规范

```
输入参数规范（按粒度不同）：
  document 级: query, top_k, score_threshold, **kwargs
  page 级:     query, top_k, doc_id_list=[...], score_threshold, **kwargs
  chunk 级:    query, top_k, doc_id_list=[...], page_id_list=[...], score_threshold, **kwargs

返回格式（统一为字典列表）：
  [
    {
      "doc_id": str,       # 文档唯一标识 (必填)
      "page_id": str,      # 页面标识 (document 级为空)
      "chunk_id": str,     # chunk 标识 (document/page 级为空)
      "content": str,      # 内容文本 (必填)
      "score": float,      # 相似度分数 0~1 (必填)
      "source": str,       # 来源知识库 ID (可选，自动填充)
      "metadata": dict,    # 扩展元数据 (可选)
    },
    ...
  ]
```

支持的后端:
- **向量数据库**: Milvus / Pinecone / Weaviate / Chroma / Qdrant
- **全文检索**: Elasticsearch / OpenSearch
- **混合检索**: 自定义混合策略
- **图数据库**: Neo4j 等（需自行适配检索函数）

---

## 6. 核心模块详解

### 6.1 全局状态 (graph_state)

全局状态是 LangGraph 图的数据中枢，所有节点通过读写状态进行通信。

```python
class GraphState(TypedDict, total=False):
    # ---- 原始输入 ----
    original_query: str

    # ---- 迭代控制 ----
    iteration_count: int           # 当前迭代轮次（每轮覆盖）
    should_continue: bool          # 是否继续迭代（每轮覆盖）

    # ---- 累积字段 (Annotated + operator.add) ----
    rewritten_queries: Annotated[list, operator.add]    # 所有改写查询
    raw_documents: Annotated[list, operator.add]         # 原始检索结果
    previous_gain_scores: Annotated[list, operator.add]  # 历史增益分数
    iteration_logs: Annotated[list, operator.add]        # 迭代日志
    retrieval_node_infos: Annotated[list, operator.add]  # 节点追踪（可视化）

    # ---- 路由决策 ----
    routing_decision: RoutingDecision  # 当前轮路由决策（含管道列表）

    # ---- 检索结果 ----
    filtered_documents: List[RetrievalResult]     # 当前轮过滤后结果
    document_history: List[RetrievalResult]        # 全量历史优质结果（去重后）

    # ---- 漏斗下钻候选 ID ----
    candidate_doc_ids: List[str]      # 候选文档 ID（供 page 级检索）
    candidate_page_ids: List[tuple]   # 候选页面 ID（供 chunk 级检索）

    # ---- 高置信度累加器 ----
    confidence_accumulator: ConfidenceAccumulator

    # ---- 评估指标 ----
    information_gain: float          # 当前轮信息增益

    # ---- 终止判定 ----
    termination_reason: str          # 终止原因
    no_gain_rounds: int              # 连续无增益轮次计数
    llm_coverage_judgment: str       # LLM 覆盖度判定结果
    continue_iteration_reason: str   # 继续迭代原因（传递给改写节点）

    # ---- 查询改写控制 ----
    need_decomposition: bool         # 当前轮是否需要拆解查询

    # ---- 最终输出 ----
    final_answer: str                # 最终生成答案
```

**关键数据结构**:

| 结构 | 核心字段 | 用途 |
|---|---|---|
| `RetrievalResult` | doc_id, page_id, chunk_id, content, source, score | 统一检索结果（三级粒度兼容） |
| `RetrievalToolCall` | tool_name, granularity, params | 管道中单个检索步骤的调用指令 |
| `RetrievalPipeline` | kb_id, steps: List[RetrievalToolCall], reasoning | 单个 KB 的有序检索步骤列表 |
| `RoutingDecision` | pipelines: List[RetrievalPipeline], reasoning | 路由决策（多 KB 多管道并行） |
| `ConfidenceAccumulator` | results, confidence_threshold, min_novelty | 高置信度累加器 |
| `IterationLog` | iteration, rewritten_queries, routing_decision, retrieved_count, filtered_count, information_gain | 单轮迭代日志 |
| `RetrievalNodeInfo` | iteration, node_name, status, duration_ms, input_summary, output_summary | 节点追踪信息 |

### 6.2 LLM 适配器 (llm_config)

全局单例模式，统一 LLM 调用接口。支持真实 LLM 和 Mock 模式无缝切换。

```python
# 初始化（项目启动时调用一次）
LLMAdapter.initialize(model_name="gpt-4o", api_key="sk-xxx")

# Mock 模式切换
from rag_iterative_system.config.llm_config import set_mock_mode, is_mock_mode
set_mock_mode(True)          # 切换到 Mock 模式
LLMAdapter.initialize(...)    # 无需真实 API Key
print(is_mock_mode())        # True

# 获取实例（自动根据 mock 模式返回对应适配器）
llm = get_llm()

# 文本调用
response = llm.call(prompt="...", system_prompt="...")

# JSON 调用（自动解析，兼容 markdown 代码块包裹）
result = llm.call_json(prompt="...", system_prompt="...")  # → dict
```

**MockLLMAdapter**: 根据提示词内容自动返回符合预期格式的响应，使整个 RAG 流程可以在无真实 API Key 时完整运行。覆盖以下场景：
- 查询改写 → 返回 `{"rewrites": [...]}`
- 拆解判定 → 返回 `{"need_decomposition": bool, "reason": "..."}`
- 路由决策 → 返回 `{"pipelines": [...], "reasoning": "..."}`
- 覆盖度判定 → 返回 `{"is_covered": bool, "uncovered_aspects": "..."}`

**JSON 解析容错**:
1. 自动剥离 markdown 代码块包裹（\`\`\`json ... \`\`\`）
2. 提取第一个 `{ ... }` 块
3. 全部失败时抛出 `LLMCallError`

### 6.3 查询改写节点 (rewrite_node)

#### 核心流程

```
输入 → [拆解判定] → 选择策略 → LLM 改写 → 输出改写查询列表
```

#### 拆解判定（条件性）

根据已有检索上下文，由 LLM 判断是否需要将查询拆解为多个子查询：

| 判断结果 | 策略 | 输出数量 |
|---|---|---|
| 不需要拆解 | 语义优化 + 同义词拓展 + 视角转换 | 1~2 条 |
| 需要拆解 | 问题拆分为子问题 + 分别优化 | 1~3 条 |

#### 首轮 vs 后续轮次

| 轮次 | 策略 | 注入上下文 |
|---|---|---|
| **首轮** (iteration=0) | 拆解判定 → 全面覆盖 / 聚焦优化 | 无（或预置上下文） |
| **后续轮次** | 拆解判定 → 针对性补充 | 高置信度结果摘要 + 继续迭代原因 + 已有改写查询 + 文档数量 |

**后续轮次额外注入**:
- **高置信度结果摘要**: 已检索到的高质量内容片段，帮助 LLM 了解已有信息
- **继续迭代原因**: 终止节点指出的未覆盖方面，引导改写方向
- **候选 ID 信息**: 已定位的文档/页面数

**降级策略**: LLM 调用失败 → 降级使用原始查询（确保不中断流程）

### 6.4 智能路由节点 (router_node)

#### 核心创新：策略反思引擎

路由节点不仅选择知识库，更是对历史检索效果的**全链路反思**：

```
输入 → 构建历史全链路上下文 → LLM 反思历史策略 → 规划新管道 → 输出管道列表
```

#### 历史上下文包含

| 维度 | 内容 | 用途 |
|---|---|---|
| 迭代摘要表 | 每轮的改写查询数、路由 KB、文档数、增益 | 快速把握整体趋势 |
| 节点详情 | 路由决策理由、检索结果分布、评估指标 | 深度分析单轮效果 |
| 信息增益趋势 | 各轮增益序列 + 趋势判断（上升/下降） | 判断策略有效性 |
| 继续迭代原因 | 终止节点指出的信息缺口 | 明确本轮检索目标 |

#### 输出格式：管道式决策

```json
{
  "pipelines": [
    {
      "kb_id": "tech_docs",
      "steps": [
        {
          "tool_name": "tech_docs__document",
          "granularity": "document",
          "params": {"query": "分布式系统高可用架构设计方法", "top_k": 5}
        },
        {
          "tool_name": "tech_docs__page",
          "granularity": "page",
          "params": {"query": "分布式系统高可用架构设计方法", "top_k": 5}
        },
        {
          "tool_name": "tech_docs__chunk",
          "granularity": "chunk",
          "params": {"query": "分布式系统高可用架构设计方法", "top_k": 5}
        }
      ],
      "reasoning": "技术文档库覆盖系统架构领域，从文档→页面→chunk 逐步下钻"
    }
  ],
  "reasoning": "整体决策理由（含对历史策略的反思）"
}
```

**降级策略**: 路由失败或返回无效目标 → 降级为全 KB 默认管道（根据候选 ID 智能选择粒度）

### 6.5 管道式检索节点 (retrieval_node)

#### 管道执行模型

```
单个 KB 管道：doc 检索 → 收集 doc_id → page 检索(doc_id_list) → 收集 page_id → chunk 检索(doc_id_list, page_id_list)
多个 KB 管道：并行执行（ThreadPoolExecutor, max_workers=8）
```

#### 前步输出自动传递

| 管道步骤 | 输入 ID 来源 | 传递给下一步 |
|---|---|---|
| Step 1: document | 无（仅 query） | → 收集 doc_id |
| Step 2: page | doc_id_list（来自 Step 1） | → 收集 (doc_id, page_id) |
| Step 3: chunk | doc_id_list + page_id_list（来自 Step 1+2） | → 最终结果 |

#### 执行模式

- **默认模式**: `ThreadPoolExecutor` 并行执行多 KB 管道（最大 8 线程）
- **降级模式**: 并行失败 → 自动切换串行执行
- **文档数量限制**: 单轮检索文档数不超过 `max_retrieved_docs_per_round`（默认 20）

#### 单步容错

每个检索函数调用通过 `safe_execute` 包裹，单 KB/单步骤失败不影响其他管道。

### 6.6 评估过滤节点 (evaluator_node)

#### 完整流水线

```
原始检索文档
    ↓
1. 低质过滤     (min_length=20, min_score=0.3)
    ↓
2. 精确去重     (层次化 ID 优先，退化为 MD5 哈希)
    ↓
3. 近似去重     (余弦相似度 > 0.95 视为重复)
    ↓
4. 历史去重     (与 document_history 比对)
    ↓
5. 长度裁剪     (总长度超 max_context_length=8000 时截断)
    ↓
过滤后文档
```

#### 并行计算

| 计算项 | 说明 |
|---|---|
| **信息增益** | 过滤后文档 vs 历史文档的平均新颖度 |
| **关键词覆盖度** | 查询词元在文档集合中的出现率 |
| **高置信度累加器更新** | 双重筛选（得分 ≥ confidence_threshold + 新颖度 ≥ min_novelty） |
| **候选 ID 收集** | 从历史文档中收集 doc_id / (doc_id, page_id)，供下轮下钻 |

#### 高置信度累加器 (ConfidenceAccumulator)

```python
class ConfidenceAccumulator:
    results: List[RetrievalResult]        # 高置信度结果列表
    confidence_threshold: float = 0.6     # reranker 得分阈值
    min_novelty: float = 0.1              # 最小新颖度阈值

    def add_results(self, new_results, existing_results=None) -> List[RetrievalResult]:
        """双重筛选：
        1. result.score >= confidence_threshold
        2. novelty(result, existing) >= min_novelty
        3. (doc_id, page_id, chunk_id) 不重复
        """
```

### 6.7 终止判定节点 (termination_node)

#### 迭代开关

- `enable_iterative_retrieval = True` → 进入 5 条件组合判定
- `enable_iterative_retrieval = False`（默认） → 首轮检索后直接终止

#### 5 条件组合判定（满足任一即终止）

| # | 条件 | 判定逻辑 | 示例 |
|---|---|---|---|
| 1 | 最大迭代轮次 | `iteration >= max_iterations` | 达到 3 轮上限 |
| 2 | 连续低增益 | `no_gain_rounds >= consecutive_threshold` | 连续 2 轮增益 < 0.05 |
| 3 | 关键词覆盖度充分 | `coverage >= 0.9` | 查询关键词 90%+ 已覆盖 |
| 4 | 无新增文档 | `filtered_count == 0` 或 `history >= max_total` | 无新文档 / 达 50 上限 |
| 5 | **LLM 语义覆盖度** | LLM 判定 `is_covered = true` | LLM 认为检索内容已覆盖查询诉求 |

#### 条件 5: LLM 语义覆盖度判定

```
输入: 查询 + 已检索文档摘要（最多 10 篇，每篇 150 字符）
LLM 分析:
  1. 提取查询的核心诉求点
  2. 逐条对照文档，判断每个诉求点是否有信息支撑
  3. 综合评估，输出 is_covered (bool)
输出: {"is_covered": bool, "coverage_analysis": "...", "uncovered_aspects": "...", "confidence": 0.0-1.0}
```

#### 继续迭代原因构建

当判定需要继续时，自动汇总以下信息传递给改写节点:
1. 基础提示: "第 N 轮检索后信息尚未充分覆盖"
2. 低增益警告: "本轮信息增益较低，可能检索方向需要调整"
3. LLM 未覆盖方面: 具体指出缺失的信息类型
4. 覆盖度不足: 当前关键词覆盖度百分比
5. 文档数量偏低: 建议扩大检索范围

### 6.8 答案生成节点 (answer_node)

#### 文档优先级

```
高置信度累加器结果 (优先)
         +
历史文档中的补充文档（去重后）
         ↓
构建格式化上下文
```

#### 上下文格式化

```
[文档1] [来源:tech_docs] [相关度:0.850] [doc=doc_1, page=p1, chunk=c3]
文档内容...

---
[文档2] [来源:faq_kb] [相关度:0.720] [doc=doc_2]
文档内容...
```

#### 保护机制

- **截断保护**: 上下文超过 `max_context_length`（8000 字符）时自动截断
- **异常降级**: 生成失败时返回包含已检索文档数的错误提示
- **溯源标注**: 每个引用标注来源知识库和分数

### 6.9 流程引擎 (rag_graph)

```python
# 构建图
graph = StateGraph(GraphState)

# 添加节点
graph.add_node("rewrite", rewrite_node)
graph.add_node("router", router_node)
graph.add_node("retrieval", retrieval_node)
graph.add_node("evaluator", evaluator_node)
graph.add_node("termination", termination_node)
graph.add_node("answer", answer_node)

# 入口
graph.set_entry_point("rewrite")

# 顺序边
graph.add_edge("rewrite", "router")
graph.add_edge("router", "retrieval")
graph.add_edge("retrieval", "evaluator")
graph.add_edge("evaluator", "termination")

# 条件边：循环闭环
graph.add_conditional_edges(
    "termination",
    _should_continue,
    {"continue": "rewrite", "generate": "answer"},
)

graph.add_edge("answer", END)
```

便捷调用:

```python
# 方式 1: 分布执行
compiled = compile_rag_graph()
result = run_rag_query("your query", compiled)

# 方式 2: 一步到位
result = run_rag_query("your query")  # 自动编译
```

---

## 7. 评估算法

### 7.1 相似度计算

| 算法 | 函数 | 复杂度 | 适用场景 |
|---|---|---|---|
| Jaccard 相似度 | `jaccard_similarity(a, b)` | O(n) | 快速粗筛，无序集合比较 |
| 余弦相似度（词频） | `cosine_similarity_text(a, b)` | O(n) | 精确文本相似度，词频加权 |

**分词策略**: 英文按空格 + 字母数字拆分；中文按字符 + 字母数字混合拆分，兼容中英文混合文本。

### 7.2 信息增益

```
信息增益 = Σ(新颖度_i) / N    (所有新文档的平均新颖度)

新颖度(新文档, 历史文档集) = 1 - max(余弦相似度(新文档, 历史文档_j))
```

- 新颖度 ∈ [0, 1]: 1 = 完全新颖，0 = 与某历史文档完全重复
- **信息增益 = 0**: 本轮无新增信息
- **信息增益 = 1**: 本轮所有文档都是全新信息
- **对 RetrievalResult 的特殊处理**: 优先按 `(doc_id, page_id, chunk_id)` 三元组精确匹配，完全一致直接判定新颖度 = 0

### 7.3 文档覆盖度（关键词）

```
覆盖度 = |查询词元 ∩ 文档词元| / |查询词元|

覆盖度 ∈ [0, 1]: 1 = 查询所有关键词都在文档中至少出现一次
```

### 7.4 过滤流水线

执行顺序: **低质过滤 → 精确去重 → 近似去重 → 历史去重 → 长度裁剪**

| 步骤 | 函数 | 方法 | 参数 |
|---|---|---|---|
| 1. 低质过滤 | `filter_low_quality` | 移除过短（< min_length）/ 低分（< min_score）文档 | `min_length=20`, `min_score=0.3` |
| 2. 精确去重 | `deduplicate_exact` | 层次化 ID 匹配（优先）→ MD5 哈希比对（退化） | - |
| 3. 近似去重 | `deduplicate_near` | 余弦相似度 > 阈值则去重（保留高分） | `threshold=0.95` |
| 4. 历史去重 | `deduplicate_against_history` | 新文档 vs 历史文档（先 ID 匹配，再相似度） | `threshold=0.95` |
| 5. 长度裁剪 | `truncate_documents` | 按分数降序，累计长度超限时截断（保留 min_doc_length 截断版） | `max_context_length=8000` |

---

## 8. 配置参数手册

### 8.1 系统配置 (SystemSettings)

#### 迭代控制

| 参数 | 默认值 | 说明 |
|---|---|---|
| `max_iterations` | 3 | 最大迭代轮次 |
| `min_information_gain` | 0.05 | 最小信息增益阈值（低于此值视为无新信息） |
| `consecutive_no_gain_rounds` | 2 | 连续无增益轮次阈值（触发条件 2 终止） |
| `enable_iterative_retrieval` | `False` | **迭代式检索总开关**（False=单轮，True=多轮迭代） |
| `enable_llm_coverage_judgment` | `True` | 是否启用 LLM 语义覆盖度判定（条件 5） |

#### 检索参数

| 参数 | 默认值 | 说明 |
|---|---|---|
| `default_top_k` | 5 | 默认检索文档数量 |
| `max_retrieved_docs_per_round` | 20 | 单轮最大检索文档数（截断保护） |
| `score_threshold` | 0.3 | 最低相似度分数阈值（低质过滤） |

#### 上下文控制

| 参数 | 默认值 | 说明 |
|---|---|---|
| `max_context_length` | 8000 | 最大上下文字符长度（答案生成时截断） |
| `max_total_documents` | 50 | 全流程累计最大文档数（触发条件 4 终止） |

#### 查询改写

| 参数 | 默认值 | 说明 |
|---|---|---|
| `max_rewrite_queries` | 3 | 需要拆解时每轮最大改写查询数（不拆解时 ≤ 2） |

#### 去重与过滤

| 参数 | 默认值 | 说明 |
|---|---|---|
| `dedup_similarity_threshold` | 0.95 | 去重相似度阈值（近似去重 + 历史去重） |
| `min_doc_length` | 20 | 最短有效文档字符数（低质过滤） |

#### 高置信度累加器

| 参数 | 默认值 | 说明 |
|---|---|---|
| `confidence_threshold` | 0.6 | reranker 得分阈值（条件 1） |
| `min_novelty_threshold` | 0.1 | 最小新颖度阈值（条件 2：信息增益筛选） |

#### LLM 调用

| 参数 | 默认值 | 说明 |
|---|---|---|
| `llm_model` | `gpt-4o` | 模型名称 |
| `llm_api_base` | `https://api.openai.com/v1` | API 基础地址 |
| `llm_api_key` | `sk-placeholder` | API 密钥 |
| `llm_temperature` | 0.0 | 温度参数（0=确定性输出） |
| `llm_max_tokens` | 4096 | 最大 token 数 |
| `llm_timeout` | 60 | 超时时间（秒） |

#### 重试与容错

| 参数 | 默认值 | 说明 |
|---|---|---|
| `max_retries` | 3 | 最大重试次数 |
| `retry_delay` | 1.0 | 基础重试间隔（秒），指数退避: 1→2→4 |
| `enable_fallback` | `True` | 是否启用降级兜底 |

#### 日志

| 参数 | 默认值 | 说明 |
|---|---|---|
| `log_level` | `INFO` | 日志级别 (`DEBUG`/`INFO`/`WARNING`/`ERROR`) |
| `enable_iteration_logging` | `True` | 是否记录迭代详细日志 |

### 8.2 环境变量覆盖

所有参数均支持环境变量覆盖，命名规则 `RAG_大写字段名`:

```bash
# 迭代控制
export RAG_MAX_ITERATIONS=5
export RAG_MIN_INFORMATION_GAIN=0.08
export RAG_ENABLE_ITERATIVE_RETRIEVAL=true
export RAG_ENABLE_LLM_COVERAGE_JUDGMENT=false

# LLM
export RAG_LLM_API_KEY="sk-your-key"
export RAG_LLM_MODEL="gpt-4o-mini"
export RAG_LLM_API_BASE="https://your-proxy.com/v1"
export RAG_LLM_TEMPERATURE=0.1
export RAG_LLM_MAX_TOKENS=8192

# 检索
export RAG_DEFAULT_TOP_K=10
export RAG_SCORE_THRESHOLD=0.4
export RAG_MAX_RETRIEVED_DOCS_PER_ROUND=30

# 去重
export RAG_DEDUP_SIMILARITY_THRESHOLD=0.90
export RAG_MIN_DOC_LENGTH=30

# 高置信度
export RAG_CONFIDENCE_THRESHOLD=0.7
export RAG_MIN_NOVELTY_THRESHOLD=0.15

# 重试
export RAG_MAX_RETRIES=5
export RAG_RETRY_DELAY=2.0

# 日志
export RAG_LOG_LEVEL=DEBUG
```

优先级: **环境变量 > 代码设定 > 默认值**

### 8.3 知识库配置

```python
register_knowledge_base(
    kb_id="unique_id",              # 唯一标识（必填）
    name="Display Name",            # 显示名称
    description="描述能力范围",       # 供路由决策使用
    domains=["领域1", "领域2"],       # 覆盖领域标签
    retrieval_mode=RetrievalMode.VECTOR,  # vector / keyword / hybrid
    top_k=5,                        # 默认检索数量
    score_threshold=0.5,            # 默认最低分数
    is_default=False,                # 设为默认知识库
    retrieval_func=your_func,       # 向后兼容：旧版单检索函数
)
```

---

## 9. 容错与降级机制

系统在每个关键环节均设有降级策略，确保单点故障不阻断整个流程:

| 模块 | 故障场景 | 降级策略 |
|---|---|---|
| **查询改写** | LLM 调用失败 | 降级使用原始查询 |
| **拆解判定** | LLM 调用失败 | 降级为不拆解 (`need_decomposition=False`) |
| **智能路由** | LLM 调用失败 / 返回无效目标 | 降级为全 KB 默认管道（根据候选 ID 智能选择粒度） |
| **多路检索** | 并行检索异常 | 自动切换串行检索 |
| **单 KB 检索** | 检索函数抛异常 | `safe_execute` 捕获，返回空列表，其他 KB 不受影响 |
| **单步管道** | 某步骤无结果 | 后续步骤可能受影响但不阻断（日志记录） |
| **答案生成** | LLM 调用失败 | 返回包含已检索文档数的错误提示 |
| **LLM 覆盖度判定** | LLM 调用失败 | 跳过条件 5，记录判定失败原因 |
| **JSON 解析** | LLM 返回非标准 JSON | 自动剥离代码块 → 提取 `{...}` 块 → 失败抛异常 |

### 重试机制

通过 `@retry_with_backoff` 装饰器实现指数退避重试:

- 默认最多重试 3 次
- 延迟: 1s → 2s → 4s → 8s（指数增长，上限 30s）
- 支持指定 `exceptions` 参数限定需要重试的异常类型
- 支持 `fallback` 参数指定全部失败后的降级返回值

### 异常体系

```
RAGSystemError               # 基础异常
  ├── LLMCallError           # LLM 调用异常（网络/API/超时）
  ├── RetrievalError         # 检索异常
  ├── RoutingError           # 路由异常
  ├── EvaluationError        # 评估异常
  └── ContextOverflowError   # 上下文超限异常
```

### 保护机制

| 机制 | 说明 |
|---|---|
| 空结果保护 | 检索无结果时不崩溃，继续流程 |
| 上下文长度限制 | `truncate_context` 防止 Token 爆炸 |
| 文档数量管控 | `max_total_documents=50` 防止历史文档无限增长 |
| 状态完整性校验 | `validate_state_integrity` 检查异常状态（空查询/负数轮次/文档超限） |
| 截断保留 | 长度裁剪时保留 `min_doc_length` 字符 + 截断标记 |

---

## 10. 可观测性

### 10.1 迭代感知日志器 (IterationLogger)

自动在每条日志前附加迭代轮次前缀:

```
[2026-04-29 10:30:01] INFO     rag_iterative        | [Iter-1] 查询改写完成: original='如何设计...' -> 3 条改写查询
[2026-04-29 10:30:02] INFO     rag_iterative        | [Iter-1] 路由决策: 目标知识库=['tech_docs'], 推理=分布式架构查询需要技术文档
[2026-04-29 10:30:02] INFO     rag_iterative        | [Iter-1] 检索完成: 总文档数=5, 各源={'tech_docs': 5}
[2026-04-29 10:30:03] INFO     rag_iterative        | [Iter-1] 评估完成: 原始=5, 过滤后=3, 信息增益=0.7200
[2026-04-29 10:30:03] INFO     rag_iterative        | [Iter-1] 终止判定: 继续迭代, 原因=
[2026-04-29 10:30:05] INFO     rag_iterative        | [Iter-2] 查询改写完成: original='如何设计...' -> 3 条改写查询
[2026-04-29 10:30:06] INFO     rag_iterative        | [Iter-2] 路由决策: 目标知识库=['faq_kb'], 推理=...
[2026-04-29 10:30:07] INFO     rag_iterative        | [Iter-2] 终止判定: 终止迭代, 原因=LLM判定覆盖充分(置信度:0.85)
[2026-04-29 10:30:07] INFO     rag_iterative        | [Iter-2] 答案生成完成: 长度=1250字符
```

### 10.2 结构化迭代日志

每轮迭代自动记录 `IterationLog`，存储在状态 `iteration_logs` 字段:

```python
@dataclass
class IterationLog:
    iteration: int                  # 当前轮次
    rewritten_queries: List[str]    # 改写查询
    routing_decision: str           # 路由决策摘要
    retrieved_count: int            # 检索文档数
    filtered_count: int             # 过滤后文档数
    information_gain: float         # 信息增益分数
    termination_reason: str         # 终止原因（仅最后一轮）
    need_decomposition: bool        # 本轮是否进行了查询拆解
    decomposition_reason: str       # 拆解判断原因
    llm_coverage_judgment: str      # LLM 覆盖度判定结果
    continue_iteration_reason: str  # 继续迭代的原因
```

### 10.3 运行结果访问

```python
result = run_rag_query("your query")

# 核心输出
result["final_answer"]          # 最终答案
result["iteration_count"]       # 总迭代轮次
result["termination_reason"]    # 终止原因
result["document_history"]      # 全流程优质文档列表

# 高置信度结果
acc = result.get("confidence_accumulator")
if acc:
    print(f"高置信度结果数: {len(acc.results)}")
    for r in acc.results:
        print(f"  [{r.source}] score={r.score:.3f}: {r.content[:80]}...")

# 迭代过程追溯
for log in result.get("iteration_logs", []):
    print(
        f"轮{log.iteration}: "
        f"检索={log.retrieved_count}, "
        f"过滤={log.filtered_count}, "
        f"增益={log.information_gain:.4f}, "
        f"拆解={'是' if log.need_decomposition else '否'}"
    )

# LLM 覆盖度判定
print(result.get("llm_coverage_judgment", ""))

# 继续迭代原因
print(result.get("continue_iteration_reason", ""))
```

### 10.4 检索过程可视化（HTML 报告）

系统自动生成交互式 HTML 报告，可在浏览器中查看完整的检索过程:

```python
from rag_iterative_system.utils.visualizer import RetrievalVisualizer

# 方式 1: 从查询结果生成
visualizer = RetrievalVisualizer()
report_path = visualizer.save_report(result)
print(f"报告已保存: {report_path}")  # retrieval_reports/report_xxx_20260429_103000.html

# 方式 2: 直接获取 HTML 字符串
html = visualizer.generate_html_report(result)

# 方式 3: 命令行中禁用
python -m rag_iterative_system.main --mock --no-visualize
```

**报告包含**:

| 标签页 | 内容 |
|---|---|
| **迭代时间线** | 每轮的改写查询、是否拆解、检索/过滤文档数、信息增益进度条、节点耗时卡片 |
| **节点详情** | 所有节点的输入/输出摘要、执行耗时、状态 |
| **LLM 判定** | LLM 覆盖度判定结果 + 继续迭代原因 |
| **最终答案** | 答案全文 |

报告文件保存在 `retrieval_reports/` 目录下。

---

## 11. Mock 模式（无 API Key 测试）

Mock 模式允许系统在没有真实 LLM API Key 的情况下完整运行，用于：
- 验证架构流程的正确性
- 测试各节点的连接和状态传递
- 调试 LangGraph 图的条件边和循环逻辑
- 快速演示系统能力

### 启用方式

```bash
# 命令行
python -m rag_iterative_system.main --mock
python -m rag_iterative_system.main --mock --iterative --query "你的问题"

# 编程方式
from rag_iterative_system.config.llm_config import set_mock_mode
set_mock_mode(True)
# 之后所有 get_llm() 调用返回 MockLLMAdapter
```

### MockLLMAdapter 行为

- `call_json(prompt, system_prompt)`: 根据提示词内容自动识别场景并返回符合预期的 JSON
  - 包含 `rewrites` → 返回改写查询结果
  - 包含 `need_decomposition` → 返回拆解判定结果
  - 包含 `pipelines` + `kb_id` → 返回路由决策结果
  - 包含 `is_covered` + `覆盖` → 返回覆盖度判定结果
- `call(prompt, system_prompt)`: 返回通用的模拟答案（含来源标注）
- Mock 模式下使用 `main.py` 中预定义的模拟检索函数（`mock_document_retrieval` / `mock_page_retrieval` / `mock_chunk_retrieval`），无需真实数据库

### Mock 模式下的完整能力

即使使用 Mock 模式，以下功能仍然完整可用：
- 三级粒度管道检索（模拟函数支持 doc_id / page_id 传递）
- 迭代式闭环（多轮改写 → 路由 → 检索 → 评估 → 终止）
- 拆解判定
- 策略反思（历史全链路上下文构建 + 趋势分析）
- LLM 覆盖度判定
- 高置信度累加器
- HTML 可视化报告生成

---

## 12. 扩展指南

### 12.1 接入新知识库

```python
from rag_iterative_system.config.knowledge_bases import (
    register_knowledge_base, register_retrieval_tool,
    RetrievalGranularity, RetrievalMode, get_registry,
)

# 1. 注册知识库元数据
register_knowledge_base(
    kb_id="milvus_docs",
    name="Milvus 文档库",
    description="向量索引的技术文档，支持语义搜索",
    domains=["向量数据库", "embedding", "语义搜索"],
    retrieval_mode=RetrievalMode.VECTOR,
    top_k=10,
)

# 2. 定义三级检索函数
def milvus_doc_search(query, top_k, score_threshold, **kwargs):
    """文档级检索"""
    ...

def milvus_page_search(query, top_k, doc_id_list=None, score_threshold=0.3, **kwargs):
    """页面级检索"""
    ...

def milvus_chunk_search(query, top_k, doc_id_list=None, page_id_list=None, score_threshold=0.3, **kwargs):
    """Chunk 级检索"""
    ...

# 3. 注册三级检索工具
register_retrieval_tool("milvus_docs", "milvus_docs__document",
    RetrievalGranularity.DOCUMENT, milvus_doc_search,
    description="文档级检索", scenario="文档定位")
register_retrieval_tool("milvus_docs", "milvus_docs__page",
    RetrievalGranularity.PAGE, milvus_page_search,
    description="页面级检索", scenario="页面下钻")
register_retrieval_tool("milvus_docs", "milvus_docs__chunk",
    RetrievalGranularity.CHUNK, milvus_chunk_search,
    description="Chunk 级检索", scenario="精确答案")

# 4. 校验
registry = get_registry()
missing = registry.validate_kb_tools("milvus_docs")
assert not missing, f"缺少粒度: {missing}"
```

无需修改任何主流程代码，路由模块会自动识别新知识库及其检索工具。

### 12.2 替换相似度算法

当前默认使用基于词频的余弦相似度。替换为向量嵌入相似度:

```python
from rag_iterative_system.evaluation.metrics import (
    compute_information_gain, compute_novelty, compute_novelty_for_result,
)
from sentence_transformers import SentenceTransformer, util

model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')

def embedding_similarity(text_a: str, text_b: str) -> float:
    emb_a = model.encode(text_a)
    emb_b = model.encode(text_b)
    return float(util.cos_sim(emb_a, emb_b))

# 使用自定义相似度函数
gain = compute_information_gain(new_docs, history_docs, similarity_func=embedding_similarity)
novelty = compute_novelty(doc, existing_docs, similarity_func=embedding_similarity)
```

### 12.3 新增终止条件

在 `termination_node.py` 中添加自定义条件:

```python
def _check_custom_condition(state: GraphState) -> tuple:
    """自定义终止条件"""
    if your_custom_logic(state):
        return True, "自定义条件触发: 具体原因"
    return False, ""

# 在 termination_node 函数中按顺序添加:
if not should_terminate:
    terminated, reason = _check_custom_condition(state)
    if terminated:
        should_terminate = True
        termination_reason = reason
```

### 12.4 自定义节点

遵循 LangGraph 节点规范，函数签名: `def node_name(state: GraphState) -> dict`:

```python
# example: 新增"查询分类"节点
def classify_node(state: GraphState) -> dict:
    query = state.get("original_query", "")
    # ... 分类逻辑 ...
    return {"query_category": "technical"}

# 在 rag_graph.py 中注册
graph.add_node("classify", classify_node)
# 调整边
graph.add_edge("rewrite", "classify")   # rewrite → classify → router
graph.add_edge("classify", "router")
# 删掉原有的: graph.add_edge("rewrite", "router")
```

### 12.5 接入真实 Reranker

当前高置信度累加器使用的是检索结果的原始 `score` 字段。如需接入专门的 Reranker（如 Cohere Rerank、BGE Reranker），在检索函数返回前或评估节点中调用 Reranker 更新 `score` 字段即可。

---

## 依赖版本

| 包 | 最低版本 | 用途 |
|---|---|---|
| `langgraph` | ≥ 0.2.0 | LangGraph 图编排框架（StateGraph + 条件边 + 循环） |
| `langchain-core` | ≥ 0.3.0 | LangChain 核心抽象（消息/模型接口） |
| `langchain-openai` | ≥ 0.2.0 | OpenAI 模型适配（ChatOpenAI） |
| `typing_extensions` | ≥ 4.0.0 | TypedDict 等类型扩展 |

---

## 设计哲学

1. **LLM 驱动，非规则驱动**: 路由、改写、覆盖度判定均由 LLM 语义决策，无硬编码规则，天然适配新领域和新知识库
2. **管道优于单步**: 三级粒度漏斗式检索，逐级下钻，兼顾召回率和精确度
3. **反思优于重复**: 路由节点分析历史效果并调整策略，避免无效重复检索
4. **优雅降级**: 每个关键环节都有容错兜底，单点故障不阻断全流程
5. **可观测性优先**: 结构化日志 + 节点追踪 + HTML 可视化报告，全流程透明
