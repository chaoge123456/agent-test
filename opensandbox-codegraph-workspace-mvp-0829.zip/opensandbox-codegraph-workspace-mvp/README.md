# OpenSandbox Workspace MVP（基于 OpenSandbox-main-0829）

本包来自 `OpenSandbox-main-0829` 的当前实现，只包含本次新增或修改的完整文件，并保留该源码树下的相对层级。

将 `OpenSandbox-main-0829/` 目录中的内容合并到测试平台上相同版本的 OpenSandbox 源码根目录。由于部分文件是完整文件而不是补丁，合并前请先备份或用 Git/三方合并检查冲突；不要直接覆盖测试平台已有的本地改动。

## 包含内容

- Server：OverlayFS workspace 服务、API 路由、请求/响应模型、配置、sandbox 删除清理 hook 与测试；
- MCP：`workspace_sandbox_create`、`codegraph_explore`；
- OpenAPI：`/workspaces/sandboxes` 契约。

本包不包含 CodeGraph 源码。镜像 `opensandbox/code-interpreter:v1.1.0` 已含 CodeGraph 时，不必重新安装；请确认容器内 `codegraph --version` 可运行。

## Linux Docker 主机配置

在 OpenSandbox Server 实际使用的 TOML 配置中加入：

```toml
[storage]
allowed_host_paths = ["/srv/agent-workspaces"]

[workspace]
enabled = true
root = "/srv/agent-workspaces"
allowed_repository_roots = ["/srv/user-code"]
retain_artifacts = true
```

用户可让 Agent 传入 `/srv/user-code/my-repo`。Server 会验证该路径在 `allowed_repository_roots` 内、是 Git 仓库，再以它为 OverlayFS 只读 lowerdir；sandbox 内真正可写的目录固定为 `/workspace/repo`。

`root` 必须同时位于 `storage.allowed_host_paths` 内，因为最终只有 `root/<workspace>/merged` 会被 Docker bind mount 到 sandbox。

## uv 安装与调试

在源码树中运行即可，`uv sync` 会使用当前本地源码：

```bash
cd OpenSandbox-main-0829/server
uv sync --all-groups
export SANDBOX_CONFIG_PATH=/absolute/path/to/workspace-test.toml
uv run opensandbox-server
```

另开终端运行 MCP：

```bash
cd OpenSandbox-main-0829/sdks/mcp/sandbox/python
uv sync --all-groups
export OPEN_SANDBOX_API_KEY=<server-api-key>
uv run opensandbox-mcp --domain 127.0.0.1:8080 --protocol http
```

测试平台需要同步 OpenSandbox Server 和 MCP 的 Python 依赖；不需要单独安装 CodeGraph Python/Node 包。

## 验证

```bash
cd OpenSandbox-main-0829/server
uv run pytest tests/test_workspace_routes.py tests/test_workspace_service.py -q
uv run ruff check opensandbox_server/config.py opensandbox_server/api/schema.py \
  opensandbox_server/api/workspace.py opensandbox_server/services/workspace.py

cd ../sdks/mcp/sandbox/python
uv run ruff check src/opensandbox_mcp/server.py
uv run pyright src/opensandbox_mcp/server.py
```

最后必须在 Docker daemon 所在 Linux 主机进行真实测试：针对同一 Git 仓库创建两个 workspace sandbox，分别修改同一文件，确认相互隔离、原仓不变，并确认 `codegraph_explore` 可看到修改后的代码。

## 当前 MVP 限制

- Server 进程需具备 OverlayFS mount/umount 权限；生产环境建议改为受限的宿主机 workspace-agent。
- workspace 映射目前是进程内状态，Server 重启后的挂载恢复尚未实现。
- 当前通过 `sandbox_kill` 触发 cleanup；TTL 异步终止事件的回收集成仍需补充。
- OpenAPI 已更新，但各语言生成 SDK 尚未生成 workspace client；MCP 目前直接调用该 HTTP endpoint。
