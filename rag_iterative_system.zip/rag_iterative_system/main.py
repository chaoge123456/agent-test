# -*- coding: utf-8 -*-
"""
项目入口、示例调用、流程测试
"""

from __future__ import annotations

import logging
import sys
from typing import Any, Dict, List

from rag_iterative_system.config.knowledge_bases import (
    KnowledgeBaseRegistry,
    RetrievalMode,
    get_registry,
    register_knowledge_base,
)
from rag_iterative_system.config.llm_config import LLMAdapter
from rag_iterative_system.config.system_settings import SystemSettings, get_settings, set_settings
from rag_iterative_system.graph.rag_graph import compile_rag_graph, run_rag_query
from rag_iterative_system.state.graph_state import Document
from rag_iterative_system.utils.logging import setup_logging

logger = logging.getLogger(__name__)


# ============================================================
# 示例：模拟检索函数（实际项目中替换为真实向量库检索）
# ============================================================

def mock_retrieval_func(
    query: str,
    top_k: int = 5,
    score_threshold: float = 0.3,
    retrieval_mode: str = "vector",
    **kwargs: Any,
) -> List[Dict[str, Any]]:
    """
    模拟检索函数

    实际项目中替换为:
    - 向量数据库检索 (Milvus, Pinecone, Weaviate等)
    - Elasticsearch全文检索
    - 混合检索等
    """
    # 模拟返回文档
    mock_docs = [
        {
            "content": f"关于'{query}'的详细说明文档。本知识库包含相关领域的专业技术资料，"
                       f"涵盖核心概念、实现方案与最佳实践。",
            "score": 0.85,
            "metadata": {"category": "technical", "version": "1.0"},
            "doc_id": f"mock_doc_{hash(query) % 1000}_1",
        },
        {
            "content": f"'{query}'的常见问题解答与使用指南。包括基础用法、高级配置、"
                       f"性能优化建议及故障排除方法。",
            "score": 0.72,
            "metadata": {"category": "faq", "version": "2.0"},
            "doc_id": f"mock_doc_{hash(query) % 1000}_2",
        },
        {
            "content": f"'{query}'相关技术架构设计与系统方案。讨论模块划分、接口定义、"
                       f"数据流转与扩展策略。",
            "score": 0.65,
            "metadata": {"category": "architecture", "version": "1.5"},
            "doc_id": f"mock_doc_{hash(query) % 1000}_3",
        },
    ]

    # 过滤低于阈值的文档
    return [doc for doc in mock_docs if doc["score"] >= score_threshold][:top_k]


def demo_setup() -> None:
    """演示环境初始化"""

    # 1. 配置系统参数
    settings = SystemSettings(
        max_iterations=3,
        min_information_gain=0.05,
        default_top_k=5,
        llm_model="gpt-4o",
        llm_api_base="https://api.openai.com/v1",
        llm_api_key="sk-your-api-key-here",  # 替换为真实API Key
        log_level="INFO",
    )
    set_settings(settings)

    # 2. 初始化日志
    setup_logging(level=settings.log_level)

    # 3. 初始化LLM适配器
    LLMAdapter.initialize(
        model_name=settings.llm_model,
        api_base=settings.llm_api_base,
        api_key=settings.llm_api_key,
        temperature=settings.llm_temperature,
        max_tokens=settings.llm_max_tokens,
        timeout=settings.llm_timeout,
    )

    # 4. 注册知识库（使用模拟检索函数）
    register_knowledge_base(
        kb_id="tech_docs",
        name="技术文档库",
        description="包含系统架构、API文档、技术规范等技术资料",
        domains=["技术", "架构", "API", "开发"],
        retrieval_mode=RetrievalMode.VECTOR,
        top_k=5,
        retrieval_func=mock_retrieval_func,
    )

    register_knowledge_base(
        kb_id="faq_kb",
        name="常见问题库",
        description="产品常见问题、使用指南、故障排除等FAQ文档",
        domains=["FAQ", "使用指南", "故障排除", "产品"],
        retrieval_mode=RetrievalMode.HYBRID,
        top_k=3,
        retrieval_func=mock_retrieval_func,
    )

    register_knowledge_base(
        kb_id="business_kb",
        name="业务知识库",
        description="业务流程、产品方案、行业知识等业务相关文档",
        domains=["业务", "产品", "方案", "行业"],
        retrieval_mode=RetrievalMode.KEYWORD,
        top_k=5,
        retrieval_func=mock_retrieval_func,
    )

    logger.info("演示环境初始化完成")


def main() -> None:
    """主入口函数"""
    demo_setup()

    # 编译图
    compiled_graph = compile_rag_graph()

    # 执行查询
    query = "如何设计一个高可用的分布式系统架构？"
    logger.info("=" * 60)
    logger.info("执行查询: %s", query)
    logger.info("=" * 60)

    result = run_rag_query(query, compiled_graph)

    # 输出结果
    print("\n" + "=" * 60)
    print("查询结果")
    print("=" * 60)
    print(f"\n原始问题: {result.get('original_query', '')}")
    print(f"迭代轮次: {result.get('iteration_count', 0)}")
    print(f"终止原因: {result.get('termination_reason', 'N/A')}")
    print(f"历史文档数: {len(result.get('document_history', []))}")
    print(f"\n最终答案:\n{result.get('final_answer', '无答案')}")

    # 输出迭代日志
    iteration_logs = result.get("iteration_logs", [])
    if iteration_logs:
        print(f"\n迭代过程日志 ({len(iteration_logs)} 轮):")
        for log in iteration_logs:
            if hasattr(log, "iteration"):
                print(
                    f"  轮次{log.iteration}: "
                    f"检索{log.retrieved_count}文档, "
                    f"过滤后{log.filtered_count}, "
                    f"增益={log.information_gain:.4f}"
                )


if __name__ == "__main__":
    main()
