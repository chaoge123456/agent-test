# -*- coding: utf-8 -*-
"""
信息增益、文本相似度、新颖度量化算法
- 向量相似度计算
- 信息增益评分
- 文本新颖度评估
"""

from __future__ import annotations

import hashlib
import logging
import math
from collections import Counter
from typing import List, Set

from rag_iterative_system.state.graph_state import Document

logger = logging.getLogger(__name__)


def _tokenize(text: str) -> List[str]:
    """简单中英文分词：按空格和标点拆分"""
    import re
    # 英文按空格，中文按字符
    tokens: List[str] = []
    # 先按空白拆分
    words = re.split(r"\s+", text.strip())
    for word in words:
        if not word:
            continue
        # 英文单词保留
        if re.match(r"^[a-zA-Z0-9]+$", word):
            tokens.append(word.lower())
        else:
            # 中文逐字拆分
            chars = re.findall(r"[\u4e00-\u9fff]|[a-zA-Z0-9]+", word)
            tokens.extend(c.lower() for c in chars)
    return tokens


def jaccard_similarity(text_a: str, text_b: str) -> float:
    """
    Jaccard相似度计算

    Args:
        text_a: 文本A
        text_b: 文本B

    Returns:
        相似度分数 [0, 1]
    """
    set_a: Set[str] = set(_tokenize(text_a))
    set_b: Set[str] = set(_tokenize(text_b))
    if not set_a and not set_b:
        return 1.0
    if not set_a or not set_b:
        return 0.0
    intersection = set_a & set_b
    union = set_a | set_b
    return len(intersection) / len(union)


def cosine_similarity_text(text_a: str, text_b: str) -> float:
    """
    基于词频的文本余弦相似度

    Args:
        text_a: 文本A
        text_b: 文本B

    Returns:
        相似度分数 [0, 1]
    """
    tokens_a = _tokenize(text_a)
    tokens_b = _tokenize(text_b)
    if not tokens_a or not tokens_b:
        return 0.0

    counter_a = Counter(tokens_a)
    counter_b = Counter(tokens_b)

    # 构建词表
    vocab = set(counter_a.keys()) | set(counter_b.keys())

    # 计算点积和模
    dot_product = sum(counter_a.get(w, 0) * counter_b.get(w, 0) for w in vocab)
    norm_a = math.sqrt(sum(v ** 2 for v in counter_a.values()))
    norm_b = math.sqrt(sum(v ** 2 for v in counter_b.values()))

    if norm_a == 0 or norm_b == 0:
        return 0.0

    return dot_product / (norm_a * norm_b)


def compute_novelty(
    new_doc: Document,
    existing_docs: List[Document],
    similarity_func=None,
) -> float:
    """
    计算新文档相对于已有文档集合的新颖度

    新颖度 = 1 - max(相似度)
    即与已有文档的最大相似度越低，新颖度越高

    Args:
        new_doc: 待评估的新文档
        existing_docs: 已有文档集合
        similarity_func: 相似度计算函数（默认cosine_similarity_text）

    Returns:
        新颖度分数 [0, 1]，1表示完全新颖
    """
    if similarity_func is None:
        similarity_func = cosine_similarity_text

    if not existing_docs:
        return 1.0

    max_sim = 0.0
    for doc in existing_docs:
        sim = similarity_func(new_doc.content, doc.content)
        max_sim = max(max_sim, sim)

    return 1.0 - max_sim


def compute_information_gain(
    new_docs: List[Document],
    history_docs: List[Document],
    similarity_func=None,
) -> float:
    """
    计算单轮检索的信息增益

    信息增益 = 所有新文档的平均新颖度
    反映本轮检索相对于历史文档的增量信息量

    Args:
        new_docs: 本轮新增的过滤后文档
        history_docs: 历史全量优质文档
        similarity_func: 相似度计算函数

    Returns:
        信息增益分数 [0, 1]
    """
    if not new_docs:
        return 0.0

    if similarity_func is None:
        similarity_func = cosine_similarity_text

    total_novelty = 0.0
    for doc in new_docs:
        novelty = compute_novelty(doc, history_docs, similarity_func)
        total_novelty += novelty

    gain = total_novelty / len(new_docs)
    logger.debug(
        "信息增益计算: 新文档=%d, 历史文档=%d, 增益=%.4f",
        len(new_docs),
        len(history_docs),
        gain,
    )
    return gain


def compute_coverage_score(
    query: str,
    documents: List[Document],
) -> float:
    """
    计算检索文档对查询的覆盖度

    基于查询关键词在文档中的出现率评估覆盖程度

    Args:
        query: 用户查询
        documents: 文档集合

    Returns:
        覆盖度分数 [0, 1]
    """
    if not documents:
        return 0.0

    query_tokens = set(_tokenize(query))
    if not query_tokens:
        return 0.0

    # 计算查询关键词在文档集合中的覆盖率
    all_doc_tokens: Set[str] = set()
    for doc in documents:
        all_doc_tokens.update(_tokenize(doc.content))

    covered = query_tokens & all_doc_tokens
    return len(covered) / len(query_tokens)


def doc_content_hash(doc: Document) -> str:
    """
    计算文档内容哈希，用于精确去重

    Args:
        doc: 文档对象

    Returns:
        内容MD5哈希值
    """
    content = doc.content.strip()
    return hashlib.md5(content.encode("utf-8")).hexdigest()
