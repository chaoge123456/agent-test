# -*- coding: utf-8 -*-
"""
文档过滤、去重、信息增益量化评估节点
- 清洗过滤：文档去重、低质过滤、上下文长度裁剪
- 增益评估：量化计算单轮迭代信息增益分数
- 粒度感知：document/page级按ID去重与ID增益，chunk级保持原逻辑
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Set, Tuple

from rag_iterative_system.evaluation.filters import full_filter_pipeline
from rag_iterative_system.evaluation.metrics import (
    compute_coverage_score,
    compute_information_gain,
)
from rag_iterative_system.state.graph_state import Document, GraphState, IterationLog
from rag_iterative_system.utils.logging import get_iteration_logger

logger = logging.getLogger(__name__)


# ---- 粒度感知工具函数 ----

def _get_granularity(doc: Document) -> str:
    """从文档 metadata 中提取粒度标记，默认 chunk"""
    return doc.metadata.get("granularity", "chunk")


def _get_granularity_id(doc: Document) -> str:
    """
    获取粒度级别的唯一标识

    - document: doc_id
    - page:     doc_id + "_" + page_id
    - chunk:    content 哈希（退化为原有逻辑）
    """
    g = _get_granularity(doc)
    if g == "document":
        return str(doc.metadata.get("doc_id", doc.doc_id))
    elif g == "page":
        return f"{doc.metadata.get('doc_id', '')}_p{doc.metadata.get('page_id', '')}"
    else:
        # chunk 级用 content 去重，与原逻辑一致
        return doc.content.strip()


def _dedup_by_granularity(
    docs: List[Document],
    seen_ids: Set[str],
) -> List[Document]:
    """
    按粒度ID去重，返回不在 seen_ids 中的新文档

    document/page 级: 按 ID 精确匹配 O(1)
    chunk 级: 按 content 精确匹配 O(1)（与原逻辑等效）
    """
    kept: List[Document] = []
    for doc in docs:
        gid = _get_granularity_id(doc)
        if gid not in seen_ids:
            seen_ids.add(gid)
            kept.append(doc)
    return kept


def _compute_granularity_gain(
    new_docs: List[Document],
    history_docs: List[Document],
) -> float:
    """
    粒度感知的信息增益计算

    - chunk 级: 调用原有的 compute_information_gain（基于文本新颖度）
    - document/page 级: 新增ID占比 = 新增条目数 / 本轮总数（更轻量、更语义准确）
    """
    if not new_docs:
        return 0.0

    granularity = _get_granularity(new_docs[0]) if new_docs else "chunk"

    if granularity == "chunk":
        return compute_information_gain(new_docs, history_docs)

    # document / page 级：按 ID 精确去重计算新增比例
    history_ids = {_get_granularity_id(doc) for doc in history_docs}
    new_count = sum(1 for doc in new_docs if _get_granularity_id(doc) not in history_ids)
    return new_count / len(new_docs) if new_docs else 0.0


def _collect_candidate_ids(docs: List[Document], granularity: str) -> Tuple[List[int], List[list]]:
    """
    从文档列表中收集候选 doc_id / page_id，供下钻传递

    Returns:
        (candidate_doc_ids, candidate_page_ids)
    """
    doc_ids: List[int] = []
    page_ids: List[list] = []

    seen_doc: Set[int] = set()
    seen_page: Set[str] = set()

    for doc in docs:
        raw_doc_id = doc.metadata.get("doc_id")
        raw_page_id = doc.metadata.get("page_id")

        # 收集 doc_id
        if raw_doc_id is not None and raw_doc_id not in seen_doc:
            doc_ids.append(raw_doc_id)
            seen_doc.add(raw_doc_id)

        # 收集 (doc_id, page_id)
        if raw_doc_id is not None and raw_page_id is not None:
            page_key = f"{raw_doc_id}_p{raw_page_id}"
            if page_key not in seen_page:
                page_ids.append([raw_doc_id, raw_page_id])
                seen_page.add(page_key)

    return doc_ids, page_ids


def _extract_current_raw_docs(raw_documents: Any) -> List[Document]:
    """
    从状态中提取当前轮的原始检索文档

    raw_documents是Annotated[list, operator.add]累积字段，
    需要只取最新一批（最后一组列表）
    """
    if not raw_documents:
        return []

    # raw_documents 可能是累积的扁平列表
    # 这里直接当作当前轮的文档处理（因为每轮检索都会追加）
    # 在实际使用中，由于LangGraph的operator.add会合并所有轮次，
    # 我们需要只处理本轮新增的文档
    if isinstance(raw_documents, list):
        # 如果元素是Document对象，直接返回
        if raw_documents and isinstance(raw_documents[0], Document):
            return raw_documents
        # 如果元素是字典，转换
        docs = []
        for item in raw_documents:
            if isinstance(item, Document):
                docs.append(item)
            elif isinstance(item, dict):
                docs.append(Document(**item))
        return docs

    return []


def evaluator_node(state: GraphState) -> dict:
    """
    结果评估节点

    执行完整的过滤流水线，计算信息增益。
    粒度感知：
    - chunk 级（默认）：行为与原逻辑完全一致
    - document/page 级：按 ID 去重 + ID 增益计算，同时收集候选 ID 供下钻

    Args:
        state: 当前图状态

    Returns:
        状态更新字典
    """
    iter_logger = get_iteration_logger()
    iteration = state.get("iteration_count", 1)

    # 获取当前轮原始检索文档
    raw_docs = _extract_current_raw_docs(state.get("raw_documents", []))

    # 确定当前轮检索粒度
    granularity = state.get("retrieval_granularity", "chunk")
    # 如果文档本身携带了粒度标记，以文档为准
    if raw_docs:
        granularity = _get_granularity(raw_docs[0])

    # 获取历史优质文档
    doc_history = state.get("document_history", [])

    # ---- 过滤流水线（所有粒度共用） ----
    filtered_docs = full_filter_pipeline(raw_docs, history_docs=doc_history)

    # ---- 粒度感知增益计算 ----
    information_gain = _compute_granularity_gain(filtered_docs, doc_history)

    # ---- 粒度感知历史合并 ----
    updated_history = list(doc_history)
    if granularity == "chunk":
        # chunk 级：按 content 精确去重（原逻辑）
        existing_contents = {doc.content.strip() for doc in updated_history}
        for doc in filtered_docs:
            if doc.content.strip() not in existing_contents:
                updated_history.append(doc)
                existing_contents.add(doc.content.strip())
    else:
        # document / page 级：按粒度 ID 去重
        seen_ids: Set[str] = set()
        for doc in updated_history:
            seen_ids.add(_get_granularity_id(doc))
        for doc in filtered_docs:
            gid = _get_granularity_id(doc)
            if gid not in seen_ids:
                updated_history.append(doc)
                seen_ids.add(gid)

    # ---- 收集候选 ID（供漏斗下钻传递） ----
    candidate_doc_ids, candidate_page_ids = _collect_candidate_ids(
        updated_history, granularity
    )
    # 合并历史已有候选（只增不减）
    prev_doc_ids = state.get("candidate_doc_ids", [])
    prev_page_ids = state.get("candidate_page_ids", [])
    merged_doc_ids = list(dict.fromkeys(prev_doc_ids + candidate_doc_ids))
    seen_page_keys: Set[str] = set()
    merged_page_ids: List[list] = []
    for pair in prev_page_ids + candidate_page_ids:
        key = f"{pair[0]}_p{pair[1]}"
        if key not in seen_page_keys:
            merged_page_ids.append(pair)
            seen_page_keys.add(key)

    # 计算覆盖度
    original_query = state.get("original_query", "")
    coverage = compute_coverage_score(original_query, updated_history)

    iter_logger.log_evaluation(
        raw_count=len(raw_docs),
        filtered_count=len(filtered_docs),
        gain=information_gain,
    )

    logger.info(
        "评估完成 [Iter-%d] [%s]: 原始=%d, 过滤后=%d, 增益=%.4f, 覆盖度=%.2f, 历史总量=%d, 候选doc=%d, 候选page=%d",
        iteration,
        granularity,
        len(raw_docs),
        len(filtered_docs),
        information_gain,
        coverage,
        len(updated_history),
        len(merged_doc_ids),
        len(merged_page_ids),
    )

    # 构建迭代日志
    iter_log = IterationLog(
        iteration=iteration,
        rewritten_queries=_get_current_queries(state),
        routing_decision=_get_routing_summary(state),
        retrieved_count=len(raw_docs),
        filtered_count=len(filtered_docs),
        information_gain=information_gain,
    )

    return {
        "filtered_documents": filtered_docs,
        "document_history": updated_history,
        "information_gain": information_gain,
        "previous_gain_scores": [information_gain],
        "retrieval_granularity": granularity,
        "candidate_doc_ids": merged_doc_ids,
        "candidate_page_ids": merged_page_ids,
        "iteration_logs": [iter_log],
    }


def _get_current_queries(state: Any) -> List[str]:
    """获取当前轮改写查询"""
    rewritten = state.get("rewritten_queries", [])
    if not rewritten:
        return [state.get("original_query", "")]
    # 取最后一组
    if isinstance(rewritten[-1], list):
        return rewritten[-1]
    return rewritten if isinstance(rewritten, list) else [str(rewritten)]


def _get_routing_summary(state: Any) -> str:
    """获取路由决策摘要"""
    routing = state.get("routing_decision")
    if routing is None:
        return ""
    if hasattr(routing, "reasoning"):
        return routing.reasoning[:200]
    return str(routing)[:200]
