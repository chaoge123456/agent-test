# -*- coding: utf-8 -*-
"""
多路并行检索执行节点
- 对接多数据源、多索引引擎
- 支持并行检索提升效率
- 聚合多源原始文档结果
"""

from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List

from rag_iterative_system.config.knowledge_bases import get_registry
from rag_iterative_system.config.system_settings import get_settings
from rag_iterative_system.state.graph_state import Document, GraphState
from rag_iterative_system.utils.error_handler import safe_execute
from rag_iterative_system.utils.logging import get_iteration_logger

logger = logging.getLogger(__name__)


def _retrieve_from_single_source(
    kb_id: str,
    queries: List[str],
    retrieval_mode: str,
    top_k: int,
    score_threshold: float,
    extra: Dict[str, Any],
) -> List[Document]:
    """从单个知识库检索文档"""
    registry = get_registry()

    try:
        retrieval_func = registry.get_retrieval_func(kb_id)
    except KeyError:
        logger.warning("知识库 %s 未注册检索函数，跳过", kb_id)
        return []

    all_docs: List[Document] = []

    for query in queries:
        try:
            result = safe_execute(
                retrieval_func,
                query=query,
                top_k=top_k,
                score_threshold=score_threshold,
                retrieval_mode=retrieval_mode,
                **extra,
                default=[],
                log_error=True,
            )
            if result and isinstance(result, list):
                for item in result:
                    if isinstance(item, dict):
                        doc = Document(
                            content=item.get("content", ""),
                            source=kb_id,
                            score=item.get("score", 0.0),
                            metadata=item.get("metadata", {}),
                            doc_id=item.get("doc_id", ""),
                        )
                        all_docs.append(doc)
                    elif isinstance(item, Document):
                        item.source = kb_id
                        all_docs.append(item)
        except Exception as e:
            logger.error(
                "知识库 %s 检索失败 (query=%s): %s",
                kb_id, query[:50], str(e)[:200],
            )

    all_docs.sort(key=lambda d: d.score, reverse=True)
    return all_docs[:top_k]


def _execute_parallel_retrieval(
    targets: List[Dict[str, Any]],
) -> List[Document]:
    """并行执行多路检索"""
    settings = get_settings()
    all_documents: List[Document] = []

    with ThreadPoolExecutor(max_workers=min(len(targets), 8)) as executor:
        futures = {}
        for target in targets:
            kb_id = target.get("kb_id", "unknown")
            future = executor.submit(
                _retrieve_from_single_source,
                kb_id=kb_id,
                queries=target.get("queries", []),
                retrieval_mode=target.get("retrieval_mode", "vector"),
                top_k=target.get("top_k", settings.default_top_k),
                score_threshold=target.get("score_threshold", settings.score_threshold),
                extra=target.get("extra", {}),
            )
            futures[future] = kb_id

        for future in as_completed(futures):
            kb_id = futures[future]
            try:
                docs = future.result()
                all_documents.extend(docs)
                logger.debug("知识库 %s 检索完成: %d 文档", kb_id, len(docs))
            except Exception as e:
                logger.error("知识库 %s 检索异常: %s", kb_id, str(e)[:200])

    return all_documents


def _execute_sequential_retrieval(
    targets: List[Dict[str, Any]],
) -> List[Document]:
    """串行执行多路检索（用于调试或资源受限场景）"""
    settings = get_settings()
    all_documents: List[Document] = []

    for target in targets:
        kb_id = target.get("kb_id", "unknown")
        docs = _retrieve_from_single_source(
            kb_id=kb_id,
            queries=target.get("queries", []),
            retrieval_mode=target.get("retrieval_mode", "vector"),
            top_k=target.get("top_k", settings.default_top_k),
            score_threshold=target.get("score_threshold", settings.score_threshold),
            extra=target.get("extra", {}),
        )
        all_documents.extend(docs)

    return all_documents


def retrieval_node(state: GraphState) -> dict:
    """
    多路检索执行节点

    根据路由决策并行/串行执行多知识库检索，聚合原始文档

    Args:
        state: 当前图状态

    Returns:
        状态更新字典，包含原始检索文档
    """
    settings = get_settings()
    iter_logger = get_iteration_logger()

    routing_decision = state.get("routing_decision")
    if routing_decision is None:
        logger.warning("路由决策为空，跳过检索")
        return {"raw_documents": []}

    targets = routing_decision.targets if hasattr(routing_decision, "targets") else []
    if not targets:
        logger.warning("路由目标为空，跳过检索")
        return {"raw_documents": []}

    # 并行检索（默认），失败时降级为串行
    try:
        raw_documents = _execute_parallel_retrieval(targets)
    except Exception as e:
        logger.error("并行检索失败，降级为串行: %s", str(e)[:200])
        raw_documents = _execute_sequential_retrieval(targets)

    # 限制单轮最大文档数
    if len(raw_documents) > settings.max_retrieved_docs_per_round:
        raw_documents.sort(key=lambda d: d.score, reverse=True)
        raw_documents = raw_documents[:settings.max_retrieved_docs_per_round]

    # 统计各源文档数
    by_source: Dict[str, int] = {}
    for doc in raw_documents:
        by_source[doc.source] = by_source.get(doc.source, 0) + 1

    iter_logger.log_retrieval(len(raw_documents), by_source)

    return {"raw_documents": raw_documents}
