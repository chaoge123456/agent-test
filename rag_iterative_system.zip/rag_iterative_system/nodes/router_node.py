# -*- coding: utf-8 -*-
"""
智能检索路由决策节点
- 依托大模型语义决策，无硬编码规则
- 结合查询意图与知识库能力选择目标知识库
- 输出标准化路由决策结构体
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, List

from rag_iterative_system.config.knowledge_bases import get_registry
from rag_iterative_system.config.llm_config import get_llm
from rag_iterative_system.config.system_settings import get_settings
from rag_iterative_system.state.graph_state import GraphState, RoutingDecision
from rag_iterative_system.utils.error_handler import retry_with_backoff, RoutingError
from rag_iterative_system.utils.logging import get_iteration_logger

logger = logging.getLogger(__name__)

# 路由决策系统提示词
ROUTING_SYSTEM_PROMPT = """你是一个智能检索路由专家。你需要根据用户查询的意图和语义，决定应该在哪些知识库中检索，以及使用什么检索策略。

可用知识库列表：
{kb_descriptions}

路由决策规则：
1. 根据查询主题匹配最相关的知识库
2. 一个查询可以路由到多个知识库
3. 对于综合性问题，选择多个知识库联合检索
4. 对于专业问题，精准选择领域匹配的知识库
5. 如果没有完全匹配的知识库，选择最接近的
6. 检索粒度选择：首次检索建议"document"（定位文档），已有候选文档后建议"page"（定位页面），需要精确答案时建议"chunk"（提取片段）。如不确定则默认"chunk"

输出JSON格式：
{{
  "targets": [
    {{
      "kb_id": "知识库ID",
      "queries": ["该知识库使用的检索查询1", "检索查询2"],
      "retrieval_mode": "vector|keyword|hybrid",
      "top_k": 5,
      "score_threshold": 0.5,
      "granularity": "document|page|chunk"
    }}
  ],
  "reasoning": "路由决策的推理过程说明"
}}"""


@retry_with_backoff(max_retries=2, exceptions=(RoutingError,))
def _call_routing_llm(prompt: str, system_prompt: str) -> RoutingDecision:
    """调用LLM执行路由决策"""
    llm = get_llm()
    result = llm.call_json(prompt, system_prompt)

    targets = result.get("targets", [])
    reasoning = result.get("reasoning", "")

    # 校验路由结果：确保目标知识库已注册
    registry = get_registry()
    valid_targets = []
    for target in targets:
        kb_id = target.get("kb_id", "")
        try:
            kb_config = registry.get(kb_id)
            # 填充默认值
            target.setdefault("retrieval_mode", kb_config.retrieval_mode.value)
            target.setdefault("top_k", kb_config.top_k)
            target.setdefault("score_threshold", kb_config.score_threshold)
            # 确保queries字段存在
            if "queries" not in target or not target["queries"]:
                target["queries"] = []
            valid_targets.append(target)
        except KeyError:
            logger.warning("路由指向未注册知识库，跳过: %s", kb_id)

    if not valid_targets:
        # 降级：路由到所有已启用知识库
        logger.warning("路由决策无有效目标，降级路由到所有已启用知识库")
        for kb in registry.list_enabled():
            valid_targets.append({
                "kb_id": kb.kb_id,
                "queries": [],
                "retrieval_mode": kb.retrieval_mode.value,
                "top_k": kb.top_k,
                "score_threshold": kb.score_threshold,
            })

    return RoutingDecision(targets=valid_targets, reasoning=reasoning)


def router_node(state: GraphState) -> dict:
    """
    智能路由决策节点

    根据改写后的查询列表，利用LLM决策目标知识库与检索策略

    Args:
        state: 当前图状态

    Returns:
        状态更新字典，包含路由决策结果
    """
    settings = get_settings()
    iter_logger = get_iteration_logger()
    registry = get_registry()

    # 获取改写查询
    rewritten_queries = state.get("rewritten_queries", [])
    # 取最新一批改写查询（最后一组）
    if rewritten_queries and isinstance(rewritten_queries[-1], list):
        current_queries = rewritten_queries[-1]
    elif isinstance(rewritten_queries, list):
        # flattened list
        current_queries = rewritten_queries if rewritten_queries else [state.get("original_query", "")]
    else:
        current_queries = [state.get("original_query", "")]

    original_query = state.get("original_query", "")

    # 构建知识库描述
    kb_descriptions = registry.get_descriptions_for_routing()
    if not kb_descriptions.strip():
        kb_descriptions = "（未注册任何知识库，将使用默认检索）"

    system_prompt = ROUTING_SYSTEM_PROMPT.format(kb_descriptions=kb_descriptions)

    user_prompt = (
        f"原始查询: {original_query}\n"
        f"当前改写查询: {json.dumps(current_queries, ensure_ascii=False)}\n\n"
        f"请进行路由决策，选择最合适的知识库和检索策略。"
    )

    try:
        routing_decision = _call_routing_llm(user_prompt, system_prompt)
    except Exception as e:
        logger.error("路由决策失败，使用降级策略: %s", str(e)[:200])
        # 降级：路由到所有已启用知识库
        fallback_targets = []
        for kb in registry.list_enabled():
            fallback_targets.append({
                "kb_id": kb.kb_id,
                "queries": current_queries,
                "retrieval_mode": kb.retrieval_mode.value,
                "top_k": kb.top_k,
                "score_threshold": kb.score_threshold,
                "extra": {
                    "granularity": state.get("retrieval_granularity", "chunk"),
                    "candidate_doc_ids": state.get("candidate_doc_ids", []),
                    "candidate_page_ids": state.get("candidate_page_ids", []),
                },
            })
        routing_decision = RoutingDecision(
            targets=fallback_targets,
            reasoning=f"路由决策异常降级: {str(e)[:100]}",
        )

    # 如果路由目标的queries为空，用当前改写查询填充
    # 同时向每个 target 的 extra 注入粒度和候选ID（供检索闭包使用）
    current_granularity = state.get("retrieval_granularity", "chunk")
    candidate_doc_ids = state.get("candidate_doc_ids", [])
    candidate_page_ids = state.get("candidate_page_ids", [])

    for target in routing_decision.targets:
        if not target.get("queries"):
            target["queries"] = current_queries

        # 粒度：LLM输出优先 → 终止节点下钻建议 → 默认chunk
        llm_granularity = target.get("granularity", "")
        extra = target.get("extra", {})
        if not isinstance(extra, dict):
            extra = {}
        extra["granularity"] = llm_granularity or current_granularity
        extra["candidate_doc_ids"] = candidate_doc_ids
        extra["candidate_page_ids"] = candidate_page_ids
        target["extra"] = extra

    iter_logger.log_routing(
        routing_decision.targets,
        routing_decision.reasoning,
    )

    return {
        "routing_decision": routing_decision,
    }
