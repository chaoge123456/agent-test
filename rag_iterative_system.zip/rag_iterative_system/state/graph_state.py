# -*- coding: utf-8 -*-
"""
LangGraph全局状态结构化定义
- 基于TypedDict的类型约束
- 使用Annotated支持状态累积（operator.add）
- 全流程数据集中管理
"""

from __future__ import annotations

import operator
from dataclasses import dataclass, field
from typing import Annotated, Any, Dict, List, Optional

from typing_extensions import TypedDict


@dataclass
class Document:
    """检索文档结构"""
    content: str                                        # 文档文本内容
    source: str                                         # 来源知识库ID
    score: float = 0.0                                  # 相似度分数
    metadata: Dict[str, Any] = field(default_factory=dict)  # 元数据
    doc_id: str = ""                                    # 文档唯一标识（用于去重）


@dataclass
class RoutingDecision:
    """路由决策结果"""
    targets: List[Dict[str, Any]] = field(default_factory=list)
    reasoning: str = ""


@dataclass
class IterationLog:
    """单轮迭代日志"""
    iteration: int                                      # 当前轮次
    rewritten_queries: List[str] = field(default_factory=list)
    routing_decision: str = ""                          # 路由决策摘要
    retrieved_count: int = 0                            # 检索文档数
    filtered_count: int = 0                             # 过滤后文档数
    information_gain: float = 0.0                       # 信息增益分数
    termination_reason: str = ""                        # 终止原因（仅最后一轮）


class GraphState(TypedDict, total=False):
    """
    LangGraph全局状态定义

    字段说明:
    - 带 Annotated[..., operator.add] 的字段在每轮迭代中累积追加
    - 不带 Annotated 的字段每轮覆盖更新
    """
    # ---- 原始输入 ----
    original_query: str                                 # 用户原始查询

    # ---- 迭代控制 ----
    iteration_count: int                                # 当前迭代轮次
    should_continue: bool                               # 是否继续迭代

    # ---- 查询改写 ----
    rewritten_queries: Annotated[list, operator.add]    # 所有改写查询（累积）

    # ---- 路由决策 ----
    routing_decision: RoutingDecision                   # 当前轮路由决策

    # ---- 检索结果 ----
    raw_documents: Annotated[list, operator.add]        # 原始检索文档（累积）
    filtered_documents: List[Document]                  # 当前轮过滤后文档

    # ---- 历史快照 ----
    document_history: List[Document]                    # 全量历史优质文档（去重后）
    previous_gain_scores: Annotated[list, operator.add] # 历史信息增益分数（累积）

    # ---- 评估指标 ----
    information_gain: float                             # 当前轮信息增益

    # ---- 粒度控制（漏斗式下钻：document → page → chunk） ----
    retrieval_granularity: str                          # 当前轮检索粒度 "chunk"(默认) / "page" / "document"
    candidate_doc_ids: List[int]                        # 文档级候选集（供下钻传递）
    candidate_page_ids: List[list]                      # 页面级候选集 [[doc_id, page_id], ...]

    # ---- 终止判定 ----
    termination_reason: str                             # 终止原因描述
    no_gain_rounds: int                                 # 连续无增益轮次计数

    # ---- 最终输出 ----
    final_answer: str                                   # 最终生成答案

    # ---- 运行日志 ----
    iteration_logs: Annotated[list, operator.add]       # 全流程迭代日志（累积）


def create_initial_state(query: str) -> dict:
    """
    创建初始状态

    Args:
        query: 用户原始查询

    Returns:
        初始化的状态字典
    """
    return {
        "original_query": query,
        "iteration_count": 0,
        "should_continue": True,
        "rewritten_queries": [],
        "routing_decision": RoutingDecision(),
        "raw_documents": [],
        "filtered_documents": [],
        "document_history": [],
        "previous_gain_scores": [],
        "information_gain": 0.0,
        "retrieval_granularity": "chunk",
        "candidate_doc_ids": [],
        "candidate_page_ids": [],
        "termination_reason": "",
        "no_gain_rounds": 0,
        "final_answer": "",
        "iteration_logs": [],
    }
