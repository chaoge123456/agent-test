# -*- coding: utf-8 -*-
"""
多知识库元数据、能力描述、检索配置管理
- 知识库注册与元数据管理
- 检索策略配置
- 支持动态注册新知识库
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class RetrievalMode(str, Enum):
    """检索模式枚举"""
    VECTOR = "vector"           # 向量语义检索
    KEYWORD = "keyword"         # 关键词检索
    HYBRID = "hybrid"           # 混合检索


@dataclass
class KnowledgeBaseConfig:
    """单个知识库配置"""
    kb_id: str                              # 知识库唯一标识
    name: str                               # 知识库显示名称
    description: str                        # 知识库能力描述（供路由模块决策）
    domains: List[str] = field(default_factory=list)  # 覆盖领域标签
    retrieval_mode: RetrievalMode = RetrievalMode.VECTOR
    top_k: int = 5                          # 默认检索文档数量
    score_threshold: float = 0.5            # 最低相似度阈值
    enabled: bool = True                    # 是否启用
    extra: Dict[str, Any] = field(default_factory=dict)  # 扩展参数


@dataclass
class RoutingTarget:
    """路由决策结果 - 单个知识库的检索指令"""
    kb_id: str
    queries: List[str]                      # 该知识库使用的检索查询列表
    retrieval_mode: RetrievalMode
    top_k: int
    score_threshold: float
    extra: Dict[str, Any] = field(default_factory=dict)


# 预置知识库注册表
_DEFAULT_KNOWLEDGE_BASES: Dict[str, KnowledgeBaseConfig] = {}


class KnowledgeBaseRegistry:
    """
    知识库注册中心

    职责:
    - 管理知识库元数据
    - 提供知识库查询接口
    - 为路由模块提供决策上下文
    """

    def __init__(self) -> None:
        self._registries: Dict[str, KnowledgeBaseConfig] = {}
        self._retrieval_funcs: Dict[str, Callable] = {}

    def register(
        self,
        config: KnowledgeBaseConfig,
        retrieval_func: Optional[Callable] = None,
    ) -> None:
        """注册知识库"""
        self._registries[config.kb_id] = config
        if retrieval_func is not None:
            self._retrieval_funcs[config.kb_id] = retrieval_func
        logger.info("注册知识库: %s (%s)", config.kb_id, config.name)

    def get(self, kb_id: str) -> KnowledgeBaseConfig:
        """获取知识库配置"""
        if kb_id not in self._registries:
            raise KeyError(f"知识库未注册: {kb_id}")
        return self._registries[kb_id]

    def get_retrieval_func(self, kb_id: str) -> Callable:
        """获取知识库检索函数"""
        if kb_id not in self._retrieval_funcs:
            raise KeyError(f"知识库检索函数未注册: {kb_id}")
        return self._retrieval_funcs[kb_id]

    def list_enabled(self) -> List[KnowledgeBaseConfig]:
        """列出所有已启用的知识库"""
        return [c for c in self._registries.values() if c.enabled]

    def list_all(self) -> List[KnowledgeBaseConfig]:
        """列出所有知识库"""
        return list(self._registries.values())

    def get_descriptions_for_routing(self) -> str:
        """生成供路由LLM决策使用的知识库描述文本"""
        lines: List[str] = []
        for kb in self.list_enabled():
            domains = ", ".join(kb.domains) if kb.domains else "通用"
            lines.append(
                f"- ID: {kb.kb_id} | 名称: {kb.name} | "
                f"领域: {domains} | 描述: {kb.description} | "
                f"检索模式: {kb.retrieval_mode.value} | 默认TopK: {kb.top_k}"
            )
        return "\n".join(lines)

    def unregister(self, kb_id: str) -> None:
        """移除知识库"""
        self._registries.pop(kb_id, None)
        self._retrieval_funcs.pop(kb_id, None)
        logger.info("移除知识库: %s", kb_id)


# 全局注册中心单例
_registry = KnowledgeBaseRegistry()


def get_registry() -> KnowledgeBaseRegistry:
    """获取全局知识库注册中心"""
    return _registry


def register_knowledge_base(
    kb_id: str,
    name: str,
    description: str,
    domains: Optional[List[str]] = None,
    retrieval_mode: RetrievalMode = RetrievalMode.VECTOR,
    top_k: int = 5,
    score_threshold: float = 0.5,
    retrieval_func: Optional[Callable] = None,
    **extra: Any,
) -> None:
    """便捷函数：注册知识库"""
    config = KnowledgeBaseConfig(
        kb_id=kb_id,
        name=name,
        description=description,
        domains=domains or [],
        retrieval_mode=retrieval_mode,
        top_k=top_k,
        score_threshold=score_threshold,
        extra=extra,
    )
    _registry.register(config, retrieval_func)
