# Qwen3 文本模型 Attention Trace：实现说明与使用教程

本文对应 vLLM 0.23.0 与 vLLM-Ascend 0.23.0 中新增的 attention trace MVP。它在 Qwen3 文本模型推理期间采集 post-RoPE Q/K/V，并按 `request_id` 独立保存，供离线重建 attention 和校验 token 对齐。

> 当前版本是 correctness-first 调试实现。采集时会同步执行 device-to-host 拷贝，只适合短请求、抽样请求和数值验证，不能用于生产全量采集。

## 1. 支持范围

| 项目 | 当前支持 |
| --- | --- |
| 模型 | Qwen3 / Qwen3-MoE 纯文本模型 |
| attention | 标准 decoder-only causal full attention |
| 并行 | TP=1，CP=1、DCP=1；建议 PP=1 |
| KV | 非量化 KV，禁用 prefix cache |
| 推理 | 无 speculative decoding，关闭 cudagraph/ACL graph |
| 存储 | 每个完成请求一个独立 trace 目录 |

不支持 Qwen3-VL、Qwen3-Omni、MLA/hybrid attention、sliding window、量化 KV、TP merge、context parallel 和 speculative decoding。关键不支持组合会显式报错。

## 2. 修改代码的核心思路

### 2.1 采集位置

Qwen3 的关键路径为：

```text
hidden states -> qkv projection -> q_norm/k_norm -> RoPE
              -> Attention.forward(q, k, v) -> Ascend attention / KV cache
```

hook 放在 vLLM 的 `Attention.forward` 内部，在 Q/K/V reshape 后、unified attention op 前：

```text
Q: [N, Hq, D]
K: [N, Hkv, D]
V: [N, Hkv, D]
```

这里的 Q/K 已经过 q_norm、k_norm 和 RoPE，因此能直接用于离线恢复线上 `QK^T`；K/V 也尚未变成 paged KV cache 的物理 block layout。这样无需修改 Qwen3 模型定义，且不依赖 NPU cache layout。

改动文件：

- `vllm-0.23.0/vllm/model_executor/layers/attention/attention.py`

上游 vLLM 仅调用 duck-typed `capture_qkv(...)`，不直接 import Ascend 插件，避免硬件耦合。

### 2.2 动态 batch 到 request 的映射

vLLM 会把多个请求拼为扁平 token batch；Attention tensor 的第 `i` 行本身没有 request ID。Ascend V1 model runner 在 forward 前构造 `TraceBatchDescriptor`，记录每个 request 的：

- `flat_start / flat_end`：在扁平 Q/K/V 中的行范围；
- `logical_position`：token 在该请求上下文中的位置；
- `token_id`：对应输入 token ID。

descriptor 通过 forward context 传到 Attention hook，collector 据此把同一个动态 batch 的数据拆分为多个 request 缓冲区。

相关文件：

- `vllm-ascend-0.23.0/vllm_ascend/worker/model_runner_v1.py`
- `vllm-ascend-0.23.0/vllm_ascend/ascend_forward_context.py`

### 2.3 请求结束时独立、原子地写文件

在父 runner 删除已结束 request state 前，Ascend runner 调用 `finalize_request(...)`。collector 根据该请求的 prompt/output token ID 筛选 prediction Q 与可见 K/V，然后：

1. 写入 `.partial` 临时目录；
2. 写入 JSON、safetensors 和索引；
3. 创建 `COMMITTED`；
4. 原子 rename 到最终目录。

离线 reader 只接受存在 `COMMITTED` 的 trace，从而避免读取半写入文件。

核心实现位于 `vllm-ascend-0.23.0/vllm_ascend/attention_trace.py`。

## 3. Token 和 Query 的对齐规则

不要把 `Q(y_t)` 误认为“预测 y_t 的 Q”。对于 prompt 长度 `P`：

```text
Q(position=P-1) -> 第一个输出 y0
Q(position=P)   -> 第二个输出 y1
Q(position=P+1) -> 第三个输出 y2
```

因此第 `t` 个输出的映射是：

```text
query_position  = P - 1 + t
target_position = P + t
```

首个输出使用 prefill 最后一个 query，不是 decode Q。对应关系记录在 `tokens.json` 的 `prediction_records` 中。

最后一个输出 token 通常没有自己的 Q/K/V：它被采样后，正常结束时不会再作为下一次 forward 输入。这是预期行为；如需它的 K/V，后续要加入不采样的 tail replay。

## 4. 保存格式

每个请求一个目录：

```text
<trace-root>/<request-id>-<random>/
  manifest.json
  tokens.json
  tensors/rank-000/
    index.json
    shard-00000.safetensors
  COMMITTED
```

`manifest.json` 保存模型、dtype、head 数、head dim、`1/sqrt(head_dim)` attention scale、采样 layers 与格式版本。`tokens.json` 保存 token ID、position、prediction 映射与每层 tensor 行索引，并保存 `token_piece`、`decoded_text`、`prompt_text`、`output_text` 和完整 `full_text`。token ID + position 仍是对齐真相；明文字段用于展示、检索和人工对比。

safetensors 中的张量为：

```text
layers.<layer>.q: [num_predictions, Hq, D]
layers.<layer>.k: [num_kv_tokens, Hkv, D]
layers.<layer>.v: [num_kv_tokens, Hkv, D]
```

## 5. NPU 环境部署与启动

同步以下文件到目标机的两套 0.23.0 源码，并按既有方式重新安装/启动：

- `vllm-0.23.0/vllm/model_executor/layers/attention/attention.py`
- `vllm-ascend-0.23.0/vllm_ascend/attention_trace.py`
- `vllm-ascend-0.23.0/vllm_ascend/ascend_forward_context.py`
- `vllm-ascend-0.23.0/vllm_ascend/worker/model_runner_v1.py`
- `vllm-ascend-0.23.0/vllm_ascend/envs.py`

写入 token 明文时，collector 会按模型 ID 懒加载同源 Hugging Face tokenizer；目标机应已安装 `transformers`，且能访问模型目录或本地 tokenizer 缓存。

设置环境变量（bash 示例）：

```bash
export VLLM_ASCEND_ATTENTION_TRACE_DIR=/data/attention-traces
export VLLM_ASCEND_ATTENTION_TRACE_LAYERS=0,35
```

第二个变量必填，格式为逗号分隔的 decoder layer index。建议先采首层、末层；使用短 prompt、`temperature=0`、生成 2 至 4 个 token 验证成功后再增加 layer 数。

同时确保启动配置满足：TP=1、CP/DCP=1、关闭 prefix caching、关闭 speculative decoding、关闭 graph replay。请求完成后检查：

```bash
find /data/attention-traces -maxdepth 2 -name COMMITTED
```

每个完成 request 应对应一个 `COMMITTED` 文件。

## 6. 离线读取与重建

```python
from vllm_ascend.attention_trace import AttentionTraceStore

trace = AttentionTraceStore().open("/data/attention-traces/<trace-id>")
q = trace.tensor(layer=35, component="q")
k = trace.tensor(layer=35, component="k")
v = trace.tensor(layer=35, component="v")
records = trace.tokens["prediction_records"]
positions = trace.tokens["layers"]["35"]["kv_positions"]
prompt_text = trace.tokens["prompt_text"]
output_text = trace.tokens["output_text"]
```

Qwen3 的 GQA 重建示例：

```python
num_q = trace.manifest["attention"]["num_attention_heads"]
num_kv = trace.manifest["attention"]["num_kv_heads"]
kv_head = query_head // (num_q // num_kv)

scores = (q[prediction_index, query_head].float()
          @ k[:, kv_head].float().T) * trace.manifest["attention"]["scale"]
probabilities = scores.softmax(dim=-1)
readout = probabilities @ v[:, kv_head].float()
```

使用 `positions` 和 `tokens.json.sequence` 将 `probabilities` 映射回 prompt/output token。不要默认平均所有 layer/head；应先保留 layer/head 维度。

## 7. 验证流程

1. 检查目录存在 `COMMITTED`，并核对 manifest 的模型、dtype、head 数。
2. 检查每条 prediction 满足 `query_position=P-1+t`，且 target token ID 与服务返回 token 一致。
3. 离线计算 QK、softmax 和 `A@V`，检查概率和为 1、无 NaN/Inf。
4. 用相同权重的 eager Qwen3 做 teacher-forced forward，在 q_norm/k_norm 和 RoPE 后抓取 reference Q/K/V，逐 layer/head/position 比较。
5. 对同一 `temperature=0` 请求对比 trace on/off 输出 token；二者应一致。

NPU 融合算子和 eager PyTorch 可能有微小浮点差异，应以 BF16/FP16 数值容差比较，不要求 bitwise 相同。

## 8. 执行链路

```mermaid
flowchart TD
  A[Scheduler 动态 batch] --> B[Ascend ModelRunner]
  B --> C[TraceBatchDescriptor]
  C --> D[Forward Context]
  D --> E[Qwen3 q_norm/k_norm + RoPE]
  E --> F[Attention.forward post-RoPE Q/K/V]
  F --> G[按 request 切分并收集]
  F --> H[正常 Ascend attention / KV cache]
  G --> I[请求结束 finalize]
  I --> J[safetensors + JSON 原子落盘]
  J --> K[离线 QK/softmax/AV 分析]
```

## 9. 后续扩展建议

先在 NPU 上完成 TP=1 reference-forward 校验，再逐步加入：异步 pinned-host writer、采样策略、tail replay、TP rank merge、prefix-cache logical KV 恢复、chunked prefill、speculative decoding 与 CP。每扩展一项，都应重复第 7 节的数值验证。
