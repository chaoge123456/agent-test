# Copyright (c) 2026 Huawei Technologies Co., Ltd. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.

"""Request-scoped Qwen3 attention trace collection.

This module intentionally does not depend on an Ascend attention kernel.  The
upstream ``Attention`` wrapper calls the collector with post-RoPE Q/K/V while
the Ascend model runner supplies the request ownership of flat batch rows.
"""

from __future__ import annotations

import json
import re
import uuid
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence

import torch


_LAYER_INDEX_RE = re.compile(r"(?:^|\.)layers\.(\d+)(?:\.|$)")
_FORMAT_NAME = "attention-trace"
_FORMAT_VERSION = 1


@dataclass(frozen=True)
class RequestSlice:
    """Ownership of a contiguous range in one model forward batch."""

    request_id: str
    flat_start: int
    flat_end: int
    positions: tuple[int, ...]
    token_ids: tuple[int, ...]

    def __post_init__(self) -> None:
        if self.flat_end - self.flat_start != len(self.positions):
            raise ValueError("RequestSlice positions do not match flat range.")
        if len(self.token_ids) != len(self.positions):
            raise ValueError("RequestSlice token_ids do not match positions.")


@dataclass(frozen=True)
class TraceBatchDescriptor:
    """Request ownership for the token-major tensors passed to Attention."""

    forward_id: int
    request_slices: tuple[RequestSlice, ...]

    @property
    def num_rows(self) -> int:
        return sum(item.flat_end - item.flat_start for item in self.request_slices)


@dataclass(frozen=True)
class TraceCaptureConfig:
    """Configuration for the debug-only synchronous trace collector."""

    output_dir: Path
    layers: frozenset[int]
    model_id: str
    model_revision: str | None
    num_layers: int
    num_attention_heads: int
    num_kv_heads: int
    head_dim: int
    dtype: str
    tp_size: int = 1
    tp_rank: int = 0

    @classmethod
    def from_values(
        cls,
        *,
        output_dir: str | None,
        raw_layers: str | None,
        model_id: str,
        model_revision: str | None,
        num_layers: int,
        num_attention_heads: int,
        num_kv_heads: int,
        head_dim: int,
        dtype: str,
        tp_size: int,
        tp_rank: int,
    ) -> "TraceCaptureConfig | None":
        """Create a config from centrally managed Ascend environment values."""
        if not output_dir:
            return None
        if not raw_layers:
            raise ValueError(
                "VLLM_ASCEND_ATTENTION_TRACE_LAYERS is required when attention "
                "tracing is enabled (for example: '0,35')."
            )
        try:
            layers = frozenset(int(value.strip()) for value in raw_layers.split(","))
        except ValueError as exc:
            raise ValueError(
                "VLLM_ASCEND_ATTENTION_TRACE_LAYERS must be comma-separated "
                "integer layer indices."
            ) from exc
        if not layers or min(layers) < 0 or max(layers) >= num_layers:
            raise ValueError("Attention trace layer indices are outside the model range.")
        return cls(
            output_dir=Path(output_dir),
            layers=layers,
            model_id=model_id,
            model_revision=model_revision,
            num_layers=num_layers,
            num_attention_heads=num_attention_heads,
            num_kv_heads=num_kv_heads,
            head_dim=head_dim,
            dtype=dtype,
            tp_size=tp_size,
            tp_rank=tp_rank,
        )


@dataclass
class _Chunk:
    positions: tuple[int, ...]
    token_ids: tuple[int, ...]
    q: torch.Tensor
    k: torch.Tensor | None
    v: torch.Tensor | None


class AttentionTraceCollector:
    """Accumulates rank-local, request-scoped post-RoPE Q/K/V tensors.

    The first implementation is deliberately synchronous and debug-only. It
    copies tensors to host in ``capture_qkv`` so it must be enabled only for
    sampled requests during correctness validation.
    """

    def __init__(
        self,
        config: TraceCaptureConfig,
        token_text_decoder: Callable[[Sequence[int], int], dict[str, Any]] | None = None,
    ) -> None:
        self.config = config
        self._token_text_decoder = token_text_decoder
        self._tokenizer: Any | None = None
        self._chunks: dict[str, dict[int, list[_Chunk]]] = defaultdict(
            lambda: defaultdict(list)
        )
        self._forward_id = 0

    @property
    def enabled(self) -> bool:
        return True

    def next_batch(
        self,
        request_ids: Sequence[str],
        num_scheduled_tokens: Sequence[int],
        positions: Sequence[int],
        token_ids: Sequence[int],
    ) -> TraceBatchDescriptor:
        """Build a descriptor matching the flat token dimension of a forward."""
        if len(request_ids) != len(num_scheduled_tokens):
            raise ValueError("request_ids and num_scheduled_tokens must have equal length.")
        if len(positions) != len(token_ids):
            raise ValueError("positions and token_ids must have equal length.")
        offset = 0
        request_slices: list[RequestSlice] = []
        for request_id, count in zip(request_ids, num_scheduled_tokens, strict=True):
            end = offset + int(count)
            request_slices.append(
                RequestSlice(
                    request_id=request_id,
                    flat_start=offset,
                    flat_end=end,
                    positions=tuple(int(value) for value in positions[offset:end]),
                    token_ids=tuple(int(value) for value in token_ids[offset:end]),
                )
            )
            offset = end
        if offset != len(positions):
            raise ValueError("Batch row count does not match scheduled-token counts.")
        self._forward_id += 1
        return TraceBatchDescriptor(self._forward_id, tuple(request_slices))

    def capture_qkv(
        self,
        *,
        layer_name: str,
        q: torch.Tensor,
        k: torch.Tensor | None,
        v: torch.Tensor | None,
        batch: TraceBatchDescriptor,
    ) -> None:
        """Capture post-RoPE tensors emitted by one Attention layer."""
        layer_index = self._parse_layer_index(layer_name)
        if layer_index not in self.config.layers:
            return
        if q.shape[0] < batch.num_rows:
            raise ValueError("Attention Q tensor is shorter than trace batch rows.")
        if k is not None and k.shape[0] < batch.num_rows:
            raise ValueError("Attention K tensor is shorter than trace batch rows.")
        if v is not None and v.shape[0] < batch.num_rows:
            raise ValueError("Attention V tensor is shorter than trace batch rows.")

        for item in batch.request_slices:
            row_slice = slice(item.flat_start, item.flat_end)
            self._chunks[item.request_id][layer_index].append(
                _Chunk(
                    positions=item.positions,
                    token_ids=item.token_ids,
                    q=q[row_slice].detach().to("cpu").contiguous(),
                    k=None
                    if k is None
                    else k[row_slice].detach().to("cpu").contiguous(),
                    v=None
                    if v is None
                    else v[row_slice].detach().to("cpu").contiguous(),
                )
            )

    def finalize_request(
        self,
        request_id: str,
        *,
        prompt_token_ids: Sequence[int],
        output_token_ids: Sequence[int],
        status: str = "complete",
    ) -> Path | None:
        """Write one request atomically and release its in-memory trace."""
        request_chunks = self._chunks.pop(request_id, None)
        if not request_chunks:
            return None
        if status != "complete":
            return self._write_incomplete(request_id, status)

        prompt_len = len(prompt_token_ids)
        output_len = len(output_token_ids)
        if prompt_len == 0:
            raise ValueError("Attention tracing requires at least one prompt token.")
        final_kv_position = prompt_len + output_len - 2
        query_positions = set(range(prompt_len - 1, prompt_len + output_len - 1))

        trace_id = f"{request_id}-{uuid.uuid4().hex[:12]}"
        final_dir = self.config.output_dir / trace_id
        partial_dir = self.config.output_dir / f".{trace_id}.partial"
        partial_dir.mkdir(parents=True, exist_ok=False)
        tensors_dir = partial_dir / "tensors" / f"rank-{self.config.tp_rank:03d}"
        tensors_dir.mkdir(parents=True)

        tensor_map: dict[str, torch.Tensor] = {}
        layer_index: dict[str, dict[str, Any]] = {}
        prediction_records: list[dict[str, int | bool]] = []
        for layer, chunks in sorted(request_chunks.items()):
            positions, token_ids, q, k, v = self._concat_chunks(chunks)
            q_rows = [index for index, position in enumerate(positions) if position in query_positions]
            kv_rows = [
                index
                for index, position in enumerate(positions)
                if position <= final_kv_position
            ]
            tensor_map[f"layers.{layer}.q"] = q[q_rows]
            if k is not None:
                tensor_map[f"layers.{layer}.k"] = k[kv_rows]
            if v is not None:
                tensor_map[f"layers.{layer}.v"] = v[kv_rows]
            layer_index[str(layer)] = {
                "q_positions": [positions[index] for index in q_rows],
                "kv_positions": [positions[index] for index in kv_rows],
                "q_token_ids": [token_ids[index] for index in q_rows],
                "kv_token_ids": [token_ids[index] for index in kv_rows],
            }
            if not prediction_records:
                q_row_for_position = {
                    positions[index]: compact_index
                    for compact_index, index in enumerate(q_rows)
                }
                prediction_records = [
                    {
                        "prediction_index": prediction_index,
                        "query_position": prompt_len - 1 + prediction_index,
                        "target_position": prompt_len + prediction_index,
                        "target_token_id": int(target_token_id),
                        "query_tensor_row": q_row_for_position[
                            prompt_len - 1 + prediction_index
                        ],
                        "accepted": True,
                    }
                    for prediction_index, target_token_id in enumerate(output_token_ids)
                    if prompt_len - 1 + prediction_index in q_row_for_position
                ]

        self._save_safetensors(tensor_map, tensors_dir / "shard-00000.safetensors")
        tokens = list(prompt_token_ids) + list(output_token_ids)
        token_text = self._decode_token_text(tokens, prompt_len)
        token_payload = {
            "sequence": [
                {
                    "logical_position": position,
                    "token_id": int(token_id),
                    "role": "prompt" if position < prompt_len else "output",
                    "token_piece": token_text["token_pieces"][position],
                    "decoded_text": token_text["decoded_tokens"][position],
                }
                for position, token_id in enumerate(tokens)
            ],
            "prompt_text": token_text["full_text"]["prompt"],
            "output_text": token_text["full_text"]["output"],
            "full_text": token_text["full_text"]["sequence"],
            "prediction_records": prediction_records,
            "layers": layer_index,
        }
        self._write_json(partial_dir / "tokens.json", token_payload)
        self._write_json(
            tensors_dir / "index.json",
            {"shards": [{"file": "shard-00000.safetensors", "tensors": sorted(tensor_map)}]},
        )
        self._write_json(
            partial_dir / "manifest.json",
            self._manifest(request_id, trace_id, prompt_len, output_len, status),
        )
        (partial_dir / "COMMITTED").touch()
        partial_dir.replace(final_dir)
        return final_dir

    def _write_incomplete(self, request_id: str, status: str) -> Path:
        trace_id = f"{request_id}-{uuid.uuid4().hex[:12]}"
        output_dir = self.config.output_dir / trace_id
        output_dir.mkdir(parents=True, exist_ok=False)
        self._write_json(output_dir / "manifest.json", self._manifest(request_id, trace_id, 0, 0, status))
        return output_dir

    def _manifest(
        self, request_id: str, trace_id: str, prompt_len: int, output_len: int, status: str
    ) -> dict[str, Any]:
        return {
            "format": _FORMAT_NAME,
            "format_version": _FORMAT_VERSION,
            "trace_id": trace_id,
            "request_id": request_id,
            "status": status,
            "model": {
                "id": self.config.model_id,
                "revision": self.config.model_revision,
            },
            "attention": {
                "kind": "causal_full",
                "qk_position": "post_rope",
                "value_position": "pre_cache",
                "scale": self.config.head_dim ** -0.5,
                "num_layers": self.config.num_layers,
                "num_attention_heads": self.config.num_attention_heads,
                "num_kv_heads": self.config.num_kv_heads,
                "head_dim": self.config.head_dim,
            },
            "parallel": {"tp_size": self.config.tp_size, "tp_rank": self.config.tp_rank},
            "capture": {"layers": sorted(self.config.layers), "synchronous_debug": True},
            "lengths": {"prompt": prompt_len, "output": output_len},
            "dtype": self.config.dtype,
        }

    @staticmethod
    def _concat_chunks(
        chunks: Iterable[_Chunk],
    ) -> tuple[
        list[int], list[int], torch.Tensor, torch.Tensor | None, torch.Tensor | None
    ]:
        ordered = list(chunks)
        positions = [position for chunk in ordered for position in chunk.positions]
        token_ids = [token_id for chunk in ordered for token_id in chunk.token_ids]
        q = torch.cat([chunk.q for chunk in ordered], dim=0)
        k = None
        if not any(chunk.k is None for chunk in ordered):
            k = torch.cat(
                [chunk.k for chunk in ordered if chunk.k is not None], dim=0
            )
        v = None
        if not any(chunk.v is None for chunk in ordered):
            v = torch.cat(
                [chunk.v for chunk in ordered if chunk.v is not None], dim=0
            )
        return positions, token_ids, q, k, v

    @staticmethod
    def _parse_layer_index(layer_name: str) -> int:
        match = _LAYER_INDEX_RE.search(layer_name)
        if match is None:
            raise ValueError(f"Cannot parse a decoder layer index from {layer_name!r}.")
        return int(match.group(1))

    def _decode_token_text(
        self, token_ids: Sequence[int], prompt_len: int
    ) -> dict[str, Any]:
        if self._token_text_decoder is not None:
            return self._token_text_decoder(token_ids, prompt_len)
        if self._tokenizer is None:
            try:
                from transformers import AutoTokenizer
            except ImportError as exc:
                raise RuntimeError(
                    "Attention trace token text requires transformers."
                ) from exc
            self._tokenizer = AutoTokenizer.from_pretrained(
                self.config.model_id,
                revision=self.config.model_revision,
                trust_remote_code=True,
            )
        tokenizer = self._tokenizer
        token_pieces = tokenizer.convert_ids_to_tokens(list(token_ids))
        decoded_tokens = [
            tokenizer.decode(
                [token_id],
                skip_special_tokens=False,
                clean_up_tokenization_spaces=False,
            )
            for token_id in token_ids
        ]
        return {
            "token_pieces": token_pieces,
            "decoded_tokens": decoded_tokens,
            "full_text": {
                "sequence": tokenizer.decode(
                    list(token_ids),
                    skip_special_tokens=False,
                    clean_up_tokenization_spaces=False,
                ),
                "prompt": tokenizer.decode(
                    list(token_ids[:prompt_len]),
                    skip_special_tokens=False,
                    clean_up_tokenization_spaces=False,
                ),
                "output": tokenizer.decode(
                    list(token_ids[prompt_len:]),
                    skip_special_tokens=False,
                    clean_up_tokenization_spaces=False,
                ),
            },
        }

    @staticmethod
    def _save_safetensors(tensors: dict[str, torch.Tensor], path: Path) -> None:
        try:
            from safetensors.torch import save_file
        except ImportError as exc:
            raise RuntimeError("Attention trace writing requires safetensors.") from exc
        save_file(tensors, str(path))

    @staticmethod
    def _write_json(path: Path, payload: Any) -> None:
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


class AttentionTraceStore:
    """Small ATF v1 reader used by offline validation and tests."""

    def open(self, trace_dir: str | Path) -> "AttentionTrace":
        return AttentionTrace(Path(trace_dir))


class AttentionTrace:
    """Loads rank-local Q/K/V tensors from one committed trace directory."""

    def __init__(self, trace_dir: Path) -> None:
        if not (trace_dir / "COMMITTED").is_file():
            raise ValueError(f"Trace is not committed: {trace_dir}")
        self.trace_dir = trace_dir
        self.manifest = json.loads((trace_dir / "manifest.json").read_text(encoding="utf-8"))
        self.tokens = json.loads((trace_dir / "tokens.json").read_text(encoding="utf-8"))

    def tensor(self, layer: int, component: str) -> torch.Tensor:
        if component not in {"q", "k", "v"}:
            raise ValueError("component must be q, k, or v")
        try:
            from safetensors.torch import load_file
        except ImportError as exc:
            raise RuntimeError("Attention trace reading requires safetensors.") from exc
        path = self.trace_dir / "tensors" / "rank-000" / "shard-00000.safetensors"
        return load_file(str(path))[f"layers.{layer}.{component}"]
