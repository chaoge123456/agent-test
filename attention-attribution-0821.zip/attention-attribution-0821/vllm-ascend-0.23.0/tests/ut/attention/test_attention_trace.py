import importlib.util
import sys
from pathlib import Path

import torch


def _load_trace_module():
    module_path = Path(__file__).parents[3] / "vllm_ascend" / "attention_trace.py"
    spec = importlib.util.spec_from_file_location("attention_trace_test", module_path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _fake_token_text(token_ids, prompt_len):
    decoded = [f"token-{token_id}" for token_id in token_ids]
    return {
        "token_pieces": [f"piece-{token_id}" for token_id in token_ids],
        "decoded_tokens": decoded,
        "full_text": {
            "sequence": "|".join(decoded),
            "prompt": "|".join(decoded[:prompt_len]),
            "output": "|".join(decoded[prompt_len:]),
        },
    }


def test_request_scoped_trace_round_trip(tmp_path: Path):
    trace = _load_trace_module()
    config = trace.TraceCaptureConfig(
        output_dir=tmp_path,
        layers=frozenset({0}),
        model_id="Qwen/Qwen3-test",
        model_revision="test",
        num_layers=1,
        num_attention_heads=4,
        num_kv_heads=2,
        head_dim=2,
        dtype="torch.bfloat16",
    )
    collector = trace.AttentionTraceCollector(config, _fake_token_text)
    batch = collector.next_batch(
        request_ids=["request-a", "request-b"],
        num_scheduled_tokens=[3, 2],
        positions=[0, 1, 2, 0, 1],
        token_ids=[10, 11, 12, 20, 21],
    )
    q = torch.arange(5 * 4 * 2, dtype=torch.float32).reshape(5, 4, 2)
    k = torch.arange(5 * 2 * 2, dtype=torch.float32).reshape(5, 2, 2)
    collector.capture_qkv(
        layer_name="model.layers.0.self_attn.attn",
        q=q,
        k=k,
        v=k + 100,
        batch=batch,
    )

    trace_dir = collector.finalize_request(
        "request-a", prompt_token_ids=[10, 11, 12], output_token_ids=[13]
    )
    assert trace_dir is not None
    loaded = trace.AttentionTraceStore().open(trace_dir)
    assert loaded.manifest["lengths"] == {"prompt": 3, "output": 1}
    assert loaded.tokens["prediction_records"] == [
        {
            "prediction_index": 0,
            "query_position": 2,
            "target_position": 3,
            "target_token_id": 13,
            "query_tensor_row": 0,
            "accepted": True,
        }
    ]
    assert torch.equal(loaded.tensor(0, "q"), q[2:3])
    assert torch.equal(loaded.tensor(0, "k"), k[:3])
    assert torch.equal(loaded.tensor(0, "v"), k[:3] + 100)
    assert loaded.tokens["sequence"][0]["token_piece"] == "piece-10"
    assert loaded.tokens["sequence"][3]["decoded_text"] == "token-13"
    assert loaded.tokens["prompt_text"] == "token-10|token-11|token-12"
    assert loaded.tokens["output_text"] == "token-13"


def test_trace_requires_a_query_for_each_output(tmp_path: Path):
    trace = _load_trace_module()
    config = trace.TraceCaptureConfig(
        output_dir=tmp_path,
        layers=frozenset({0}),
        model_id="Qwen/Qwen3-test",
        model_revision=None,
        num_layers=1,
        num_attention_heads=2,
        num_kv_heads=1,
        head_dim=2,
        dtype="torch.float32",
    )
    collector = trace.AttentionTraceCollector(config, _fake_token_text)
    batch = collector.next_batch(
        request_ids=["request-a"],
        num_scheduled_tokens=[2],
        positions=[0, 1],
        token_ids=[10, 11],
    )
    q = torch.zeros(2, 2, 2)
    k = torch.zeros(2, 1, 2)
    collector.capture_qkv(
        layer_name="model.layers.0.self_attn.attn", q=q, k=k, v=k, batch=batch
    )
    trace_dir = collector.finalize_request(
        "request-a", prompt_token_ids=[10, 11], output_token_ids=[12, 13]
    )
    assert trace_dir is not None
    loaded = trace.AttentionTraceStore().open(trace_dir)
    # y1 has no query row because position 2 was not forwarded. The trace
    # remains readable but must not pretend that this prediction was captured.
    assert len(loaded.tokens["prediction_records"]) == 1
