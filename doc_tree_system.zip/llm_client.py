"""LLM client for document tree system.

Provides integration with various LLM providers including DeepSeek, OpenAI, etc.
"""

import json
import logging
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List
import requests

logger = logging.getLogger(__name__)


class BaseLLMClient(ABC):
    """Base class for LLM clients."""
    
    @abstractmethod
    def complete(
        self, 
        prompt: str, 
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> str:
        """
        Get completion from LLM.
        
        Args:
            prompt: Input prompt
            temperature: Sampling temperature
            max_tokens: Maximum tokens to generate
            **kwargs: Additional parameters
            
        Returns:
            Generated text
        """
        pass
    
    @abstractmethod
    def chat_complete(
        self,
        messages: List[Dict[str, str]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> str:
        """
        Get chat completion from LLM.
        
        Args:
            messages: List of message dicts with 'role' and 'content'
            temperature: Sampling temperature
            max_tokens: Maximum tokens to generate
            **kwargs: Additional parameters
            
        Returns:
            Generated text
        """
        pass


class DeepSeekClient(BaseLLMClient):
    """Client for DeepSeek API."""
    
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.deepseek.com",
        model: str = "deepseek-chat",
        default_temperature: float = 0.1,
        default_max_tokens: int = 2000,
        timeout: int = 60,
    ):
        """
        Initialize DeepSeek client.
        
        Args:
            api_key: DeepSeek API key
            base_url: API base URL
            model: Model name
            default_temperature: Default temperature
            default_max_tokens: Default max tokens
            timeout: Request timeout in seconds
        """
        self.api_key = api_key
        self.base_url = base_url.rstrip('/')
        self.model = model
        self.default_temperature = default_temperature
        self.default_max_tokens = default_max_tokens
        self.timeout = timeout
        
        self.headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}"
        }
        
        logger.info(f"DeepSeek client initialized with model: {model}")
    
    def complete(
        self, 
        prompt: str, 
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> str:
        """
        Get completion from DeepSeek.
        
        Args:
            prompt: Input prompt
            temperature: Sampling temperature
            max_tokens: Maximum tokens to generate
            **kwargs: Additional parameters
            
        Returns:
            Generated text
        """
        # Convert prompt to chat format
        messages = [{"role": "user", "content": prompt}]
        return self.chat_complete(messages, temperature, max_tokens, **kwargs)
    
    def chat_complete(
        self,
        messages: List[Dict[str, str]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> str:
        """
        Get chat completion from DeepSeek.
        
        Args:
            messages: List of message dicts with 'role' and 'content'
            temperature: Sampling temperature
            max_tokens: Maximum tokens to generate
            **kwargs: Additional parameters
            
        Returns:
            Generated text
        """
        url = f"{self.base_url}/chat/completions"
        
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature if temperature is not None else self.default_temperature,
            "max_tokens": max_tokens if max_tokens is not None else self.default_max_tokens,
        }
        
        # Add any additional parameters
        payload.update(kwargs)
        
        try:
            logger.debug(f"Sending request to DeepSeek API")
            response = requests.post(
                url,
                headers=self.headers,
                json=payload,
                timeout=self.timeout
            )
            response.raise_for_status()
            
            result = response.json()
            content = result["choices"][0]["message"]["content"]
            
            logger.debug(f"Received response from DeepSeek API")
            return content
        
        except requests.exceptions.RequestException as e:
            logger.error(f"DeepSeek API request failed: {e}")
            raise
        except (KeyError, IndexError) as e:
            logger.error(f"Failed to parse DeepSeek API response: {e}")
            raise


class OpenAIClient(BaseLLMClient):
    """Client for OpenAI API."""
    
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.openai.com/v1",
        model: str = "gpt-4",
        default_temperature: float = 0.1,
        default_max_tokens: int = 2000,
        timeout: int = 60,
    ):
        """
        Initialize OpenAI client.
        
        Args:
            api_key: OpenAI API key
            base_url: API base URL
            model: Model name
            default_temperature: Default temperature
            default_max_tokens: Default max tokens
            timeout: Request timeout in seconds
        """
        self.api_key = api_key
        self.base_url = base_url.rstrip('/')
        self.model = model
        self.default_temperature = default_temperature
        self.default_max_tokens = default_max_tokens
        self.timeout = timeout
        
        self.headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}"
        }
        
        logger.info(f"OpenAI client initialized with model: {model}")
    
    def complete(
        self, 
        prompt: str, 
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> str:
        """Get completion from OpenAI."""
        messages = [{"role": "user", "content": prompt}]
        return self.chat_complete(messages, temperature, max_tokens, **kwargs)
    
    def chat_complete(
        self,
        messages: List[Dict[str, str]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> str:
        """Get chat completion from OpenAI."""
        url = f"{self.base_url}/chat/completions"
        
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature if temperature is not None else self.default_temperature,
            "max_tokens": max_tokens if max_tokens is not None else self.default_max_tokens,
        }
        
        payload.update(kwargs)
        
        try:
            logger.debug(f"Sending request to OpenAI API")
            response = requests.post(
                url,
                headers=self.headers,
                json=payload,
                timeout=self.timeout
            )
            response.raise_for_status()
            
            result = response.json()
            content = result["choices"][0]["message"]["content"]
            
            logger.debug(f"Received response from OpenAI API")
            return content
        
        except requests.exceptions.RequestException as e:
            logger.error(f"OpenAI API request failed: {e}")
            raise
        except (KeyError, IndexError) as e:
            logger.error(f"Failed to parse OpenAI API response: {e}")
            raise


def create_llm_client(
    provider: str = "deepseek",
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    model: Optional[str] = None,
    **kwargs
) -> BaseLLMClient:
    """
    Factory function to create LLM client.
    
    Args:
        provider: Provider name ('deepseek', 'openai')
        api_key: API key
        base_url: Base URL
        model: Model name
        **kwargs: Additional parameters
        
    Returns:
        LLM client instance
    """
    if provider == "deepseek":
        return DeepSeekClient(
            api_key=api_key or "",
            base_url=base_url or "https://api.deepseek.com",
            model=model or "deepseek-chat",
            **kwargs
        )
    elif provider == "openai":
        return OpenAIClient(
            api_key=api_key or "",
            base_url=base_url or "https://api.openai.com/v1",
            model=model or "gpt-4",
            **kwargs
        )
    else:
        raise ValueError(f"Unknown provider: {provider}")