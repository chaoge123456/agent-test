#!/usr/bin/env python3
"""
Example script for processing documents with the Document Tree System.

Usage:
    python process_document.py --input sample_input.json --output result.json
"""

import argparse
import json
import sys
import logging
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from doc_tree_system.pipeline import DocumentTreePipeline, create_pipeline
from doc_tree_system.config.settings import load_settings


def setup_logging(log_level: str = "INFO", log_file: Optional[str] = None):
    """Setup logging configuration."""
    handlers = [logging.StreamHandler(sys.stdout)]
    
    if log_file:
        handlers.append(logging.FileHandler(log_file, encoding='utf-8'))
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=handlers
    )


def load_input_data(input_path: str) -> dict:
    """Load input data from JSON file."""
    with open(input_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def save_output(result: dict, output_path: str, pretty: bool = True):
    """Save output to JSON file."""
    with open(output_path, 'w', encoding='utf-8') as f:
        if pretty:
            json.dump(result, f, ensure_ascii=False, indent=2)
        else:
            json.dump(result, f, ensure_ascii=False)


def main():
    parser = argparse.ArgumentParser(
        description='Process documents with the Document Tree System'
    )
    parser.add_argument(
        '--input', '-i',
        required=True,
        help='Input JSON file path'
    )
    parser.add_argument(
        '--output', '-o',
        required=True,
        help='Output JSON file path'
    )
    parser.add_argument(
        '--config', '-c',
        help='Configuration file path (JSON or YAML)'
    )
    parser.add_argument(
        '--log-level',
        default='INFO',
        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
        help='Logging level'
    )
    parser.add_argument(
        '--log-file',
        help='Log file path'
    )
    parser.add_argument(
        '--pretty', '-p',
        action='store_true',
        default=True,
        help='Pretty print output JSON'
    )
    
    args = parser.parse_args()
    
    # Setup logging
    setup_logging(args.log_level, args.log_file)
    logger = logging.getLogger(__name__)
    
    try:
        # Load input data
        logger.info(f"Loading input from {args.input}")
        input_data = load_input_data(args.input)
        
        # Extract document title and pages
        document_title = input_data.get("document_title")
        pages_data = input_data.get("pages", [])
        
        logger.info(f"Processing document: {document_title}")
        logger.info(f"Total pages: {len(pages_data)}")
        
        # Create pipeline
        logger.info("Initializing pipeline...")
        pipeline = create_pipeline(args.config)
        
        # Process document
        logger.info("Processing document...")
        result = pipeline.process(pages_data, document_title)
        
        # Save output
        if result.success:
            logger.info("Processing successful!")
            output_data = {
                "success": True,
                "document": result.document_tree.to_dict(),
                "stats": result.processing_stats,
            }
            save_output(output_data, args.output, args.pretty)
            logger.info(f"Output saved to {args.output}")
        else:
            logger.error(f"Processing failed: {result.error_message}")
            output_data = {
                "success": False,
                "error": result.error_message,
            }
            save_output(output_data, args.output, args.pretty)
            sys.exit(1)
    
    except Exception as e:
        logger.exception("Unexpected error during processing")
        output_data = {
            "success": False,
            "error": str(e),
        }
        save_output(output_data, args.output, args.pretty)
        sys.exit(1)


if __name__ == "__main__":
    main()