"""
Example: Using DeepSeek API with Document Tree System

This example shows how to integrate DeepSeek LLM with the document tree system.
"""

import json
import logging
from pathlib import Path

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def main():
    """Main example function."""
    
    # DeepSeek API configuration
    # 使用您提供的API信息
    DEEPSEEK_CONFIG = {
        "api_key": "sk-71345ea7232d4739b41c16dabd51d0b8",
        "model": "deepseek-chat",
        "base_url": "https://api.deepseek.com",
        "temperature": 0.1,
        "max_tokens": 2000,
    }
    
    logger.info("=" * 60)
    logger.info("Document Tree System - DeepSeek Integration Example")
    logger.info("=" * 60)
    
    # Step 1: Create LLM Client
    logger.info("\n[Step 1] Creating DeepSeek LLM Client...")
    
    try:
        from doc_tree_system.llm_client import DeepSeekClient
        
        llm_client = DeepSeekClient(
            api_key=DEEPSEEK_CONFIG["api_key"],
            base_url=DEEPSEEK_CONFIG["base_url"],
            model=DEEPSEEK_CONFIG["model"],
            default_temperature=DEEPSEEK_CONFIG["temperature"],
            default_max_tokens=DEEPSEEK_CONFIG["max_tokens"],
        )
        
        logger.info("✓ DeepSeek client created successfully")
        logger.info(f"  - Model: {DEEPSEEK_CONFIG['model']}")
        logger.info(f"  - Base URL: {DEEPSEEK_CONFIG['base_url']}")
        
    except Exception as e:
        logger.error(f"✗ Failed to create DeepSeek client: {e}")
        return
    
    # Step 2: Test LLM Connection
    logger.info("\n[Step 2] Testing LLM Connection...")
    
    try:
        # Simple test prompt
        test_prompt = "Hello! Please respond with 'DeepSeek API is working correctly.'"
        response = llm_client.complete(test_prompt)
        
        logger.info(f"✓ LLM connection successful")
        logger.info(f"  - Response: {response[:100]}...")
        
    except Exception as e:
        logger.error(f"✗ LLM connection failed: {e}")
        logger.warning("  Continuing without LLM functionality...")
    
    # Step 3: Load Sample Data
    logger.info("\n[Step 3] Loading Sample Document Data...")
    
    try:
        # Load the sample input
        sample_path = Path(__file__).parent / "sample_input.json"
        
        if not sample_path.exists():
            logger.warning(f"Sample file not found: {sample_path}")
            logger.info("  Creating sample data...")
            # Create minimal sample data
            sample_data = {
                "document_title": "示例文档",
                "pages": []
            }
        else:
            with open(sample_path, 'r', encoding='utf-8') as f:
                sample_data = json.load(f)
        
        logger.info(f"✓ Loaded document: {sample_data.get('document_title', 'Unknown')}")
        logger.info(f"  - Pages: {len(sample_data.get('pages', []))}")
        
    except Exception as e:
        logger.error(f"✗ Failed to load sample data: {e}")
        return
    
    # Step 4: Create Pipeline with LLM
    logger.info("\n[Step 4] Creating Document Processing Pipeline...")
    
    try:
        from doc_tree_system.pipeline import DocumentTreePipeline
        from doc_tree_system.config.settings import Settings
        
        # Create settings with LLM configuration
        settings = Settings()
        settings.llm.api_key = DEEPSEEK_CONFIG["api_key"]
        settings.llm.model = DEEPSEEK_CONFIG["model"]
        settings.llm.base_url = DEEPSEEK_CONFIG["base_url"]
        settings.llm.temperature = DEEPSEEK_CONFIG["temperature"]
        settings.llm.max_tokens = DEEPSEEK_CONFIG["max_tokens"]
        settings.llm.use_llm = True
        
        # Create pipeline with LLM client
        pipeline = DocumentTreePipeline(
            settings=settings,
            llm_client=llm_client
        )
        
        logger.info("✓ Pipeline created successfully")
        logger.info(f"  - LLM: {settings.llm.model}")
        logger.info(f"  - Temperature: {settings.llm.temperature}")
        
    except Exception as e:
        logger.error(f"✗ Failed to create pipeline: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return
    
    # Step 5: Process Document
    logger.info("\n[Step 5] Processing Document...")
    
    try:
        result = pipeline.process(
            pages_data=sample_data.get("pages", []),
            document_title=sample_data.get("document_title")
        )
        
        if result.success:
            logger.info("✓ Document processing successful!")
            logger.info(f"  - Stats: {json.dumps(result.processing_stats, indent=2, ensure_ascii=False)}")
            
            # Save output
            output_path = Path(__file__).parent / "output.json"
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(result.document_tree.to_dict(), f, ensure_ascii=False, indent=2)
            
            logger.info(f"  - Output saved to: {output_path}")
            
            # Print tree preview
            logger.info("\n[Document Tree Preview]")
            print_tree_preview(result.document_tree.root)
            
        else:
            logger.error(f"✗ Document processing failed: {result.error_message}")
    
    except Exception as e:
        logger.error(f"✗ Error during document processing: {e}")
        import traceback
        logger.error(traceback.format_exc())
    
    logger.info("\n" + "=" * 60)
    logger.info("Example completed!")
    logger.info("=" * 60)


def print_tree_preview(node, indent=0, max_depth=3):
    """Print a preview of the document tree."""
    if indent > max_depth:
        return
    
    prefix = "  " * indent
    text_preview = node.text[:50] + "..." if len(node.text) > 50 else node.text
    level_info = f"[L{node.level}] " if node.level else ""
    
    print(f"{prefix}{level_info}{node.node_type}: {text_preview}")
    
    for child in node.children:
        print_tree_preview(child, indent + 1, max_depth)


if __name__ == "__main__":
    main()