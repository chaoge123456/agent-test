# Document Tree System - 自动化文档树组织系统

## 系统概述

本系统旨在将扫描版或数字文档（PDF、图片）自动解析为层次化的文档树结构。输入为通过版面分析与OCR模型生成的每页JSON数据（包含元素类别、坐标、文本、阅读顺序等），输出为嵌套的JSON树，反映文档的章节、段落、表格、图片等元素的隶属关系。

## 特性

- **模块化设计**：五个核心模块，职责清晰
- **规则与LLM结合**：平衡准确性与成本
- **跨页元素处理**：智能合并跨页的文本、表格、列表
- **多栏布局支持**：自动检测并校正阅读顺序
- **正文识别**：自动识别文档正文起止页
- **可扩展架构**：支持自定义规则和配置

## 系统架构

### 五个核心模块

1. **预处理与跨页合并 (Preprocessor)**
   - 清洗OCR输出
   - 校正阅读顺序
   - 合并跨页的连续文本块、表格等

2. **正文起止识别 (BodyDetector)**
   - 确定文档正文的起始页和结束页
   - 排除封面、目录、附录等

3. **页面内层级构建 (PageTreeBuilder)**
   - 对每一页使用规则和LLM生成局部树结构
   - 处理标题层级、段落归属

4. **全局树整合 (GlobalTreeIntegrator)**
   - 将各页局部树增量合并为完整文档树
   - 处理跨页标题、段落归属

5. **后处理与结构化输出**
   - 添加元数据
   - 格式化输出
   - 生成最终JSON

## 安装

```bash
# 克隆仓库
git clone <repository-url>
cd doc_tree_system

# 安装依赖
pip install -r requirements.txt
```

## 使用方法

### 命令行使用

```bash
python -m doc_tree_system.examples.process_document \
    --input examples/sample_input.json \
    --output output.json \
    --config config.yaml
```

### Python API

```python
from doc_tree_system.pipeline import create_pipeline

# 创建pipeline
pipeline = create_pipeline(config_path="config.yaml")

# 准备输入数据
pages_data = [
    {
        "page_index": 0,
        "boxes": [
            {
                "cls_id": 0,
                "label": "paragraph_title",
                "coordinate": [100, 100, 500, 150],
                "box_name": "title_0",
                "page_index": 0,
                "box_id": 0,
                "recognize": "第一章 引言",
                "title_level": 1
            },
            # ... more boxes
        ]
    },
    # ... more pages
]

# 处理文档
result = pipeline.process(pages_data, document_title="示例文档")

if result.success:
    # 获取文档树
    doc_tree = result.document_tree
    
    # 转换为JSON
    json_output = doc_tree.to_json(indent=2)
    print(json_output)
    
    # 获取统计信息
    print(result.processing_stats)
else:
    print(f"Processing failed: {result.error_message}")
```

## 配置

系统支持通过配置文件进行自定义。配置文件可以是JSON或YAML格式。

### 示例配置 (config.yaml)

```yaml
llm:
  model: gpt-4
  temperature: 0.1
  max_tokens: 2000
  use_llm: true

preprocessing:
  filter_header_footer: true
  correct_multi_column: true
  merge_cross_page_text: true
  column_detection_threshold: 0.3

body_detection:
  min_body_pages: 3
  max_cover_pages: 5
  use_llm_for_boundaries: true
  confidence_threshold: 0.7

tree_building:
  rule_confidence_threshold: 0.8
  use_llm_refinement: true
  max_tree_depth: 10

output:
  format: json
  include_bboxes: true
  include_metadata: true
  pretty_print: true
  indent: 2
```

## 输入/输出格式

### 输入格式

输入为每页的JSON数据，包含版面分析和OCR结果：

```json
{
  "document_title": "文档标题",
  "pages": [
    {
      "page_index": 0,
      "width": 1200,
      "height": 1600,
      "boxes": [
        {
          "cls_id": 0,
          "label": "paragraph_title",
          "coordinate": [100, 100, 500, 150],
          "box_name": "title_0",
          "page_index": 0,
          "box_id": 0,
          "recognize": "第一章 引言",
          "title_level": 1
        }
      ]
    }
  ]
}
```

### 输出格式

输出为层次化的JSON树结构：

```json
{
  "document": {
    "node_id": "doc_root",
    "type": "document",
    "text": "文档标题",
    "page_range": [0, 10],
    "children": [
      {
        "node_id": "title_1",
        "type": "title",
        "level": 1,
        "text": "第一章 引言",
        "page_range": [0, 0],
        "children": [
          {
            "node_id": "para_1",
            "type": "paragraph",
            "text": "段落内容...",
            "page_range": [0, 0]
          }
        ]
      }
    ]
  },
  "metadata": {
    "title": "文档标题",
    "total_pages": 11
  }
}
```

## 开发

### 运行测试

```bash
# 运行所有测试
pytest tests/

# 运行特定测试
pytest tests/test_preprocessor.py

# 生成覆盖率报告
pytest --cov=doc_tree_system tests/
```

### 代码质量

```bash
# 代码格式化
black doc_tree_system/

# 代码检查
flake8 doc_tree_system/

# 类型检查
mypy doc_tree_system/
```

## 贡献

欢迎贡献！请阅读 [CONTRIBUTING.md](CONTRIBUTING.md) 了解如何参与项目开发。

## 许可证

本项目采用 MIT 许可证。详见 [LICENSE](LICENSE) 文件。

## 联系方式

- 项目主页: <repository-url>
- 问题反馈: <issue-tracker-url>
- 邮箱: <contact-email>