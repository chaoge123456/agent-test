# 文档树系统 - 快速开始指南

## 环境准备

### 1. 安装Python 3.9+
```bash
python --version  # 确保版本 >= 3.9
```

### 2. 创建虚拟环境
```bash
cd doc_tree_system
python -m venv venv

# Windows
venv\Scripts\activate

# Linux/Mac
source venv/bin/activate
```

### 3. 安装依赖
```bash
pip install -r requirements.txt
```

## 快速使用

### 方式1：使用示例脚本

```bash
# 使用DeepSeek处理示例文档
python examples/use_deepseek.py
```

### 方式2：使用命令行工具

```bash
# 处理单个文档
python examples/process_document.py \
    --input examples/sample_input.json \
    --output output.json
```

### 方式3：在Python代码中使用

```python
from doc_tree_system.pipeline import create_pipeline
import json

# 创建pipeline
pipeline = create_pipeline()

# 准备输入数据
with open('examples/sample_input.json', 'r') as f:
    input_data = json.load(f)

# 处理文档
result = pipeline.process(
    pages_data=input_data['pages'],
    document_title=input_data['document_title']
)

# 输出结果
if result.success:
    print(json.dumps(result.document_tree.to_dict(), 
                    indent=2, ensure_ascii=False))
else:
    print(f"处理失败: {result.error_message}")
```

## 使用DeepSeek LLM

### 1. 配置API密钥

方式1：环境变量
```bash
export DOC_TREE_DEEPSEEK_API_KEY="your-api-key"
```

方式2：配置文件
```yaml
# config/deepseek_config.yaml
llm:
  api_key: "your-api-key"
  model: "deepseek-chat"
```

### 2. 运行示例

```bash
python examples/use_deepseek.py
```

## 开发指南

### 运行测试

```bash
# 运行所有测试
pytest

# 运行特定测试
pytest tests/test_models.py

# 生成覆盖率报告
pytest --cov=doc_tree_system --cov-report=html
```

### 代码格式化

```bash
# 使用black格式化代码
black .

# 使用isort排序导入
isort .
```

### 代码检查

```bash
# 运行flake8
flake8 . --max-line-length=100

# 运行mypy类型检查
mypy .
```

## 常见问题

### Q1: 安装依赖时遇到错误
A: 确保Python版本 >= 3.9，并安装了必要的系统依赖

### Q2: LLM调用失败
A: 检查API密钥是否正确配置，网络是否畅通

### Q3: 内存不足
A: 对于大型文档，可以分批处理或增加系统内存

### Q4: 处理速度慢
A: 考虑使用异步处理、缓存机制或分布式处理

## 下一步

- 阅读 [README.md](README.md) 了解完整功能
- 查看 [OPTIMIZATION_GUIDE.md](OPTIMIZATION_GUIDE.md) 了解优化建议
- 查看 [examples/](examples/) 目录获取更多示例
- 查看 [tests/](tests/) 目录了解测试用例

## 获取帮助

- 提交Issue: https://github.com/chaoge123456/document-tree-system/issues
- 发送邮件: chao3236@gmail.com

---

祝你使用愉快！ 🚀
