"""Core data models for document tree system."""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any, Tuple
from enum import Enum
import json


class ElementType(Enum):
    """Document element types."""
    PARAGRAPH_TITLE = "paragraph_title"
    IMAGE = "image"
    TEXT = "text"
    NUMBER = "number"
    ABSTRACT = "abstract"
    CONTENT = "content"
    FIGURE_TITLE = "figure_title"
    FORMULA = "formula"
    TABLE = "table"
    TABLE_TITLE = "table_title"
    REFERENCE = "reference"
    DOC_TITLE = "doc_title"
    FOOTNOTE = "footnote"
    HEADER = "header"
    ALGORITHM = "algorithm"
    FOOTER = "footer"
    SEAL = "seal"
    CHART_TITLE = "chart_title"
    CHART = "chart"
    FORMULA_NUMBER = "formula_number"
    HEADER_IMAGE = "header_image"
    FOOTER_IMAGE = "footer_image"
    ASIDE_TEXT = "aside_text"


# Mapping from class_id to element type
CLASS_ID_MAPPING = {
    0: ElementType.PARAGRAPH_TITLE,
    1: ElementType.IMAGE,
    2: ElementType.TEXT,
    3: ElementType.NUMBER,
    4: ElementType.ABSTRACT,
    5: ElementType.CONTENT,
    6: ElementType.FIGURE_TITLE,
    7: ElementType.FORMULA,
    8: ElementType.TABLE,
    9: ElementType.TABLE_TITLE,
    10: ElementType.REFERENCE,
    11: ElementType.DOC_TITLE,
    12: ElementType.FOOTNOTE,
    13: ElementType.HEADER,
    14: ElementType.ALGORITHM,
    15: ElementType.FOOTER,
    16: ElementType.SEAL,
    17: ElementType.CHART_TITLE,
    18: ElementType.CHART,
    19: ElementType.FORMULA_NUMBER,
    20: ElementType.HEADER_IMAGE,
    21: ElementType.FOOTER_IMAGE,
    22: ElementType.ASIDE_TEXT,
}


@dataclass
class BoundingBox:
    """Bounding box with coordinates."""
    x1: float
    y1: float
    x2: float
    y2: float
    
    @property
    def width(self) -> float:
        return self.x2 - self.x1
    
    @property
    def height(self) -> float:
        return self.y2 - self.y1
    
    @property
    def center(self) -> Tuple[float, float]:
        return ((self.x1 + self.x2) / 2, (self.y1 + self.y2) / 2)
    
    def to_list(self) -> List[float]:
        return [self.x1, self.y1, self.x2, self.y2]
    
    @classmethod
    def from_list(cls, coords: List[float]) -> "BoundingBox":
        return cls(x1=coords[0], y1=coords[1], x2=coords[2], y2=coords[3])


@dataclass
class PageRange:
    """Page range for cross-page elements."""
    start_page: int
    end_page: int
    
    @property
    def is_cross_page(self) -> bool:
        return self.start_page != self.end_page
    
    @property
    def page_count(self) -> int:
        return self.end_page - self.start_page + 1


@dataclass
class Box:
    """Individual box element from OCR output."""
    cls_id: int
    label: str
    coordinate: BoundingBox
    box_name: str
    page_index: int
    box_id: int
    recognize: str
    title_level: Optional[int] = None
    
    @property
    def element_type(self) -> ElementType:
        return CLASS_ID_MAPPING.get(self.cls_id, ElementType.TEXT)
    
    @property
    def is_title(self) -> bool:
        return self.element_type in [
            ElementType.PARAGRAPH_TITLE,
            ElementType.DOC_TITLE,
            ElementType.TABLE_TITLE,
            ElementType.FIGURE_TITLE,
            ElementType.CHART_TITLE,
        ]
    
    @property
    def is_content(self) -> bool:
        return self.element_type in [
            ElementType.TEXT,
            ElementType.ABSTRACT,
            ElementType.CONTENT,
        ]
    
    @property
    def is_header_footer(self) -> bool:
        return self.element_type in [
            ElementType.HEADER,
            ElementType.FOOTER,
            ElementType.HEADER_IMAGE,
            ElementType.FOOTER_IMAGE,
        ]
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Box":
        """Create Box from dictionary."""
        return cls(
            cls_id=data["cls_id"],
            label=data["label"],
            coordinate=BoundingBox.from_list(data["coordinate"]),
            box_name=data["box_name"],
            page_index=data["page_index"],
            box_id=data["box_id"],
            recognize=data["recognize"],
            title_level=data.get("title_level"),
        )
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert Box to dictionary."""
        return {
            "cls_id": self.cls_id,
            "label": self.label,
            "coordinate": self.coordinate.to_list(),
            "box_name": self.box_name,
            "page_index": self.page_index,
            "box_id": self.box_id,
            "recognize": self.recognize,
            "title_level": self.title_level,
        }


@dataclass
class Page:
    """Page containing multiple boxes."""
    page_index: int
    boxes: List[Box] = field(default_factory=list)
    width: float = 0.0
    height: float = 0.0
    
    @property
    def sorted_boxes(self) -> List[Box]:
        """Get boxes sorted by reading order."""
        return sorted(self.boxes, key=lambda b: b.box_id)
    
    def get_boxes_by_type(self, element_type: ElementType) -> List[Box]:
        """Get boxes of specific type."""
        return [b for b in self.boxes if b.element_type == element_type]


@dataclass
class DocumentElement:
    """Processed document element (cross-page merged)."""
    element_id: str
    element_type: ElementType
    text: str
    bboxes: List[Dict[str, Any]]  # List of {page, coordinate}
    page_range: PageRange
    title_level: Optional[int] = None
    box_ids: List[int] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    is_cross_page: bool = False
    
    @property
    def is_title(self) -> bool:
        return self.element_type in [
            ElementType.PARAGRAPH_TITLE,
            ElementType.DOC_TITLE,
            ElementType.TABLE_TITLE,
            ElementType.FIGURE_TITLE,
            ElementType.CHART_TITLE,
        ]


@dataclass
class TreeNode:
    """Tree node for document structure."""
    node_id: str
    node_type: str  # document, section, paragraph, table, figure, etc.
    level: Optional[int] = None  # For title nodes
    text: str = ""
    page_range: Optional[PageRange] = None
    bboxes: List[Dict[str, Any]] = field(default_factory=list)
    children: List["TreeNode"] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    source_element_id: Optional[str] = None
    
    def add_child(self, child: "TreeNode") -> None:
        """Add child node."""
        self.children.append(child)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = {
            "node_id": self.node_id,
            "type": self.node_type,
            "text": self.text,
        }
        if self.level is not None:
            result["level"] = self.level
        if self.page_range:
            result["page_range"] = [self.page_range.start_page, self.page_range.end_page]
        if self.bboxes:
            result["bboxes"] = self.bboxes
        if self.metadata:
            result["metadata"] = self.metadata
        if self.children:
            result["children"] = [c.to_dict() for c in self.children]
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TreeNode":
        """Create from dictionary."""
        node = cls(
            node_id=data["node_id"],
            node_type=data["type"],
            text=data.get("text", ""),
            level=data.get("level"),
        )
        if "page_range" in data:
            pr = data["page_range"]
            node.page_range = PageRange(pr[0], pr[1])
        if "bboxes" in data:
            node.bboxes = data["bboxes"]
        if "metadata" in data:
            node.metadata = data["metadata"]
        if "children" in data:
            node.children = [cls.from_dict(c) for c in data["children"]]
        return node


@dataclass
class DocumentTree:
    """Complete document tree with metadata."""
    root: TreeNode
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def document_title(self) -> Optional[str]:
        """Get document title."""
        for child in self.root.children:
            if child.node_type == "doc_title":
                return child.text
        return None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "document": self.root.to_dict(),
            "metadata": self.metadata,
        }
    
    def to_json(self, indent: int = 2) -> str:
        """Convert to JSON string."""
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=indent)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DocumentTree":
        """Create from dictionary."""
        return cls(
            root=TreeNode.from_dict(data["document"]),
            metadata=data.get("metadata", {}),
        )
    
    @classmethod
    def from_json(cls, json_str: str) -> "DocumentTree":
        """Create from JSON string."""
        return cls.from_dict(json.loads(json_str))