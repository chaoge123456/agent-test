"""
Main pipeline for document tree construction.

Orchestrates the entire process from OCR output to hierarchical document tree.
"""

import json
import logging
from typing import List, Dict, Any, Optional, Tuple
from pathlib import Path
from dataclasses import dataclass

from .core.models import (
    Box, Page, DocumentElement, TreeNode, DocumentTree, PageRange
)
from .modules.preprocessor import Preprocessor, PreprocessingConfig
from .modules.body_detector import BodyDetector, BodyDetectionConfig
from .modules.page_tree_builder import PageTreeBuilder, PageTreeConfig
from .modules.global_tree_integrator import GlobalTreeIntegrator, IntegrationConfig
from .config.settings import Settings, load_settings


logger = logging.getLogger(__name__)


@dataclass
class PipelineResult:
    """Result of pipeline execution."""
    success: bool
    document_tree: Optional[DocumentTree] = None
    error_message: Optional[str] = None
    processing_stats: Dict[str, Any] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "success": self.success,
            "document_tree": self.document_tree.to_dict() if self.document_tree else None,
            "error_message": self.error_message,
            "processing_stats": self.processing_stats,
        }


class DocumentTreePipeline:
    """Main pipeline for document tree construction."""
    
    def __init__(
        self, 
        settings: Optional[Settings] = None,
        llm_client=None
    ):
        """
        Initialize pipeline.
        
        Args:
            settings: Configuration settings
            llm_client: Optional LLM client for advanced processing
        """
        self.settings = settings or load_settings()
        self.llm_client = llm_client
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Initialize modules
        self._init_modules()
    
    def _init_modules(self):
        """Initialize processing modules."""
        # Preprocessor
        preprocess_config = PreprocessingConfig(
            filter_types=[],  # Will use default
            column_threshold=self.settings.preprocessing.column_detection_threshold,
            merge_text_threshold=0.8,
        )
        self.preprocessor = Preprocessor(preprocess_config)
        
        # Body detector
        body_config = BodyDetectionConfig(
            min_body_pages=self.settings.body_detection.min_body_pages,
            max_cover_pages=self.settings.body_detection.max_cover_pages,
            use_llm_for_boundaries=self.settings.body_detection.use_llm_for_boundaries,
            confidence_threshold=self.settings.body_detection.confidence_threshold,
        )
        self.body_detector = BodyDetector(body_config)
        
        # Page tree builder
        tree_config = PageTreeConfig(
            rule_confidence_threshold=self.settings.tree_building.rule_confidence_threshold,
            use_llm_refinement=self.settings.tree_building.use_llm_refinement,
            max_tree_depth=self.settings.tree_building.max_tree_depth,
            llm_model=self.settings.llm.model,
            llm_temperature=self.settings.llm.temperature,
            llm_max_tokens=self.settings.llm.max_tokens,
        )
        self.page_tree_builder = PageTreeBuilder(tree_config, self.llm_client)
        
        # Global tree integrator
        integration_config = IntegrationConfig(
            text_continuation_threshold=0.7,
            title_similarity_threshold=0.8,
            use_llm_for_boundaries=self.settings.body_detection.use_llm_for_boundaries,
            llm_confidence_threshold=self.settings.body_detection.confidence_threshold,
        )
        self.global_integrator = GlobalTreeIntegrator(integration_config, self.llm_client)
    
    def process(
        self, 
        pages_data: List[Dict[str, Any]],
        document_title: Optional[str] = None
    ) -> PipelineResult:
        """
        Process OCR output and build document tree.
        
        Args:
            pages_data: List of page data from OCR (each containing boxes)
            document_title: Optional document title
            
        Returns:
            PipelineResult containing the document tree or error
        """
        try:
            self.logger.info(f"Starting pipeline processing for {len(pages_data)} pages")
            
            stats = {
                "input_pages": len(pages_data),
                "preprocessing": {},
                "body_detection": {},
                "tree_building": {},
            }
            
            # Step 1: Convert to internal format
            pages = self._convert_input(pages_data)
            
            # Step 2: Preprocessing (filtering, reading order, cross-page merge)
            global_elements = self.preprocessor.process(pages)
            stats["preprocessing"]["output_elements"] = len(global_elements)
            
            # Step 3: Body detection
            body_start, body_end = self.body_detector.detect(pages)
            stats["body_detection"]["start_page"] = body_start
            stats["body_detection"]["end_page"] = body_end
            
            # Filter elements to body range
            body_elements = [
                e for e in global_elements
                if body_start <= e.page_range.start_page <= body_end
            ]
            
            # Step 4: Build page-level trees
            # Group elements by page
            page_element_map: Dict[int, List[DocumentElement]] = {}
            for elem in body_elements:
                page_idx = elem.page_range.start_page
                if page_idx not in page_element_map:
                    page_element_map[page_idx] = []
                page_element_map[page_idx].append(elem)
            
            # Build trees for each page
            page_trees = []
            for page_idx in sorted(page_element_map.keys()):
                page_elems = page_element_map[page_idx]
                tree = self.page_tree_builder.build_tree(
                    page_elems, 
                    page_idx,
                    use_llm=self.settings.tree_building.use_llm_refinement
                )
                page_trees.append(tree)
            
            stats["tree_building"]["page_trees"] = len(page_trees)
            
            # Step 5: Global integration
            document_tree = self.global_integrator.integrate(
                page_trees,
                document_title=document_title
            )
            
            self.logger.info("Pipeline processing complete")
            
            return PipelineResult(
                success=True,
                document_tree=document_tree,
                processing_stats=stats,
            )
        
        except Exception as e:
            self.logger.error(f"Pipeline processing failed: {e}", exc_info=True)
            return PipelineResult(
                success=False,
                error_message=str(e),
            )
    
    def _convert_input(self, pages_data: List[Dict[str, Any]]) -> List[Page]:
        """Convert input data to internal Page format."""
        pages = []
        
        for page_data in pages_data:
            page_index = page_data.get("page_index", len(pages))
            boxes_data = page_data.get("boxes", [])
            
            boxes = []
            for box_data in boxes_data:
                try:
                    box = Box.from_dict(box_data)
                    boxes.append(box)
                except Exception as e:
                    self.logger.warning(f"Failed to parse box: {e}")
            
            page = Page(
                page_index=page_index,
                boxes=boxes,
                width=page_data.get("width", 0),
                height=page_data.get("height", 0),
            )
            pages.append(page)
        
        return pages


def create_pipeline(
    config_path: Optional[str] = None,
    llm_client=None
) -> DocumentTreePipeline:
    """
    Factory function to create a pipeline with optional config.
    
    Args:
        config_path: Path to configuration file
        llm_client: Optional LLM client
        
    Returns:
        Configured DocumentTreePipeline instance
    """
    settings = load_settings(config_path)
    return DocumentTreePipeline(settings, llm_client)