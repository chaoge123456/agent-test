"""
Document Tree System - Automated document tree organization.

This package provides tools to parse scanned or digital documents (PDF, images)
into hierarchical document tree structures.
"""

__version__ = "0.1.0"
__author__ = "Document Tree System"

from .core.models import DocumentTree, TreeNode
from .pipeline import DocumentTreePipeline

__all__ = [
    "DocumentTree",
    "TreeNode", 
    "DocumentTreePipeline",
]