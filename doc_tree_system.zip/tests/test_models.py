"""Tests for core data models."""

import pytest
from doc_tree_system.core.models import (
    BoundingBox, PageRange, Box, Page, DocumentElement,
    TreeNode, DocumentTree, ElementType
)


class TestBoundingBox:
    """Tests for BoundingBox."""
    
    def test_creation(self):
        bbox = BoundingBox(x1=10, y1=20, x2=100, y2=200)
        assert bbox.x1 == 10
        assert bbox.y1 == 20
        assert bbox.x2 == 100
        assert bbox.y2 == 200
    
    def test_properties(self):
        bbox = BoundingBox(x1=10, y1=20, x2=100, y2=200)
        assert bbox.width == 90
        assert bbox.height == 180
        assert bbox.center == (55.0, 110.0)
    
    def test_serialization(self):
        bbox = BoundingBox(x1=10, y1=20, x2=100, y2=200)
        bbox_list = bbox.to_list()
        assert bbox_list == [10, 20, 100, 200]
        
        bbox2 = BoundingBox.from_list(bbox_list)
        assert bbox2.x1 == bbox.x1


class TestPageRange:
    """Tests for PageRange."""
    
    def test_single_page(self):
        pr = PageRange(start_page=0, end_page=0)
        assert not pr.is_cross_page
        assert pr.page_count == 1
    
    def test_cross_page(self):
        pr = PageRange(start_page=0, end_page=5)
        assert pr.is_cross_page
        assert pr.page_count == 6


class TestBox:
    """Tests for Box."""
    
    def test_creation(self):
        box = Box(
            cls_id=0,
            label="paragraph_title",
            coordinate=BoundingBox(100, 100, 500, 150),
            box_name="test_box",
            page_index=0,
            box_id=0,
            recognize="Test Title",
            title_level=1
        )
        
        assert box.cls_id == 0
        assert box.element_type == ElementType.PARAGRAPH_TITLE
        assert box.is_title
        assert not box.is_content
    
    def test_serialization(self):
        box = Box(
            cls_id=2,
            label="text",
            coordinate=BoundingBox(100, 200, 500, 300),
            box_name="text_0",
            page_index=0,
            box_id=1,
            recognize="Some text content",
        )
        
        box_dict = box.to_dict()
        assert box_dict["cls_id"] == 2
        assert box_dict["coordinate"] == [100, 200, 500, 300]


class TestTreeNode:
    """Tests for TreeNode."""
    
    def test_creation(self):
        node = TreeNode(
            node_id="test_node",
            node_type="title",
            level=1,
            text="Test Title"
        )
        
        assert node.node_id == "test_node"
        assert node.node_type == "title"
        assert node.level == 1
        assert node.text == "Test Title"
    
    def test_hierarchy(self):
        root = TreeNode(node_id="root", node_type="document")
        child1 = TreeNode(node_id="child1", node_type="title")
        child2 = TreeNode(node_id="child2", node_type="paragraph")
        
        root.add_child(child1)
        root.add_child(child2)
        
        assert len(root.children) == 2
        assert root.children[0].node_id == "child1"
    
    def test_serialization(self):
        node = TreeNode(
            node_id="test",
            node_type="title",
            level=1,
            text="Test",
            page_range=PageRange(0, 0),
        )
        
        node_dict = node.to_dict()
        assert node_dict["node_id"] == "test"
        assert node_dict["type"] == "title"
        assert node_dict["level"] == 1


class TestDocumentTree:
    """Tests for DocumentTree."""
    
    def test_creation(self):
        root = TreeNode(node_id="root", node_type="document", text="Test Doc")
        doc_tree = DocumentTree(root=root, metadata={"author": "Test"})
        
        assert doc_tree.root.node_id == "root"
        assert doc_tree.metadata["author"] == "Test"
    
    def test_json_serialization(self):
        root = TreeNode(node_id="root", node_type="document")
        child = TreeNode(node_id="child", node_type="title", text="Title")
        root.add_child(child)
        
        doc_tree = DocumentTree(root=root)
        json_str = doc_tree.to_json()
        
        assert "document" in json_str
        assert "root" in json_str
        
        # Test deserialization
        doc_tree2 = DocumentTree.from_json(json_str)
        assert doc_tree2.root.node_id == "root"
        assert len(doc_tree2.root.children) == 1