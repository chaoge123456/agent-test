"""Tests for preprocessor module."""

import pytest
from doc_tree_system.core.models import Box, Page, BoundingBox, ElementType
from doc_tree_system.modules.preprocessor import (
    Preprocessor, PreprocessingConfig
)


class TestPreprocessor:
    """Tests for Preprocessor."""
    
    def test_creation(self):
        config = PreprocessingConfig()
        preprocessor = Preprocessor(config)
        assert preprocessor.config == config
    
    def test_filter_non_content(self):
        config = PreprocessingConfig()
        preprocessor = Preprocessor(config)
        
        # Create test page with header, footer, and content
        boxes = [
            Box(  # Header - should be filtered
                cls_id=13,
                label="header",
                coordinate=BoundingBox(0, 0, 1200, 50),
                box_name="header_0",
                page_index=0,
                box_id=0,
                recognize="Header Text",
            ),
            Box(  # Content - should be kept
                cls_id=2,
                label="text",
                coordinate=BoundingBox(100, 200, 1100, 300),
                box_name="text_0",
                page_index=0,
                box_id=1,
                recognize="Main content text.",
            ),
            Box(  # Footer - should be filtered
                cls_id=15,
                label="footer",
                coordinate=BoundingBox(0, 1550, 1200, 1600),
                box_name="footer_0",
                page_index=0,
                box_id=2,
                recognize="Page 1",
            ),
        ]
        
        page = Page(page_index=0, boxes=boxes, width=1200, height=1600)
        
        # Filter the page
        filtered_pages = preprocessor._filter_non_content([page])
        
        # Check results
        assert len(filtered_pages) == 1
        assert len(filtered_pages[0].boxes) == 1  # Only content box should remain
        assert filtered_pages[0].boxes[0].element_type == ElementType.TEXT
    
    def test_cross_page_text_merge(self):
        config = PreprocessingConfig()
        preprocessor = Preprocessor(config)
        
        # Create two pages with text that should be merged
        page1_boxes = [
            Box(
                cls_id=2,
                label="text",
                coordinate=BoundingBox(100, 100, 1100, 200),
                box_name="text_0",
                page_index=0,
                box_id=0,
                recognize="This is a sentence that continues",
            ),
        ]
        
        page2_boxes = [
            Box(
                cls_id=2,
                label="text",
                coordinate=BoundingBox(100, 100, 1100, 200),
                box_name="text_0",
                page_index=1,
                box_id=0,
                recognize="to the next page without ending.",
            ),
        ]
        
        pages = [
            Page(page_index=0, boxes=page1_boxes, width=1200, height=1600),
            Page(page_index=1, boxes=page2_boxes, width=1200, height=1600),
        ]
        
        # Process pages
        elements = preprocessor.process(pages)
        
        # Check that texts were merged
        assert len(elements) == 1
        assert "continues to the next page" in elements[0].text
        assert elements[0].is_cross_page
        assert elements[0].page_range.start_page == 0
        assert elements[0].page_range.end_page == 1


def test_empty_pages():
    """Test handling of empty pages."""
    config = PreprocessingConfig()
    preprocessor = Preprocessor(config)
    
    # Create empty page
    pages = [Page(page_index=0, boxes=[], width=1200, height=1600)]
    
    # Process should not crash
    elements = preprocessor.process(pages)
    assert len(elements) == 0


def test_single_element():
    """Test processing single element."""
    config = PreprocessingConfig()
    preprocessor = Preprocessor(config)
    
    box = Box(
        cls_id=2,
        label="text",
        coordinate=BoundingBox(100, 100, 1100, 200),
        box_name="text_0",
        page_index=0,
        box_id=0,
        recognize="Single text element.",
    )
    
    pages = [Page(page_index=0, boxes=[box], width=1200, height=1600)]
    elements = preprocessor.process(pages)
    
    assert len(elements) == 1
    assert elements[0].text == "Single text element."