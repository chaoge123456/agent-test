"""File utilities."""

import json
import os
from pathlib import Path
from typing import Any, Union


def save_json(data: Any, path: Union[str, Path], indent: int = 2, ensure_ascii: bool = False) -> None:
    """
    Save data to JSON file.
    
    Args:
        data: Data to save
        path: File path
        indent: JSON indentation
        ensure_ascii: Whether to escape non-ASCII characters
    """
    path = Path(path)
    ensure_dir(path.parent)
    
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=indent, ensure_ascii=ensure_ascii)


def load_json(path: Union[str, Path]) -> Any:
    """
    Load data from JSON file.
    
    Args:
        path: File path
        
    Returns:
        Loaded data
    """
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def ensure_dir(path: Union[str, Path]) -> Path:
    """
    Ensure directory exists.
    
    Args:
        path: Directory path
        
    Returns:
        Path object
    """
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def read_text(path: Union[str, Path], encoding: str = 'utf-8') -> str:
    """
    Read text file.
    
    Args:
        path: File path
        encoding: File encoding
        
    Returns:
        File content
    """
    with open(path, 'r', encoding=encoding) as f:
        return f.read()


def write_text(content: str, path: Union[str, Path], encoding: str = 'utf-8') -> None:
    """
    Write text file.
    
    Args:
        content: Content to write
        path: File path
        encoding: File encoding
    """
    path = Path(path)
    ensure_dir(path.parent)
    
    with open(path, 'w', encoding=encoding) as f:
        f.write(content)