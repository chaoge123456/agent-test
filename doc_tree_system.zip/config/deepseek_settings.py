"""
DeepSeek-specific configuration and utilities.

This module provides DeepSeek-specific configuration classes and helpers.
"""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any
import os


@dataclass
class DeepSeekConfig:
    """DeepSeek-specific configuration."""
    
    # API Configuration
    api_key: str = ""
    model: str = "deepseek-chat"
    base_url: str = "https://api.deepseek.com"
    
    # Generation Parameters
    temperature: float = 0.1
    max_tokens: int = 2000
    top_p: float = 1.0
    frequency_penalty: float = 0.0
    presence_penalty: float = 0.0
    
    # Retry Configuration
    max_retries: int = 3
    retry_delay: float = 1.0
    timeout: float = 60.0
    
    # Feature Flags
    use_streaming: bool = False
    validate_ssl: bool = True
    
    @classmethod
    def from_env(cls) -> "DeepSeekConfig":
        """Create configuration from environment variables."""
        return cls(
            api_key=os.getenv("DOC_TREE_DEEPSEEK_API_KEY", ""),
            model=os.getenv("DOC_TREE_DEEPSEEK_MODEL", "deepseek-chat"),
            base_url=os.getenv("DOC_TREE_DEEPSEEK_BASE_URL", "https://api.deepseek.com"),
            temperature=float(os.getenv("DOC_TREE_DEEPSEEK_TEMPERATURE", "0.1")),
            max_tokens=int(os.getenv("DOC_TREE_DEEPSEEK_MAX_TOKENS", "2000")),
            max_retries=int(os.getenv("DOC_TREE_DEEPSEEK_MAX_RETRIES", "3")),
            timeout=float(os.getenv("DOC_TREE_DEEPSEEK_TIMEOUT", "60.0")),
        )
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DeepSeekConfig":
        """Create configuration from dictionary."""
        # Filter only valid fields
        valid_fields = {k: v for k, v in data.items() if k in cls.__dataclass_fields__}
        return cls(**valid_fields)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        return {
            "api_key": "***" if self.api_key else "",
            "model": self.model,
            "base_url": self.base_url,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "top_p": self.top_p,
            "frequency_penalty": self.frequency_penalty,
            "presence_penalty": self.presence_penalty,
            "max_retries": self.max_retries,
            "retry_delay": self.retry_delay,
            "timeout": self.timeout,
            "use_streaming": self.use_streaming,
            "validate_ssl": self.validate_ssl,
        }
    
    def merge_with_env(self) -> "DeepSeekConfig":
        """Merge with environment variables (env vars take precedence)."""
        env_config = self.from_env()
        
        # Create new config with current values, overridden by env vars
        merged = DeepSeekConfig(
            api_key=env_config.api_key if env_config.api_key else self.api_key,
            model=env_config.model if env_config.model != "deepseek-chat" else self.model,
            base_url=env_config.base_url if env_config.base_url != "https://api.deepseek.com" else self.base_url,
            temperature=env_config.temperature if os.getenv("DOC_TREE_DEEPSEEK_TEMPERATURE") else self.temperature,
            max_tokens=env_config.max_tokens if os.getenv("DOC_TREE_DEEPSEEK_MAX_TOKENS") else self.max_tokens,
            top_p=env_config.top_p if os.getenv("DOC_TREE_DEEPSEEK_TOP_P") else self.top_p,
            frequency_penalty=env_config.frequency_penalty if os.getenv("DOC_TREE_DEEPSEEK_FREQUENCY_PENALTY") else self.frequency_penalty,
            presence_penalty=env_config.presence_penalty if os.getenv("DOC_TREE_DEEPSEEK_PRESENCE_PENALTY") else self.presence_penalty,
            max_retries=env_config.max_retries if os.getenv("DOC_TREE_DEEPSEEK_MAX_RETRIES") else self.max_retries,
            retry_delay=env_config.retry_delay if os.getenv("DOC_TREE_DEEPSEEK_RETRY_DELAY") else self.retry_delay,
            timeout=env_config.timeout if os.getenv("DOC_TREE_DEEPSEEK_TIMEOUT") else self.timeout,
        )
        
        return merged


def get_deepseek_config(
    config_path: Optional[str] = None,
    use_env: bool = True
) -> DeepSeekConfig:
    """
    Get DeepSeek configuration from multiple sources.
    
    Priority order (highest first):
    1. Environment variables
    2. Config file
    3. Default values
    
    Args:
        config_path: Path to YAML/JSON config file
        use_env: Whether to load from environment variables
        
    Returns:
        DeepSeekConfig instance
    """
    # Start with default config
    config = DeepSeekConfig()
    
    # Load from config file if provided
    if config_path:
        import yaml
        from pathlib import Path
        
        path = Path(config_path)
        if path.exists():
            with open(path, 'r', encoding='utf-8') as f:
                if path.suffix == '.json':
                    import json
                    data = json.load(f)
                else:
                    data = yaml.safe_load(f)
            
            # Look for llm section or deepseek section
            if 'llm' in data:
                llm_data = data['llm']
                # Check if it's DeepSeek config
                if llm_data.get('base_url', '').startswith('https://api.deepseek'):
                    config = DeepSeekConfig.from_dict(llm_data)
            elif 'deepseek' in data:
                config = DeepSeekConfig.from_dict(data['deepseek'])
    
    # Override with environment variables if requested
    if use_env:
        config = config.merge_with_env()
    
    return config