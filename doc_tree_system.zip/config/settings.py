"""Configuration settings for document tree system."""

import os
import json
from dataclasses import dataclass, field
from typing import Optional, Dict, Any
from pathlib import Path


@dataclass
class LLMConfig:
    """LLM configuration."""
    model: str = "gpt-4"
    temperature: float = 0.1
    max_tokens: int = 2000
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    use_llm: bool = True


@dataclass
class PreprocessingConfig:
    """Preprocessing configuration."""
    filter_header_footer: bool = True
    correct_multi_column: bool = True
    merge_cross_page_text: bool = True
    merge_cross_page_tables: bool = True
    column_detection_threshold: float = 0.3


@dataclass
class BodyDetectionConfig:
    """Body detection configuration."""
    min_body_pages: int = 3
    max_cover_pages: int = 5
    use_llm_for_boundaries: bool = True
    confidence_threshold: float = 0.7


@dataclass
class TreeBuildingConfig:
    """Tree building configuration."""
    rule_confidence_threshold: float = 0.8
    use_llm_refinement: bool = True
    max_tree_depth: int = 10
    title_patterns_priority: list = field(default_factory=lambda: [
        "chinese_chapter",
        "numeric_decimal",
        "roman_numeral",
        "alphabet",
    ])


@dataclass
class OutputConfig:
    """Output configuration."""
    format: str = "json"  # json, xml, markdown
    include_bboxes: bool = True
    include_metadata: bool = True
    pretty_print: bool = True
    indent: int = 2


@dataclass
class Settings:
    """Main settings container."""
    llm: LLMConfig = field(default_factory=LLMConfig)
    preprocessing: PreprocessingConfig = field(default_factory=PreprocessingConfig)
    body_detection: BodyDetectionConfig = field(default_factory=BodyDetectionConfig)
    tree_building: TreeBuildingConfig = field(default_factory=TreeBuildingConfig)
    output: OutputConfig = field(default_factory=OutputConfig)
    
    # Logging
    log_level: str = "INFO"
    log_file: Optional[str] = None
    
    # Performance
    max_workers: int = 4
    chunk_size: int = 10
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Settings":
        """Create settings from dictionary."""
        return cls(
            llm=LLMConfig(**data.get("llm", {})),
            preprocessing=PreprocessingConfig(**data.get("preprocessing", {})),
            body_detection=BodyDetectionConfig(**data.get("body_detection", {})),
            tree_building=TreeBuildingConfig(**data.get("tree_building", {})),
            output=OutputConfig(**data.get("output", {})),
            log_level=data.get("log_level", "INFO"),
            log_file=data.get("log_file"),
            max_workers=data.get("max_workers", 4),
            chunk_size=data.get("chunk_size", 10),
        )
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert settings to dictionary."""
        return {
            "llm": self.llm.__dict__,
            "preprocessing": self.preprocessing.__dict__,
            "body_detection": self.body_detection.__dict__,
            "tree_building": self.tree_building.__dict__,
            "output": self.output.__dict__,
            "log_level": self.log_level,
            "log_file": self.log_file,
            "max_workers": self.max_workers,
            "chunk_size": self.chunk_size,
        }


def load_settings(config_path: Optional[str] = None) -> Settings:
    """Load settings from file or environment."""
    # Default settings
    settings = Settings()
    
    # Load from file if provided
    if config_path and os.path.exists(config_path):
        with open(config_path, 'r', encoding='utf-8') as f:
            if config_path.endswith('.json'):
                data = json.load(f)
            else:
                # Assume YAML format
                try:
                    import yaml
                    data = yaml.safe_load(f)
                except ImportError:
                    raise ImportError("PyYAML is required for YAML config files")
        
        settings = Settings.from_dict(data)
    
    # Override with environment variables
    if os.getenv("DOC_TREE_LLM_MODEL"):
        settings.llm.model = os.getenv("DOC_TREE_LLM_MODEL")
    
    if os.getenv("DOC_TREE_LLM_API_KEY"):
        settings.llm.api_key = os.getenv("DOC_TREE_LLM_API_KEY")
    
    if os.getenv("DOC_TREE_LOG_LEVEL"):
        settings.log_level = os.getenv("DOC_TREE_LOG_LEVEL")
    
    return settings