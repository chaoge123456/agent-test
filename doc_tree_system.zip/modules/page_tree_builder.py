"""
Page-level tree building module.

Constructs hierarchical tree structure for a single page (or merged page block)
using a combination of rule-based parsing and LLM refinement.
"""

import json
import re
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import logging

from ..core.models import (
    DocumentElement, TreeNode, PageRange, BoundingBox,
    ElementType, Page
)


logger = logging.getLogger(__name__)


@dataclass
class TitlePattern:
    """Pattern for matching and parsing titles."""
    pattern: re.Pattern
    level: int
    pattern_type: str  # 'numeric', 'chinese', 'roman', 'alphabet'


@dataclass
class PageTreeConfig:
    """Configuration for page tree building."""
    # Confidence thresholds
    rule_confidence_threshold: float = 0.8
    llm_correction_threshold: float = 0.6
    
    # Title patterns (ordered by priority)
    title_patterns: List[TitlePattern] = field(default_factory=lambda: [
        # Chinese chapter patterns
        TitlePattern(re.compile(r'^[第]([一二三四五六七八九十百千]+)[章节卷篇]([、.\s]|$)'), 1, 'chinese'),
        # Numeric patterns (1., 1.1, 1.1.1)
        TitlePattern(re.compile(r'^(\d+)\.\s'), 1, 'numeric'),
        TitlePattern(re.compile(r'^(\d+)\.(\d+)\.\s'), 2, 'numeric'),
        TitlePattern(re.compile(r'^(\d+)\.(\d+)\.(\d+)\.?\s'), 3, 'numeric'),
        # Roman numerals
        TitlePattern(re.compile(r'^[IVX]+\.\s'), 1, 'roman'),
        # Alphabet
        TitlePattern(re.compile(r'^[A-Z]\.\s'), 2, 'alphabet'),
    ])
    
    # LLM configuration
    llm_model: str = "gpt-4"
    llm_temperature: float = 0.1
    llm_max_tokens: int = 2000
    
    # Multi-column handling
    max_columns: int = 3


class PageTreeBuilder:
    """Builds hierarchical tree for a single page or page block."""
    
    def __init__(self, config: Optional[PageTreeConfig] = None, llm_client=None):
        self.config = config or PageTreeConfig()
        self.llm_client = llm_client
        self.logger = logging.getLogger(self.__class__.__name__)
    
    def build_tree(
        self, 
        elements: List[DocumentElement],
        page_index: int,
        use_llm: bool = True
    ) -> TreeNode:
        """
        Build tree structure for given elements.
        
        Args:
            elements: List of document elements (already preprocessed)
            page_index: Page index for this tree
            use_llm: Whether to use LLM for refinement
            
        Returns:
            TreeNode representing the page structure
        """
        self.logger.info(f"Building tree for page {page_index} with {len(elements)} elements")
        
        if not elements:
            return TreeNode(
                node_id=f"page_{page_index}",
                node_type="page",
                text="",
                page_range=PageRange(page_index, page_index),
            )
        
        # Step 1: Parse titles and determine levels using rules
        parsed_elements = self._parse_title_levels(elements)
        
        # Step 2: Build initial tree using rules
        root = self._build_tree_by_rules(parsed_elements, page_index)
        
        # Step 3: Refine with LLM if needed and available
        if use_llm and self.llm_client:
            confidence = self._calculate_tree_confidence(root)
            if confidence < self.config.rule_confidence_threshold:
                self.logger.info(f"Tree confidence {confidence:.2f} below threshold, using LLM refinement")
                root = self._refine_with_llm(root, parsed_elements, page_index)
        
        return root
    
    def _parse_title_levels(
        self, 
        elements: List[DocumentElement]
    ) -> List[Tuple[DocumentElement, int, float]]:
        """
        Parse title levels using pattern matching.
        
        Returns:
            List of (element, level, confidence) tuples
        """
        parsed = []
        
        for element in elements:
            if not element.is_title:
                parsed.append((element, 0, 1.0))
                continue
            
            text = element.text.strip()
            level, confidence = self._match_title_pattern(text)
            
            # If OCR provided title_level, use it as a reference
            if element.title_level is not None:
                # Compare with pattern result
                if abs(element.title_level - level) <= 1:
                    # Use OCR level with high confidence
                    level = element.title_level
                    confidence = max(confidence, 0.9)
                else:
                    # Conflict - prefer pattern if confidence is high
                    if confidence < 0.8:
                        level = element.title_level
                        confidence = 0.7
            
            parsed.append((element, level, confidence))
        
        return parsed
    
    def _match_title_pattern(self, text: str) -> Tuple[int, float]:
        """Match title pattern and return (level, confidence)."""
        for pattern in self.config.title_patterns:
            match = pattern.pattern.match(text)
            if match:
                # Calculate confidence based on pattern specificity
                confidence = 0.9
                if pattern.pattern_type == 'numeric':
                    # Check level consistency
                    groups = len(match.groups())
                    if groups == pattern.level:
                        confidence = 0.95
                
                return pattern.level, confidence
        
        # Default to level 1 for unmatched titles
        return 1, 0.5
    
    def _build_tree_by_rules(
        self, 
        parsed_elements: List[Tuple[DocumentElement, int, float]],
        page_index: int
    ) -> TreeNode:
        """Build tree structure using rule-based approach."""
        root = TreeNode(
            node_id=f"page_{page_index}",
            node_type="page",
            text="",
            page_range=PageRange(page_index, page_index),
        )
        
        # Stack to track current path in tree
        # Each entry: (node, level)
        stack: List[Tuple[TreeNode, int]] = [(root, 0)]
        
        for element, level, confidence in parsed_elements:
            node = self._create_node_from_element(
                element, level, f"{page_index}_{len(root.children)}"
            )
            
            # Determine where to attach this node
            if element.is_title:
                # Title node - find appropriate parent based on level
                while stack and stack[-1][1] >= level:
                    stack.pop()
                
                if not stack:
                    # Should not happen, but attach to root
                    root.add_child(node)
                    stack.append((node, level))
                else:
                    parent, parent_level = stack[-1]
                    parent.add_child(node)
                    stack.append((node, level))
            else:
                # Non-title node - attach to current parent
                if not stack:
                    root.add_child(node)
                else:
                    parent, _ = stack[-1]
                    parent.add_child(node)
        
        return root
    
    def _create_node_from_element(
        self, 
        element: DocumentElement, 
        level: int,
        suffix: str
    ) -> TreeNode:
        """Create TreeNode from DocumentElement."""
        node_type = element.element_type.value
        
        # Map element types to node types
        type_mapping = {
            ElementType.PARAGRAPH_TITLE: "title",
            ElementType.DOC_TITLE: "doc_title",
            ElementType.TEXT: "paragraph",
            ElementType.ABSTRACT: "paragraph",
            ElementType.TABLE: "table",
            ElementType.TABLE_TITLE: "table_title",
            ElementType.IMAGE: "figure",
            ElementType.FIGURE_TITLE: "figure_title",
        }
        
        if element.element_type in type_mapping:
            node_type = type_mapping[element.element_type]
        
        return TreeNode(
            node_id=f"node_{suffix}",
            node_type=node_type,
            level=level if element.is_title else None,
            text=element.text,
            page_range=element.page_range,
            bboxes=element.bboxes,
            source_element_id=element.element_id,
            metadata={
                "is_cross_page": element.is_cross_page,
                "title_level": element.title_level,
            }
        )
    
    def _calculate_tree_confidence(self, root: TreeNode) -> float:
        """Calculate overall confidence of the tree structure."""
        # This is a simplified confidence calculation
        # In practice, would use more sophisticated metrics
        
        def check_consistency(node: TreeNode) -> Tuple[int, int]:
            """Check tree consistency. Returns (valid_count, total_count)."""
            valid = 1
            total = 1
            
            prev_level = 0
            for child in node.children:
                if child.node_type == "title":
                    if child.level is not None:
                        # Check level consistency
                        if child.level < prev_level:
                            valid -= 0.5  # Penalize but don't fully invalidate
                        prev_level = child.level
                
                c_valid, c_total = check_consistency(child)
                valid += c_valid
                total += c_total
            
            return valid, total
        
        valid, total = check_consistency(root)
        return valid / total if total > 0 else 0.0
    
    def _refine_with_llm(
        self, 
        root: TreeNode, 
        parsed_elements: List[Tuple[DocumentElement, int, float]],
        page_index: int
    ) -> TreeNode:
        """Refine tree structure using LLM."""
        if not self.llm_client:
            return root
        
        try:
            # Prepare input for LLM
            elements_data = []
            for element, level, confidence in parsed_elements:
                elements_data.append({
                    "id": element.element_id,
                    "type": element.element_type.value,
                    "text": element.text[:100] + "..." if len(element.text) > 100 else element.text,
                    "is_title": element.is_title,
                    "title_level": element.title_level,
                    "predicted_level": level,
                    "confidence": confidence,
                })
            
            # Build prompt
            prompt = self._build_refinement_prompt(elements_data, page_index)
            
            # Call LLM
            response = self.llm_client.complete(prompt)
            
            # Parse response
            refined_structure = self._parse_llm_response(response)
            
            # Rebuild tree from refined structure
            if refined_structure:
                return self._build_tree_from_structure(refined_structure, parsed_elements, page_index)
            
        except Exception as e:
            self.logger.error(f"LLM refinement failed: {e}")
        
        return root
    
    def _build_refinement_prompt(self, elements_data: List[Dict], page_index: int) -> str:
        """Build prompt for LLM tree refinement."""
        prompt = f"""You are a document structure analysis expert. Please analyze the following document elements from page {page_index} and build a hierarchical tree structure.

Elements (in reading order):
```json
{json.dumps(elements_data, ensure_ascii=False, indent=2)}
```

Rules:
1. Title elements should form the hierarchy based on their levels
2. Non-title elements should be attached to the nearest preceding title
3. Levels: 1 = highest (chapter), 2 = section, 3 = subsection, etc.
4. A higher-level title should close all lower-level sections before it

Please output the tree structure in JSON format:
```json
{{
  "root": {{
    "type": "page",
    "children": [
      {{
        "type": "title",
        "level": 1,
        "element_id": "elem_0_0",
        "children": [
          {{
            "type": "paragraph",
            "element_id": "elem_0_1"
          }}
        ]
      }}
    ]
  }}
}}
```

Output only the JSON structure, no additional explanation."""
        
        return prompt
    
    def _parse_llm_response(self, response: str) -> Optional[Dict]:
        """Parse LLM response to extract tree structure."""
        try:
            # Extract JSON from response
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                json_str = json_match.group()
                return json.loads(json_str)
        except Exception as e:
            self.logger.error(f"Failed to parse LLM response: {e}")
        
        return None
    
    def _build_tree_from_structure(
        self, 
        structure: Dict, 
        parsed_elements: List[Tuple[DocumentElement, int, float]],
        page_index: int
    ) -> TreeNode:
        """Build TreeNode from LLM structure."""
        element_map = {e.element_id: e for e, _, _ in parsed_elements}
        
        def build_node(node_data: Dict) -> TreeNode:
            node_type = node_data.get("type", "unknown")
            element_id = node_data.get("element_id")
            level = node_data.get("level")
            
            # Get text from element if available
            text = ""
            if element_id and element_id in element_map:
                text = element_map[element_id].text
            
            node = TreeNode(
                node_id=f"{node_type}_{page_index}_{len(node_data.get('children', []))}",
                node_type=node_type,
                level=level,
                text=text,
            )
            
            # Recursively build children
            for child_data in node_data.get("children", []):
                child_node = build_node(child_data)
                node.add_child(child_node)
            
            return node
        
        root_data = structure.get("root", {})
        return build_node(root_data)