"""
Preprocessing and cross-page merging module.

Handles:
- Non-content element filtering
- Reading order correction for multi-column layouts
- Cross-page element merging (text, tables, lists)
"""

import re
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
import logging

from ..core.models import (
    Box, Page, DocumentElement, PageRange, BoundingBox,
    ElementType, CLASS_ID_MAPPING
)


logger = logging.getLogger(__name__)


@dataclass
class PreprocessingConfig:
    """Configuration for preprocessing."""
    # Elements to filter out
    filter_types: List[ElementType] = field(default_factory=lambda: [
        ElementType.HEADER,
        ElementType.FOOTER,
        ElementType.NUMBER,
        ElementType.HEADER_IMAGE,
        ElementType.FOOTER_IMAGE,
        ElementType.ASIDE_TEXT,
    ])
    
    # Multi-column detection threshold
    column_threshold: float = 0.3  # Minimum width ratio for column separation
    
    # Cross-page text merging
    merge_text_threshold: float = 0.8  # Confidence threshold for merging
    sentence_end_pattern: re.Pattern = field(default_factory=lambda: re.compile(
        r'[。！？.!?;；]\s*$'
    ))
    
    # Cross-page table detection
    table_vertical_gap_threshold: float = 50.0  # Max vertical gap for table continuation
    
    # Page dimension for layout analysis
    page_width: float = 1000.0
    page_height: float = 1400.0


class Preprocessor:
    """Main preprocessor class."""
    
    def __init__(self, config: Optional[PreprocessingConfig] = None):
        self.config = config or PreprocessingConfig()
        self.logger = logging.getLogger(self.__class__.__name__)
    
    def process(self, pages: List[Page]) -> List[DocumentElement]:
        """
        Main preprocessing pipeline.
        
        Args:
            pages: List of pages with boxes
            
        Returns:
            List of processed document elements (merged and ordered)
        """
        self.logger.info(f"Starting preprocessing for {len(pages)} pages")
        
        # Step 1: Filter non-content elements
        filtered_pages = self._filter_non_content(pages)
        self.logger.info(f"After filtering: {sum(len(p.boxes) for p in filtered_pages)} elements")
        
        # Step 2: Correct reading order for multi-column layouts
        reordered_pages = self._correct_reading_order(filtered_pages)
        
        # Step 3: Merge cross-page elements
        merged_elements = self._merge_cross_page_elements(reordered_pages)
        self.logger.info(f"After cross-page merging: {len(merged_elements)} elements")
        
        return merged_elements
    
    def _filter_non_content(self, pages: List[Page]) -> List[Page]:
        """Filter out header, footer, page numbers, etc."""
        filtered_pages = []
        
        for page in pages:
            filtered_boxes = [
                box for box in page.boxes
                if box.element_type not in self.config.filter_types
            ]
            
            # Additional heuristics for footer/header detection by position
            filtered_boxes = self._filter_by_position(filtered_boxes, page.height)
            
            new_page = Page(
                page_index=page.page_index,
                boxes=filtered_boxes,
                width=page.width,
                height=page.height,
            )
            filtered_pages.append(new_page)
        
        return filtered_pages
    
    def _filter_by_position(self, boxes: List[Box], page_height: float) -> List[Box]:
        """Filter boxes by position (header/footer regions)."""
        if page_height <= 0:
            return boxes
        
        header_threshold = page_height * 0.05  # Top 5%
        footer_threshold = page_height * 0.95  # Bottom 5%
        
        filtered = []
        for box in boxes:
            center_y = (box.coordinate.y1 + box.coordinate.y2) / 2
            
            # Skip if in header/footer region and is text
            if box.element_type in [ElementType.TEXT, ElementType.NUMBER]:
                if center_y < header_threshold or center_y > footer_threshold:
                    continue
            
            filtered.append(box)
        
        return filtered
    
    def _correct_reading_order(self, pages: List[Page]) -> List[Page]:
        """Correct reading order for multi-column layouts."""
        corrected_pages = []
        
        for page in pages:
            if not page.boxes:
                corrected_pages.append(page)
                continue
            
            # Detect if multi-column layout
            columns = self._detect_columns(page)
            
            if len(columns) > 1:
                # Reorder boxes by column
                reordered = self._reorder_by_columns(page.boxes, columns)
                page.boxes = reordered
            else:
                # Single column - just sort by box_id
                page.boxes = sorted(page.boxes, key=lambda b: b.box_id)
            
            corrected_pages.append(page)
        
        return corrected_pages
    
    def _detect_columns(self, page: Page) -> List[Tuple[float, float]]:
        """Detect column boundaries in a page."""
        if not page.boxes:
            return []
        
        # Get x coordinates of all boxes
        x_coords = []
        for box in page.boxes:
            if box.element_type in [ElementType.TEXT, ElementType.PARAGRAPH_TITLE]:
                x_coords.append((box.coordinate.x1, box.coordinate.x2))
        
        if not x_coords:
            return [(0, page.width)]
        
        # Simple clustering by x1 positions
        x1_positions = [x[0] for x in x_coords]
        x1_positions.sort()
        
        # Detect gaps between columns
        gaps = []
        for i in range(len(x1_positions) - 1):
            gap = x1_positions[i + 1] - x1_positions[i]
            if gap > page.width * self.config.column_threshold:
                gaps.append((x1_positions[i], x1_positions[i + 1]))
        
        if not gaps:
            return [(0, page.width)]
        
        # Define column boundaries from gaps
        columns = []
        start = 0
        for gap_start, gap_end in gaps:
            columns.append((start, (gap_start + gap_end) / 2))
            start = (gap_start + gap_end) / 2
        columns.append((start, page.width))
        
        return columns
    
    def _reorder_by_columns(self, boxes: List[Box], columns: List[Tuple[float, float]]) -> List[Box]:
        """Reorder boxes by column order."""
        # Assign each box to a column
        box_columns = []
        for box in boxes:
            center_x = (box.coordinate.x1 + box.coordinate.x2) / 2
            for col_idx, (col_start, col_end) in enumerate(columns):
                if col_start <= center_x <= col_end:
                    box_columns.append((box, col_idx, box.coordinate.y1))
                    break
        
        # Sort by column index, then by y position
        box_columns.sort(key=lambda x: (x[1], x[2]))
        
        # Reassign box_ids
        reordered = []
        for new_id, (box, _, _) in enumerate(box_columns):
            box.box_id = new_id
            reordered.append(box)
        
        return reordered
    
    def _merge_cross_page_elements(self, pages: List[Page]) -> List[DocumentElement]:
        """Merge elements that span across pages."""
        elements = []
        current_element = None
        
        for page in pages:
            sorted_boxes = sorted(page.boxes, key=lambda b: b.box_id)
            
            for box in sorted_boxes:
                # Check if this box should be merged with current element
                if current_element and self._should_merge(current_element, box):
                    self._merge_box_to_element(current_element, box)
                else:
                    # Start new element
                    if current_element:
                        elements.append(current_element)
                    current_element = self._create_element_from_box(box)
        
        # Don't forget the last element
        if current_element:
            elements.append(current_element)
        
        return elements
    
    def _should_merge(self, element: DocumentElement, box: Box) -> bool:
        """Determine if box should be merged with current element."""
        # Only merge same types
        if element.element_type != box.element_type:
            return False
        
        # Only merge text elements across pages
        if element.element_type not in [ElementType.TEXT, ElementType.ABSTRACT, ElementType.CONTENT]:
            return False
        
        # Check if current element text ends with sentence terminator
        if self.config.sentence_end_pattern.search(element.text):
            return False
        
        # Check if box is on next page
        if box.page_index != element.page_range.end_page + 1:
            return False
        
        # Check if box starts with lowercase (continuation)
        if box.recognize and box.recognize[0].islower():
            return True
        
        # Check if box doesn't start with a number or uppercase letter
        if box.recognize and not (box.recognize[0].isupper() or box.recognize[0].isdigit()):
            return True
        
        return False
    
    def _merge_box_to_element(self, element: DocumentElement, box: Box) -> None:
        """Merge box into existing element."""
        # Merge text
        if element.text and box.recognize:
            # Add space if needed
            if not element.text.endswith(' ') and not box.recognize.startswith(' '):
                element.text += ' '
            element.text += box.recognize
        elif box.recognize:
            element.text = box.recognize
        
        # Update bboxes
        element.bboxes.append({
            "page": box.page_index,
            "coordinate": box.coordinate.to_list(),
        })
        
        # Update page range
        element.page_range.end_page = max(element.page_range.end_page, box.page_index)
        element.is_cross_page = element.page_range.is_cross_page
        
        # Update box_ids
        element.box_ids.append(box.box_id)
    
    def _create_element_from_box(self, box: Box) -> DocumentElement:
        """Create new document element from box."""
        return DocumentElement(
            element_id=f"elem_{box.page_index}_{box.box_id}",
            element_type=box.element_type,
            text=box.recognize or "",
            bboxes=[{
                "page": box.page_index,
                "coordinate": box.coordinate.to_list(),
            }],
            page_range=PageRange(box.page_index, box.page_index),
            title_level=box.title_level,
            box_ids=[box.box_id],
            metadata={
                "box_name": box.box_name,
                "label": box.label,
            },
            is_cross_page=False,
        )