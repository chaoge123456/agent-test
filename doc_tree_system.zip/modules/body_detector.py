"""
Body content detection module.

Identifies the start and end pages of the main document body,
excluding cover page, table of contents, appendices, etc.
"""

import json
import re
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import logging

from ..core.models import Box, Page, ElementType


logger = logging.getLogger(__name__)


class PageType(Enum):
    """Classification of page types."""
    COVER = "cover"
    TABLE_OF_CONTENTS = "table_of_contents"
    PREFACE = "preface"
    BODY = "body"
    APPENDIX = "appendix"
    REFERENCES = "references"
    INDEX = "index"
    BACK_COVER = "back_cover"
    UNKNOWN = "unknown"


@dataclass
class PageFeatures:
    """Extracted features from a page for classification."""
    page_index: int
    element_count: int = 0
    text_element_count: int = 0
    title_element_count: int = 0
    has_doc_title: bool = False
    has_paragraph_title: bool = False
    toc_indicators: int = 0  # Table of contents indicators
    page_number_position: Optional[str] = None  # 'top', 'bottom', 'none'
    avg_text_length: float = 0.0
    has_chapter_numbering: bool = False
    has_appendix_keywords: bool = False
    has_reference_keywords: bool = False


@dataclass
class BodyDetectionConfig:
    """Configuration for body detection."""
    # Heuristic thresholds
    min_body_pages: int = 3
    max_cover_pages: int = 5
    body_text_density_threshold: float = 0.3
    
    # Keywords for detection
    toc_keywords: List[str] = field(default_factory=lambda: [
        "目录", "contents", "table of contents", "目次",
        "章", "节", "chapter", "section"
    ])
    
    appendix_keywords: List[str] = field(default_factory=lambda: [
        "附录", "appendix", "附", "annex"
    ])
    
    reference_keywords: List[str] = field(default_factory=lambda: [
        "参考文献", "references", "bibliography", "引用"
    ])
    
    preface_keywords: List[str] = field(default_factory=lambda: [
        "前言", "preface", "引言", "introduction", "绪论"
    ])


class BodyDetector:
    """Detects body content start and end pages."""
    
    def __init__(self, config: Optional[BodyDetectionConfig] = None):
        self.config = config or BodyDetectionConfig()
        self.logger = logging.getLogger(self.__class__.__name__)
    
    def detect(self, pages: List[Page]) -> Tuple[int, int]:
        """
        Detect body start and end pages.
        
        Args:
            pages: List of pages
            
        Returns:
            Tuple of (body_start_page, body_end_page)
        """
        if not pages:
            return (0, 0)
        
        self.logger.info(f"Detecting body content in {len(pages)} pages")
        
        # Extract features for all pages
        page_features = [self._extract_features(page) for page in pages]
        
        # Classify pages
        page_types = [self._classify_page(features) for features in page_features]
        
        # Determine body start
        body_start = self._find_body_start(page_features, page_types)
        
        # Determine body end
        body_end = self._find_body_end(page_features, page_types, body_start)
        
        self.logger.info(f"Body content: pages {body_start} to {body_end}")
        
        return (body_start, body_end)
    
    def _extract_features(self, page: Page) -> PageFeatures:
        """Extract features from a page."""
        features = PageFeatures(page_index=page.page_index)
        
        features.element_count = len(page.boxes)
        
        total_text_length = 0
        for box in page.boxes:
            if box.element_type in [ElementType.TEXT, ElementType.ABSTRACT, ElementType.CONTENT]:
                features.text_element_count += 1
                total_text_length += len(box.recognize or "")
            
            if box.element_type == ElementType.PARAGRAPH_TITLE:
                features.title_element_count += 1
                features.has_paragraph_title = True
            
            if box.element_type == ElementType.DOC_TITLE:
                features.has_doc_title = True
            
            # Check for TOC indicators
            text = (box.recognize or "").lower()
            for keyword in self.config.toc_keywords:
                if keyword in text:
                    features.toc_indicators += 1
            
            # Check for appendix keywords
            for keyword in self.config.appendix_keywords:
                if keyword in text:
                    features.has_appendix_keywords = True
            
            # Check for reference keywords
            for keyword in self.config.reference_keywords:
                if keyword in text:
                    features.has_reference_keywords = True
            
            # Check for chapter numbering
            if re.match(r'^\d+\.?\s', text) or re.match(r'^[第卷]\d+[章节]', text):
                features.has_chapter_numbering = True
        
        if features.text_element_count > 0:
            features.avg_text_length = total_text_length / features.text_element_count
        
        return features
    
    def _classify_page(self, features: PageFeatures) -> PageType:
        """Classify a page into a type."""
        # TOC detection
        if features.toc_indicators >= 3 or (
            features.toc_indicators >= 1 and 
            features.element_count < 10 and
            features.text_element_count < 5
        ):
            return PageType.TABLE_OF_CONTENTS
        
        # Cover page detection
        if features.page_index == 0 and (
            features.has_doc_title or
            (features.element_count <= 3 and features.text_element_count <= 2)
        ):
            return PageType.COVER
        
        # Appendix detection
        if features.has_appendix_keywords:
            return PageType.APPENDIX
        
        # References detection
        if features.has_reference_keywords:
            return PageType.REFERENCES
        
        # Preface detection (early pages without chapter numbering)
        if features.page_index < 5 and not features.has_chapter_numbering:
            # Check for preface keywords
            # This is a simplified check - in practice would use more sophisticated detection
            if features.has_paragraph_title and features.element_count < 20:
                return PageType.PREFACE
        
        # Body content
        if features.has_chapter_numbering or features.has_paragraph_title:
            return PageType.BODY
        
        return PageType.UNKNOWN
    
    def _find_body_start(self, features: List[PageFeatures], page_types: List[PageType]) -> int:
        """Find the start page of body content."""
        # Look for first body page
        for i, page_type in enumerate(page_types):
            if page_type == PageType.BODY:
                # Check if this is really body (has chapter numbering)
                if features[i].has_chapter_numbering:
                    return i
                # Or has substantial content
                if features[i].text_element_count >= 3:
                    return i
        
        # If no clear body found, look for transition from TOC/Preface to content
        prev_type = None
        for i, page_type in enumerate(page_types):
            if prev_type in [PageType.TABLE_OF_CONTENTS, PageType.PREFACE] and \
               page_type in [PageType.UNKNOWN, PageType.BODY]:
                return i
            prev_type = page_type
        
        # Fallback: skip first few pages if they look like cover/TOC
        for i, page_type in enumerate(page_types[:self.config.max_cover_pages]):
            if page_type not in [PageType.COVER, PageType.TABLE_OF_CONTENTS]:
                return i
        
        return 0
    
    def _find_body_end(self, features: List[PageFeatures], page_types: List[PageType], 
                       body_start: int) -> int:
        """Find the end page of body content."""
        if body_start >= len(page_types):
            return body_start
        
        # Look for transition to appendix/references
        for i in range(len(page_types) - 1, body_start, -1):
            if page_types[i] in [PageType.APPENDIX, PageType.REFERENCES]:
                # Check if previous page is still body
                if i > 0 and page_types[i-1] == PageType.BODY:
                    return i - 1
                # Otherwise continue looking
        
        # Look for substantial content decrease
        body_pages = [i for i in range(body_start, len(page_types)) 
                     if page_types[i] == PageType.BODY]
        
        if len(body_pages) >= 3:
            # Check last few pages for content decrease
            for i in range(len(body_pages) - 1, max(len(body_pages) - 4, 0), -1):
                page_idx = body_pages[i]
                if features[page_idx].text_element_count < 3:
                    # Check if this pattern continues
                    if i > 0:
                        prev_idx = body_pages[i-1]
                        if features[prev_idx].text_element_count >= 3:
                            return prev_idx
        
        # Default to last body page
        body_pages = [i for i in range(body_start, len(page_types)) 
                     if page_types[i] == PageType.BODY]
        if body_pages:
            return body_pages[-1]
        
        return body_start