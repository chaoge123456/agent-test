"""
Global tree integration module.

Merges page-level trees into a complete document tree.
Handles cross-page title continuation, paragraph归属, and boundary conditions.
"""

import re
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
from collections import deque
import logging

from ..core.models import (
    TreeNode, DocumentTree, PageRange, BoundingBox,
    ElementType, DocumentElement
)


logger = logging.getLogger(__name__)


@dataclass
class IntegrationConfig:
    """Configuration for global tree integration."""
    # Merge thresholds
    text_continuation_threshold: float = 0.7
    title_similarity_threshold: float = 0.8
    table_continuation_threshold: float = 0.6
    
    # Sentence end detection
    sentence_end_pattern: re.Pattern = field(default_factory=lambda: re.compile(
        r'[。！？.!?;；…]\s*$'
    ))
    
    # Maximum depth to prevent excessive nesting
    max_tree_depth: int = 10
    
    # Cross-page merging options
    merge_cross_page_paragraphs: bool = True
    merge_cross_page_tables: bool = True
    merge_cross_page_titles: bool = False  # Usually titles don't merge across pages
    
    # LLM for boundary detection
    use_llm_for_boundaries: bool = True
    llm_confidence_threshold: float = 0.7


class GlobalTreeIntegrator:
    """Integrates page-level trees into global document tree."""
    
    def __init__(self, config: Optional[IntegrationConfig] = None, llm_client=None):
        self.config = config or IntegrationConfig()
        self.llm_client = llm_client
        self.logger = logging.getLogger(self.__class__.__name__)
    
    def integrate(
        self, 
        page_trees: List[TreeNode],
        document_title: Optional[str] = None
    ) -> DocumentTree:
        """
        Integrate page trees into global document tree.
        
        Args:
            page_trees: List of page-level tree roots
            document_title: Optional document title
            
        Returns:
            DocumentTree representing the complete document
        """
        self.logger.info(f"Integrating {len(page_trees)} page trees")
        
        if not page_trees:
            # Return empty document tree
            return DocumentTree(
                root=TreeNode(
                    node_id="doc_root",
                    node_type="document",
                    text=document_title or "",
                ),
                metadata={"title": document_title},
            )
        
        # Create document root
        doc_root = TreeNode(
            node_id="doc_root",
            node_type="document",
            text=document_title or "",
            page_range=PageRange(
                page_trees[0].page_range.start_page if page_trees[0].page_range else 0,
                page_trees[-1].page_range.end_page if page_trees[-1].page_range else 0,
            ),
        )
        
        # Incrementally merge page trees
        for i, page_tree in enumerate(page_trees):
            self.logger.debug(f"Merging page tree {i}")
            doc_root = self._merge_page_tree(doc_root, page_tree, i == 0)
        
        # Create final document tree
        document_tree = DocumentTree(
            root=doc_root,
            metadata={
                "title": document_title,
                "total_pages": len(page_trees),
            },
        )
        
        self.logger.info("Global tree integration complete")
        return document_tree
    
    def _merge_page_tree(
        self, 
        global_root: TreeNode, 
        page_tree: TreeNode,
        is_first_page: bool
    ) -> TreeNode:
        """Merge a page tree into the global tree."""
        if not page_tree.children:
            return global_root
        
        if is_first_page:
            # First page - just add all children
            for child in page_tree.children:
                global_root.add_child(child)
        else:
            # Check for cross-page merging at boundaries
            # Get last leaf of global tree and first element of new page
            last_leaf = self._get_last_leaf(global_root)
            first_new = page_tree.children[0] if page_tree.children else None
            
            if last_leaf and first_new:
                should_merge, merged_node = self._try_merge_boundary(
                    last_leaf, first_new
                )
                
                if should_merge and merged_node:
                    # Replace last leaf with merged node
                    self._replace_last_leaf(global_root, merged_node)
                    # Add remaining children from page_tree
                    for child in page_tree.children[1:]:
                        global_root.add_child(child)
                else:
                    # No merge needed, just add all children
                    for child in page_tree.children:
                        global_root.add_child(child)
            else:
                # No boundary to check, add all children
                for child in page_tree.children:
                    global_root.add_child(child)
        
        return global_root
    
    def _get_last_leaf(self, node: TreeNode) -> Optional[TreeNode]:
        """Get the last leaf node in the tree."""
        if not node.children:
            return node
        return self._get_last_leaf(node.children[-1])
    
    def _replace_last_leaf(self, root: TreeNode, new_node: TreeNode) -> None:
        """Replace the last leaf node with a new node."""
        if not root.children:
            return
        
        # Navigate to the last leaf's parent
        parent = root
        while parent.children[-1].children:
            parent = parent.children[-1]
        
        # Replace last child
        parent.children[-1] = new_node
    
    def _try_merge_boundary(
        self, 
        last_node: TreeNode, 
        first_new: TreeNode
    ) -> Tuple[bool, Optional[TreeNode]]:
        """
        Try to merge boundary nodes across pages.
        
        Returns:
            (should_merge, merged_node)
        """
        # Check node types
        if last_node.node_type != first_new.node_type:
            return False, None
        
        # Handle different types
        if last_node.node_type in ["paragraph", "text"]:
            if not self.config.merge_cross_page_paragraphs:
                return False, None
            
            # Check if last node text ends with sentence terminator
            last_text = last_node.text or ""
            if self.config.sentence_end_pattern.search(last_text):
                return False, None
            
            # Check if first new text starts with lowercase (continuation)
            first_text = first_new.text or ""
            if first_text and first_text[0].islower():
                # Likely continuation
                merged = TreeNode(
                    node_id=last_node.node_id,
                    node_type=last_node.node_type,
                    text=last_text + " " + first_text,
                    page_range=PageRange(
                        last_node.page_range.start_page if last_node.page_range else 0,
                        first_new.page_range.end_page if first_new.page_range else 0,
                    ),
                    bboxes=(last_node.bboxes or []) + (first_new.bboxes or []),
                )
                return True, merged
        
        elif last_node.node_type == "table":
            if not self.config.merge_cross_page_tables:
                return False, None
            
            # Check for table continuation
            # This is a simplified check - would need more sophisticated logic
            # to detect if tables are actually continuations
            return False, None
        
        # Default: don't merge
        return False, None
    
    def _detect_boundaries_with_llm(
        self,
        boundary_context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Use LLM to detect boundaries when rules are ambiguous."""
        if not self.llm_client or not self.config.use_llm_for_boundaries:
            return {"merge": False, "confidence": 0.0}
        
        try:
            prompt = f"""You are analyzing the boundary between two pages in a document.

Previous page last element:
```json
{json.dumps(boundary_context.get('last_element', {}), ensure_ascii=False, indent=2)}
```

Next page first element:
```json
{json.dumps(boundary_context.get('first_element', {}), ensure_ascii=False, indent=2)}
```

Determine if these elements should be merged (e.g., a paragraph that continues across pages).

Rules for merging:
1. Text elements can merge if the previous doesn't end with a sentence terminator (., !, ?, etc.)
2. Text elements can merge if the next starts with a lowercase letter
3. Tables should merge only if they appear to be the same table split across pages
4. Titles should NOT merge across pages

Output your decision in JSON format:
```json
{{
  "merge": true/false,
  "reason": "brief explanation",
  "confidence": 0.0-1.0
}}
```

Output only the JSON."""
            
            response = self.llm_client.complete(prompt)
            
            # Extract JSON
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                result = json.loads(json_match.group())
                return {
                    "merge": result.get("merge", False),
                    "reason": result.get("reason", ""),
                    "confidence": result.get("confidence", 0.0),
                }
        
        except Exception as e:
            self.logger.error(f"LLM boundary detection failed: {e}")
        
        return {"merge": False, "confidence": 0.0}